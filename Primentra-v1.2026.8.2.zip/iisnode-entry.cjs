// CommonJS entry point for iisnode (Model B deployment).
//
// package.json declares "type": "module", so server.js is an ES module. iisnode loads its
// entry point with require(), which cannot load an ES module (it throws ERR_REQUIRE_ESM).
// This CommonJS shim is the entry iisnode runs; it loads server.js via dynamic import()
// instead — import() is available inside CommonJS. iisnode's handler and rewrite rule in
// web.config point at this file, not at server.js directly.
//
// server.js reads process.env.PORT (which iisnode sets to a named pipe) and starts listening
// on it, exactly as it does for a normal TCP port.
import('./server.js').catch((err) => {
  console.error('Primentra failed to start under iisnode:', err);
  process.exit(1);
});
