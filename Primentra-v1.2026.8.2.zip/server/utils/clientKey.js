// Which client a rate limiter should count against.
//
// Express's req.ip is the socket peer, which is correct for a direct install but wrong behind a
// reverse proxy: every request then arrives from 127.0.0.1 (ARR) or over a named pipe (iisnode),
// so all users would share a single bucket and one person mistyping a password could lock out an
// entire organisation.
//
// X-Forwarded-For carries the real client address, but it is attacker-controlled when the request
// comes straight off the network — the service port is reachable on the LAN — so it is trusted
// only when the request demonstrably came from a proxy on this machine: a loopback peer, or no
// peer address at all, which means a named pipe and therefore IIS on this same host.

import { ipKeyGenerator } from 'express-rate-limit';

function isLocalPeer(peer) {
  if (!peer) return true; // named pipe (iisnode) — only reachable from this machine
  return peer === '127.0.0.1' || peer === '::1' || peer === '::ffff:127.0.0.1';
}

export function clientKey(req) {
  const peer = req.socket?.remoteAddress || '';

  // ipKeyGenerator groups an IPv6 address by its /64 prefix; without it a caller with an IPv6
  // range could sidestep the limit by moving one address along.
  if (isLocalPeer(peer)) {
    const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (forwarded) return ipKeyGenerator(forwarded);
  }

  if (peer) return ipKeyGenerator(peer);

  // iisnode without a forwarded address: no client identity is available at all. Counting every
  // request in one bucket would turn the login limiter into a denial-of-service switch, so fall
  // back to the account being addressed — that still throttles brute-forcing a single account.
  const account = String(req.body?.email || req.body?.username || '').toLowerCase();
  return account ? `account:${account}` : 'no-client-address';
}
