import crypto from 'crypto';

/**
 * Hash a password using scrypt with a random salt.
 * Returns "salt:hash" format for storage.
 */
export function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

/**
 * Verify a password against a stored "salt:hash" string.
 */
export function verifyPassword(password, storedHash) {
  if (!storedHash || !storedHash.includes(':')) return false;
  const [salt, hash] = storedHash.split(':');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  const stored = Buffer.from(hash, 'hex');
  const candidate = Buffer.from(derived, 'hex');
  // timingSafeEqual throws on a length mismatch, which a corrupt or truncated stored hash
  // would cause — that must read as "wrong password", not as a 500.
  if (stored.length !== candidate.length) return false;
  return crypto.timingSafeEqual(stored, candidate);
}

/**
 * Generate a cryptographically secure random token (64-char hex string).
 */
export function generateToken() {
  return crypto.randomBytes(32).toString('hex');
}
