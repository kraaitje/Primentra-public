// Input validation helpers

export function requireFields(body, fields) {
  const missing = fields.filter(f => body[f] === undefined || body[f] === null || body[f] === '');
  if (missing.length > 0) {
    const err = new Error(`Missing required fields: ${missing.join(', ')}`);
    err.status = 400;
    throw err;
  }
}

export function requireId(params, name = 'id') {
  const val = parseInt(params[name], 10);
  if (isNaN(val) || val <= 0) {
    const err = new Error(`Invalid ${name}: must be a positive integer`);
    err.status = 400;
    throw err;
  }
  return val;
}

export function optionalInt(value, defaultValue = null) {
  if (value === undefined || value === null || value === '') return defaultValue;
  const parsed = parseInt(value, 10);
  return isNaN(parsed) ? defaultValue : parsed;
}

// Wrap async route handlers to catch errors
export function asyncHandler(fn) {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}
