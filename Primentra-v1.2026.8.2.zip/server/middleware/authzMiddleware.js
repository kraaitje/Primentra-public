/**
 * Authorization middleware shared across routes.
 *
 * requireAdmin — blocks any caller that is not a Primentra administrator.
 * Use on schema-mutation and destructive system routes. Read routes should
 * NOT use this; they rely on per-entity permission checks where applicable.
 */
export function requireAdmin(req, res, next) {
  if (!req.user?.isAdministrator) {
    return res.status(403).json({
      success: false,
      error: { code: 'PERMISSION_DENIED', message: 'Administrator access required.' },
    });
  }
  next();
}
