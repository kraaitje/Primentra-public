import crypto from 'crypto';
import { sessions, getSessionTtlMs } from '../routes/auth.js';
import { execute } from '../db.js';

// Routes that do NOT require authentication.
// Exported so the rate limiter and body-size guard in server.js apply to exactly this set —
// one list, so a new public route cannot be added without also being throttled.
export const PUBLIC_PATHS = [
  '/api/auth',
  '/api/settings',
  '/api/health',
  '/api/test-connection',
  '/api/validate-license',
  '/api/setup-database',
  '/api/trial-status',
  '/api/activate-trial',
];

// Re-verify admin/approval status from DB at most once every 5 minutes per session
const ROLE_CHECK_INTERVAL_MS = 5 * 60 * 1000;

// Cache apiEnabled setting for 30s to avoid a DB hit on every API request
let apiEnabledCache = null;
let apiEnabledCacheAt = 0;
const API_ENABLED_TTL_MS = 30_000;

async function isApiEnabled() {
  const now = Date.now();
  if (apiEnabledCache !== null && now - apiEnabledCacheAt < API_ENABLED_TTL_MS) {
    return apiEnabledCache;
  }
  try {
    const result = await execute('usp_Settings_GetApp');
    const setting = result.recordset?.find(r => r.SettingKey === 'apiEnabled');
    apiEnabledCache = setting?.SettingValue !== 'false';
    apiEnabledCacheAt = Date.now();
    return apiEnabledCache;
  } catch {
    // Fail closed on DB error: serve a stale cached value if we have one,
    // otherwise deny API access rather than leaving the kill switch open.
    return apiEnabledCache !== null ? apiEnabledCache : false;
  }
}

// Invalidate the cache when apiEnabled is toggled via settings
export function invalidateApiEnabledCache() {
  apiEnabledCache = null;
  apiEnabledCacheAt = 0;
}

export async function authMiddleware(req, res, next) {
  // Auth only applies to API routes — frontend files are always public
  if (!req.originalUrl.startsWith('/api/')) {
    return next();
  }

  // Dev mode: skip auth entirely so developers never need to log in
  if (process.env.NODE_ENV === 'development') {
    req.user = { id: 0, email: 'dev@local', displayName: 'Developer', isAdministrator: true, groups: [] };
    return next();
  }

  // Check if this path is public (no auth required)
  const path = req.originalUrl.split('?')[0]; // strip query params
  if (PUBLIC_PATHS.some(p => path === p || path.startsWith(p + '/'))) {
    return next();
  }

  // ── API Key authentication ───────────────────────────────────────────────
  const apiKey = req.headers['x-api-key'];
  if (apiKey) {
    const apiErr = (status, code, message) =>
      res.status(status).json({ success: false, error: { code, message } });

    // Check global kill switch
    if (!(await isApiEnabled())) {
      return apiErr(503, 'API_DISABLED', 'API access is currently disabled.');
    }

    // Hash key with SHA-256
    const hash = crypto.createHash('sha256').update(apiKey).digest('hex');

    let keyRow, roles;
    try {
      const result = await execute('usp_ApiKey_GetByHash', { KeyHash: hash });
      if (!result.recordsets[0]?.length) {
        return apiErr(401, 'INVALID_KEY', 'Invalid API key.');
      }
      keyRow = result.recordsets[0][0];
      roles = result.recordsets[1] || [];
    } catch {
      return apiErr(500, 'INTERNAL_ERROR', 'Authentication failed. Please try again.');
    }

    if (!keyRow.IsActive || !keyRow.UserIsActive) {
      return apiErr(401, 'KEY_DISABLED', 'API key is disabled.');
    }
    if (keyRow.ExpiresAt && new Date(keyRow.ExpiresAt) < new Date()) {
      return apiErr(401, 'KEY_EXPIRED', 'API key has expired.');
    }

    req.user = {
      id: keyRow.UserId,
      email: keyRow.Email,
      displayName: keyRow.DisplayName,
      isAdministrator: roles.some(r => r.IsAdmin),
      roles,
    };

    // Fire-and-forget usage tracking — never blocks the request
    const opMap = { GET: 'R', POST: 'C', PUT: 'U', PATCH: 'U', DELETE: 'D' };
    const operation = opMap[req.method] || 'R';
    execute('usp_ApiKey_RecordUsage', { KeyId: keyRow.KeyId, Operation: operation }).catch(() => {});

    return next();
  }

  // ── Session (Bearer token) authentication ────────────────────────────────
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, error: 'Authentication required.' });
  }

  const token = auth.slice(7);
  const session = sessions.get(token);

  if (!session) {
    return res.status(401).json({ success: false, error: 'Invalid or expired session.' });
  }

  if (session.expiresAt < Date.now()) {
    sessions.delete(token);
    return res.status(401).json({ success: false, error: 'Session expired. Please sign in again.' });
  }

  // Sliding window: reset session expiry on every authenticated request
  session.expiresAt = Date.now() + getSessionTtlMs();

  // Periodically re-verify admin/approval status from DB so revoked rights take effect within 5 minutes
  if (!session.lastRoleCheckAt || Date.now() - session.lastRoleCheckAt > ROLE_CHECK_INTERVAL_MS) {
    try {
      const result = await execute('usp_User_GetById', { Id: session.userId });
      const user = result.recordsets[0]?.[0];
      if (user) {
        session.isAdministrator = !!user.IsAdministrator;
        session.canApprove = !!user.CanApprove;
      }
    } catch { /* keep existing session values on DB error */ }
    session.lastRoleCheckAt = Date.now();
  }

  req.user = {
    id: session.userId,
    email: session.email,
    displayName: session.displayName,
    isAdministrator: !!session.isAdministrator,
    roles: session.roles,
  };

  next();
}
