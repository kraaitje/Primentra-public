import { execute } from '../db.js';

/**
 * Factory: returns Express middleware that checks a single CRUD bit
 * for the entity specified by req.params.entityId.
 *
 * @param {'CanCreate'|'CanRead'|'CanUpdate'|'CanDelete'} requiredBit
 */
const ADMIN_PERMS = { CanCreate: 1, CanRead: 1, CanUpdate: 1, CanDelete: 1, IsModerator: 1 };

export function checkEntityPermission(requiredBit) {
  return async (req, res, next) => {
    try {
      if (req.user?.isAdministrator) {
        req.entityPerms = ADMIN_PERMS;
        return next();
      }

      const entityId = parseInt(req.params.entityId, 10);
      if (!entityId || isNaN(entityId)) {
        return res.status(400).json({ success: false, error: 'Valid entityId is required.' });
      }

      const userId = req.user?.id;
      if (!userId) {
        return res.status(403).json({ success: false, error: { code: 'PERMISSION_DENIED', message: 'Permission check requires authentication.' } });
      }

      const result = await execute('usp_Permission_GetEffective', {
        UserId: userId,
        EntityId: entityId,
      });

      const perms = result.recordset?.[0] || {};
      req.entityPerms = perms;

      if (!perms[requiredBit]) {
        return res.status(403).json({ success: false, error: { code: 'PERMISSION_DENIED', message: 'You do not have permission to perform this action.' } });
      }

      next();
    } catch (err) {
      next(err);
    }
  };
}

/**
 * Factory: returns Express middleware that passes if ANY of the specified
 * CRUD bits is set. Used for save-changes which mixes creates and updates.
 *
 * @param {Array<'CanCreate'|'CanRead'|'CanUpdate'|'CanDelete'>} bits
 */
export function checkEntityPermissionAny(bits) {
  return async (req, res, next) => {
    try {
      if (req.user?.isAdministrator) {
        req.entityPerms = ADMIN_PERMS;
        return next();
      }

      const entityId = parseInt(req.params.entityId, 10);
      if (!entityId || isNaN(entityId)) {
        return res.status(400).json({ success: false, error: 'Valid entityId is required.' });
      }

      const userId = req.user?.id;
      if (!userId) {
        return res.status(403).json({ success: false, error: { code: 'PERMISSION_DENIED', message: 'Permission check requires authentication.' } });
      }

      const result = await execute('usp_Permission_GetEffective', {
        UserId: userId,
        EntityId: entityId,
      });

      const perms = result.recordset?.[0] || {};
      req.entityPerms = perms;

      if (!bits.some(b => !!perms[b])) {
        return res.status(403).json({ success: false, error: { code: 'PERMISSION_DENIED', message: 'You do not have permission to perform this action.' } });
      }

      next();
    } catch (err) {
      next(err);
    }
  };
}
