import crypto from 'crypto';
import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'fs';
import { execSync } from 'child_process';
import os from 'os';

// Trial duration
const TRIAL_DAYS = 60;

// Storage locations — cryptic names that blend with Windows system data
const REGISTRY_KEY = 'HKLM\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SysprepInfo';
const REGISTRY_VALUE = 'DeviceToken';
const REGISTRY_SECRET_VALUE = 'DeviceMetadataHash';
const HIDDEN_DIR = 'C:\\ProgramData\\Microsoft\\DeviceSync';
const HIDDEN_FILE = HIDDEN_DIR + '\\dmrchk.dat';
const SECRET_FILE = HIDDEN_DIR + '\\dmrchk.key';

// Per-installation HMAC secret — generated once, stored persistently
// Falls back to env var, then to a derived key from MachineGuid
function getTrialSecret() {
  if (process.env.PRIMENTRA_TRIAL_SECRET) return process.env.PRIMENTRA_TRIAL_SECRET;

  // Try to read from hidden file first (fastest)
  try {
    if (existsSync(SECRET_FILE)) {
      const secret = readFileSync(SECRET_FILE, 'utf-8').trim();
      if (secret.length >= 32) return secret;
    }
  } catch { /* fall through */ }

  // Try to read from registry
  try {
    const raw = execSync(
      `reg query "${REGISTRY_KEY}" /v ${REGISTRY_SECRET_VALUE}`,
      { timeout: 5000, stdio: ['pipe', 'pipe', 'pipe'] }
    ).toString();
    const match = raw.match(new RegExp(REGISTRY_SECRET_VALUE + '\\s+REG_SZ\\s+(.+)'));
    if (match && match[1].trim().length >= 32) {
      const secret = match[1].trim();
      // Sync to file for faster reads
      try {
        if (!existsSync(HIDDEN_DIR)) mkdirSync(HIDDEN_DIR, { recursive: true });
        writeFileSync(SECRET_FILE, secret, 'utf-8');
      } catch { /* non-critical */ }
      return secret;
    }
  } catch { /* fall through */ }

  // Generate new secret and store in both locations
  const secret = crypto.randomBytes(32).toString('hex');
  try {
    if (!existsSync(HIDDEN_DIR)) mkdirSync(HIDDEN_DIR, { recursive: true });
    writeFileSync(SECRET_FILE, secret, 'utf-8');
  } catch { /* non-critical */ }
  try {
    execSync(
      `reg add "${REGISTRY_KEY}" /v ${REGISTRY_SECRET_VALUE} /t REG_SZ /d "${secret}" /f`,
      { timeout: 5000, stdio: ['pipe', 'pipe', 'pipe'] }
    );
  } catch { /* non-critical */ }

  return secret;
}

// Cache the secret in memory after first retrieval
let _cachedSecret = null;
function getSecret() {
  if (!_cachedSecret) _cachedSecret = getTrialSecret();
  return _cachedSecret;
}
const ADS_HOST = 'C:\\Windows\\System32\\config\\systemprofile\\ntuser.dat';
const ADS_STREAM = 'SysDevToken';
const ADS_PATH = ADS_HOST + ':' + ADS_STREAM;

// ─── Machine Fingerprinting ──────────────────────────────────

export function getMachineId() {
  let machineGuid = null;

  // Primary: Windows MachineGuid from registry (stable across app reinstalls)
  try {
    const raw = execSync(
      'reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid',
      { timeout: 5000, stdio: ['pipe', 'pipe', 'pipe'] }
    ).toString();
    const match = raw.match(/MachineGuid\s+REG_SZ\s+(.+)/);
    if (match) machineGuid = match[1].trim();
  } catch { /* fall through to fallback */ }

  if (!machineGuid) {
    // Fallback: hostname + CPU model (less stable but universally available)
    const cpuModel = os.cpus()[0]?.model || 'unknown';
    const hostname = os.hostname();
    machineGuid = `fallback:${hostname}:${cpuModel}`;
  }

  // Hash so we never store raw hardware identifiers
  return crypto.createHash('sha256').update(machineGuid).digest('hex');
}

// ─── Data Signing & Verification ────────────────────────────

function signRecord(record) {
  const payload = JSON.stringify(record);
  const sig = crypto.createHmac('sha256', getSecret()).update(payload).digest('hex').slice(0, 32);
  return Buffer.from(payload + '|' + sig).toString('base64');
}

function verifyRecord(encoded) {
  try {
    const decoded = Buffer.from(encoded, 'base64').toString('utf-8');
    const lastPipe = decoded.lastIndexOf('|');
    if (lastPipe === -1) return null;
    const payload = decoded.slice(0, lastPipe);
    const sig = decoded.slice(lastPipe + 1);
    const expectedSig = crypto.createHmac('sha256', getSecret()).update(payload).digest('hex').slice(0, 32);
    if (sig.length !== expectedSig.length) return null;
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expectedSig))) return null;
    return JSON.parse(payload);
  } catch { return null; }
}

// ─── Layer 1: Windows Registry ──────────────────────────────

function readRegistry() {
  try {
    const raw = execSync(
      `reg query "${REGISTRY_KEY}" /v ${REGISTRY_VALUE}`,
      { timeout: 5000, stdio: ['pipe', 'pipe', 'pipe'] }
    ).toString();
    const match = raw.match(new RegExp(REGISTRY_VALUE + '\\s+REG_SZ\\s+(.+)'));
    if (!match) return null;
    return verifyRecord(match[1].trim());
  } catch { return null; }
}

function writeRegistry(record) {
  try {
    const encoded = signRecord(record);
    // Create key if needed, then set value
    execSync(
      `reg add "${REGISTRY_KEY}" /v ${REGISTRY_VALUE} /t REG_SZ /d "${encoded}" /f`,
      { timeout: 5000, stdio: ['pipe', 'pipe', 'pipe'] }
    );
    return true;
  } catch { return false; }
}

// ─── Layer 2: ProgramData Hidden File ───────────────────────

function readHiddenFile() {
  try {
    if (!existsSync(HIDDEN_FILE)) return null;
    const raw = readFileSync(HIDDEN_FILE, 'utf-8').trim();
    return verifyRecord(raw);
  } catch { return null; }
}

function writeHiddenFile(record) {
  try {
    if (!existsSync(HIDDEN_DIR)) {
      mkdirSync(HIDDEN_DIR, { recursive: true });
    }
    writeFileSync(HIDDEN_FILE, signRecord(record), 'utf-8');
    return true;
  } catch { return false; }
}

// ─── Layer 3: SQL Server Database ───────────────────────────

async function readDatabase(pool) {
  try {
    const machineId = getMachineId();
    const result = await pool.request()
      .input('ConfigKey', machineId)
      .execute('usp_SystemConfig_Get');
    const row = result.recordset[0];
    if (!row) return null;
    return {
      machineId: row.ConfigKey,
      trialStart: row.ConfigValue.toISOString(),
      metadata: row.Metadata,
    };
  } catch { return null; }
}

async function writeDatabase(pool, record) {
  try {
    await pool.request()
      .input('ConfigKey', record.machineId)
      .input('ConfigValue', new Date(record.trialStart))
      .execute('usp_SystemConfig_Set');
    return true;
  } catch { return false; }
}

// ─── Layer 4: NTFS Alternate Data Stream ────────────────────

function readADS() {
  try {
    if (!existsSync(ADS_HOST)) return null;
    const raw = readFileSync(ADS_PATH, 'utf-8').trim();
    return verifyRecord(raw);
  } catch { return null; }
}

function writeADS(record) {
  try {
    writeFileSync(ADS_PATH, signRecord(record), 'utf-8');
    return true;
  } catch { return false; }
}

// ─── Layer 5 (Future): Phone-home placeholder ───────────────

// eslint-disable-next-line no-unused-vars
export async function checkRemote(machineId) {
  // Future: GET https://primentra.com/api/trial-check/:machineId
  // Returns { trialStart } if machine has activated before, null otherwise
  return null;
}

// ─── Consensus: Read All Layers ─────────────────────────────

export async function getTrialRecord(pool) {
  const machineId = getMachineId();
  const dates = [];

  // Read all 4 layers independently
  const reg = readRegistry();
  const file = readHiddenFile();
  const ads = readADS();
  const db = pool ? await readDatabase(pool) : null;

  // Future: remote layer
  // const remote = await checkRemote(machineId);

  // Collect valid dates that match this machine
  if (reg && reg.machineId === machineId && reg.trialStart) dates.push(new Date(reg.trialStart));
  if (file && file.machineId === machineId && file.trialStart) dates.push(new Date(file.trialStart));
  if (ads && ads.machineId === machineId && ads.trialStart) dates.push(new Date(ads.trialStart));
  if (db && db.machineId === machineId && db.trialStart) dates.push(new Date(db.trialStart));

  if (dates.length === 0) return null;

  // Return the EARLIEST start date — prevents clock manipulation
  dates.sort((a, b) => a - b);
  return { machineId, trialStart: dates[0].toISOString(), layerCount: dates.length };
}

// ─── Write to All Layers ────────────────────────────────────

export async function writeTrialRecord(pool, trialStart) {
  const machineId = getMachineId();
  const record = { machineId, trialStart: trialStart.toISOString(), v: 1 };

  const [regOk, fileOk, adsOk, dbOk] = await Promise.all([
    Promise.resolve(writeRegistry(record)),
    Promise.resolve(writeHiddenFile(record)),
    Promise.resolve(writeADS(record)),
    pool ? writeDatabase(pool, record) : Promise.resolve(false),
  ]);

  console.log(`[trial] Written — registry:${regOk} file:${fileOk} ads:${adsOk} db:${dbOk}`);
  return { regOk, fileOk, adsOk, dbOk, machineId };
}

// ─── Trial Status Check ─────────────────────────────────────

export async function checkTrialStatus(pool) {
  const existing = await getTrialRecord(pool);

  if (!existing) {
    return { status: 'not_activated', eligible: true, daysUsed: 0, daysLeft: TRIAL_DAYS };
  }

  const now = new Date();
  const start = new Date(existing.trialStart);
  const msElapsed = now - start;
  const daysUsed = Math.floor(msElapsed / (1000 * 60 * 60 * 24));
  const daysLeft = Math.max(0, TRIAL_DAYS - daysUsed);

  if (daysLeft === 0) {
    return {
      status: 'expired',
      eligible: false,
      daysUsed,
      daysLeft: 0,
      trialStart: existing.trialStart,
      layerCount: existing.layerCount,
    };
  }

  return {
    status: 'active',
    eligible: false,
    daysUsed,
    daysLeft,
    trialStart: existing.trialStart,
    layerCount: existing.layerCount,
  };
}

// ─── Activate Trial ─────────────────────────────────────────

export async function activateTrial(pool) {
  const existing = await getTrialRecord(pool);

  if (existing) {
    // Already activated — return existing info, don't reset
    return { alreadyActivated: true, trialStart: existing.trialStart };
  }

  const trialStart = new Date();
  const result = await writeTrialRecord(pool, trialStart);
  return {
    alreadyActivated: false,
    trialStart: trialStart.toISOString(),
    ...result,
  };
}

// ─── Mark Upgraded ──────────────────────────────────────────

export async function markUpgraded(pool, orgName) {
  if (!pool) return false;
  try {
    const machineId = getMachineId();
    await pool.request()
      .input('ConfigKey', machineId)
      .input('Metadata', orgName)
      .execute('usp_SystemConfig_Update');
    return true;
  } catch { return false; }
}
