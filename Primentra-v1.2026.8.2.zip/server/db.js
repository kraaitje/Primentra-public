import sql from 'mssql';
import { readConfig } from './config.js';

let pool = null;

// Single source of truth for the mssql/tedious connection config. server.js imports this for
// /api/test-connection and /api/setup-database so a successful test can never describe a
// different connection than the one the application actually opens.
export function buildSqlConfig(settings, { requestTimeout = 120000, pool: poolOptions } = {}) {
  // instanceName and port are mutually exclusive in tedious: with an instanceName set the driver
  // asks SQL Server Browser (UDP 1434) to resolve the instance's dynamic port and conflicts with
  // the port supplied here, so filling in both fields fails or hangs. A port already addresses the
  // instance directly and needs no Browser lookup, so an explicit port wins and drops the instance.
  const explicitPort = Number(settings.sqlPort) || null;
  const config = {
    server: settings.hostname,
    database: settings.database,
    user: settings.username,
    password: settings.password || '',
    options: {
      // Encrypt the connection (required when the SQL Server forces encryption);
      // trustServerCertificate accepts the server's self-signed cert. Mirrors the
      // SSMS "Encrypt + Trust server certificate" combo that works against default installs.
      encrypt: true,
      trustServerCertificate: settings.trustServerCertificate ?? true,
      instanceName: explicitPort ? undefined : (settings.instance || undefined),
      connectTimeout: 10000,
      requestTimeout,
    },
  };
  // Port logic: explicit port > default 1433 for default instances.
  // A named instance without an explicit port is resolved through SQL Server Browser.
  if (explicitPort) config.port = explicitPort;
  else if (!settings.instance) config.port = 1433;
  if (poolOptions) config.pool = poolOptions;
  return config;
}

// True when the caller filled in both an instance name and a port. Not an error — buildSqlConfig
// resolves it by using the port — but worth saying out loud, because the connection then goes to
// the port and ignores the instance name the user typed.
export function hasInstanceAndPort(settings) {
  return !!(settings.instance && Number(settings.sqlPort));
}

export async function getPool() {
  if (pool) {
    try {
      if (pool.connected) return pool;
    } catch {
      // Pool in bad state, reset it
      pool = null;
    }
  }

  const config = readConfig();
  if (!config.hostname || !config.database || !config.username) {
    throw new Error('Database not configured. Set hostname, database and username in settings.');
  }

  try {
    const dbConfig = buildSqlConfig(config, {
      pool: { max: 25, min: 2, idleTimeoutMillis: 60000 },
    });
    pool = await sql.connect(dbConfig);

    // Handle pool errors to trigger reconnect
    pool.on('error', (err) => {
      // Log pool error — import logger lazily to avoid circular dependency
      import('./logger.js').then(m => m.default.error('DB pool error, resetting connection', { message: err.message })).catch(() => {});
      console.error('[db] Pool error, resetting connection:', err.message);
      pool = null;
    });

    return pool;
  } catch (err) {
    pool = null;
    throw err;
  }
}

// Reset the pool on errors that indicate the connection/database is gone
// (e.g. after DROP DATABASE, SQL Server restart, network failure)
function shouldResetPool(err) {
  const code = err?.code || '';
  const msg = (err?.message || '').toLowerCase();
  return code === 'ESOCKET' || code === 'ELOGIN' || code === 'ECONNCLOSED' ||
    msg.includes('connection is closed') || msg.includes('not opened') ||
    msg.includes('database') && msg.includes('not exist') ||
    msg.includes('login failed');
}

export async function query(sqlText, params = {}) {
  const p = await getPool();
  const request = p.request();
  for (const [key, val] of Object.entries(params)) {
    if (val && typeof val === 'object' && val.type) {
      request.input(key, val.type, val.value);
    } else {
      request.input(key, val);
    }
  }
  try {
    return await request.query(sqlText);
  } catch (err) {
    if (shouldResetPool(err)) pool = null;
    throw err;
  }
}

export async function execute(procName, params = {}, options = {}) {
  const p = await getPool();
  const request = p.request();
  if (options.timeout) request.timeout = options.timeout;
  for (const [key, val] of Object.entries(params)) {
    if (val && typeof val === 'object' && val.type) {
      request.input(key, val.type, val.value);
    } else {
      request.input(key, val);
    }
  }
  try {
    return await request.execute(procName);
  } catch (err) {
    if (shouldResetPool(err)) pool = null;
    throw err;
  }
}

export { sql };
