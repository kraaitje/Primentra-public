import sql from 'mssql';
import { readConfig } from './config.js';

let pool = null;

export async function getPool() {
  if (pool) {
    try {
      if (pool.connected) return pool;
    } catch {
      // Pool in bad state, reset it
      pool = null;
    }
  }

  const config = readConfig();
  if (!config.hostname || !config.database || !config.username) {
    throw new Error('Database not configured. Set hostname, database and username in settings.');
  }

  try {
    const dbConfig = {
      server: config.hostname,
      database: config.database,
      user: config.username,
      password: config.password || '',
      options: {
        // Encrypt the connection (required when the SQL Server forces encryption);
        // trustServerCertificate accepts the server's self-signed cert. Mirrors the
        // SSMS "Encrypt + Trust server certificate" combo that works against default installs.
        encrypt: true,
        trustServerCertificate: config.trustServerCertificate ?? true,
        instanceName: config.instance || undefined,
        connectTimeout: 10000,
        requestTimeout: 120000,
      },
      pool: { max: 25, min: 2, idleTimeoutMillis: 60000 },
    };
    // Port logic: explicit port > default 1433 for default instances
    // Named instances without explicit port use SQL Browser (dynamic)
    if (config.sqlPort) dbConfig.port = config.sqlPort;
    else if (!config.instance) dbConfig.port = 1433;
    pool = await sql.connect(dbConfig);

    // Handle pool errors to trigger reconnect
    pool.on('error', (err) => {
      // Log pool error — import logger lazily to avoid circular dependency
      import('./logger.js').then(m => m.default.error('DB pool error, resetting connection', { message: err.message })).catch(() => {});
      console.error('[db] Pool error, resetting connection:', err.message);
      pool = null;
    });

    return pool;
  } catch (err) {
    pool = null;
    throw err;
  }
}

// Reset the pool on errors that indicate the connection/database is gone
// (e.g. after DROP DATABASE, SQL Server restart, network failure)
function shouldResetPool(err) {
  const code = err?.code || '';
  const msg = (err?.message || '').toLowerCase();
  return code === 'ESOCKET' || code === 'ELOGIN' || code === 'ECONNCLOSED' ||
    msg.includes('connection is closed') || msg.includes('not opened') ||
    msg.includes('database') && msg.includes('not exist') ||
    msg.includes('login failed');
}

export async function query(sqlText, params = {}) {
  const p = await getPool();
  const request = p.request();
  for (const [key, val] of Object.entries(params)) {
    if (val && typeof val === 'object' && val.type) {
      request.input(key, val.type, val.value);
    } else {
      request.input(key, val);
    }
  }
  try {
    return await request.query(sqlText);
  } catch (err) {
    if (shouldResetPool(err)) pool = null;
    throw err;
  }
}

export async function execute(procName, params = {}, options = {}) {
  const p = await getPool();
  const request = p.request();
  if (options.timeout) request.timeout = options.timeout;
  for (const [key, val] of Object.entries(params)) {
    if (val && typeof val === 'object' && val.type) {
      request.input(key, val.type, val.value);
    } else {
      request.input(key, val);
    }
  }
  try {
    return await request.execute(procName);
  } catch (err) {
    if (shouldResetPool(err)) pool = null;
    throw err;
  }
}

export { sql };
