import crypto from 'crypto';
import { Router } from 'express';
import { execute } from '../db.js';
import { asyncHandler, requireId } from '../middleware/validate.js';
import logger from '../logger.js';
import { invalidateApiEnabledCache } from '../middleware/authMiddleware.js';

const router = Router();

// ── Helpers ──────────────────────────────────────────────────────────────────

function generateApiKey() {
  const raw = 'prm_' + crypto.randomBytes(24).toString('base64url');
  const hash = crypto.createHash('sha256').update(raw).digest('hex');
  const prefix = raw.slice(0, 12); // e.g. "prm_Ab12XyZw"
  return { raw, hash, prefix };
}

function adminOnly(req, res) {
  if (!req.user?.isAdministrator) {
    res.status(403).json({ success: false, error: 'Administrator access required.' });
    return false;
  }
  return true;
}

async function writeAudit(action, userId, comment, details) {
  try {
    await execute('usp_AuditLog_Write', {
      EntityId: null,
      EntityName: 'API',
      ModelName: 'System',
      Action: action,
      RecordCount: 1,
      UserId: userId || null,
      Comment: comment,
      Details: JSON.stringify(details),
    });
  } catch (err) {
    logger.warn(`Audit log write failed (${action}): ${err.message}`, { error: err.message, category: 'audit' });
  }
}

// ── Routes ───────────────────────────────────────────────────────────────────

// GET /api/api-users — List all API users + key info
router.get('/api-users', asyncHandler(async (req, res) => {
  if (!adminOnly(req, res)) return;

  const result = await execute('usp_ApiUser_GetAll');
  const users = result.recordsets[0] || [];
  const memberships = result.recordsets[1] || [];

  // Group role memberships by userId
  const roleMap = {};
  for (const m of memberships) {
    if (!roleMap[m.UserId]) roleMap[m.UserId] = [];
    roleMap[m.UserId].push({ id: m.RoleId, name: m.RoleName });
  }

  const data = users.map(u => ({
    id: u.Id,
    displayName: u.DisplayName,
    email: u.Email,
    isActive: !!u.IsActive,
    createdAt: u.CreatedAt,
    modifiedAt: u.ModifiedAt,
    roles: roleMap[u.Id] || [],
    key: u.KeyId ? {
      id: u.KeyId,
      name: u.KeyName,
      prefix: u.KeyPrefix,
      isActive: !!u.KeyIsActive,
      expiresAt: u.ExpiresAt,
      lastUsedAt: u.LastUsedAt,
      callCount: Number(u.CallCount),
      readCount: Number(u.ReadCount || 0),
      createCount: Number(u.CreateCount || 0),
      updateCount: Number(u.UpdateCount || 0),
      deleteCount: Number(u.DeleteCount || 0),
      createdAt: u.KeyCreatedAt,
    } : null,
  }));

  res.json({ success: true, data });
}));

// POST /api/api-users — Create API user + generate key
router.post('/api-users', asyncHandler(async (req, res) => {
  if (!adminOnly(req, res)) return;

  const { displayName, keyName, expiresAt, roleIds } = req.body;

  if (!displayName?.trim()) {
    return res.status(400).json({ success: false, error: 'displayName is required.' });
  }

  const { raw, hash, prefix } = generateApiKey();
  // Build a stable unique email for the API user (not shown in UI, just for DB uniqueness)
  const slug = displayName.toLowerCase().replace(/[^a-z0-9]/g, '-').slice(0, 40);
  const email = `api-${slug}-${Date.now()}@api.internal`;

  const result = await execute('usp_ApiUser_Create', {
    DisplayName: displayName.trim(),
    Email: email,
    KeyName: keyName?.trim() || 'Default key',
    KeyHash: hash,
    KeyPrefix: prefix,
    ExpiresAt: expiresAt || null,
    RoleIdsJson: Array.isArray(roleIds) && roleIds.length ? JSON.stringify(roleIds) : null,
  });

  const user = result.recordsets[0]?.[0];
  const key = result.recordsets[1]?.[0];
  const roles = result.recordsets[2] || [];

  await writeAudit('api_user_created', req.user.id,
    `Created API user: ${displayName}`,
    { apiUserId: user?.Id, displayName, roleIds, expiresAt, keyPrefix: prefix });

  res.json({
    success: true,
    data: {
      id: user?.Id,
      displayName: user?.DisplayName,
      email: user?.Email,
      isActive: !!user?.IsActive,
      roles: roles.map(r => ({ id: r.RoleId, name: r.RoleName })),
      key: {
        id: key?.Id,
        prefix,
        isActive: true,
        expiresAt: expiresAt || null,
        callCount: 0,
        readCount: 0,
        createCount: 0,
        updateCount: 0,
        deleteCount: 0,
        lastUsedAt: null,
      },
      // Raw key shown ONCE — never stored, not returned again
      rawKey: raw,
    },
  });
}));

// PUT /api/api-users/:id — Update API user
router.put('/api-users/:id', asyncHandler(async (req, res) => {
  if (!adminOnly(req, res)) return;

  const id = requireId(req.params);
  const { displayName, isActive, expiresAt, clearExpiry, roleIds } = req.body;

  const result = await execute('usp_ApiUser_Update', {
    UserId: id,
    DisplayName: displayName?.trim() || null,
    IsActive: isActive !== undefined ? (isActive ? 1 : 0) : null,
    ExpiresAt: expiresAt || null,
    ClearExpiry: clearExpiry ? 1 : 0,
    RoleIdsJson: Array.isArray(roleIds) ? JSON.stringify(roleIds) : null,
  });

  if (!result.recordsets[0]?.length) {
    return res.status(404).json({ success: false, error: 'API user not found.' });
  }

  const user = result.recordsets[0][0];
  const key = result.recordsets[1]?.[0];
  const roles = result.recordsets[2] || [];

  const changes = {};
  if (displayName !== undefined) changes.displayName = displayName;
  if (isActive !== undefined) changes.isActive = isActive;
  if (expiresAt !== undefined) changes.expiresAt = expiresAt;
  if (clearExpiry) changes.expiresAt = null;
  if (roleIds !== undefined) changes.roleIds = roleIds;

  await writeAudit('api_user_updated', req.user.id,
    `Updated API user: ${user.DisplayName}`,
    { apiUserId: id, changes });

  res.json({
    success: true,
    data: {
      id: user.Id,
      displayName: user.DisplayName,
      isActive: !!user.IsActive,
      roles: roles.map(r => ({ id: r.RoleId, name: r.RoleName })),
      key: key ? {
        id: key.Id,
        prefix: key.KeyPrefix,
        isActive: !!key.IsActive,
        expiresAt: key.ExpiresAt,
        callCount: Number(key.CallCount),
        readCount: Number(key.ReadCount || 0),
        createCount: Number(key.CreateCount || 0),
        updateCount: Number(key.UpdateCount || 0),
        deleteCount: Number(key.DeleteCount || 0),
        lastUsedAt: key.LastUsedAt,
      } : null,
    },
  });
}));

// POST /api/api-users/:id/regenerate — Regenerate API key
router.post('/api-users/:id/regenerate', asyncHandler(async (req, res) => {
  if (!adminOnly(req, res)) return;

  const id = requireId(req.params);
  const { keyName, expiresAt } = req.body;
  const { raw, hash, prefix: newPrefix } = generateApiKey();

  const result = await execute('usp_ApiKey_Regenerate', {
    UserId: id,
    KeyName: keyName?.trim() || 'Default key',
    NewHash: hash,
    NewPrefix: newPrefix,
    ExpiresAt: expiresAt || null,
  });

  const row = result.recordset?.[0];
  if (!row) {
    return res.status(404).json({ success: false, error: 'API user not found or has no active key.' });
  }

  await writeAudit('api_key_regenerated', req.user.id,
    `Regenerated key for API user #${id}`,
    { apiUserId: id, oldKeyPrefix: row.OldKeyPrefix, newKeyPrefix: newPrefix });

  res.json({
    success: true,
    data: {
      prefix: newPrefix,
      expiresAt: expiresAt || null,
      // Raw key shown ONCE
      rawKey: raw,
    },
  });
}));

// DELETE /api/api-users/:id — Delete API user
router.delete('/api-users/:id', asyncHandler(async (req, res) => {
  if (!adminOnly(req, res)) return;

  const id = requireId(req.params);

  const result = await execute('usp_ApiUser_Delete', { UserId: id });
  const displayName = result.recordset?.[0]?.DisplayName || `User #${id}`;

  await writeAudit('api_user_deleted', req.user.id,
    `Deleted API user: ${displayName}`,
    { apiUserId: id, displayName });

  res.json({ success: true });
}));

export default router;
