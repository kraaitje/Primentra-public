import { Router } from 'express';
import { execute, sql } from '../db.js';
import { asyncHandler, requireId, optionalInt } from '../middleware/validate.js';
import { requireAdmin } from '../middleware/authzMiddleware.js';

const router = Router();

// ─── System user lookup (cached) ─────────────────────────────────────────────
let _systemUserId = null;
async function getSystemUserId() {
  if (_systemUserId != null) return _systemUserId;
  const result = await sql.query`SELECT TOP 1 Id FROM Users WHERE IsSystem = 1 AND IsDeleted = 0`;
  if (result.recordset.length > 0) {
    _systemUserId = result.recordset[0].Id;
  }
  return _systemUserId;
}

// ─── Mapper functions ─────────────────────────────────────────────────────────

function mapConfiguration(r) {
  return {
    id: r.Id,
    entityId: r.EntityId,
    isEnabled: r.IsEnabled,
    tableName: r.TableName,
    defaultImportAction: r.DefaultImportAction,
    defaultMergeMode: r.DefaultMergeMode,
    sentinelText: r.SentinelText,
    sentinelNumber: r.SentinelNumber != null ? String(r.SentinelNumber) : null,
    sentinelDateTime: r.SentinelDateTime,
    createdAt: r.CreatedAt,
    modifiedAt: r.ModifiedAt,
  };
}

function mapFieldRule(r) {
  return {
    id: r.Id,
    entityId: r.EntityId,
    attributeId: r.AttributeId,
    attributeName: r.AttributeName || r.Name,
    displayName: r.DisplayName,
    dataType: r.DataType,
    mergeMode: r.MergeMode,
    onValidationError: r.OnValidationError,
    sourcePriority: r.SourcePriority ? JSON.parse(r.SourcePriority) : null,
  };
}

function mapBatch(r) {
  return {
    id: r.Id,
    batchTag: r.BatchTag,
    status: r.Status,
    statusLabel: r.StatusLabel,
    totalRows: r.TotalRows,
    successRows: r.SuccessRows,
    errorRows: r.ErrorRows,
    skippedRows: r.SkippedRows,
    startedAt: r.StartedAt,
    completedAt: r.CompletedAt,
    startedBy: r.StartedBy,
    startedByName: r.StartedByName,
    createdAt: r.CreatedAt,
  };
}

function mapBatchResult(r) {
  return {
    batchId: r.Id,
    status: r.Status,
    totalRows: r.TotalRows,
    successRows: r.SuccessRows,
    errorRows: r.ErrorRows,
    skippedRows: r.SkippedRows,
    startedAt: r.StartedAt,
    completedAt: r.CompletedAt,
  };
}

function mapError(r) {
  return {
    id: r.Id,
    stagingRowId: r.StagingRowId,
    code: r.Code,
    attributeName: r.AttributeName,
    stagingValue: r.StagingValue,
    errorCode: r.ErrorCode,
    errorMessage: r.ErrorMessage,
    createdAt: r.CreatedAt,
  };
}

function mapColumnMeta(r) {
  return {
    attributeId: r.AttributeId,
    name: r.Name,
    displayName: r.DisplayName,
    dataType: r.DataType,
    sortOrder: r.SortOrder,
  };
}

function configResponse(result) {
  return {
    configuration: result.recordsets[0]?.[0] ? mapConfiguration(result.recordsets[0][0]) : null,
    fieldRules: (result.recordsets[1] || []).map(mapFieldRule),
  };
}

function mapSchedulerConfig(r) {
  return {
    id: r.Id,
    entityId: r.EntityId,
    processingMode: r.ProcessingMode,
    scheduleType: r.ScheduleType,
    intervalMinutes: r.IntervalMinutes,
    runTimes: r.RunTimes,
    runDays: r.RunDays,
    runDaysOfMonth: r.RunDaysOfMonth,
    triggerOnNewRows: r.TriggerOnNewRows,
    triggerRowThreshold: r.TriggerRowThreshold,
    triggerIdleMinutes: r.TriggerIdleMinutes,
    triggerDebounceSeconds: r.TriggerDebounceSeconds,
    zombieTimeoutMinutes: r.ZombieTimeoutMinutes ?? 30,
    isRunning: r.IsRunning,
    runStartedAt: r.RunStartedAt,
    runStartedBy: r.RunStartedBy,
    nextScheduledRun: r.NextScheduledRun,
    lastCompletedAt: r.LastCompletedAt,
    lastTriggerCheck: r.LastTriggerCheck,
    isEnabled: r.IsEnabled,
    createdAt: r.CreatedAt,
    modifiedAt: r.ModifiedAt,
    pendingRows: r.PendingRows,
    oldestRowAge: r.OldestRowAge,
  };
}

function mapSchedulerLog(r) {
  return {
    id: r.Id,
    entityId: r.EntityId,
    eventTime: r.EventTime,
    eventType: r.EventType,
    triggerSource: r.TriggerSource,
    message: r.Message,
    rowsQueued: r.RowsQueued,
    durationMs: r.DurationMs,
    batchId: r.BatchId,
  };
}

// ─── Static sub-paths (must come BEFORE /:entityId routes) ───────────────────

router.get('/batches/:batchId/errors', requireAdmin, asyncHandler(async (req, res) => {
  const batchId = requireId(req.params, 'batchId');
  const result = await execute('usp_Staging_GetErrors', {
    BatchId: batchId,
    PageSize: optionalInt(req.query.pageSize, 100),
    PageNumber: optionalInt(req.query.page, 1),
  });
  res.json({
    errors: (result.recordsets[0] || []).map(mapError),
    summary: result.recordsets[1]?.[0] || {},
  });
}));

router.delete('/batches/:batchId/clear', requireAdmin, asyncHandler(async (req, res) => {
  const batchId = requireId(req.params, 'batchId');
  const { status = 'all' } = req.query;
  const result = await execute('usp_Staging_ClearBatch', {
    BatchId: batchId,
    ClearStatus: status,
  });
  res.json({ success: true, deletedRows: result.recordset[0]?.DeletedRows || 0 });
}));

router.delete('/:entityId/history', requireAdmin, asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const result = await execute('usp_Staging_ClearBatchHistory', { EntityId: entityId });
  res.json({ success: true, deletedBatches: result.recordset[0]?.DeletedBatches || 0 });
}));

// ─── Entity-scoped routes ─────────────────────────────────────────────────────

router.get('/:entityId/scheduler/log', requireAdmin, asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const result = await execute('usp_Scheduler_GetLog', {
    EntityId: entityId,
    PageSize: optionalInt(req.query.pageSize, 50),
    PageNumber: optionalInt(req.query.page, 1),
  });
  res.json({
    log: (result.recordsets[0] || []).map(mapSchedulerLog),
    totalCount: result.recordsets[1]?.[0]?.TotalCount || 0,
  });
}));

router.post('/:entityId/scheduler/test', requireAdmin, asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const result = await execute('usp_Scheduler_TestRun', { EntityId: entityId });
  const row = result.recordset?.[0];
  res.json({
    wouldFire: row?.WouldFire ?? false,
    reason: row?.Reason || null,
    pendingRows: row?.PendingRows || 0,
    oldestRowAge: row?.OldestRowAge || 0,
    nextScheduledRun: row?.NextScheduledRun || null,
  });
}));

router.get('/:entityId/scheduler', requireAdmin, asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const result = await execute('usp_Scheduler_GetConfig', { EntityId: entityId });
  const row = result.recordset?.[0];
  res.json({ config: row ? mapSchedulerConfig(row) : null });
}));

router.put('/:entityId/scheduler', requireAdmin, asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const { processingMode, scheduleType, intervalMinutes, runTimes, runDays, runDaysOfMonth,
          triggerOnNewRows, triggerRowThreshold, triggerIdleMinutes, triggerDebounceSeconds,
          zombieTimeoutMinutes, isEnabled } = req.body;
  const result = await execute('usp_Scheduler_SaveConfig', {
    EntityId: entityId,
    ProcessingMode: processingMode,
    ScheduleType: scheduleType ?? null,
    IntervalMinutes: intervalMinutes ?? null,
    RunTimes: runTimes ?? null,
    RunDays: runDays ?? null,
    RunDaysOfMonth: runDaysOfMonth ?? null,
    TriggerOnNewRows: triggerOnNewRows ?? false,
    TriggerRowThreshold: triggerRowThreshold ?? null,
    TriggerIdleMinutes: triggerIdleMinutes ?? null,
    TriggerDebounceSeconds: triggerDebounceSeconds ?? 60,
    ZombieTimeoutMinutes: zombieTimeoutMinutes ?? 30,
    IsEnabled: isEnabled ?? true,
  });
  const row = result.recordset?.[0];
  res.json({ config: row ? mapSchedulerConfig(row) : null });
}));

router.post('/:entityId/enable', requireAdmin, asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const result = await execute('usp_Staging_CreateTable', { EntityId: entityId });
  const row = result.recordset?.[0];
  res.json({ success: true, configuration: row ? mapConfiguration(row) : null });
}));

router.delete('/:entityId/disable', requireAdmin, asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  await execute('usp_Staging_DropTable', { EntityId: entityId });
  res.json({ success: true });
}));

router.get('/:entityId/config', requireAdmin, asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const result = await execute('usp_Staging_GetConfiguration', { EntityId: entityId });
  res.json(configResponse(result));
}));

router.put('/:entityId/config', requireAdmin, asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const { defaultImportAction, defaultMergeMode, sentinelText, sentinelNumber, sentinelDateTime, fieldRules } = req.body;
  const result = await execute('usp_Staging_SaveConfiguration', {
    EntityId: entityId,
    DefaultImportAction: defaultImportAction ?? null,
    DefaultMergeMode: defaultMergeMode ?? null,
    SentinelText: sentinelText ?? null,
    SentinelNumber: { type: sql.VarChar(40), value: sentinelNumber != null ? String(sentinelNumber) : null },
    SentinelDateTime: sentinelDateTime ?? null,
    FieldRules: fieldRules ? JSON.stringify(fieldRules) : null,
  });
  res.json(configResponse(result));
}));

router.get('/:entityId/rows', requireAdmin, asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const result = await execute('usp_Staging_GetStagedRows', {
    EntityId: entityId,
    ImportStatus: optionalInt(req.query.importStatus),
    BatchId: optionalInt(req.query.batchId),
    PageSize: optionalInt(req.query.pageSize, 50),
    PageNumber: optionalInt(req.query.page, 1),
  });
  res.json({
    rows: result.recordsets[0] || [],
    summary: result.recordsets[1]?.[0] || {},
    columns: (result.recordsets[2] || []).map(mapColumnMeta),
  });
}));

router.post('/:entityId/process', requireAdmin, asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const { batchTag, batchId } = req.body || {};
  const systemUserId = await getSystemUserId();
  const result = await execute('usp_Staging_ProcessBatch', {
    EntityId: entityId,
    BatchTag: batchTag || null,
    BatchId: optionalInt(batchId),
    UserId: systemUserId,
  });
  // The final recordset from the SP is the batch summary
  const lastRs = result.recordsets?.[result.recordsets.length - 1];
  if (!lastRs?.[0]) {
    return res.status(500).json({ error: 'Batch processing returned no result.' });
  }
  res.json(mapBatchResult(lastRs[0]));
}));

router.get('/:entityId/batches', requireAdmin, asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const result = await execute('usp_Staging_GetBatches', {
    EntityId: entityId,
    PageSize: optionalInt(req.query.pageSize, 50),
    PageNumber: optionalInt(req.query.page, 1),
  });
  res.json({
    batches: (result.recordsets[0] || []).map(mapBatch),
    totalCount: result.recordsets[1]?.[0]?.TotalCount || 0,
  });
}));

router.post('/:entityId/rebuild', requireAdmin, asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const result = await execute('usp_Staging_RebuildTable', { EntityId: entityId });
  res.json({ success: true, changes: result.recordset || [] });
}));

export default router;
