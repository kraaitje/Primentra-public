import { Router } from 'express';
import { execute } from '../db.js';
import { asyncHandler, requireId } from '../middleware/validate.js';
import logger from '../logger.js';
import { sendApprovalRequestEmail, sendApprovalDecisionEmail } from '../email.js';

const router = Router();

// Helper: convert PascalCase SQL column names to camelCase
function camelRow(r) {
  if (!r) return r;
  const out = {};
  for (const [k, v] of Object.entries(r)) out[k[0].toLowerCase() + k.slice(1)] = v;
  return out;
}

function camelRows(rows) {
  return (rows || []).map(camelRow);
}

const VALID_OPERATIONS = ['insert', 'update', 'delete'];

function isPlainObject(v) {
  return typeof v === 'object' && v !== null && !Array.isArray(v);
}

// usp_Approval_ApproveRow reads every submitted value back as `$."<field>".new`, where <field>
// is the attribute's exact name — SQL Server JSON paths are case-sensitive. A snapshot in any
// other shape is stored happily and then silently misapplied on approval: the new row's Name
// falls back to its RowCode (so the row is named after its code) and every attribute value is
// dropped, while the approval's diff view still shows the values that were submitted. The SPs
// cannot tell a wrong shape from an absent value, so the shape is enforced here, at the door.
//
// `allowedFields` is null when the entity's metadata could not be read; field names are then
// left unchecked rather than rejecting a submission over a failed lookup.
function validateChanges(changes, allowedFields) {
  for (let i = 0; i < changes.length; i++) {
    const change = changes[i];
    const where = `changes[${i}]`;

    if (!isPlainObject(change)) return `${where} must be an object`;
    if (!VALID_OPERATIONS.includes(change.operation)) {
      return `${where}.operation must be one of ${VALID_OPERATIONS.join(', ')}`;
    }
    // A delete carries no field values — nothing to check.
    if (change.operation === 'delete') continue;

    const snapshot = change.snapshotData;
    if (!isPlainObject(snapshot) || Object.keys(snapshot).length === 0) {
      return `${where}.snapshotData must be an object of { field: { old, new } } entries`;
    }

    for (const [field, entry] of Object.entries(snapshot)) {
      if (!isPlainObject(entry) || !Object.prototype.hasOwnProperty.call(entry, 'new')) {
        return `${where}.snapshotData["${field}"] must be an object with a "new" property`;
      }
      if (allowedFields && !allowedFields.has(field)) {
        return `${where}.snapshotData["${field}"] is not a field of this entity ` +
          `(field names are case-sensitive; expected one of: ${[...allowedFields].join(', ')})`;
      }
    }

    // Without a name entry the approved row would be named after its code.
    if (change.operation === 'insert' && !isPlainObject(snapshot.name)) {
      return `${where}.snapshotData must include a "name" entry for an insert`;
    }
  }
  return null;
}

// Field names the snapshot may use: the two built-in row columns plus the entity's attributes,
// spelled exactly as usp_Approval_ApproveRow looks them up.
async function readAllowedFields(entityId) {
  try {
    const meta = await execute('usp_Entity_GetById', { Id: entityId });
    if (!meta.recordsets?.[0]?.length) return null;
    const attributes = meta.recordsets[1] || [];
    return new Set(['code', 'name', ...attributes.map(a => a.Name).filter(Boolean)]);
  } catch (err) {
    logger.warn('approval-submit-field-lookup', { error: err.message });
    return null;
  }
}

// POST /api/approvals
// Body: { entityId, changes: [{entityRowId, operation, rowCode, snapshotData, rowModifiedAtSnapshot}], submitterNote, previousRequestId }
// Response 200: { id: INT }
router.post('/', asyncHandler(async (req, res) => {
  const { entityId, changes, submitterNote, previousRequestId } = req.body;
  const userId = req.user?.id;

  if (!entityId) {
    return res.status(400).json({ error: 'entityId is required' });
  }
  if (!Array.isArray(changes) || changes.length === 0) {
    return res.status(400).json({ error: 'changes array is required and must not be empty' });
  }

  const invalid = validateChanges(changes, await readAllowedFields(entityId));
  if (invalid) {
    return res.status(400).json({ error: invalid });
  }

  const result = await execute('usp_Approval_Submit', {
    EntityId: entityId,
    RowsJson: JSON.stringify(changes),
    SubmittedByUserId: userId,
    SubmitterNote: submitterNote || null,
    PreviousRequestId: previousRequestId || null,
  });

  const newId = result.recordset[0]?.Id;

  // Fire-and-forget: send notification email to approvers
  (async () => {
    try {
      const [approversResult, entityResult] = await Promise.all([
        execute('usp_EntityApprover_GetByEntity', { EntityId: entityId }),
        execute('usp_Entity_GetById', { Id: entityId }),
      ]);
      const approvers = (approversResult.recordset || []).filter(a => a.ReceivesEmail);
      if (approvers.length === 0) return;

      const entityName = entityResult.recordset?.[0]?.DisplayName || '';
      const countNew = changes.filter(c => c.operation === 'insert').length;
      const countEdit = changes.filter(c => c.operation === 'update').length;
      const countDelete = changes.filter(c => c.operation === 'delete').length;

      const config = (await import('../config.js')).readConfig();
      // appBaseUrl is the configured public address of this install. The old `appUrl`
      // key was never defined anywhere, so these links always fell back to localhost.
      const appUrl = config.appBaseUrl || 'http://localhost:5173';

      for (const approver of approvers) {
        const otherApprovers = approvers
          .filter(a => a.Email !== approver.Email)
          .map(a => a.DisplayName || a.Email || '');
        await sendApprovalRequestEmail({
          to: approver.Email,
          submitterName: req.user?.displayName || 'A user',
          entityName,
          countNew,
          countEdit,
          countDelete,
          submitterNote: submitterNote || null,
          otherApprovers,
          appUrl,
        }).catch(err => logger.error('approval-request-email', { error: err.message }));
      }
    } catch (err) {
      logger.error('approval-request-email-lookup', { error: err.message });
    }
  })();

  res.json({ id: newId });
}));

// GET /api/approvals/pending-count
// IMPORTANT: must be registered BEFORE /:id to avoid routing conflict
// Response 200: { pendingForMe, myApproved, myRejected }
router.get('/pending-count', asyncHandler(async (req, res) => {
  const userId = req.user?.id;
  const isAdmin = req.user?.isAdministrator ? 1 : 0;

  const result = await execute('usp_Approval_GetPendingCount', { UserId: userId, IsAdministrator: isAdmin });
  const row = result.recordset[0] || {};

  res.json({
    pendingForMe: row.PendingForMe ?? 0,
    myApproved: row.MyApproved ?? 0,
    myRejected: row.MyRejected ?? 0,
  });
}));

// GET /api/approvals/pending
// IMPORTANT: must be registered BEFORE /:id to avoid routing conflict
// Response 200: [{ id, entityId, entityName, submittedByUserId, submitterName, submittedAt, status, version, countNew, countEdit, countDelete }]
router.get('/pending', asyncHandler(async (req, res) => {
  const userId = req.user?.id;
  const isAdmin = req.user?.isAdministrator ? 1 : 0;

  const result = await execute('usp_Approval_GetPendingForApprover', { UserId: userId, IsAdministrator: isAdmin });
  res.json(camelRows(result.recordset));
}));

// GET /api/approvals/recent
// IMPORTANT: must be registered BEFORE /:id to avoid routing conflict
// Response 200: [{ id, entityId, entityName, submittedByUserId, submitterName, submittedAt, status, version, countNew, countEdit, countDelete }]
router.get('/recent', asyncHandler(async (req, res) => {
  const userId = req.user?.id;
  const isAdmin = req.user?.isAdministrator ? 1 : 0;

  const result = await execute('usp_Approval_GetRecentForApprover', { UserId: userId, IsAdministrator: isAdmin });
  res.json(camelRows(result.recordset));
}));

// GET /api/approvals/mine
// IMPORTANT: must be registered BEFORE /:id to avoid routing conflict
// Response 200: [{ id, entityId, entityName, submittedByUserId, submitterName, submittedAt, status, version, countNew, countEdit, countDelete, latestDecision, latestReviewerName }]
router.get('/mine', asyncHandler(async (req, res) => {
  const userId = req.user?.id;

  const result = await execute('usp_Approval_GetMine', { UserId: userId });
  res.json(camelRows(result.recordset));
}));

// GET /api/approvals/:id
// Response 200: flattened detail object the frontend ApprovalsView expects
// Response 403/500: { error: string }
router.get('/:id', asyncHandler(async (req, res) => {
  const id = requireId(req.params, 'id');
  const userId = req.user?.id;

  try {
    const result = await execute('usp_Approval_GetDetail', {
      RequestId: id,
      RequestingUserId: userId,
      IsAdministrator: req.user?.isAdministrator ? 1 : 0,
    });

    const requestRow = camelRow(result.recordsets[0]?.[0]);
    const rows = camelRows(result.recordsets[1]);
    const reviews = camelRows(result.recordsets[2]);
    const voteStatusRow = camelRow(result.recordsets[3]?.[0]) || {};

    if (!requestRow) {
      return res.status(404).json({ error: 'Approval request not found' });
    }

    // Build the flattened shape the frontend ApprovalsView expects
    const detail = {
      id: requestRow.id,
      entityId: requestRow.entityId,
      entityName: requestRow.entityName,
      approvalStrategy: requestRow.approvalStrategy || 'any',
      submittedByUserId: requestRow.submittedByUserId,
      submitterName: requestRow.submitterName,
      submittedAt: requestRow.submittedAt,
      status: requestRow.status,
      version: requestRow.version,
      submitterNote: requestRow.submitterNote,
      previousRequestId: requestRow.previousRequestId,
      // changes = the approval rows
      changes: rows.map(r => ({
        id: r.id,
        approvalRequestId: r.approvalRequestId,
        entityRowId: r.entityRowId,
        operation: r.operation ? r.operation.toLowerCase() : r.operation,
        rowStatus: r.rowStatus,
        rowCode: r.rowCode,
        snapshotData: r.snapshotData,
        rowModifiedAtSnapshot: r.rowModifiedAtSnapshot,
        isConflict: r.isConflict,
      })),
      // reviews (send-back / reject comments)
      reviews,
      // history: empty for now — previous request versions would require a separate query
      history: [],
      // approvers: empty — would require EntityApprovers join
      approvers: [],
      // vote status for strategy='all' multi-approver gate
      voteStatus: {
        totalApprovers: voteStatusRow.totalApprovers ?? 0,
        votedApproved: voteStatusRow.votedApproved ?? 0,
        hasCurrentUserVoted: !!voteStatusRow.hasCurrentUserVoted,
      },
    };

    res.json(detail);
  } catch (err) {
    if (err.message && err.message.toLowerCase().includes('access denied')) {
      return res.status(403).json({ error: err.message });
    }
    throw err;
  }
}));

// POST /api/approvals/:id/approve-all
// Body: { comment }
// Response 200: { ok: true, outcome: 'applied'|'voted'|'already_voted' }
router.post('/:id/approve-all', asyncHandler(async (req, res) => {
  const id = requireId(req.params, 'id');
  const { comment } = req.body;
  const userId = req.user?.id;

  const result = await execute('usp_Approval_ApproveAll', {
    RequestId: id,
    ApprovedByUserId: userId,
    Comment: comment || null,
    IsAdministrator: req.user?.isAdministrator ? 1 : 0,
  });

  const outcome = result.recordset?.[0]?.Outcome || 'applied';

  // Only notify the submitter when the changes are actually applied (not intermediate votes)
  if (outcome === 'applied') {
    sendDecisionEmail({ requestId: id, userId, decision: 'approved', comment, req }).catch(() => {});
  }

  res.json({ ok: true, outcome });
}));

// POST /api/approvals/:id/force-approve
// Body: { comment }
// Response 200: { ok: true }
// Requires administrator — bypasses multi-approver strategy
router.post('/:id/force-approve', asyncHandler(async (req, res) => {
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ error: 'Administrator access required' });
  }

  const id = requireId(req.params, 'id');
  const { comment } = req.body;
  const userId = req.user?.id;

  await execute('usp_Approval_ForceApprove', {
    RequestId: id,
    ApprovedByUserId: userId,
    Comment: comment || null,
  });

  sendDecisionEmail({ requestId: id, userId, decision: 'approved', comment, req }).catch(() => {});

  res.json({ ok: true });
}));

// POST /api/approvals/:id/rows/:rowId/approve
// Response 200: { ok: true }
router.post('/:id/rows/:rowId/approve', asyncHandler(async (req, res) => {
  const id = requireId(req.params, 'id');
  const rowId = requireId(req.params, 'rowId');
  const userId = req.user?.id;

  await execute('usp_Approval_ApproveRow', {
    ApprovalRowId: rowId,
    ApprovedByUserId: userId,
    IsAdministrator: req.user?.isAdministrator ? 1 : 0,
  });

  res.json({ ok: true });
}));

// POST /api/approvals/:id/rows/:rowId/reject
// Response 200: { ok: true }
router.post('/:id/rows/:rowId/reject', asyncHandler(async (req, res) => {
  const id = requireId(req.params, 'id');
  const rowId = requireId(req.params, 'rowId');
  const userId = req.user?.id;

  await execute('usp_Approval_RejectRow', {
    ApprovalRowId: rowId,
    ReviewedByUserId: userId,
    IsAdministrator: req.user?.isAdministrator ? 1 : 0,
  });

  res.json({ ok: true });
}));

// POST /api/approvals/:id/send-back
// Body: { comment }
// Response 200: { ok: true }
router.post('/:id/send-back', asyncHandler(async (req, res) => {
  const id = requireId(req.params, 'id');
  const { comment } = req.body;
  const userId = req.user?.id;

  await execute('usp_Approval_SendBack', {
    RequestId: id,
    ReviewedByUserId: userId,
    Comment: comment || null,
    IsAdministrator: req.user?.isAdministrator ? 1 : 0,
  });

  // Fire-and-forget: notify submitter
  sendDecisionEmail({ requestId: id, userId, decision: 'sent_back', comment, req }).catch(() => {});

  res.json({ ok: true });
}));

// POST /api/approvals/:id/reject
// Body: { comment }
// Response 200: { ok: true }
router.post('/:id/reject', asyncHandler(async (req, res) => {
  const id = requireId(req.params, 'id');
  const { comment } = req.body;
  const userId = req.user?.id;

  await execute('usp_Approval_Reject', {
    RequestId: id,
    ReviewedByUserId: userId,
    Comment: comment || null,
    IsAdministrator: req.user?.isAdministrator ? 1 : 0,
  });

  // Fire-and-forget: notify submitter
  sendDecisionEmail({ requestId: id, userId, decision: 'rejected', comment, req }).catch(() => {});

  res.json({ ok: true });
}));

// Internal helper: look up submitter email and send decision notification
async function sendDecisionEmail({ requestId, userId, decision, comment, req }) {
  try {
    // Use GetDetail SP to retrieve submitter info (no dedicated SP for submitter lookup)
    const infoResult = await execute('usp_Approval_GetDetail', {
      RequestId: requestId,
      RequestingUserId: userId,
    });
    const requestHeader = infoResult.recordsets?.[0]?.[0];
    if (!requestHeader) return;

    // Look up the submitter's email from Users table
    const userResult = await execute('usp_User_GetById', { Id: requestHeader.SubmittedByUserId }).catch(() => null);
    const submitterEmail = userResult?.recordset?.[0]?.Email;
    if (!submitterEmail) return;

    const info = {
      SubmitterEmail: submitterEmail,
      SubmitterName: requestHeader.SubmitterName,
      EntityName: requestHeader.EntityName,
    };
    if (!info.SubmitterEmail) return;

    const config = (await import('../config.js')).readConfig();
    // appBaseUrl is the configured public address of this install. The old `appUrl`
    // key was never defined anywhere, so these links always fell back to localhost.
    const appUrl = config.appBaseUrl || 'http://localhost:5173';

    await sendApprovalDecisionEmail({
      to: info.SubmitterEmail,
      submitterName: info.SubmitterName || 'User',
      entityName: info.EntityName || '',
      decision,
      reviewerName: req.user?.displayName || 'A reviewer',
      comment: comment || null,
      appUrl,
    });
  } catch (err) {
    logger.error('approval-decision-email', { error: err.message });
  }
}

// Authorization for approval decisions lives in the stored procedures, so it holds for every
// caller rather than only the routes below. They signal refusal by throwing 'Access denied: …';
// map that to 403 so the client gets the real reason instead of a generic 500.
router.use((err, req, res, next) => {
  if (typeof err?.message === 'string' && err.message.toLowerCase().startsWith('access denied')) {
    return res.status(403).json({ success: false, error: err.message });
  }
  next(err);
});

export default router;
