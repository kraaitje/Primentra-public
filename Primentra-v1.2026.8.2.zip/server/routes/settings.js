import { Router } from 'express';
import { execute } from '../db.js';
import { asyncHandler } from '../middleware/validate.js';
import { requireAdmin } from '../middleware/authzMiddleware.js';
import logger from '../logger.js';
import { invalidateApiEnabledCache } from '../middleware/authMiddleware.js';

const router = Router();

// ==========================================
// USER SETTINGS
// ==========================================

// GET /api/db-settings/user — Get all settings for the authenticated user.
// Always scoped to req.user.id — a caller-supplied userId is ignored to prevent
// reading another user's preferences (IDOR).
router.get('/user', asyncHandler(async (req, res) => {
  const userId = req.user?.id ?? null;

  const result = await execute('usp_Settings_GetUser', { UserId: userId });

  const settings = {};
  for (const r of result.recordset) {
    try {
      settings[r.SettingKey] = JSON.parse(r.SettingValue);
    } catch {
      settings[r.SettingKey] = r.SettingValue;
    }
  }

  res.json(settings);
}));

// PUT /api/db-settings/user — Save settings for the authenticated user
// Always scoped to req.user.id — a caller-supplied userId in the body is ignored
// to prevent writing another user's preferences (IDOR).
router.put('/user', asyncHandler(async (req, res) => {
  const { settings } = req.body;
  const uid = req.user?.id ?? null;

  if (!settings || typeof settings !== 'object') {
    return res.status(400).json({ success: false, message: 'settings object required' });
  }

  // Convert values to strings for JSON storage
  const settingsForDb = {};
  for (const [key, value] of Object.entries(settings)) {
    settingsForDb[key] = typeof value === 'string' ? value : JSON.stringify(value);
  }

  await execute('usp_Settings_SaveUser', {
    UserId: uid,
    SettingsJson: JSON.stringify(settingsForDb),
  });

  res.json({ success: true });
}));

// ==========================================
// APP SETTINGS
// ==========================================

// GET /api/db-settings/app — Get all app settings
router.get('/app', asyncHandler(async (req, res) => {
  const result = await execute('usp_Settings_GetApp');
  const settings = {};
  for (const r of result.recordset) {
    try {
      settings[r.SettingKey] = JSON.parse(r.SettingValue);
    } catch {
      settings[r.SettingKey] = r.SettingValue;
    }
  }
  res.json(settings);
}));

// POST /api/db-settings/app — Save app settings
router.post('/app', requireAdmin, asyncHandler(async (req, res) => {
  const { settings } = req.body;

  if (!settings || typeof settings !== 'object') {
    return res.status(400).json({ success: false, message: 'settings object required' });
  }

  // Detect apiEnabled toggle before saving so we can audit the change
  let apiEnabledBefore = null;
  if ('apiEnabled' in settings) {
    try {
      const prev = await execute('usp_Settings_GetApp');
      const s = prev.recordset?.find(r => r.SettingKey === 'apiEnabled');
      apiEnabledBefore = s?.SettingValue ?? 'true';
    } catch { /* ignore — non-blocking */ }
  }

  const settingsForDb = {};
  for (const [key, value] of Object.entries(settings)) {
    settingsForDb[key] = typeof value === 'string' ? value : JSON.stringify(value);
  }

  await execute('usp_Settings_SaveApp', {
    SettingsJson: JSON.stringify(settingsForDb),
  });

  // Invalidate middleware cache whenever app settings are saved
  invalidateApiEnabledCache();

  // Audit apiEnabled toggle if it changed
  if (apiEnabledBefore !== null) {
    const newValue = String(settings.apiEnabled);
    const changed = apiEnabledBefore !== newValue;
    if (changed) {
      const action = newValue === 'false' ? 'api_access_disabled' : 'api_access_enabled';
      try {
        await execute('usp_AuditLog_Write', {
          EntityId: null,
          EntityName: 'API',
          ModelName: 'System',
          Action: action,
          RecordCount: 1,
          UserId: req.user?.id || null,
          Comment: action === 'api_access_disabled' ? 'API access disabled' : 'API access enabled',
          Details: JSON.stringify({ previousValue: apiEnabledBefore, newValue }),
        });
      } catch (err) {
        logger.warn(`Audit log write failed (${action}): ${err.message}`, { error: err.message, category: 'audit' });
      }
    }
  }

  res.json({ success: true });
}));

export default router;
