import { Router } from 'express';
import { execute, getPool, sql } from '../db.js';
import { asyncHandler, requireId } from '../middleware/validate.js';
import { checkEntityPermission, checkEntityPermissionAny } from '../middleware/permissionMiddleware.js';

const router = Router();

// Helper: pivot EAV rows into flat objects for the frontend
function pivotRows(records) {
  const rowMap = new Map();

  for (const r of records) {
    // Convert BIGINT IDs from strings to numbers (mssql returns BIGINT as string)
    const numId = Number(r.Id);
    if (!rowMap.has(numId)) {
      rowMap.set(numId, {
        id: numId,
        code: r.Code,
        name: r.Name,
        createdAt: r.CreatedAt,
        modifiedAt: r.ModifiedAt,
        createdBy: r.CreatedBy,
        createdByName: r.CreatedByName || null,
        modifiedBy: r.ModifiedBy,
        modifiedByName: r.ModifiedByName || null,
        hasPendingApproval: !!r.HasPendingApproval,
      });
    }

    const row = rowMap.get(numId);
    if (r.AttributeName) {
      const col = r.AttributeName;
      if (r.DataType === 'Domain' && r.DomainValue) {
        // Store domain as the row ID; frontend will display via lookup
        row[col] = Number(r.DomainValue);
        // Also provide display info
        row[`_${col}_display`] = r.DomainCode && r.DomainName
          ? `{${r.DomainCode}} ${r.DomainName}`
          : String(r.DomainValue);
      } else if (r.DataType === 'Int') {
        row[col] = r.IntValue;
      } else if (r.DataType === 'Boolean') {
        row[col] = r.IntValue != null ? Number(r.IntValue) : null;
      } else if (r.DataType === 'Decimal') {
        row[col] = r.DecimalValue != null ? parseFloat(r.DecimalValue) : null;
      } else if (r.DataType === 'DateTime') {
        row[col] = r.DateTimeValue;
      } else {
        row[col] = r.TextValue;
      }
    }
  }

  return Array.from(rowMap.values());
}

// Helper: pivot EAV rows into readable objects for audit log (uses DisplayName)
export function pivotRowsForAudit(records) {
  const rowMap = new Map();

  for (const r of records) {
    const numId = Number(r.Id);
    if (!rowMap.has(numId)) {
      rowMap.set(numId, { code: r.Code, name: r.Name });
    }

    const row = rowMap.get(numId);
    if (r.AttributeName) {
      const col = r.AttributeName;
      if (r.DataType === 'Domain' && r.DomainValue) {
        row[col] = r.DomainCode && r.DomainName
          ? `{${r.DomainCode}} ${r.DomainName}`
          : String(r.DomainValue);
      } else if (r.DataType === 'Int') {
        row[col] = r.IntValue;
      } else if (r.DataType === 'Boolean') {
        row[col] = r.IntValue != null ? (r.IntValue === 1 ? 'Yes' : 'No') : null;
      } else if (r.DataType === 'Decimal') {
        row[col] = r.DecimalValue != null ? parseFloat(r.DecimalValue) : null;
      } else if (r.DataType === 'DateTime') {
        row[col] = r.DateTimeValue;
      } else {
        row[col] = r.TextValue;
      }
    }
  }

  // Remove null-only attribute columns to keep snapshot clean
  const rows = Array.from(rowMap.values());
  if (rows.length > 0) {
    const keysToRemove = [];
    const baseKeys = new Set(['code', 'name']);
    for (const key of Object.keys(rows[0])) {
      if (!baseKeys.has(key) && rows.every(r => r[key] == null)) keysToRemove.push(key);
    }
    for (const row of rows) {
      for (const key of keysToRemove) delete row[key];
    }
  }

  return rows;
}

// GET /api/data/counts — Row counts per entity (for sidebar badges) — cached 5s
let countsCache = null;
let countsCacheAt = 0;
const COUNTS_TTL_MS = 5000;

router.get('/counts', asyncHandler(async (req, res) => {
  const now = Date.now();
  if (countsCache && (now - countsCacheAt) < COUNTS_TTL_MS) {
    return res.json(countsCache);
  }
  const result = await execute('usp_Data_GetRowCounts');
  countsCache = {};
  for (const r of result.recordset) countsCache[r.EntityId] = r.Cnt;
  countsCacheAt = now;
  res.json(countsCache);
}));

// GET /api/data/:entityId — All rows for entity (pivoted)
// With pagination params: ?page=1&pageSize=100&search=...&sortField=...&sortDirection=ASC
// Without params: returns all data (backwards-compatible, used for export)
router.get('/:entityId', checkEntityPermission('CanRead'), asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const { page, pageSize, search, sortField, sortDirection, columnFilters, textFilters } = req.query;

  // If pagination params present, use paginated SP
  if (page) {
    const result = await execute('usp_Data_GetByEntityPaginated', {
      EntityId: entityId,
      PageNumber: { type: sql.Int, value: parseInt(page, 10) || 1 },
      PageSize: { type: sql.Int, value: parseInt(pageSize, 10) || 100 },
      SearchText: search || null,
      SortField: sortField || null,
      SortDirection: ['ASC', 'DESC'].includes((sortDirection || '').toUpperCase()) ? sortDirection.toUpperCase() : 'ASC',
      ColumnFilters: columnFilters || null,
      TextFilters: textFilters || null,
    });

    // SP returns two recordsets: [0] = EAV data, [1] = pagination metadata
    const rows = pivotRows(result.recordsets[0] || []);
    const meta = result.recordsets[1]?.[0] || { TotalCount: 0, PageNumber: 1, PageSize: 100, TotalPages: 0 };

    return res.json({
      rows,
      pagination: {
        totalCount: meta.TotalCount,
        pageNumber: meta.PageNumber,
        pageSize: meta.PageSize,
        totalPages: meta.TotalPages,
      },
    });
  }

  // No pagination params: return all data (backwards-compatible)
  const result = await execute('usp_Data_GetByEntity', { EntityId: entityId });
  res.json(pivotRows(result.recordset));
}));

// GET /api/data/:entityId/:rowId — Single row
router.get('/:entityId/:rowId', checkEntityPermission('CanRead'), asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const rowId = parseInt(req.params.rowId, 10);

  const result = await execute('usp_Data_GetSingleRow', {
    EntityId: entityId,
    RowId: { type: sql.BigInt, value: rowId },
  });

  const rows = pivotRows(result.recordset);
  if (rows.length === 0) {
    return res.status(404).json({ success: false, message: 'Row not found' });
  }
  res.json(rows[0]);
}));

// POST /api/data/:entityId — Create new row
router.post('/:entityId', checkEntityPermission('CanCreate'), asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const { code, name, values } = req.body;
  const userId = req.user?.id;

  if (!code && !name) {
    return res.status(400).json({ success: false, message: 'code or name is required' });
  }

  const result = await execute('usp_Data_SaveRow', {
    EntityId: entityId,
    RowId: { type: sql.BigInt, value: null },
    Code: String(code ?? ''),
    Name: String(name ?? ''),
    Values: JSON.stringify(values || []),
    UserId: userId || null,
  });

  const newId = Number(result.recordset[0]?.Id);
  res.json({ success: true, id: newId });
}));

// PUT /api/data/:entityId/:rowId — Update existing row
router.put('/:entityId/:rowId', checkEntityPermission('CanUpdate'), asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const rowId = parseInt(req.params.rowId, 10);
  const { code, name, values } = req.body;
  const userId = req.user?.id;

  await execute('usp_Data_SaveRow', {
    EntityId: entityId,
    RowId: { type: sql.BigInt, value: rowId },
    Code: String(code ?? ''),
    Name: String(name ?? ''),
    Values: JSON.stringify(values || []),
    UserId: userId || null,
  });

  res.json({ success: true, id: rowId });
}));

// DELETE /api/data/:entityId/purge — Purge all data rows from entity
// NOTE: Must be registered BEFORE /:entityId to prevent Express from matching "purge" as entityId
// body.saveSnapshot: if true, snapshot all rows to audit log before deleting
router.delete('/:entityId/purge', checkEntityPermission('CanDelete'), asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const userId = req.user?.id;
  const saveSnapshot = req.body?.saveSnapshot !== false; // default true for backwards compat

  const pool = await getPool();
  const transaction = pool.transaction();
  await transaction.begin();

  try {
    // Get entity meta for audit before deleting
    const metaReq = transaction.request();
    metaReq.input('EntityId', sql.Int, entityId);
    const metaResult = await metaReq.execute('usp_Data_GetEntityMeta');
    const entInfo = metaResult.recordset[0] || { EntityName: 'Unknown', ModelName: 'Unknown' };

    // Optionally snapshot all rows before purge for audit trail
    let purgedSnapshot = [];
    if (saveSnapshot) {
      const snapshotReq = transaction.request();
      snapshotReq.input('EntityId', sql.Int, entityId);
      const snapshotResult = await snapshotReq.execute('usp_Data_GetAllRowsSnapshot');
      purgedSnapshot = pivotRowsForAudit(snapshotResult.recordset);
    }

    // Delete all rows
    const delReq = transaction.request();
    delReq.input('EntityId', sql.Int, entityId);
    const delResult = await delReq.execute('usp_Data_DeleteAllRows');
    const deletedCount = delResult.recordset[0]?.DeletedCount || 0;

    // Write audit log (with or without snapshot)
    const auditReq = transaction.request();
    auditReq.input('EntityId', sql.Int, entityId);
    auditReq.input('EntityName', sql.NVarChar(200), entInfo.EntityName);
    auditReq.input('ModelName', sql.NVarChar(200), entInfo.ModelName);
    auditReq.input('Action', sql.NVarChar(20), 'purge');
    auditReq.input('RecordCount', sql.Int, deletedCount);
    auditReq.input('UserId', sql.Int, userId || null);
    auditReq.input('Comment', sql.NVarChar(1000), saveSnapshot
      ? `Purged all data: ${deletedCount} rows deleted (snapshot saved)`
      : `Purged all data: ${deletedCount} rows deleted (no snapshot)`);
    auditReq.input('Details', sql.NVarChar(sql.MAX), purgedSnapshot.length > 0 ? JSON.stringify(purgedSnapshot) : null);
    await auditReq.execute('usp_AuditLog_Write');

    await transaction.commit();

    // Invalidate counts cache
    countsCache = null;
    countsCacheAt = 0;

    res.json({ success: true, deletedCount });
  } catch (err) {
    await transaction.rollback();
    throw err;
  }
}));

// DELETE /api/data/:entityId — Delete rows (body: { rowIds: [] })
// Server-side snapshot: captures full row data before deleting for audit trail.
router.delete('/:entityId', checkEntityPermission('CanDelete'), asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const { rowIds } = req.body;
  const userId = req.user?.id;

  if (!Array.isArray(rowIds) || rowIds.length === 0) {
    return res.status(400).json({ success: false, message: 'rowIds array required' });
  }

  const sanitizedIds = rowIds.filter(id => Number.isInteger(id) && id > 0);
  if (sanitizedIds.length === 0) {
    return res.status(400).json({ success: false, message: 'rowIds must contain positive integers' });
  }

  const rowIdsJson = JSON.stringify(sanitizedIds);
  const pool = await getPool();
  const transaction = pool.transaction();
  await transaction.begin();

  try {
    // Snapshot rows before deleting (server-side, full data)
    const snapshotReq = transaction.request();
    snapshotReq.input('EntityId', sql.Int, entityId);
    snapshotReq.input('RowIdsJson', sql.NVarChar(sql.MAX), rowIdsJson);
    const snapshotResult = await snapshotReq.execute('usp_Data_GetRowsSnapshot');
    const deletedSnapshot = pivotRowsForAudit(snapshotResult.recordset);

    const deleteReq = transaction.request();
    deleteReq.input('EntityId', sql.Int, entityId);
    deleteReq.input('RowIds', sql.NVarChar(sql.MAX), rowIdsJson);
    const result = await deleteReq.execute('usp_Data_DeleteRows');
    const deletedCount = result.recordset[0]?.DeletedCount ?? sanitizedIds.length;

    const metaReq = transaction.request();
    metaReq.input('EntityId', sql.Int, entityId);
    const metaResult = await metaReq.execute('usp_Data_GetEntityMeta');
    const entInfo = metaResult.recordset[0] || { EntityName: 'Unknown', ModelName: 'Unknown' };

    const auditReq = transaction.request();
    auditReq.input('EntityId', sql.Int, entityId);
    auditReq.input('EntityName', sql.NVarChar(200), entInfo.EntityName);
    auditReq.input('ModelName', sql.NVarChar(200), entInfo.ModelName);
    auditReq.input('Action', sql.NVarChar(20), 'delete');
    auditReq.input('RecordCount', sql.Int, deletedCount);
    auditReq.input('UserId', sql.Int, userId || null);
    auditReq.input('Comment', sql.NVarChar(1000), null);
    auditReq.input('Details', sql.NVarChar(sql.MAX), deletedSnapshot.length > 0 ? JSON.stringify(deletedSnapshot) : null);
    await auditReq.execute('usp_AuditLog_Write');

    await transaction.commit();
    res.json({ success: true, deletedCount });
  } catch (err) {
    await transaction.rollback();
    throw err;
  }
}));

// POST /api/data/:entityId/save-changes — Batch save pending changes from grid
router.post('/:entityId/save-changes', checkEntityPermissionAny(['CanCreate', 'CanUpdate']), asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const { changes, comment } = req.body;
  const userId = req.user?.id;
  // changes: [{ rowId, code, name, values: [{attributeId, textValue, intValue, ...}] }]

  if (!Array.isArray(changes) || changes.length === 0) {
    return res.status(400).json({ success: false, message: 'changes array required' });
  }

  // Per-row Create vs Update enforcement
  const perms = req.entityPerms || {};
  const hasCreate = !!perms.CanCreate;
  const hasUpdate = !!perms.CanUpdate;
  for (const change of changes) {
    const isNew = !change.rowId;
    if (isNew && !hasCreate) {
      return res.status(403).json({ success: false, error: 'You do not have Create permission for this entity.' });
    }
    if (!isNew && !hasUpdate) {
      return res.status(403).json({ success: false, error: 'You do not have Update permission for this entity.' });
    }
  }

  const pool = await getPool();
  const transaction = pool.transaction();
  await transaction.begin();

  try {
    // Fetch attribute metadata early — needed for both old-value capture and audit
    const attrReq = transaction.request();
    attrReq.input('EntityId', sql.Int, entityId);
    const attrResult = await attrReq.execute('usp_Data_GetAttributeNames');
    const attrMap = new Map(attrResult.recordset.map(a => [Number(a.Id), {
      name: a.Name, displayName: a.DisplayName, dataType: a.DataType,
    }]));

    // For edit rows: snapshot current values BEFORE saving so we can record old→new
    // oldValuesByRowId: rowId → { code, name, attrs: Map(displayName → formattedValue) }
    const oldValuesByRowId = new Map();
    for (const change of changes) {
      if (!change.rowId) continue;
      const oldReq = transaction.request();
      oldReq.input('EntityId', sql.Int, entityId);
      oldReq.input('RowId', sql.BigInt, change.rowId);
      const oldResult = await oldReq.execute('usp_Data_GetSingleRow');
      const baseRow = oldResult.recordset[0];
      const attrs = new Map();
      for (const r of oldResult.recordset) {
        if (!r.AttributeId) continue;
        const attr = attrMap.get(Number(r.AttributeId));
        if (!attr) continue;
        let val = null;
        if (attr.dataType === 'Domain' && r.DomainValue != null) {
          val = r.DomainCode && r.DomainName ? `{${r.DomainCode}} ${r.DomainName}` : String(r.DomainValue);
        } else {
          val = r.TextValue ?? r.IntValue ?? r.DecimalValue ?? r.DateTimeValue ?? null;
        }
        if (val != null) attrs.set(attr.displayName, val);
      }
      oldValuesByRowId.set(Number(change.rowId), {
        code: baseRow?.Code ?? '',
        name: baseRow?.Name ?? '',
        attrs,
      });
    }

    const savedIds = [];
    const savedTimestamps = [];

    for (const change of changes) {
      const request = transaction.request();
      request.input('EntityId', sql.Int, entityId);
      request.input('RowId', sql.BigInt, change.rowId || null);
      request.input('Code', sql.NVarChar(200), String(change.code ?? ''));
      request.input('Name', sql.NVarChar(500), String(change.name ?? ''));
      request.input('Values', sql.NVarChar(sql.MAX), JSON.stringify(change.values || []));
      request.input('UserId', sql.Int, userId || null);

      const result = await request.execute('usp_Data_SaveRow');
      const row = result.recordset[0];
      savedIds.push(Number(row?.Id));
      savedTimestamps.push({
        modifiedAt: row?.ModifiedAt || null,
        createdAt: row?.CreatedAt || null,
      });
    }

    // Write audit log
    if (comment || changes.length > 0) {
      // Get entity meta
      const metaReq = transaction.request();
      metaReq.input('EntityId', sql.Int, entityId);
      const metaResult = await metaReq.execute('usp_Data_GetEntityMeta');
      const entInfo = metaResult.recordset[0] || { EntityName: 'Unknown', ModelName: 'Unknown' };

      // Determine action: 'create' if all rows are new, 'edit' if all existing, 'create/edit' if mixed
      const newCount = changes.filter(c => !c.rowId).length;
      const editCount = changes.length - newCount;
      const action = newCount > 0 && editCount === 0 ? 'create' : editCount > 0 && newCount === 0 ? 'edit' : 'create/edit';

      // Collect domain value IDs that need resolution
      const domainIdsToResolve = new Set();
      for (const change of changes) {
        for (const v of (change.values || [])) {
          const attr = attrMap.get(Number(v.attributeId));
          if (attr?.dataType === 'Domain' && v.domainValue) domainIdsToResolve.add(Number(v.domainValue));
        }
      }

      // Batch-resolve domain IDs to display values
      const domainDisplay = new Map();
      if (domainIdsToResolve.size > 0) {
        const domReq = transaction.request();
        domReq.input('RowIdsJson', sql.NVarChar(sql.MAX), JSON.stringify([...domainIdsToResolve]));
        const domResult = await domReq.execute('usp_Data_ResolveDomainIds');
        for (const r of domResult.recordset) {
          domainDisplay.set(Number(r.Id), r.Code && r.Name ? `{${r.Code}} ${r.Name}` : String(r.Id));
        }
      }

      // Build readable details with old→new change tracking for edits
      const detailRecords = changes.map((change, idx) => {
        const record = { code: change.code || '', name: change.name || '' };
        if (savedIds[idx]) record._savedId = savedIds[idx];
        const isNew = !change.rowId;
        const changedFieldSet = new Set(change.changedFields || []);

        if (!isNew) {
          // Edit: build structured changes array with old and new values
          const oldSnap = oldValuesByRowId.get(Number(change.rowId)) || { code: '', name: '', attrs: new Map() };
          const changesArr = [];

          // Code / Name changes (excluded from change.values, tracked separately)
          if (changedFieldSet.size === 0 || changedFieldSet.has('code')) {
            const newCode = change.code || '';
            if (newCode !== oldSnap.code) {
              changesArr.push({ field: 'Code', oldValue: oldSnap.code || null, newValue: newCode || null });
            }
          }
          if (changedFieldSet.size === 0 || changedFieldSet.has('name')) {
            const newName = change.name || '';
            if (newName !== oldSnap.name) {
              changesArr.push({ field: 'Name', oldValue: oldSnap.name || null, newValue: newName || null });
            }
          }

          // Custom attribute changes
          for (const v of (change.values || [])) {
            const attr = attrMap.get(Number(v.attributeId));
            if (!attr) continue;
            if (changedFieldSet.size > 0 && !changedFieldSet.has(attr.name)) continue;
            let newVal = null;
            if (attr.dataType === 'Domain' && v.domainValue) {
              newVal = domainDisplay.get(Number(v.domainValue)) || String(v.domainValue);
            } else {
              newVal = v.intValue ?? v.decimalValue ?? v.dateTimeValue ?? v.textValue ?? null;
            }
            const oldVal = oldSnap.attrs.get(attr.displayName) ?? null;
            changesArr.push({
              field: attr.displayName,
              oldValue: oldVal !== null ? String(oldVal) : null,
              newValue: newVal !== null ? String(newVal) : null,
            });
          }
          if (changesArr.length > 0) record.changes = changesArr;
        } else {
          // Create: store all provided field values as a flat snapshot
          for (const v of (change.values || [])) {
            const attr = attrMap.get(Number(v.attributeId));
            if (!attr) continue;
            if (attr.dataType === 'Domain' && v.domainValue) {
              record[attr.displayName] = domainDisplay.get(Number(v.domainValue)) || String(v.domainValue);
            } else {
              const val = v.intValue ?? v.decimalValue ?? v.dateTimeValue ?? v.textValue ?? null;
              if (val != null) record[attr.displayName] = val;
            }
          }
        }
        return record;
      });

      const auditReq = transaction.request();
      auditReq.input('EntityId', sql.Int, entityId);
      auditReq.input('EntityName', sql.NVarChar(200), entInfo.EntityName);
      auditReq.input('ModelName', sql.NVarChar(200), entInfo.ModelName);
      auditReq.input('Action', sql.NVarChar(20), action);
      auditReq.input('RecordCount', sql.Int, changes.length);
      auditReq.input('UserId', sql.Int, userId || null);
      auditReq.input('Comment', sql.NVarChar(1000), comment || null);
      auditReq.input('Details', sql.NVarChar(sql.MAX), JSON.stringify(detailRecords));
      await auditReq.execute('usp_AuditLog_Write');
    }

    await transaction.commit();
    res.json({ success: true, savedIds, savedTimestamps });
  } catch (err) {
    import('../logger.js').then(m => m.default.error(`save-changes: ${err.message}`, {
      method: 'POST', path: req.path, statusCode: 500,
      stack: err.stack, requestBody: JSON.stringify(req.body)?.slice(0, 2000),
    })).catch(() => {});
    await transaction.rollback();
    // Check for validation error from stored procedure
    if (err.number === 50001) {
      return res.status(400).json({ success: false, message: err.message, validationError: true });
    }
    throw err;
  }
}));

// POST /api/data/:entityId/bulk — Bulk import/overwrite
router.post('/:entityId/bulk', checkEntityPermissionAny(['CanCreate', 'CanUpdate', 'CanDelete']), asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const { rows, action } = req.body;
  const userId = req.user?.id;
  // action: 'import' | 'overwrite' | 'delete_import'
  // rows: [{ code, name, values: [{attributeId, textValue, ...}] }]

  if (!Array.isArray(rows)) {
    return res.status(400).json({ success: false, message: 'rows array required' });
  }

  const VALID_ACTIONS = ['import', 'overwrite', 'delete_import'];
  if (!VALID_ACTIONS.includes(action)) {
    return res.status(400).json({ success: false, message: 'action must be import, overwrite, or delete_import' });
  }

  // Action-level permission enforcement
  const perms = req.entityPerms || {};
  if (action === 'delete_import') {
    if (!perms.CanDelete) return res.status(403).json({ success: false, error: 'Delete+Import requires Delete permission.' });
    if (!perms.CanCreate) return res.status(403).json({ success: false, error: 'Delete+Import requires Create permission.' });
  } else if (action === 'overwrite') {
    if (!perms.CanUpdate) return res.status(403).json({ success: false, error: 'Overwrite requires Update permission.' });
  } else if (action === 'import') {
    if (!perms.CanCreate) return res.status(403).json({ success: false, error: 'Import requires Create permission.' });
  }

  const pool = await getPool();
  const transaction = pool.transaction();
  await transaction.begin();

  try {
    let imported = 0, updated = 0, skipped = 0;

    if (action === 'delete_import') {
      // Delete all existing rows for this entity
      const delReq = transaction.request();
      delReq.input('EntityId', sql.Int, entityId);
      await delReq.execute('usp_Data_DeleteAllRows');
    }

    // Get existing codes for this entity (for import/overwrite logic)
    const existReq = transaction.request();
    existReq.input('EntityId', sql.Int, entityId);
    const existingResult = await existReq.execute('usp_Data_GetExistingCodes');
    const existingByCode = new Map(existingResult.recordset.map(r => [r.Code, r.Id]));

    for (const row of rows) {
      const existingId = existingByCode.get(row.code);

      if (action === 'import' && existingId) {
        skipped++;
        continue;
      }

      const request = transaction.request();
      request.input('EntityId', sql.Int, entityId);
      request.input('RowId', sql.BigInt, (action === 'overwrite' && existingId) ? existingId : null);
      request.input('Code', sql.NVarChar(200), String(row.code ?? ''));
      request.input('Name', sql.NVarChar(500), String(row.name ?? ''));
      request.input('Values', sql.NVarChar(sql.MAX), JSON.stringify(row.values || []));
      request.input('UserId', sql.Int, userId || null);

      await request.execute('usp_Data_SaveRow');

      if (existingId && action === 'overwrite') {
        updated++;
      } else {
        imported++;
      }
    }

    // Write audit log
    const metaReq = transaction.request();
    metaReq.input('EntityId', sql.Int, entityId);
    const metaResult = await metaReq.execute('usp_Data_GetEntityMeta');
    const entInfo = metaResult.recordset[0] || { EntityName: 'Unknown', ModelName: 'Unknown' };

    const auditReq = transaction.request();
    auditReq.input('EntityId', sql.Int, entityId);
    auditReq.input('EntityName', sql.NVarChar(200), entInfo.EntityName);
    auditReq.input('ModelName', sql.NVarChar(200), entInfo.ModelName);
    auditReq.input('Action', sql.NVarChar(20), 'import');
    auditReq.input('RecordCount', sql.Int, imported + updated);
    auditReq.input('UserId', sql.Int, userId || null);
    auditReq.input('Comment', sql.NVarChar(1000), `Bulk ${action}: ${imported} imported, ${updated} updated, ${skipped} skipped`);
    auditReq.input('Details', sql.NVarChar(sql.MAX), null);
    await auditReq.execute('usp_AuditLog_Write');

    await transaction.commit();
    res.json({ success: true, imported, updated, skipped });
  } catch (err) {
    await transaction.rollback();
    throw err;
  }
}));

export default router;
