import { Router } from 'express';
import { execute, sql } from '../db.js';
import { asyncHandler } from '../middleware/validate.js';
import { requireAdmin } from '../middleware/authzMiddleware.js';
import logger from '../logger.js';
import { readFileSync, statSync, existsSync, unlinkSync } from 'fs';

const router = Router();

// Allowed sort columns (whitelist to prevent SQL injection)
const ALLOWED_SORT_COLS = ['Timestamp', 'Level', 'StatusCode', 'Path', 'Message'];
const ALLOWED_SORT_DIRS = ['ASC', 'DESC'];

// GET /api/error-log — Paginated error log with filters and sorting
router.get('/', requireAdmin, asyncHandler(async (req, res) => {
  const { page = 1, pageSize = 50, level, search, dateFrom, dateTo, sortColumn, sortDirection } = req.query;

  const sortCol = ALLOWED_SORT_COLS.includes(sortColumn) ? sortColumn : 'Timestamp';
  const sortDir = ALLOWED_SORT_DIRS.includes(sortDirection?.toUpperCase()) ? sortDirection.toUpperCase() : 'DESC';

  const result = await execute('usp_ErrorLog_Get', {
    PageNumber: { type: sql.Int, value: parseInt(page, 10) || 1 },
    PageSize: { type: sql.Int, value: parseInt(pageSize, 10) || 50 },
    Level: level || null,
    SearchText: search || null,
    DateFrom: dateFrom || null,
    DateTo: dateTo || null,
    SortColumn: sortCol,
    SortDirection: sortDir,
  });

  const rows = result.recordset || [];
  const total = rows.length > 0 ? rows[0].TotalCount : 0;
  const entries = rows.map(({ TotalCount, ...r }) => r);

  res.json({
    entries,
    pagination: {
      totalCount: total,
      pageNumber: parseInt(page, 10) || 1,
      pageSize: parseInt(pageSize, 10) || 50,
      totalPages: Math.ceil(total / (parseInt(pageSize, 10) || 50)),
    },
  });
}));

// GET /api/error-log/stats — Summary stats
router.get('/stats', requireAdmin, asyncHandler(async (req, res) => {
  const result = await execute('usp_ErrorLog_GetStats');
  const stats = result.recordset[0] || {
    TotalEntries: 0, ErrorCount: 0, WarnCount: 0, InfoCount: 0,
    OldestEntry: null, NewestEntry: null,
  };

  let fileSize = 0;
  let fileExists = false;
  let fileLines = 0;
  try {
    if (existsSync(logger.LOG_FILE)) {
      fileExists = true;
      fileSize = statSync(logger.LOG_FILE).size;
      const content = readFileSync(logger.LOG_FILE, 'utf8');
      fileLines = content.trim().split('\n').filter(Boolean).length;
    }
  } catch { /* ignore */ }

  res.json({
    database: {
      totalEntries: stats.TotalEntries,
      errorCount: stats.ErrorCount,
      warnCount: stats.WarnCount,
      infoCount: stats.InfoCount,
      oldestEntry: stats.OldestEntry,
      newestEntry: stats.NewestEntry,
    },
    file: { exists: fileExists, sizeBytes: fileSize, lineCount: fileLines },
  });
}));

// POST /api/error-log/cleanup — Delete old entries by retention
router.post('/cleanup', requireAdmin, asyncHandler(async (req, res) => {
  const { retentionDays = 30 } = req.body;
  const result = await execute('usp_ErrorLog_Cleanup', {
    RetentionDays: { type: sql.Int, value: parseInt(retentionDays, 10) || 30 },
  });
  const deletedCount = result.recordset[0]?.DeletedCount || 0;
  res.json({ success: true, deletedCount });
}));

// DELETE /api/error-log/truncate — Delete ALL database entries
router.delete('/truncate', requireAdmin, asyncHandler(async (req, res) => {
  const result = await execute('usp_ErrorLog_Truncate');
  const deletedCount = result.recordset[0]?.DeletedCount || 0;
  res.json({ success: true, deletedCount });
}));

// DELETE /api/error-log/file — Delete the system log file
router.delete('/file', requireAdmin, asyncHandler(async (req, res) => {
  if (existsSync(logger.LOG_FILE)) {
    unlinkSync(logger.LOG_FILE);
    // Also delete rotation files
    for (let i = 1; i <= 3; i++) {
      const rotFile = logger.LOG_FILE.replace('.txt', `.${i}.txt`);
      if (existsSync(rotFile)) unlinkSync(rotFile);
    }
    res.json({ success: true, message: 'Log file deleted' });
  } else {
    res.json({ success: true, message: 'Log file does not exist' });
  }
}));

// GET /api/error-log/file/download — Download raw errorlog.txt
router.get('/file/download', requireAdmin, asyncHandler(async (req, res) => {
  if (!existsSync(logger.LOG_FILE)) {
    return res.status(404).json({ error: 'Log file not found' });
  }
  res.download(logger.LOG_FILE, 'errorlog.txt');
}));

// GET /api/error-log/file — Last N lines from errorlog.txt
router.get('/file', requireAdmin, asyncHandler(async (req, res) => {
  const { lines = 200 } = req.query;
  const maxLines = Math.min(parseInt(lines, 10) || 200, 1000);

  if (!existsSync(logger.LOG_FILE)) {
    return res.json({ entries: [], fileExists: false, totalLines: 0 });
  }

  try {
    const content = readFileSync(logger.LOG_FILE, 'utf8');
    const allLines = content.trim().split('\n').filter(Boolean);
    const lastLines = allLines.slice(-maxLines);
    const entries = lastLines.map(line => {
      try { return JSON.parse(line); } catch { return { message: line, level: 'info' }; }
    }).reverse(); // newest first

    res.json({ entries, fileExists: true, totalLines: allLines.length });
  } catch (err) {
    logger.warn(`Failed to read log file: ${err.message}`, {
      error: err.message,
      category: 'errorlog',
    });
    res.json({ entries: [], fileExists: true, totalLines: 0, error: err.message });
  }
}));

export default router;
