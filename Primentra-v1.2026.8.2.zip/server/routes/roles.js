import { Router } from 'express';
import { execute } from '../db.js';
import { asyncHandler, requireFields, requireId } from '../middleware/validate.js';

const router = Router();

// ==========================================
// ROLES
// ==========================================

// GET /api/roles — All roles with members
router.get('/', asyncHandler(async (req, res) => {
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ success: false, error: 'Administrator access required.' });
  }
  const result = await execute('usp_Role_GetAll');
  const roles = result.recordsets[0];
  const members = result.recordsets[1];

  const membersByRole = {};
  for (const m of members) {
    if (!membersByRole[m.RoleId]) membersByRole[m.RoleId] = [];
    membersByRole[m.RoleId].push({ userId: m.UserId, email: m.Email, displayName: m.DisplayName });
  }

  res.json(roles.map(r => ({
    id: r.Id,
    name: r.Name,
    description: r.Description,
    isAdmin: !!r.IsAdmin,
    canApprove: !!r.CanApprove,
    members: membersByRole[r.Id] || [],
    createdAt: r.CreatedAt,
  })));
}));

// POST /api/roles — Create role
router.post('/', asyncHandler(async (req, res) => {
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ success: false, error: 'Administrator access required.' });
  }
  requireFields(req.body, ['name']);
  const { name, description, isAdmin, canApprove, members } = req.body;

  const result = await execute('usp_Role_Create', {
    Name: name,
    Description: description || null,
    IsAdmin: isAdmin ? 1 : 0,
    CanApprove: canApprove ? 1 : 0,
    MembersJson: Array.isArray(members) ? JSON.stringify(members) : null,
  });

  const role = result.recordsets[0][0];
  const returnedMembers = result.recordsets[1] || [];
  res.json({
    id: role.Id,
    name: role.Name,
    description: role.Description,
    isAdmin: !!role.IsAdmin,
    canApprove: !!role.CanApprove,
    members: returnedMembers.map(m => ({ userId: m.UserId, email: m.Email, displayName: m.DisplayName })),
  });
}));

// PUT /api/roles/:id — Update role
router.put('/:id', asyncHandler(async (req, res) => {
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ success: false, error: 'Administrator access required.' });
  }
  const id = requireId(req.params);
  const { name, description, isAdmin, canApprove, members } = req.body;

  const result = await execute('usp_Role_Update', {
    Id: id,
    Name: name || null,
    Description: description !== undefined ? description : null,
    IsAdmin: isAdmin !== undefined ? (isAdmin ? 1 : 0) : null,
    CanApprove: canApprove !== undefined ? (canApprove ? 1 : 0) : null,
    MembersJson: Array.isArray(members) ? JSON.stringify(members) : null,
  });

  if (result.recordsets[0].length === 0) {
    return res.status(404).json({ success: false, message: 'Role not found' });
  }

  const role = result.recordsets[0][0];
  const returnedMembers = result.recordsets[1] || [];
  res.json({
    id: role.Id,
    name: role.Name,
    description: role.Description,
    isAdmin: !!role.IsAdmin,
    canApprove: !!role.CanApprove,
    members: returnedMembers.map(m => ({ userId: m.UserId, email: m.Email, displayName: m.DisplayName })),
  });
}));

// DELETE /api/roles/:id — Delete role (cascades members + permissions)
router.delete('/:id', asyncHandler(async (req, res) => {
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ success: false, error: 'Administrator access required.' });
  }
  const id = requireId(req.params);
  const result = await execute('usp_Role_Delete', { Id: id });
  res.json({ success: true, deleted: (result.recordset[0]?.Deleted || 0) > 0 });
}));

// ==========================================
// PERMISSIONS
// ==========================================

// GET /api/roles/permissions — All permissions (optionally filtered by roleId)
// Non-admin users may call this to retrieve permissions for their own roles only.
router.get('/permissions', asyncHandler(async (req, res) => {
  const mapPerm = p => ({
    id: p.Id, roleId: p.RoleId, scope: p.Scope, targetId: p.TargetId, level: p.Level,
    canCreate: !!p.CanCreate, canRead: !!p.CanRead, canUpdate: !!p.CanUpdate,
    canDelete: !!p.CanDelete, isModerator: !!p.IsModerator, isExplicit: !!p.IsExplicit,
  });

  if (!req.user?.isAdministrator) {
    // Non-admin: return only permissions for their own roles
    const userRoleIds = (req.user?.roles || []).map(r => r.roleId);
    if (userRoleIds.length === 0) return res.json([]);
    const results = await Promise.all(
      userRoleIds.map(rid => execute('usp_Permission_GetByScope', { RoleId: rid }))
    );
    return res.json(results.flatMap(r => r.recordset).map(mapPerm));
  }

  // Admin: return all permissions (or filtered by roleId query param)
  const roleId = req.query.roleId ? parseInt(req.query.roleId, 10) : null;
  const result = await execute('usp_Permission_GetByScope', { RoleId: roleId });
  res.json(result.recordset.map(mapPerm));
}));

// POST /api/roles/permissions — Create or update permission (upsert)
router.post('/permissions', asyncHandler(async (req, res) => {
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ success: false, error: 'Administrator access required.' });
  }
  requireFields(req.body, ['roleId', 'scope', 'targetId']);
  const { roleId, scope, targetId, level, canCreate, canRead, canUpdate, canDelete, isModerator, isExplicit } = req.body;

  const result = await execute('usp_Permission_Upsert', {
    RoleId: roleId,
    Scope: scope,
    TargetId: targetId,
    Level: level || null,
    CanCreate: canCreate ? 1 : 0,
    CanRead: canRead ? 1 : 0,
    CanUpdate: canUpdate ? 1 : 0,
    CanDelete: canDelete ? 1 : 0,
    IsModerator: isModerator ? 1 : 0,
    IsExplicit: isExplicit ? 1 : 0,
    UserId: req.user?.id || null,
  });

  if (result.recordset[0]?.Removed) {
    return res.json({ success: true, removed: true });
  }

  const p = result.recordset[0];
  res.json({
    id: p.Id, roleId: p.RoleId, scope: p.Scope, targetId: p.TargetId, level: p.Level,
    canCreate: !!p.CanCreate, canRead: !!p.CanRead, canUpdate: !!p.CanUpdate,
    canDelete: !!p.CanDelete, isModerator: !!p.IsModerator, isExplicit: !!p.IsExplicit,
  });
}));

// POST /api/roles/permissions/bulk — Bulk save permissions for a role
router.post('/permissions/bulk', asyncHandler(async (req, res) => {
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ success: false, error: 'Administrator access required.' });
  }
  const { roleId, permissions } = req.body;
  if (!roleId || !Array.isArray(permissions)) {
    return res.status(400).json({ success: false, message: 'roleId and permissions array required' });
  }

  await execute('usp_Permission_BulkSave', {
    RoleId: roleId,
    PermissionsJson: JSON.stringify(permissions),
    UserId: req.user?.id || null,
  });

  res.json({ success: true });
}));

// DELETE /api/roles/permissions/:id — Delete single permission
router.delete('/permissions/:id', asyncHandler(async (req, res) => {
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ success: false, error: 'Administrator access required.' });
  }
  const id = requireId(req.params);
  const result = await execute('usp_Permission_Delete', { Id: id });
  res.json({ success: true, deleted: (result.recordset[0]?.Deleted || 0) > 0 });
}));

export default router;
