import { Router } from 'express';
import { asyncHandler } from '../middleware/validate.js';
import { sendTestEmail } from '../email.js';
import logger from '../logger.js';

const router = Router();

// POST /test — send test email to verify SMTP configuration
router.post('/test', asyncHandler(async (req, res) => {
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ success: false, error: 'Only administrators can send test emails.' });
  }

  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ success: false, error: 'Recipient email is required.' });
  }

  try {
    await sendTestEmail(email);
    res.json({ success: true, message: `Test email sent to ${email}.` });
  } catch (err) {
    logger.error(`SMTP test email failed: ${err.message}`, {
      method: 'POST',
      path: '/api/email/test',
      statusCode: 500,
      userId: req.user?.id || null,
      stack: err.stack,
    });
    res.json({ success: false, error: err.message });
  }
}));

export default router;
