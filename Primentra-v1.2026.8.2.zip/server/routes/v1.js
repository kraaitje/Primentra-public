/**
 * Public REST API v1
 * All endpoints require authentication via X-API-Key header or session Bearer token.
 * Permissions are enforced identically to the internal app (same SPs, same role checks).
 *
 * CORS: Not supported in v1. This API is intended for server-to-server use only.
 */
import { Router } from 'express';
import { rateLimit } from 'express-rate-limit';
import { execute, sql } from '../db.js';
import { asyncHandler } from '../middleware/validate.js';
import { checkEntityPermission } from '../middleware/permissionMiddleware.js';
import { clientKey } from '../utils/clientKey.js';

const router = Router();

// Rate limit the public API: 300 requests/minute, keyed by API key (falling
// back to client IP for session-token callers). Prevents a single key from
// overwhelming the server.
const v1Limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.headers['x-api-key'] || clientKey(req),
  message: { success: false, error: { code: 'RATE_LIMITED', message: 'Too many requests. Please slow down.' } },
});
router.use(v1Limiter);

const MAX_PAGE_SIZE = 1000;
const DEFAULT_PAGE_SIZE = 100;

// ── Response helpers ─────────────────────────────────────────────────────────

function ok(res, data, pagination) {
  const body = { success: true, data };
  if (pagination) body.pagination = pagination;
  res.json(body);
}

function err(res, status, code, message) {
  res.status(status).json({ success: false, error: { code, message } });
}

// ── Audit helper ─────────────────────────────────────────────────────────────

async function writeAudit(entityId, entityName, modelName, action, userId, comment) {
  try {
    await execute('usp_AuditLog_Write', {
      EntityId: entityId,
      EntityName: entityName,
      ModelName: modelName,
      Action: action,
      RecordCount: 1,
      UserId: userId || null,
      Comment: comment || null,
      Details: null,
    });
  } catch {
    // Audit failures are non-blocking — never let them break the API response
  }
}

// ── EAV pivot (replicates data.js pivotRows for API output) ──────────────────

function pivotRows(records) {
  const rowMap = new Map();
  for (const r of records) {
    const numId = Number(r.Id);
    if (!rowMap.has(numId)) {
      rowMap.set(numId, {
        id: numId,
        code: r.Code,
        name: r.Name,
        createdAt: r.CreatedAt,
        modifiedAt: r.ModifiedAt,
        createdBy: r.CreatedBy,
        modifiedBy: r.ModifiedBy,
      });
    }
    const row = rowMap.get(numId);
    if (r.AttributeName) {
      if (r.DataType === 'Domain' && r.DomainValue) {
        row[r.AttributeName] = Number(r.DomainValue);
        row[`_${r.AttributeName}_display`] = r.DomainCode && r.DomainName
          ? `{${r.DomainCode}} ${r.DomainName}` : String(r.DomainValue);
      } else if (r.DataType === 'Int') {
        row[r.AttributeName] = r.IntValue;
      } else if (r.DataType === 'Boolean') {
        row[r.AttributeName] = r.IntValue != null ? Number(r.IntValue) : null;
      } else if (r.DataType === 'Decimal') {
        row[r.AttributeName] = r.DecimalValue != null ? parseFloat(r.DecimalValue) : null;
      } else if (r.DataType === 'DateTime') {
        row[r.AttributeName] = r.DateTimeValue;
      } else {
        row[r.AttributeName] = r.TextValue;
      }
    }
  }
  return Array.from(rowMap.values());
}

// ── Entity metadata ───────────────────────────────────────────────────────────

// GET /api/v1/entities — List entities the caller can read
// Admins see all entities. Non-admins are filtered to entities where their
// effective permission grants CanRead. No permission-aware list SP exists, so
// we post-filter; the per-entity CanRead checks run in parallel to avoid a
// sequential N+1 round-trip.
router.get('/entities', asyncHandler(async (req, res) => {
  const result = await execute('usp_Entity_GetAll', { ModelId: null });
  let entities = (result.recordset || []).map(e => ({
    id: e.Id,
    name: e.Name,
    description: e.Description,
    modelId: e.ModelId,
    modelName: e.ModelName,
  }));

  if (!req.user?.isAdministrator) {
    const readable = await Promise.all(entities.map(async (e) => {
      const perm = await execute('usp_Permission_GetEffective', { UserId: req.user.id, EntityId: e.id });
      return perm.recordset?.[0]?.CanRead ? e : null;
    }));
    entities = readable.filter(Boolean);
  }

  ok(res, entities);
}));

// GET /api/v1/entities/:entityId — Entity metadata + attributes
router.get('/entities/:entityId', asyncHandler(async (req, res) => {
  const entityId = parseInt(req.params.entityId, 10);
  if (!entityId || isNaN(entityId)) return err(res, 400, 'VALIDATION_ERROR', 'entityId must be a positive integer.');

  // Non-admins must have CanRead on this specific entity.
  if (!req.user?.isAdministrator) {
    const perm = await execute('usp_Permission_GetEffective', { UserId: req.user.id, EntityId: entityId });
    if (!perm.recordset?.[0]?.CanRead) {
      return err(res, 403, 'PERMISSION_DENIED', 'You do not have permission to read this entity.');
    }
  }

  const [entityResult, attrResult] = await Promise.all([
    execute('usp_Entity_GetById', { Id: entityId }),
    execute('usp_Attribute_GetByEntity', { EntityId: entityId }).catch(() => ({ recordset: [] })),
  ]);

  const entity = entityResult.recordsets?.[0]?.[0] || entityResult.recordset?.[0];
  if (!entity) return err(res, 404, 'NOT_FOUND', 'Entity not found.');

  const attributes = (attrResult.recordset || []).map(a => ({
    id: a.Id,
    name: a.Name,
    displayName: a.DisplayName,
    dataType: a.DataType,
    isRequired: !!a.IsRequired,
    sortOrder: a.SortOrder,
  }));

  ok(res, {
    id: entity.Id,
    name: entity.Name,
    description: entity.Description,
    modelId: entity.ModelId,
    modelName: entity.ModelName,
    attributes,
  });
}));

// ── Entity record CRUD ────────────────────────────────────────────────────────

// GET /api/v1/entities/:entityId/records — Paginated record list
router.get('/entities/:entityId/records', checkEntityPermission('CanRead'), asyncHandler(async (req, res) => {
  const entityId = parseInt(req.params.entityId, 10);
  if (!entityId || isNaN(entityId)) return err(res, 400, 'VALIDATION_ERROR', 'entityId must be a positive integer.');

  const rawPage = parseInt(req.query.page, 10) || 1;
  const rawSize = parseInt(req.query.pageSize, 10) || DEFAULT_PAGE_SIZE;
  const pageSize = Math.min(rawSize, MAX_PAGE_SIZE);
  const search = req.query.search || null;

  const result = await execute('usp_Data_GetByEntityPaginated', {
    EntityId: entityId,
    PageNumber: { type: sql.Int, value: rawPage },
    PageSize: { type: sql.Int, value: pageSize },
    SearchText: search,
    SortField: null,
    SortDirection: 'ASC',
    ColumnFilters: null,
    TextFilters: null,
  });

  const rows = pivotRows(result.recordsets[0] || []);
  const meta = result.recordsets[1]?.[0] || { TotalCount: 0, PageNumber: rawPage, PageSize: pageSize, TotalPages: 0 };

  ok(res, rows, {
    page: meta.PageNumber,
    pageSize: meta.PageSize,
    total: meta.TotalCount,
    totalPages: meta.TotalPages,
  });
}));

// GET /api/v1/entities/:entityId/records/:recordId — Single record
router.get('/entities/:entityId/records/:recordId', checkEntityPermission('CanRead'), asyncHandler(async (req, res) => {
  const entityId = parseInt(req.params.entityId, 10);
  const recordId = parseInt(req.params.recordId, 10);
  if (!entityId || !recordId) return err(res, 400, 'VALIDATION_ERROR', 'entityId and recordId must be positive integers.');

  const result = await execute('usp_Data_GetSingleRow', {
    EntityId: entityId,
    RowId: { type: sql.BigInt, value: recordId },
  });

  const rows = pivotRows(result.recordset || []);
  if (!rows.length) return err(res, 404, 'NOT_FOUND', 'Record not found.');

  ok(res, rows[0]);
}));

// POST /api/v1/entities/:entityId/records — Create record
router.post('/entities/:entityId/records', checkEntityPermission('CanCreate'), asyncHandler(async (req, res) => {
  const entityId = parseInt(req.params.entityId, 10);
  if (!entityId) return err(res, 400, 'VALIDATION_ERROR', 'entityId must be a positive integer.');

  const { code, name, values } = req.body;
  if (!code && !name) return err(res, 400, 'VALIDATION_ERROR', 'code or name is required.');

  // Fetch entity meta for audit log
  const metaResult = await execute('usp_Entity_GetById', { Id: entityId });
  const entityMeta = metaResult.recordsets?.[0]?.[0] || metaResult.recordset?.[0] || {};

  const result = await execute('usp_Data_SaveRow', {
    EntityId: entityId,
    RowId: { type: sql.BigInt, value: null },
    Code: String(code ?? ''),
    Name: String(name ?? ''),
    Values: JSON.stringify(values || []),
    UserId: req.user?.id || null,
  });

  const newId = Number(result.recordset[0]?.Id);
  const createLabel = [code, name].filter(Boolean).join(' — ') || `Record #${newId}`;
  writeAudit(entityId, entityMeta.Name || 'Unknown', entityMeta.ModelName || 'Unknown', 'create', req.user?.id, createLabel);
  ok(res, { id: newId });
}));

// PUT /api/v1/entities/:entityId/records/:recordId — Update record
router.put('/entities/:entityId/records/:recordId', checkEntityPermission('CanUpdate'), asyncHandler(async (req, res) => {
  const entityId = parseInt(req.params.entityId, 10);
  const recordId = parseInt(req.params.recordId, 10);
  if (!entityId || !recordId) return err(res, 400, 'VALIDATION_ERROR', 'entityId and recordId must be positive integers.');

  const { code, name, values } = req.body;

  const [metaResult, existsResult] = await Promise.all([
    execute('usp_Entity_GetById', { Id: entityId }),
    execute('usp_Data_GetSingleRow', { EntityId: entityId, RowId: { type: sql.BigInt, value: recordId } }),
  ]);
  const entityMeta = metaResult.recordsets?.[0]?.[0] || metaResult.recordset?.[0] || {};
  if (!pivotRows(existsResult.recordset || []).length) return err(res, 404, 'NOT_FOUND', 'Record not found.');

  await execute('usp_Data_SaveRow', {
    EntityId: entityId,
    RowId: { type: sql.BigInt, value: recordId },
    Code: String(code ?? ''),
    Name: String(name ?? ''),
    Values: JSON.stringify(values || []),
    UserId: req.user?.id || null,
  });

  const editLabel = [code, name].filter(Boolean).join(' — ') || `Record #${recordId}`;
  writeAudit(entityId, entityMeta.Name || 'Unknown', entityMeta.ModelName || 'Unknown', 'edit', req.user?.id, editLabel);
  ok(res, { id: recordId });
}));

// DELETE /api/v1/entities/:entityId/records/:recordId — Delete record
router.delete('/entities/:entityId/records/:recordId', checkEntityPermission('CanDelete'), asyncHandler(async (req, res) => {
  const entityId = parseInt(req.params.entityId, 10);
  const recordId = parseInt(req.params.recordId, 10);
  if (!entityId || !recordId) return err(res, 400, 'VALIDATION_ERROR', 'entityId and recordId must be positive integers.');

  const [metaResult, recordResult] = await Promise.all([
    execute('usp_Entity_GetById', { Id: entityId }),
    execute('usp_Data_GetSingleRow', { EntityId: entityId, RowId: { type: sql.BigInt, value: recordId } }),
  ]);
  const entityMeta = metaResult.recordsets?.[0]?.[0] || metaResult.recordset?.[0] || {};
  const recordRows = pivotRows(recordResult.recordset || []);
  const recordLabel = recordRows[0]
    ? [recordRows[0].code, recordRows[0].name].filter(Boolean).join(' — ') || `Record #${recordId}`
    : `Record #${recordId}`;

  const result = await execute('usp_Data_DeleteRows', {
    EntityId: entityId,
    RowIds: JSON.stringify([recordId]),
  });

  const deleted = result.recordset?.[0]?.DeletedCount ?? 0;
  if (deleted === 0) return err(res, 404, 'NOT_FOUND', 'Record not found.');

  writeAudit(entityId, entityMeta.Name || 'Unknown', entityMeta.ModelName || 'Unknown', 'delete', req.user?.id, recordLabel);
  ok(res, { deleted: true });
}));

export default router;
