import { Router } from 'express';
import { execute, query } from '../db.js';
import { asyncHandler, requireFields, requireId } from '../middleware/validate.js';
import { requireAdmin } from '../middleware/authzMiddleware.js';

const router = Router();

function mapModel(r) {
  return {
    id: r.Id,
    name: r.Name,
    description: r.Description,
    isActive: r.IsActive,
    sortOrder: r.SortOrder,
    createdDate: r.CreatedAt?.toISOString().slice(0, 10),
    modifiedDate: r.ModifiedAt?.toISOString().slice(0, 10),
  };
}

// GET /api/models — All models
router.get('/', asyncHandler(async (req, res) => {
  const result = await execute('usp_Model_GetAll');
  res.json(result.recordset.map(mapModel));
}));

// POST /api/models — Create model
router.post('/', requireAdmin, asyncHandler(async (req, res) => {
  requireFields(req.body, ['name']);
  const { name, description, isActive, sortOrder, createdAt, modifiedAt } = req.body;

  const result = await execute('usp_Model_Create', {
    Name: String(name),
    Description: description != null ? String(description) : null,
    IsActive: isActive !== false ? 1 : 0,
    SortOrder: sortOrder || 0,
    CreatedAt: createdAt || null,
    ModifiedAt: modifiedAt || null,
  });

  res.json(mapModel(result.recordset[0]));
}));

// PUT /api/models/reorder — Reorder models (must be before /:id)
router.put('/reorder', requireAdmin, asyncHandler(async (req, res) => {
  const { order } = req.body; // [{id, sortOrder}]
  if (!Array.isArray(order)) {
    return res.status(400).json({ success: false, message: 'order array required' });
  }

  await execute('usp_Model_Reorder', {
    OrderJson: JSON.stringify(order),
  });
  res.json({ success: true });
}));

// PUT /api/models/:id — Update model
router.put('/:id', requireAdmin, asyncHandler(async (req, res) => {
  const id = requireId(req.params);
  const { name, description, isActive, sortOrder } = req.body;

  const result = await execute('usp_Model_Update', {
    Id: id,
    Name: name ? String(name) : null,
    Description: description != null ? String(description) : null,
    IsActive: isActive !== undefined ? (isActive ? 1 : 0) : null,
    SortOrder: sortOrder !== undefined ? sortOrder : null,
  });

  if (result.recordset.length === 0) {
    return res.status(404).json({ success: false, message: 'Model not found' });
  }

  res.json(mapModel(result.recordset[0]));
}));

// DELETE /api/models/:id — Delete model with streaming progress
// Uses NDJSON (newline-delimited JSON) to stream progress events to the frontend.
// Phase 1: Batch-delete data rows across all entities with progress. Phase 2: Metadata cleanup.
router.delete('/:id', requireAdmin, async (req, res) => {
  let id;
  try { id = requireId(req.params); } catch (err) {
    return res.status(400).json({ success: false, message: err.message });
  }

  res.writeHead(200, {
    'Content-Type': 'application/x-ndjson',
    'Cache-Control': 'no-cache',
    'X-Accel-Buffering': 'no',
  });

  const send = (data) => { try { res.write(JSON.stringify(data) + '\n'); } catch { /* connection closed */ } };

  try {
    // Get total row count across all entities in the model
    const countResult = await query(
      `SELECT
         (SELECT COUNT(*) FROM EntityRows er INNER JOIN Entities e ON e.Id = er.EntityId WHERE e.ModelId = @Id) AS TotalRows,
         (SELECT COUNT(*) FROM EntityValues ev INNER JOIN EntityRows er ON er.Id = ev.EntityRowId INNER JOIN Entities e ON e.Id = er.EntityId WHERE e.ModelId = @Id) AS TotalValues`,
      { Id: id }
    );
    const totalRows = countResult.recordset[0].TotalRows;
    const totalValues = countResult.recordset[0].TotalValues;
    const grandTotal = totalValues + totalRows;

    send({ phase: 'start', totalRows, totalValues, grandTotal });

    // Phase 1: Batch-delete data rows with progress
    const BATCH_SIZE = 50000;
    const MAX_BATCHES = 2000;
    let batches = 0;
    let deletedTotal = 0;

    while (batches < MAX_BATCHES) {
      const batch = await execute('usp_Model_DeleteDataBatch', { Id: id, BatchSize: BATCH_SIZE }, { timeout: 60000 });
      const row = batch.recordset?.[0];
      if (!row || row.BatchDeleted === 0) break;

      deletedTotal += row.BatchDeleted;
      const pct = grandTotal > 0 ? Math.min(99, Math.round((deletedTotal / grandTotal) * 100)) : 0;
      send({ phase: row.Phase, progress: pct, deleted: deletedTotal, total: grandTotal });
      batches++;
    }

    // Phase 2: Metadata cleanup + final delete
    send({ phase: 'metadata', progress: 99, message: 'Cleaning up metadata...' });
    const result = await execute('usp_Model_Delete', { Id: id }, { timeout: 120000 });
    const deleted = (result.recordset[0]?.Deleted || 0) > 0;

    send({ phase: 'done', deleted, deletedTotal, totalRows, totalValues });
    res.end();

  } catch (err) {
    send({ phase: 'error', message: err.message || 'Delete failed' });
    res.end();
  }
});

export default router;
