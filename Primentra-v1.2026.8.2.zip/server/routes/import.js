import { Router } from 'express';
import { execute, getPool, sql } from '../db.js';
import { asyncHandler, requireId } from '../middleware/validate.js';
import { requireAdmin } from '../middleware/authzMiddleware.js';
import { checkEntityPermission } from '../middleware/permissionMiddleware.js';
import logger from '../logger.js';
import crypto from 'crypto';

const router = Router();

// POST /api/import/upload — Upload JSON data to staging table
router.post('/upload', requireAdmin, asyncHandler(async (req, res) => {
  const { data } = req.body;
  // data: array of { model, entity, rows } objects (same format as export)

  if (!Array.isArray(data) || data.length === 0) {
    return res.status(400).json({ success: false, message: 'data array required' });
  }

  const sessionId = crypto.randomUUID();

  // Flatten data into array for bulk staging SP
  const flatData = [];
  for (const item of data) {
    const entityName = item.entity || item.entityName || 'Unknown';
    const modelName = item.model || item.modelName || '';
    for (const row of (item.rows || [])) {
      flatData.push({ entityName, modelName, rowData: row });
    }
  }

  await execute('usp_Import_UploadStaging', {
    SessionId: { type: sql.UniqueIdentifier, value: sessionId },
    DataJson: JSON.stringify(flatData),
  });

  res.json({ success: true, sessionId });
}));

// GET /api/import/:sessionId/preview — Preview staged data
router.get('/:sessionId/preview', requireAdmin, asyncHandler(async (req, res) => {
  const sessionId = req.params.sessionId;

  const result = await execute('usp_Import_GetPreview', {
    SessionId: { type: sql.UniqueIdentifier, value: sessionId },
  });

  const staged = result.recordsets[0]; // EntityName, ModelName, RowCount
  const entityInfo = result.recordsets[1]; // EntityId, EntityName, ExistingCount

  // Build lookup for entity info
  const entityLookup = new Map(entityInfo.map(e => [e.EntityName, e]));

  const preview = staged.map(s => ({
    entityName: s.EntityName,
    modelName: s.ModelName,
    importCount: s.RowCount,
    existingCount: entityLookup.get(s.EntityName)?.ExistingCount || 0,
    entityId: entityLookup.get(s.EntityName)?.EntityId || null,
  }));

  res.json({ sessionId, entities: preview });
}));

// POST /api/import/:sessionId/execute — Execute staged import
router.post('/:sessionId/execute', requireAdmin, asyncHandler(async (req, res) => {
  const sessionId = req.params.sessionId;
  const { actions } = req.body;
  // actions: { [entityName]: 'import' | 'overwrite' | 'delete_import' | 'skip' }

  if (!actions || typeof actions !== 'object') {
    return res.status(400).json({ success: false, message: 'actions object required' });
  }

  const pool = await getPool();
  const results = {};

  for (const [entityName, action] of Object.entries(actions)) {
    if (action === 'skip') {
      results[entityName] = { status: 'skipped' };
      continue;
    }

    // Get entity by name
    const entResult = await execute('usp_Entity_GetByName', { Name: entityName });
    if (entResult.recordset.length === 0) {
      results[entityName] = { status: 'error', message: 'Entity not found in database' };
      continue;
    }
    const entityId = entResult.recordset[0].Id;

    // Get attributes for this entity
    const attrResult = await execute('usp_Attribute_GetByEntity', { EntityId: entityId });
    const attributes = attrResult.recordset;

    // Get staged rows
    const stagedResult = await execute('usp_Import_GetStagedRows', {
      SessionId: { type: sql.UniqueIdentifier, value: sessionId },
      EntityName: entityName,
    });

    const transaction = pool.transaction();
    await transaction.begin();

    try {
      let imported = 0, updated = 0, skipped = 0;

      if (action === 'delete_import') {
        const delReq = transaction.request();
        delReq.input('EntityId', sql.Int, entityId);
        await delReq.execute('usp_Data_DeleteAllRows');
      }

      // Get existing codes
      const existReq = transaction.request();
      existReq.input('EntityId', sql.Int, entityId);
      const existingResult = await existReq.execute('usp_Data_GetExistingCodes');
      const existingByCode = new Map(existingResult.recordset.map(r => [r.Code, r.Id]));

      // Batch-collect all domain values that need resolving across all staged rows
      const domainResolveItems = [];
      const stagedRows = stagedResult.recordset;

      for (let rowIdx = 0; rowIdx < stagedRows.length; rowIdx++) {
        const rowData = JSON.parse(stagedRows[rowIdx].RowData);
        for (const attr of attributes) {
          if (attr.IsCode || attr.IsName) continue;
          if (attr.DataType !== 'Domain' || !attr.DomainEntityId) continue;
          const rawVal = rowData[attr.Name] ?? rowData[attr.DisplayName] ?? null;
          if (rawVal === null || rawVal === undefined) continue;
          domainResolveItems.push({
            idx: domainResolveItems.length,
            domainEntityId: attr.DomainEntityId,
            textValue: String(rawVal),
            rowIdx,
            attrId: attr.Id,
          });
        }
      }

      // Single SP call to resolve all domain values at once
      const domainResolved = new Map(); // key: `${rowIdx}_${attrId}` → resolvedId
      if (domainResolveItems.length > 0) {
        const batchReq = transaction.request();
        batchReq.input('ItemsJson', sql.NVarChar(sql.MAX), JSON.stringify(
          domainResolveItems.map(d => ({ idx: d.idx, domainEntityId: d.domainEntityId, textValue: d.textValue }))
        ));
        const batchResult = await batchReq.execute('usp_Data_ResolveDomainValuesBatch');
        for (const r of batchResult.recordset) {
          const item = domainResolveItems[r.idx];
          if (item && r.ResolvedRowId) {
            domainResolved.set(`${item.rowIdx}_${item.attrId}`, Number(r.ResolvedRowId));
          }
        }
      }

      for (let rowIdx = 0; rowIdx < stagedRows.length; rowIdx++) {
        const staged = stagedRows[rowIdx];
        const rowData = JSON.parse(staged.RowData);
        const code = rowData.code || rowData.Code || '';
        const name = rowData.name || rowData.Name || '';
        const existingId = existingByCode.get(code);

        if (action === 'import' && existingId) {
          skipped++;
          continue;
        }

        // Build attribute values array using pre-resolved domain values
        const values = [];
        for (const attr of attributes) {
          if (attr.IsCode || attr.IsName) continue; // Code/Name are on EntityRows

          const rawVal = rowData[attr.Name] ?? rowData[attr.DisplayName] ?? null;
          if (rawVal === null || rawVal === undefined) continue;

          const entry = { attributeId: attr.Id };
          if (attr.DataType === 'Int') {
            entry.intValue = parseInt(rawVal, 10) || null;
          } else if (attr.DataType === 'Decimal') {
            entry.decimalValue = parseFloat(rawVal) || null;
          } else if (attr.DataType === 'DateTime') {
            entry.dateTimeValue = rawVal;
          } else if (attr.DataType === 'Domain') {
            // Use pre-resolved domain value from batch call
            entry.domainValue = domainResolved.get(`${rowIdx}_${attr.Id}`) || null;
          } else {
            entry.textValue = String(rawVal);
          }
          values.push(entry);
        }

        const request = transaction.request();
        request.input('EntityId', sql.Int, entityId);
        request.input('RowId', sql.BigInt, (action === 'overwrite' && existingId) ? existingId : null);
        request.input('Code', sql.NVarChar(200), code);
        request.input('Name', sql.NVarChar(500), name);
        request.input('Values', sql.NVarChar(sql.MAX), JSON.stringify(values));
        request.input('UserId', sql.Int, null);
        await request.execute('usp_Data_SaveRow');

        if (existingId && action === 'overwrite') updated++;
        else imported++;

        // Mark staged row as processed
        const markReq = transaction.request();
        markReq.input('Id', sql.BigInt, staged.Id);
        await markReq.execute('usp_Import_MarkProcessed');
      }

      await transaction.commit();
      results[entityName] = { status: 'success', imported, updated, skipped };
    } catch (err) {
      await transaction.rollback();
      logger.error(`Import transaction failed for entity "${entityName}": ${err.message}`, {
        error: err.message,
        category: 'import',
      });
      results[entityName] = { status: 'error', message: err.message };
    }
  }

  res.json({ success: true, results });
}));

// GET /api/export/:entityId — Export entity data as JSON
router.get('/export/:entityId', checkEntityPermission('CanRead'), asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');

  const result = await execute('usp_Export_GetEntityData', { EntityId: entityId });

  // Result set 1: entity info
  if (result.recordsets[0].length === 0) {
    return res.status(404).json({ success: false, message: 'Entity not found' });
  }
  const entInfo = result.recordsets[0][0];

  // Result set 3: row data — pivot into flat rows
  const rowMap = new Map();
  for (const r of result.recordsets[2]) {
    if (!rowMap.has(r.Id)) {
      rowMap.set(r.Id, { code: r.Code, name: r.Name });
    }
    const row = rowMap.get(r.Id);
    if (r.AttributeName) {
      if (r.DataType === 'Domain' && r.DomainValue) {
        row[r.AttributeName] = r.DomainCode ? `{${r.DomainCode}} ${r.DomainName}` : r.DomainValue;
      } else if (r.DataType === 'Int') {
        row[r.AttributeName] = r.IntValue;
      } else if (r.DataType === 'Decimal') {
        row[r.AttributeName] = r.DecimalValue != null ? parseFloat(r.DecimalValue) : null;
      } else if (r.DataType === 'DateTime') {
        row[r.AttributeName] = r.DateTimeValue;
      } else {
        row[r.AttributeName] = r.TextValue;
      }
    }
  }

  res.json([{
    model: entInfo.ModelName,
    entity: entInfo.EntityName,
    exportedAt: new Date().toISOString(),
    rows: Array.from(rowMap.values()),
  }]);
}));

// POST /api/import/xlsx — Import data directly for a single entity (bulk)
router.post('/xlsx', requireAdmin, asyncHandler(async (req, res) => {
  const { conflictAction, rows } = req.body;
  const entityId = parseInt(req.body.entityId, 10);

  if (isNaN(entityId) || entityId <= 0) {
    return res.status(400).json({ success: false, message: 'Invalid entityId' });
  }
  if (!Array.isArray(rows)) {
    return res.status(400).json({ success: false, message: 'rows[] required' });
  }
  if (!['import', 'overwrite', 'delete_import'].includes(conflictAction)) {
    return res.status(400).json({ success: false, message: 'Invalid conflictAction' });
  }
  if (rows.length > 50000) {
    return res.status(400).json({ success: false, message: 'Maximum 50,000 rows per import' });
  }

  if (rows.length === 0) {
    return res.json({ success: true, inserted: 0, updated: 0, skipped: 0, errors: [] });
  }

  const userId = req.user?.id || null;

  // 1. Batch-resolve domain text values to numeric IDs
  const domainItems = [];
  rows.forEach((row, ri) => {
    (row.values || []).forEach(v => {
      if (v.domainValue != null && typeof v.domainValue === 'string') {
        domainItems.push({ idx: domainItems.length, domainEntityId: v.domainEntityId, textValue: v.domainValue, rowIdx: ri, attrId: v.attributeId });
      }
    });
  });

  const domainResolved = new Map();
  if (domainItems.length > 0) {
    const batchResult = await execute('usp_Data_ResolveDomainValuesBatch', {
      ItemsJson: { type: sql.NVarChar(sql.MAX), value: JSON.stringify(
        domainItems.map(d => ({ idx: d.idx, domainEntityId: d.domainEntityId, textValue: d.textValue }))
      )},
    });
    for (const r of batchResult.recordset) {
      const item = domainItems[r.idx];
      if (item && r.ResolvedRowId) domainResolved.set(`${item.rowIdx}_${item.attrId}`, Number(r.ResolvedRowId));
    }
  }

  // 2. Build resolved rows for the bulk SP
  const resolvedRows = rows.map((row, ri) => {
    const values = (row.values || []).map(v => {
      const entry = { attributeId: v.attributeId };
      if (v.domainValue != null && typeof v.domainValue === 'string') {
        const resolved = domainResolved.get(`${ri}_${v.attributeId}`);
        if (resolved != null) entry.domainValue = resolved;
      } else {
        if (v.textValue     !== undefined) entry.textValue     = v.textValue;
        if (v.intValue      !== undefined) entry.intValue      = v.intValue;
        if (v.decimalValue  !== undefined) entry.decimalValue  = v.decimalValue;
        if (v.dateTimeValue !== undefined) entry.dateTimeValue = v.dateTimeValue;
      }
      return entry;
    }).filter(v => Object.keys(v).length > 1);
    return { code: (row.code || '').trim(), name: (row.name || '').trim(), values };
  });

  // 3. Single bulk SP call — handles delete/insert/update and EntityValues in one transaction
  try {
    const result = await execute('usp_Data_BulkImportRows', {
      EntityId:       { type: sql.Int,           value: entityId },
      ConflictAction: { type: sql.NVarChar(20),   value: conflictAction },
      RowsJson:       { type: sql.NVarChar(sql.MAX), value: JSON.stringify(resolvedRows) },
      UserId:         { type: sql.Int,           value: userId },
    });
    const { inserted, updated, skipped } = result.recordset[0];

    // Write audit log for bulk import
    if (inserted + updated > 0) {
      try {
        const metaResult = await execute('usp_Data_GetEntityMeta', { EntityId: { type: sql.Int, value: entityId } });
        const entInfo = metaResult.recordset[0] || { EntityName: 'Unknown', ModelName: 'Unknown' };
        const pool = await getPool();
        const auditReq = pool.request();
        auditReq.input('EntityId', sql.Int, entityId);
        auditReq.input('EntityName', sql.NVarChar(200), entInfo.EntityName);
        auditReq.input('ModelName', sql.NVarChar(200), entInfo.ModelName);
        auditReq.input('Action', sql.NVarChar(50), 'import');
        auditReq.input('RecordCount', sql.Int, inserted + updated);
        auditReq.input('UserId', sql.Int, userId);
        auditReq.input('Comment', sql.NVarChar(1000), `Bulk ${conflictAction}: ${inserted} inserted, ${updated} updated, ${skipped} skipped`);
        auditReq.input('Details', sql.NVarChar(sql.MAX), null);
        await auditReq.execute('usp_AuditLog_Write');
      } catch (auditErr) {
        logger.warn(`Audit log write failed for bulk import: ${auditErr.message}`);
      }
    }

    res.json({ success: true, inserted, updated, skipped, errors: [] });
  } catch (err) {
    logger.error(`Bulk import failed entity ${entityId}: ${err.message}`, { category: 'import' });
    res.status(500).json({ success: false, message: err.message || 'Import failed. Please try again.' });
  }
}));

export default router;
