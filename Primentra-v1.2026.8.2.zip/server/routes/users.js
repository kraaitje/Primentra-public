import { Router } from 'express';
import { execute } from '../db.js';
import { asyncHandler, requireFields, requireId } from '../middleware/validate.js';
import { hashPassword, generateToken } from '../utils/crypto.js';
import { sendWelcomeEmail } from '../email.js';
import { autoLoginTokens } from './auth.js';
import { readConfig } from '../config.js';
import logger from '../logger.js';

const router = Router();

function mapUser(u, memberships, isAdmin = false) {
  return {
    id: u.Id,
    email: u.Email,
    displayName: u.DisplayName,
    mustChangePassword: u.MustChangePassword,
    isActive: u.IsActive,
    isSystem: !!u.IsSystem,
    // 'api' distinguishes an API account from the internal system account — both are IsSystem
    userType: u.UserType || 'standard',
    isAdministrator: !!u.IsAdministrator,
    roles: (memberships || []).map(m => ({ roleId: m.RoleId, roleName: m.RoleName })),
    createdAt: u.CreatedAt,
    modifiedAt: u.ModifiedAt,
    ...(isAdmin && { passwordLastChangedAt: u.PasswordLastChangedAt ?? null }),
  };
}

// GET /api/users — All users with role memberships
router.get('/', asyncHandler(async (req, res) => {
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ success: false, error: 'Administrator access required.' });
  }
  const result = await execute('usp_User_GetAll');
  const users = result.recordsets[0];
  const memberships = result.recordsets[1];

  const membershipsByUser = {};
  for (const m of memberships) {
    if (!membershipsByUser[m.UserId]) membershipsByUser[m.UserId] = [];
    membershipsByUser[m.UserId].push(m);
  }

  res.json(users.map(u => mapUser(u, membershipsByUser[u.Id], !!req.user?.isAdministrator)));
}));

// GET /api/users/dashboard-activity — user activity for dashboard widget (must be before /:id)
router.get('/dashboard-activity', asyncHandler(async (req, res) => {
  // Exposes every user's name and last-login time — administrator-only, like the rest of
  // this file. Without this an API-key caller with no roles could read the staff list.
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ success: false, error: 'Administrator access required.' });
  }
  const result = await execute('usp_Dashboard_GetUserActivity');
  const users = result.recordsets[0].map(u => ({
    id: u.Id,
    displayName: u.DisplayName,
    lastLoginAt: u.LastLoginAt,
    isActive: u.IsActive,
  }));
  const summary = result.recordsets[1][0];
  res.json({
    users,
    summary: {
      activeLastWeek: summary.ActiveLastWeek,
      activeLastMonth: summary.ActiveLastMonth,
      activeLastQuarter: summary.ActiveLastQuarter,
      totalActive: summary.TotalActive,
      totalInactive: summary.TotalInactive,
    },
  });
}));

// GET /api/users/dashboard-preferences — must be before /:id
router.get('/dashboard-preferences', asyncHandler(async (req, res) => {
  const userId = req.user?.id;
  const result = await execute('usp_User_GetDashboardPreferences', { UserId: userId });
  const raw = result.recordset?.[0]?.DashboardPreferences || '{}';
  try { res.json(JSON.parse(raw)); } catch { res.json({}); }
}));

// PUT /api/users/dashboard-preferences
router.put('/dashboard-preferences', asyncHandler(async (req, res) => {
  const userId = req.user?.id;
  const prefs = JSON.stringify(req.body);
  await execute('usp_User_SaveDashboardPreferences', { UserId: userId, Preferences: prefs });
  res.json({ success: true });
}));

// GET /api/users/:id — Single user with role memberships
router.get('/:id', asyncHandler(async (req, res) => {
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ success: false, error: 'Administrator access required.' });
  }
  const id = requireId(req.params);
  const result = await execute('usp_User_GetById', { Id: id });

  if (result.recordsets[0].length === 0) {
    return res.status(404).json({ success: false, message: 'User not found' });
  }

  const u = result.recordsets[0][0];
  const memberships = result.recordsets[1];

  res.json(mapUser(u, memberships, !!req.user?.isAdministrator));
}));

// POST /api/users/system — Create or return existing system user
router.post('/system', asyncHandler(async (req, res) => {
  // System users are permanent (they cannot be deleted, see DELETE below), so creating
  // them is an administrator action — not something any authenticated caller, including
  // an API-key user with no roles, should be able to do.
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ success: false, error: 'Administrator access required.' });
  }
  requireFields(req.body, ['email', 'displayName']);
  const { email, displayName } = req.body;

  const result = await execute('usp_User_CreateSystem', {
    Email: email,
    DisplayName: displayName,
  });

  const row = result.recordset[0];
  res.json({ id: row.Id, displayName: row.DisplayName });
}));

// POST /api/users — Create user
router.post('/', asyncHandler(async (req, res) => {
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ success: false, error: 'Administrator access required.' });
  }
  requireFields(req.body, ['email', 'displayName']);
  const { email, displayName, password, mustChangePassword, isActive, roleIds } = req.body;

  // Server-side email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test((email || '').trim())) {
    return res.status(400).json({ success: false, error: 'Invalid email address.' });
  }

  const result = await execute('usp_User_Create', {
    Email: email,
    DisplayName: displayName,
    PasswordHash: password ? hashPassword(password) : null,
    MustChangePassword: mustChangePassword !== undefined ? mustChangePassword : true,
    IsActive: isActive !== undefined ? isActive : true,
    RoleIdsJson: Array.isArray(roleIds) ? JSON.stringify(roleIds) : null,
  });

  const u = result.recordsets[0][0];
  const memberships = result.recordsets[1];

  // Audit log: user created
  try {
    await execute('usp_AuditLog_Write', {
      EntityId: null, EntityName: 'Authentication', ModelName: 'System',
      Action: 'user_created', RecordCount: 1,
      UserId: req.user?.id || null,
      Comment: null,
      Details: JSON.stringify({ targetUserId: u.Id, email: u.Email, displayName: u.DisplayName, isActive: u.IsActive }),
    });
  } catch (err) {
    logger.warn(`Audit log write failed (user_created): ${err.message}`, { error: err.message, category: 'audit' });
  }

  res.json(mapUser(u, memberships, true));
}));

// PUT /api/users/:id — Update user
router.put('/:id', asyncHandler(async (req, res) => {
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ success: false, error: 'Administrator access required.' });
  }
  const id = requireId(req.params);
  const { email, displayName, password, mustChangePassword, isActive, roleIds } = req.body;

  const result = await execute('usp_User_Update', {
    Id: id,
    Email: email || null,
    DisplayName: displayName || null,
    PasswordHash: password ? hashPassword(password) : null,
    MustChangePassword: mustChangePassword !== undefined ? mustChangePassword : null,
    IsActive: isActive !== undefined ? isActive : null,
    RoleIdsJson: Array.isArray(roleIds) ? JSON.stringify(roleIds) : null,
  });

  if (result.recordsets[0].length === 0) {
    return res.status(404).json({ success: false, message: 'User not found' });
  }

  const u = result.recordsets[0][0];
  const memberships = result.recordsets[1];

  // Audit log: user updated
  try {
    const changes = {};
    if (email) changes.email = email;
    if (displayName) changes.displayName = displayName;
    if (password) changes.passwordChanged = true;
    if (mustChangePassword !== undefined) changes.mustChangePassword = mustChangePassword;
    if (isActive !== undefined) changes.isActive = isActive;
    if (Array.isArray(roleIds)) changes.roleIds = roleIds;
    await execute('usp_AuditLog_Write', {
      EntityId: null, EntityName: 'Authentication', ModelName: 'System',
      Action: 'user_updated', RecordCount: 1,
      UserId: req.user?.id || null,
      Comment: null,
      Details: JSON.stringify({ targetUserId: u.Id, email: u.Email, displayName: u.DisplayName, ...changes }),
    });
  } catch (err) {
    logger.warn(`Audit log write failed (user_updated): ${err.message}`, { error: err.message, category: 'audit' });
  }

  res.json(mapUser(u, memberships, true));
}));

// POST /api/users/:id/send-welcome-email — Send (or resend) welcome email
router.post('/:id/send-welcome-email', asyncHandler(async (req, res) => {
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ success: false, error: 'Administrator access required.' });
  }

  const id = requireId(req.params);
  const result = await execute('usp_User_GetById', { Id: id });

  if (result.recordsets[0].length === 0) {
    return res.status(404).json({ success: false, message: 'User not found' });
  }

  const u = result.recordsets[0][0];
  const memberships = result.recordsets[1];
  const roles = memberships.map(m => ({ roleId: m.RoleId, roleName: m.RoleName }));
  // Configured URL only. The welcome mail can carry a 72-hour auto-login token, so deriving
  // the host from Origin/Referer/Host would let a caller aim that link at a host they control.
  const loginUrl = (readConfig().appBaseUrl || '').replace(/\/$/, '');
  if (!loginUrl) {
    return res.status(422).json({
      success: false,
      error: 'Application URL is not configured. Set it under Administration → General Settings before sending welcome emails.',
    });
  }
  const { password } = req.body; // optional — only present when called right after user creation

  // If mustChangePassword: generate a one-time auto-login token (72h) and send a magic link
  let loginLink = null;
  if (u.MustChangePassword) {
    const autoToken = generateToken();
    autoLoginTokens.set(autoToken, {
      userId: u.Id,
      email: u.Email,
      displayName: u.DisplayName,
      isAdministrator: !!u.IsAdministrator,
      canApprove: !!u.CanApprove,
      roles,
      expiresAt: Date.now() + 72 * 60 * 60 * 1000, // 72 hours
    });
    loginLink = `${loginUrl}/?autologin=${autoToken}`;
  }

  await sendWelcomeEmail({
    to: u.Email,
    displayName: u.DisplayName,
    email: u.Email,
    password: loginLink ? null : (password || null),
    loginUrl,
    loginLink,
    mustChangePassword: !!u.MustChangePassword,
    roles,
  });

  // Audit log
  try {
    await execute('usp_AuditLog_Write', {
      EntityId: null, EntityName: 'Authentication', ModelName: 'System',
      Action: 'welcome_email_sent', RecordCount: 1,
      UserId: req.user?.id || null,
      Comment: null,
      Details: JSON.stringify({ targetUserId: id, email: u.Email }),
    });
  } catch (err) {
    logger.warn(`Audit log write failed (welcome_email_sent): ${err.message}`, { error: err.message, category: 'audit' });
  }

  res.json({ success: true });
}));

// DELETE /api/users/:id — Soft-delete user (sets IsDeleted=1, removes memberships + favorites + settings)
router.delete('/:id', asyncHandler(async (req, res) => {
  if (!req.user?.isAdministrator) {
    return res.status(403).json({ success: false, error: 'Administrator access required.' });
  }
  const id = requireId(req.params);

  // Get user info before deletion for audit log + system user check
  let deletedEmail = null, deletedName = null, isSystem = false;
  try {
    const userResult = await execute('usp_User_GetById', { Id: id });
    if (userResult.recordsets[0].length > 0) {
      deletedEmail = userResult.recordsets[0][0].Email;
      deletedName = userResult.recordsets[0][0].DisplayName;
      isSystem = !!userResult.recordsets[0][0].IsSystem;
    }
  } catch { /* continue with delete even if lookup fails */ }

  // Block deletion of system users
  if (isSystem) {
    return res.status(400).json({ success: false, message: 'System users cannot be deleted.' });
  }

  const result = await execute('usp_User_Delete', { Id: id });
  const deleted = (result.recordset[0]?.Deleted || 0) > 0;

  // Audit log: user deleted
  if (deleted) {
    try {
      await execute('usp_AuditLog_Write', {
        EntityId: null, EntityName: 'Authentication', ModelName: 'System',
        Action: 'user_deleted', RecordCount: 1,
        UserId: req.user?.id || null,
        Comment: null,
        Details: JSON.stringify({ targetUserId: id, email: deletedEmail, displayName: deletedName, softDeleted: true }),
      });
    } catch (err) {
      logger.warn(`Audit log write failed (user_deleted): ${err.message}`, { error: err.message, category: 'audit' });
    }
  }

  res.json({ success: true, deleted });
}));

export default router;
