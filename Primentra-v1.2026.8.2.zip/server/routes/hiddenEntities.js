import { Router } from 'express';
import { execute } from '../db.js';
import { asyncHandler, requireFields } from '../middleware/validate.js';

const router = Router();

// GET /api/hidden-entities — Get hidden entities for the authenticated user
router.get('/', asyncHandler(async (req, res) => {
  const userId = req.user?.id;
  if (!userId) return res.json([]);

  const result = await execute('usp_UserHiddenEntities_GetByUser', { UserId: userId });
  res.json(result.recordset.map(r => r.EntityId));
}));

// POST /api/hidden-entities/toggle — Toggle hidden state for the authenticated user
router.post('/toggle', asyncHandler(async (req, res) => {
  requireFields(req.body, ['entityId']);
  const { entityId } = req.body;

  const result = await execute('usp_UserHiddenEntities_Toggle', {
    UserId: req.user.id,
    EntityId: entityId,
  });

  res.json({ status: result.recordset[0].Status });
}));

export default router;
