import { Router } from 'express';
import { rateLimit } from 'express-rate-limit';
import { execute, query } from '../db.js';
import { asyncHandler } from '../middleware/validate.js';
import { hashPassword, verifyPassword, generateToken } from '../utils/crypto.js';
import { escapeHtml } from '../utils/html.js';
import { readConfig, writeConfig } from '../config.js';
import { sendMail } from '../email.js';
import logger from '../logger.js';
import { clientKey } from '../utils/clientKey.js';

const router = Router();

// E2E test runs set E2E_DISABLE_RATE_LIMIT=1 so the per-IP login limiter does not
// saturate during long serial suites. NEVER set this in production — it is opt-in
// via an explicit env var, so production behaviour is unchanged.
const RATE_LIMIT_DISABLED = process.env.E2E_DISABLE_RATE_LIMIT === '1';
// keyGenerator: behind IIS every request otherwise looks like 127.0.0.1 (or has no address at all
// under iisnode), which would put every user in one bucket. See utils/clientKey.js.
const makeLimiter = (opts) =>
  (RATE_LIMIT_DISABLED ? (req, res, next) => next() : rateLimit({ keyGenerator: clientKey, ...opts }));

// Rate limiters for sensitive auth endpoints
// Login: 10 attempts per 15 minutes per IP
const loginLimiter = makeLimiter({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many login attempts. Please wait 15 minutes before trying again.' },
  skipSuccessfulRequests: true,
});

// Auto-login: 5 attempts per 15 minutes per IP (one-time tokens, tighter limit)
const autologinLimiter = makeLimiter({
  windowMs: 15 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many requests. Please try again later.' },
});

// Forgot-password: 5 requests per hour per IP (prevents email flooding)
const forgotPasswordLimiter = makeLimiter({
  windowMs: 60 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many password reset requests. Please wait before trying again.' },
});

// Reset-password: 10 attempts per 15 minutes per IP
const resetPasswordLimiter = makeLimiter({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many attempts. Please request a new reset link.' },
});

// In-memory session store: token -> { userId, email, displayName, roles, expiresAt }
export const sessions = new Map();

// In-memory password reset tokens: token -> { email, expiresAt }
const resetTokens = new Map();

// In-memory auto-login tokens (one-time, 72h): token -> { userId, email, displayName, isAdministrator, roles, expiresAt }
export const autoLoginTokens = new Map();

// Clean expired reset tokens every 15 minutes
setInterval(() => {
  const now = Date.now();
  for (const [token, data] of resetTokens) {
    if (data.expiresAt < now) resetTokens.delete(token);
  }
  for (const [token, data] of autoLoginTokens) {
    if (data.expiresAt < now) autoLoginTokens.delete(token);
  }
}, 15 * 60 * 1000);

// Clean expired sessions every hour
setInterval(() => {
  const now = Date.now();
  for (const [token, session] of sessions) {
    if (session.expiresAt < now) sessions.delete(token);
  }
}, 60 * 60 * 1000);

// Drop every session belonging to a user, optionally sparing one token (the caller's own,
// so changing your own password does not log you out of the tab you are working in).
//
// Changing a password is the standard reaction to a suspected compromise. Without this a
// stolen token stays valid for the full session TTL — and the sliding expiry in
// authMiddleware keeps renewing it for as long as the attacker keeps using it.
function invalidateSessionsFor({ userId, email }, keepToken = null) {
  let dropped = 0;
  for (const [token, session] of sessions) {
    if (token === keepToken) continue;
    const matches = (userId != null && session.userId === userId) || (email && session.email === email);
    if (matches) { sessions.delete(token); dropped++; }
  }
  return dropped;
}

// Dynamic session TTL from config (default 24 hours)
export function getSessionTtlMs() {
  const config = readConfig();
  const hours = config.sessionTimeoutHours || 24;
  return hours * 60 * 60 * 1000;
}

// Helper: extract token from Authorization header
function getToken(req) {
  const auth = req.headers.authorization;
  if (auth && auth.startsWith('Bearer ')) return auth.slice(7);
  return null;
}

// Helper: validate session token and return { token, session } or null
// Cleans up expired sessions as a side effect.
function getValidSession(req) {
  const token = getToken(req);
  if (!token || !sessions.has(token)) return null;
  const session = sessions.get(token);
  if (session.expiresAt < Date.now()) {
    sessions.delete(token);
    return null;
  }
  return { token, session };
}

// GET /status — returns { firstRun, authenticated, user, schemaVersion }
router.get('/status', asyncHandler(async (req, res) => {
  // Count real human users (inline query — doesn't depend on SP being up to date)
  const countResult = await query("SELECT COUNT(*) AS UserCount FROM Users WHERE IsDeleted = 0 AND IsSystem = 0 AND UserType = 'standard'");
  const userCount = countResult.recordset[0].UserCount;

  // Read schema version from DB
  let schemaVersion = null;
  try {
    const sv = await query("SELECT TOP 1 Version FROM SchemaVersion");
    schemaVersion = sv.recordset[0]?.Version || null;
  } catch { /* SchemaVersion table may not exist yet */ }

  const sessionTimeoutMs = getSessionTtlMs();

  // forceSetupScreen in config forces the first-run setup screen (admin recovery)
  const config = readConfig();
  if (userCount === 0 || config.forceSetupScreen) {
    return res.json({ firstRun: true, authenticated: false, user: null, sessionTimeoutMs, schemaVersion });
  }

  // Check if current request has a valid session
  const valid = getValidSession(req);
  if (valid) {
    const { session } = valid;
    return res.json({
      firstRun: false,
      authenticated: true,
      user: { id: session.userId, email: session.email, displayName: session.displayName, isAdministrator: !!session.isAdministrator, canApprove: !!session.canApprove, roles: session.roles },
      sessionTimeoutMs,
      schemaVersion,
    });
  }

  return res.json({ firstRun: false, authenticated: false, user: null, sessionTimeoutMs, schemaVersion });
}));

// POST /login — email + password -> token
router.post('/login', loginLimiter, asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ success: false, error: 'Email and password are required.' });
  }

  // Look up user by email
  const result = await execute('usp_User_GetByEmail', { Email: email.trim() });
  const user = result.recordsets[0][0];

  if (!user) {
    // No account to count this against, so record it separately: a run of unknown addresses from
    // one machine is a far clearer attack signal than a single mistyped password, and until now it
    // left no trace anywhere. The reply is deliberately identical to a wrong password.
    await execute('usp_Auth_RecordUnknownLogin', {
      Email: String(email).trim().slice(0, 320),
      IpAddress: clientKey(req),
    });
    return res.status(401).json({ success: false, error: 'Invalid email or password.' });
  }

  // Check if account is locked
  if (!user.IsActive) {
    return res.status(401).json({ success: false, error: 'Account is locked. Contact your administrator.', locked: true });
  }

  // Verify password
  if (!verifyPassword(password, user.PasswordHash)) {
    // Record failed attempt
    const ip = req.ip || req.connection?.remoteAddress || null;
    const loginResult = await execute('usp_User_RecordLogin', { UserId: user.Id, Success: false, IpAddress: ip });
    const state = loginResult.recordset[0];

    if (!state.IsActive) {
      return res.status(401).json({ success: false, error: 'Account is locked after too many failed attempts. Contact your administrator.', locked: true });
    }

    const remaining = 5 - state.FailedLoginAttempts;
    return res.status(401).json({ success: false, error: 'Invalid email or password.', attemptsRemaining: remaining > 0 ? remaining : 0 });
  }

  // Successful login — record it
  const ip = req.ip || req.connection?.remoteAddress || null;
  await execute('usp_User_RecordLogin', { UserId: user.Id, Success: true, IpAddress: ip });

  // Build session
  const roles = result.recordsets[1].map(m => ({ roleId: m.RoleId, roleName: m.RoleName }));
  const token = generateToken();
  sessions.set(token, {
    userId: user.Id,
    email: user.Email,
    displayName: user.DisplayName,
    isAdministrator: !!user.IsAdministrator,
    canApprove: !!user.CanApprove,
    roles,
    expiresAt: Date.now() + getSessionTtlMs(),
  });

  res.json({
    success: true,
    token,
    user: { id: user.Id, email: user.Email, displayName: user.DisplayName, isAdministrator: !!user.IsAdministrator, canApprove: !!user.CanApprove, roles },
    mustChangePassword: user.MustChangePassword,
  });
}));

// POST /setup-first-user — create the first admin account during initial setup.
// This is a PUBLIC endpoint (it must work before any user exists), so it may ONLY
// create an account when no real users exist yet. forceSetupScreen is an admin-only
// server-side config (mds-config.json) escape hatch for recovery.
// SECURITY: never gate this on a client-supplied flag — a caller could simply assert it
// to create an admin on a configured system (see removed `afterSetup` bypass).
router.post('/setup-first-user', asyncHandler(async (req, res) => {
  const config = readConfig();
  const countResult = await query("SELECT COUNT(*) AS UserCount FROM Users WHERE IsDeleted = 0 AND IsSystem = 0 AND UserType = 'standard'");
  const userCount = countResult.recordset[0].UserCount;

  if (userCount > 0 && !config.forceSetupScreen) {
    return res.status(400).json({ success: false, error: 'Users already exist. Setup is not allowed.' });
  }

  const { email, displayName, password } = req.body;
  if (!email || !displayName || !password) {
    return res.status(400).json({ success: false, error: 'Email, display name, and password are required.' });
  }

  if (password.length < 8) {
    return res.status(400).json({ success: false, error: 'Password must be at least 8 characters.' });
  }

  // Create the first user (no roles yet, will be assigned to Administrators role next)
  const passwordHash = hashPassword(password);
  const userResult = await execute('usp_User_Create', {
    Email: email.trim(),
    DisplayName: displayName.trim(),
    PasswordHash: passwordHash,
    MustChangePassword: false,
    IsActive: true,
    RoleIdsJson: null,
  });

  const user = userResult.recordsets[0][0];

  // Find or create the Administrators role with IsAdmin=1 and assign this user to it
  // (The setup script may have already created the role during schema deployment)
  const existingRoles = await execute('usp_Role_GetAll');
  const existingAdmin = existingRoles.recordset?.find(r => r.IsAdmin === true || r.IsAdmin === 1);

  let adminRole;
  if (existingAdmin) {
    // usp_Role_Update REPLACES the member list, so the existing members have to be carried
    // over explicitly. Passing only the new id here once removed every other administrator
    // from the role. Relevant on the forceSetupScreen recovery path, where accounts exist.
    const currentMembers = (existingRoles.recordsets?.[1] || [])
      .filter(m => m.RoleId === existingAdmin.Id)
      .map(m => m.UserId);
    const members = [...new Set([...currentMembers, user.Id])];

    const updateResult = await execute('usp_Role_Update', {
      Id: existingAdmin.Id,
      Name: existingAdmin.Name,
      Description: existingAdmin.Description,
      IsAdmin: 1,
      CanApprove: existingAdmin.CanApprove ? 1 : 0,
      MembersJson: JSON.stringify(members),
    });
    adminRole = updateResult.recordsets[0][0];
  } else {
    // No admin role yet — create one
    const roleResult = await execute('usp_Role_Create', {
      Name: 'Administrators',
      Description: 'Full system access',
      IsAdmin: 1,
      CanApprove: 0,
      MembersJson: JSON.stringify([user.Id]),
    });
    adminRole = roleResult.recordsets[0][0];
  }
  const roles = [{ roleId: adminRole.Id, roleName: adminRole.Name }];

  // Auto-login: create session
  const token = generateToken();
  sessions.set(token, {
    userId: user.Id,
    email: user.Email,
    displayName: user.DisplayName,
    isAdministrator: true,
    roles,
    expiresAt: Date.now() + getSessionTtlMs(),
  });

  // Log the setup event
  try {
    await execute('usp_AuditLog_Write', {
      EntityId: null,
      EntityName: 'Authentication',
      ModelName: 'System',
      Action: 'first_user_setup',
      Details: JSON.stringify({ email: user.Email, displayName: user.DisplayName }),
      UserId: user.Id,
    });
  } catch (err) {
    logger.warn(`Audit log write failed (first_user_setup): ${err.message}`, { error: err.message, category: 'audit' });
  }

  // Clear forceSetupScreen flag so the setup screen doesn't show again
  if (config.forceSetupScreen) {
    writeConfig({ ...config, forceSetupScreen: false });
  }

  res.json({
    success: true,
    token,
    user: { id: user.Id, email: user.Email, displayName: user.DisplayName, isAdministrator: true, roles },
  });
}));

// POST /logout — invalidate session
router.post('/logout', asyncHandler(async (req, res) => {
  const token = getToken(req);
  if (token && sessions.has(token)) {
    const session = sessions.get(token);
    // Log logout event
    try {
      await execute('usp_AuditLog_Write', {
        EntityId: null,
        EntityName: 'Authentication',
        ModelName: 'System',
        Action: 'logout',
        Details: JSON.stringify({ email: session.email }),
        UserId: session.userId,
      });
    } catch (err) {
      logger.warn(`Audit log write failed (logout): ${err.message}`, { error: err.message, category: 'audit' });
    }
    sessions.delete(token);
  }
  res.json({ success: true });
}));

// GET /me — get current user info
router.get('/me', asyncHandler(async (req, res) => {
  const result = getValidSession(req);
  if (!result) return res.status(401).json({ success: false, error: 'Not authenticated.' });

  const { session } = result;
  res.json({
    id: session.userId,
    email: session.email,
    displayName: session.displayName,
    isAdministrator: !!session.isAdministrator,
    canApprove: !!session.canApprove,
    roles: session.roles,
  });
}));

// POST /forgot-password — request a password reset link via email
router.post('/forgot-password', forgotPasswordLimiter, asyncHandler(async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ success: false, error: 'Email is required.' });

  // The reset link must come from configured state only. Origin and Host are supplied by
  // the caller, so falling back to them lets anyone mail a victim a genuine-looking reset
  // link pointing at a host they control, and collect the token when it is clicked.
  //
  // Answered before the user lookup: whether the application URL is configured does not
  // depend on the email address, so reporting it plainly reveals nothing about which
  // accounts exist — and staying silent here would leave the user staring at a success
  // message while no mail is ever sent.
  const baseUrl = (readConfig().appBaseUrl || '').replace(/\/$/, '');
  if (!baseUrl) {
    logger.error('Password reset requested but appBaseUrl is not configured — no email sent. Set the application URL under Administration → General Settings.', { category: 'auth' });
    return res.status(503).json({
      success: false,
      error: 'Password reset is unavailable because the application URL has not been configured. Please contact your administrator.',
    });
  }

  const result = await execute('usp_User_GetByEmail', { Email: email.trim() });
  const user = result.recordsets[0][0];

  if (user) {
    // Invalidate any existing reset tokens for this email (one token per user)
    for (const [existingToken, data] of resetTokens) {
      if (data.email === email.trim()) resetTokens.delete(existingToken);
    }

    const token = generateToken();
    resetTokens.set(token, { email: email.trim(), expiresAt: Date.now() + 30 * 60 * 1000 });

    const resetUrl = `${baseUrl}/?reset=${token}`;

    const safeName = escapeHtml(user.DisplayName);
    const safeUrl  = escapeHtml(resetUrl);

    try {
      await sendMail({
        to: email.trim(),
        subject: 'Primentra — Reset your password 🔑',
        html: `
<div style="font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;max-width:560px;margin:0 auto">
  <div style="background:#0f766e;padding:28px 32px;border-radius:12px 12px 0 0">
    <div style="font-size:22px;font-weight:700;color:#fff;letter-spacing:-0.5px">Primentra</div>
    <div style="font-size:13px;color:#99f6e4;margin-top:4px">Master Data Management</div>
  </div>
  <div style="background:#ffffff;padding:32px;border-left:1px solid #e2e8f0;border-right:1px solid #e2e8f0">
    <div style="text-align:center;margin-bottom:20px">
      <div style="width:48px;border-radius:12px;background:#f0fdfa;border:1px solid #99f6e4;display:inline-block;text-align:center;padding:11px 0;font-size:26px">&#128273;</div>
    </div>
    <h2 style="font-size:20px;font-weight:700;color:#0f172a;margin:0 0 8px">Reset your password</h2>
    <p style="font-size:14px;color:#334155;line-height:1.6;margin:0 0 8px">Hi ${safeName},</p>
    <p style="font-size:14px;color:#334155;line-height:1.6;margin:0 0 24px">
      You requested a password reset for your Primentra account. Click the button below to choose a new password. This link expires in <strong>30 minutes</strong>.
    </p>
    <div style="text-align:center;margin:28px 0">
      <a href="${safeUrl}" style="display:inline-block;background:#0f766e;color:#ffffff;text-decoration:none;font-weight:700;font-size:14px;padding:12px 32px;border-radius:8px">Reset password</a>
    </div>
    <p style="font-size:13px;color:#64748b;line-height:1.5;margin:0">
      Or copy and paste this link into your browser:<br/>
      <a href="${safeUrl}" style="color:#0f766e;word-break:break-all">${safeUrl}</a>
    </p>
    <div style="margin-top:24px;padding:12px 16px;background:#f8fafc;border-radius:8px;border:1px solid #e2e8f0">
      <p style="font-size:13px;color:#64748b;margin:0">&#128274; If you didn&rsquo;t request this, you can safely ignore this email. Your password will not change.</p>
    </div>
  </div>
  <div style="padding:16px 32px;background:#f8fafc;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 12px 12px">
    <p style="font-size:12px;color:#94a3b8;margin:0">Sent by Primentra</p>
  </div>
</div>`,
        text: `Hi ${user.DisplayName},\n\nYou requested a password reset for your Primentra account.\n\nReset your password (valid for 30 minutes):\n${resetUrl}\n\nIf you didn't request this, ignore this email — your password will not change.`,
      });
    } catch (err) {
      logger.warn(`Forgot-password email failed for ${email.trim()}: ${err.message}`, { error: err.message, category: 'email' });
    }
  }

  // Always respond with success to prevent email enumeration
  res.json({ success: true });
}));

// POST /reset-password — validate token and set new password
router.post('/reset-password', resetPasswordLimiter, asyncHandler(async (req, res) => {
  const { token, newPassword } = req.body;
  if (!token || !newPassword) {
    return res.status(400).json({ success: false, error: 'Token and new password are required.' });
  }
  if (newPassword.length < 8) {
    return res.status(400).json({ success: false, error: 'Password must be at least 8 characters.' });
  }

  const resetData = resetTokens.get(token);
  if (!resetData || resetData.expiresAt < Date.now()) {
    resetTokens.delete(token);
    return res.json({ success: false, error: 'This reset link has expired or is invalid. Please request a new one.' });
  }

  const passwordHash = hashPassword(newPassword);
  await execute('usp_User_ResetPassword', { Email: resetData.email, NewPasswordHash: passwordHash });
  resetTokens.delete(token);

  // A reset is initiated by someone who has lost access; every existing session for this
  // account is suspect, including one an attacker may be holding.
  const dropped = invalidateSessionsFor({ email: resetData.email });
  if (dropped > 0) logger.info(`Password reset invalidated ${dropped} active session(s)`, { category: 'auth' });

  res.json({ success: true });
}));

// POST /autologin — validate a one-time auto-login token and create session
router.post('/autologin', autologinLimiter, asyncHandler(async (req, res) => {
  const { token } = req.body;
  if (!token) return res.status(400).json({ success: false, error: 'Token is required.' });

  const data = autoLoginTokens.get(token);
  if (!data || data.expiresAt < Date.now()) {
    autoLoginTokens.delete(token);
    return res.json({ success: false, error: 'This login link has expired or already been used. Please contact your administrator.' });
  }

  // One-time use — delete immediately
  autoLoginTokens.delete(token);

  // mustChangePassword: true on the session means the user arrived via a magic link
  // and has never set their own password — skip the old-password check in /change-password.
  const sessionToken = generateToken();
  sessions.set(sessionToken, {
    userId: data.userId,
    email: data.email,
    displayName: data.displayName,
    isAdministrator: data.isAdministrator,
    canApprove: !!data.canApprove,
    roles: data.roles,
    mustChangePassword: true,
    expiresAt: Date.now() + getSessionTtlMs(),
  });

  res.json({
    success: true,
    token: sessionToken,
    user: { id: data.userId, email: data.email, displayName: data.displayName, isAdministrator: data.isAdministrator, canApprove: !!data.canApprove, roles: data.roles },
    mustChangePassword: true,
  });
}));

// POST /change-password — authenticated user changes their own password
router.post('/change-password', asyncHandler(async (req, res) => {
  const result = getValidSession(req);
  if (!result) return res.status(401).json({ success: false, error: 'Not authenticated.' });
  const { session } = result;

  const { currentPassword, newPassword } = req.body;
  const isForcedChange = !!session.mustChangePassword;

  // Magic-link sessions have no known password — skip old-password verification.
  // Regular sessions (password login) must always supply the current password.
  if (!isForcedChange && !currentPassword) {
    return res.status(400).json({ success: false, error: 'Current password is required.' });
  }
  if (!newPassword) {
    return res.status(400).json({ success: false, error: 'New password is required.' });
  }
  if (newPassword.length < 8) {
    return res.status(400).json({ success: false, error: 'New password must be at least 8 characters.' });
  }

  if (!isForcedChange) {
    // Load user to verify current password
    const userResult = await execute('usp_User_GetByEmail', { Email: session.email });
    const user = userResult.recordsets[0][0];
    if (!user) return res.status(404).json({ success: false, error: 'User not found.' });

    if (!verifyPassword(currentPassword, user.PasswordHash)) {
      return res.json({ success: false, error: 'Current password is incorrect.' });
    }
  }

  const newHash = hashPassword(newPassword);
  await execute('usp_User_ChangePassword', { UserId: session.userId, NewPasswordHash: newHash });

  // Sign out everywhere except the session doing the change.
  const dropped = invalidateSessionsFor({ userId: session.userId }, result.token);
  if (dropped > 0) logger.info(`Password change invalidated ${dropped} other session(s)`, { category: 'auth' });

  // Clear the mustChangePassword flag from the session now that it is done
  session.mustChangePassword = false;

  // Write audit log
  try {
    await execute('usp_AuditLog_Write', {
      EntityId: null, EntityName: 'Authentication', ModelName: 'System',
      Action: isForcedChange ? 'password_forced_change' : 'password_changed',
      RecordCount: 1,
      UserId: session.userId, Comment: null,
      Details: JSON.stringify({ email: session.email }),
    });
  } catch (err) {
    logger.warn(`Audit log write failed (password_change): ${err.message}`, { error: err.message, category: 'audit' });
  }

  res.json({ success: true });
}));

// POST /extend — reset session TTL (called by "Stay Logged In" button)
router.post('/extend', asyncHandler(async (req, res) => {
  const result = getValidSession(req);
  if (!result) return res.status(401).json({ success: false, error: 'Invalid or expired session.' });
  result.session.expiresAt = Date.now() + getSessionTtlMs();
  res.json({ success: true });
}));

export default router;
