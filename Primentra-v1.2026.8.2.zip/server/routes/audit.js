import { Router } from 'express';
import { execute } from '../db.js';
import { asyncHandler, optionalInt, requireId } from '../middleware/validate.js';
import { requireAdmin } from '../middleware/authzMiddleware.js';
import { checkEntityPermission } from '../middleware/permissionMiddleware.js';

const router = Router();

// GET /api/audit-log/dashboard — Lightweight data for dashboard widgets
router.get('/dashboard', requireAdmin, asyncHandler(async (req, res) => {
  const days = optionalInt(req.query.days, 365);
  const result = await execute('usp_AuditLog_GetDashboard', { Days: days });
  const items = result.recordset.map(r => ({
    id: r.Id,
    entityId: r.EntityId,
    entityName: r.EntityName,
    modelName: r.ModelName,
    action: r.Action,
    recordCount: r.RecordCount,
    userId: r.UserId,
    userDisplayName: r.UserDisplayName || null,
    comment: r.Comment,
    createdAt: r.CreatedAt,
  }));
  res.json({ items });
}));

// GET /api/audit-log — Paginated audit log with filters
router.get('/', requireAdmin, asyncHandler(async (req, res) => {
  const page = optionalInt(req.query.page, 1);
  const pageSize = optionalInt(req.query.pageSize, 50);
  const entityId = optionalInt(req.query.entityId);
  const action = req.query.action || null;

  const result = await execute('usp_AuditLog_GetPaginated', {
    Page: page,
    PageSize: pageSize,
    EntityId: entityId || null,
    Action: action,
  });

  const total = result.recordsets[0][0].Total;
  const records = result.recordsets[1];

  // Parse details and collect entity IDs that need column name resolution
  const items = records.map(r => ({
    id: r.Id,
    entityId: r.EntityId,
    entityName: r.EntityName,
    modelName: r.ModelName,
    action: r.Action,
    recordCount: r.RecordCount,
    userId: r.UserId,
    userEmail: r.UserEmail || null,
    userDisplayName: r.UserDisplayName || null,
    comment: r.Comment,
    details: r.Details ? JSON.parse(r.Details) : null,
    createdAt: r.CreatedAt,
  }));

  // Resolve uda_* column names to readable attribute names
  const entityIdsNeedingResolve = new Set();
  for (const item of items) {
    if (Array.isArray(item.details)) {
      for (const rec of item.details) {
        if (Object.keys(rec).some(k => k.startsWith('uda_'))) {
          entityIdsNeedingResolve.add(item.entityId);
          break;
        }
      }
    }
  }

  if (entityIdsNeedingResolve.size > 0) {
    const attrResult = await execute('usp_AuditLog_ResolveAttributes', {
      EntityIdsJson: JSON.stringify([...entityIdsNeedingResolve]),
    });

    // Build per-entity mapping: Name → DisplayName
    const entityAttrMap = new Map();
    for (const a of attrResult.recordset) {
      if (!entityAttrMap.has(a.EntityId)) entityAttrMap.set(a.EntityId, new Map());
      entityAttrMap.get(a.EntityId).set(a.Name, a.DisplayName);
    }

    // Replace uda_* keys with readable names and strip null-only columns
    const baseKeys = new Set(['code', 'name', 'id', '_savedId']);
    for (const item of items) {
      if (Array.isArray(item.details) && entityIdsNeedingResolve.has(item.entityId)) {
        const colMap = entityAttrMap.get(item.entityId);
        if (colMap) {
          item.details = item.details.map(rec => {
            const resolved = {};
            for (const [k, v] of Object.entries(rec)) {
              const readable = k.startsWith('uda_') ? colMap.get(k) || k : k;
              resolved[readable] = v;
            }
            return resolved;
          });
          // Remove columns that are null in all records
          if (item.details.length > 0) {
            const allKeys = [...new Set(item.details.flatMap(r => Object.keys(r)))];
            const nullOnlyKeys = allKeys.filter(k => !baseKeys.has(k) && item.details.every(r => r[k] == null));
            if (nullOnlyKeys.length > 0) {
              for (const rec of item.details) {
                for (const k of nullOnlyKeys) delete rec[k];
              }
            }
          }
        }
      }
    }
  }

  res.json({
    items,
    total,
    page,
    pageSize,
    totalPages: Math.ceil(total / pageSize),
  });
}));

// GET /api/audit-log/row/:entityId/:rowCode — Get audit history for a specific row
router.get('/row/:entityId/:rowCode', checkEntityPermission('CanRead'), asyncHandler(async (req, res) => {
  const entityId = requireId(req.params, 'entityId');
  const rowCode = req.params.rowCode;
  const rowId = req.query.rowId ? Number(req.query.rowId) : null;

  const result = await execute('usp_AuditLog_GetByRow', {
    EntityId: entityId,
    RowCode: rowCode,
    RowId: rowId,
  });

  const items = result.recordset.map(r => ({
    id: r.Id,
    action: r.Action,
    userId: r.UserId,
    userEmail: r.UserEmail || null,
    userDisplayName: r.UserDisplayName || null,
    comment: r.Comment,
    details: r.Details ? JSON.parse(r.Details) : null,
    createdAt: r.CreatedAt,
  }));

  res.json({ items });
}));

// POST /api/audit-log — Write audit entry (internal use)
router.post('/', requireAdmin, asyncHandler(async (req, res) => {
  const { entityId, entityName, modelName, action, recordCount, comment, details } = req.body;
  const userId = req.user?.id;

  const result = await execute('usp_AuditLog_Write', {
    EntityId: entityId || null,
    EntityName: entityName || 'Unknown',
    ModelName: modelName || 'Unknown',
    Action: action || 'edit',
    RecordCount: recordCount || 1,
    UserId: userId || null,
    Comment: comment || null,
    Details: details ? JSON.stringify(details) : null,
  });

  res.json({ success: true, id: result.recordset[0]?.Id });
}));

// POST /api/audit-log/cleanup — Cleanup old entries
router.post('/cleanup', requireAdmin, asyncHandler(async (req, res) => {
  const retentionDays = optionalInt(req.body.retentionDays, 90);
  const result = await execute('usp_AuditLog_Cleanup', { RetentionDays: retentionDays });
  res.json({ success: true, deletedCount: result.recordset[0]?.DeletedCount || 0 });
}));

export default router;
