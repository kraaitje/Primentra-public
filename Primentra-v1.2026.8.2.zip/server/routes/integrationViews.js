import { Router } from 'express';
import { execute, sql, getPool } from '../db.js';
import { asyncHandler, requireFields, requireId } from '../middleware/validate.js';
import { requireAdmin } from '../middleware/authzMiddleware.js';
import logger from '../logger.js';

// ── Helper: write audit log entry for integration view changes ──
async function writeViewAudit(action, viewName, userId, comment) {
  try {
    const pool = await getPool();
    const req = pool.request();
    req.input('EntityId', sql.Int, null);
    req.input('EntityName', sql.NVarChar(200), 'Integration View');
    req.input('ModelName', sql.NVarChar(200), 'System');
    req.input('Action', sql.NVarChar(50), action);
    req.input('RecordCount', sql.Int, 1);
    req.input('UserId', sql.Int, userId || null);
    req.input('Comment', sql.NVarChar(1000), comment || null);
    req.input('Details', sql.NVarChar(sql.MAX), null);
    await req.execute('usp_AuditLog_Write');
  } catch (err) {
    logger.warn(`Audit log write failed for integration view: ${err.message}`);
  }
}

const router = Router();

// ── Helper: map DB row to JSON ──
function mapView(r) {
  return {
    id: r.Id,
    name: r.Name,
    entityId: r.EntityId,
    viewType: r.ViewType,
    excludedColumns: r.ExcludedColumns ? JSON.parse(r.ExcludedColumns) : [],
    columnSnapshot: r.ColumnSnapshot ? JSON.parse(r.ColumnSnapshot) : [],
    typeSnapshot: r.TypeSnapshot ? JSON.parse(r.TypeSnapshot) : {},
    createdAt: r.CreatedAt,
  };
}

// ── Deploy SQL view via stored procedure ──
async function deployView(viewName, entityId, excludedColumns, viewType) {
  const params = {
    ViewName: viewName,
    EntityId: Number(entityId),
    ExcludedColumns: excludedColumns?.length ? JSON.stringify(excludedColumns) : null,
    ViewType: viewType || 'flat',
  };
  try {
    await execute('usp_IntegrationView_Deploy', params);
    return { deployed: true };
  } catch (err) {
    logger.warn(`deployView SP failed: ${err.message}`, { path: '/integration-views/deploy' });
    return { deployed: false, error: err.message || String(err) };
  }
}

// ── Drop SQL view via stored procedure ──
async function dropView(viewName) {
  try {
    await execute('usp_IntegrationView_Drop', { ViewName: viewName });
  } catch (err) {
    logger.warn(`dropView failed for "${viewName}": ${err.message}`, {
      error: err.message,
      category: 'integration-views',
    });
  }
}

// GET /api/integration-views — All integration views
router.get('/', asyncHandler(async (req, res) => {
  const result = await execute('usp_IntegrationView_GetAll');
  res.json(result.recordset.map(mapView));
}));

// POST /api/integration-views — Create view
router.post('/', requireAdmin, asyncHandler(async (req, res) => {
  requireFields(req.body, ['name', 'entityId']);
  const { name, entityId, viewType, excludedColumns, columnSnapshot, typeSnapshot } = req.body;

  const result = await execute('usp_IntegrationView_Create', {
    Name: name,
    EntityId: entityId,
    ViewType: viewType || 'flat',
    ExcludedColumns: excludedColumns ? JSON.stringify(excludedColumns) : null,
    ColumnSnapshot: columnSnapshot ? JSON.stringify(columnSnapshot) : null,
    TypeSnapshot: typeSnapshot ? JSON.stringify(typeSnapshot) : null,
  });

  const view = mapView(result.recordset[0]);

  // Deploy SQL view via stored procedure
  const deploy = await deployView(name, entityId, excludedColumns, viewType || 'flat');
  await writeViewAudit('create', name, req.user?.id, `Created integration view "${name}"`);
  res.json({ ...view, sqlDeployed: deploy.deployed, sqlError: deploy.error || null });
}));

// PUT /api/integration-views/:id — Update view
router.put('/:id', requireAdmin, asyncHandler(async (req, res) => {
  const id = requireId(req.params);
  const { name, entityId, viewType, excludedColumns, columnSnapshot, typeSnapshot } = req.body;

  const result = await execute('usp_IntegrationView_Update', {
    Id: id,
    Name: name || null,
    EntityId: entityId || null,
    ViewType: viewType || null,
    ExcludedColumns: excludedColumns ? JSON.stringify(excludedColumns) : null,
    ColumnSnapshot: columnSnapshot ? JSON.stringify(columnSnapshot) : null,
    TypeSnapshot: typeSnapshot ? JSON.stringify(typeSnapshot) : null,
  });

  // First recordset is old name, second is updated row
  const oldName = result.recordsets[0][0]?.OldName;
  if (result.recordsets[1].length === 0) {
    return res.status(404).json({ success: false, message: 'View not found' });
  }

  const view = mapView(result.recordsets[1][0]);

  // Drop old view if renamed
  if (oldName && name && oldName !== name) {
    await dropView(oldName);
  }

  // Deploy updated SQL view
  const deploy = await deployView(view.name, view.entityId, view.excludedColumns, view.viewType);
  await writeViewAudit('edit', view.name, req.user?.id, `Updated integration view "${view.name}"`);
  res.json({ ...view, sqlDeployed: deploy.deployed, sqlError: deploy.error || null });
}));

// DELETE /api/integration-views/:id — Delete view
router.delete('/:id', requireAdmin, asyncHandler(async (req, res) => {
  const id = requireId(req.params);

  const result = await execute('usp_IntegrationView_Delete', { Id: id });
  // First recordset returns name for SQL view cleanup
  const viewName = result.recordsets[0][0]?.Name;
  if (viewName) {
    await dropView(viewName);
  }

  await writeViewAudit('delete', viewName || `view #${id}`, req.user?.id, `Deleted integration view "${viewName || id}"`);
  res.json({ success: true, deleted: true });
}));

// POST /api/integration-views/:id/sync — Sync view (update snapshot + redeploy SQL)
router.post('/:id/sync', requireAdmin, asyncHandler(async (req, res) => {
  const id = requireId(req.params);

  const result = await execute('usp_IntegrationView_GetSyncData', { Id: id });

  const viewRow = result.recordsets[0][0];
  if (!viewRow) {
    return res.status(404).json({ success: false, message: 'View not found' });
  }

  const attributes = result.recordsets[1];
  if (attributes.length === 0) {
    return res.status(404).json({ success: false, message: 'Entity not found or has no attributes' });
  }

  const currentExcluded = viewRow.ExcludedColumns ? JSON.parse(viewRow.ExcludedColumns) : [];

  // Build column snapshot using {TableName}_{FieldName} convention
  const allEntitiesForSync = result.recordsets[2] || [];
  const entityEntry = allEntitiesForSync.find(e => e.Id === viewRow.EntityId);
  const tableName = entityEntry?.TableName || entityEntry?.Name || 'Entity';

  // System fields (ID, Code, Name first — CreatedAt/ModifiedAt after custom attrs)
  const cols = [
    { name: `${tableName}_ID`, dataType: 'Int' },
    { name: `${tableName}_Code`, dataType: 'Text' },
    { name: `${tableName}_Name`, dataType: 'Text' },
  ];

  // Custom attributes (skip IsCode/IsName system fields)
  // For hierarchy views, skip Domain attributes — parent entity fields are included instead
  const BUILTIN = new Set(['Id', 'Code', 'Name', 'CreatedAt', 'ModifiedAt']);
  for (const a of attributes) {
    if (BUILTIN.has(a.DisplayName)) continue;
    if (viewRow.ViewType === 'hierarchy' && a.DataType === 'Domain' && a.DomainEntityId) continue;
    cols.push({ name: `${tableName}_${a.DisplayName}`, dataType: a.DataType });
  }

  // CreatedAt/ModifiedAt last within main entity columns
  cols.push(
    { name: `${tableName}_CreatedAt`, dataType: 'DateTime' },
    { name: `${tableName}_ModifiedAt`, dataType: 'DateTime' },
  );

  if (viewRow.ViewType === 'hierarchy') {
    const allEntities = result.recordsets[2];
    const allAttrs = result.recordsets[3];
    const entitiesMap = new Map(allEntities.map(e => [e.Id, e]));

    const addParents = (attrs, visited) => {
      for (const attr of attrs) {
        if (attr.DataType !== 'Domain' || !attr.DomainEntityId) continue;
        if (visited.has(attr.DomainEntityId)) continue;
        visited.add(attr.DomainEntityId);
        const parent = entitiesMap.get(attr.DomainEntityId);
        if (!parent) continue;
        const parentPrefix = parent.TableName || parent.Name;
        // Parent system fields
        cols.push(
          { name: `${parentPrefix}_ID`, dataType: 'Int' },
          { name: `${parentPrefix}_Code`, dataType: 'Text' },
          { name: `${parentPrefix}_Name`, dataType: 'Text' },
        );
        // Parent custom attributes
        const parentAttrs = allAttrs.filter(a => a.EntityId === attr.DomainEntityId);
        for (const pa of parentAttrs) {
          if (BUILTIN.has(pa.DisplayName)) continue;
          cols.push({ name: `${parentPrefix}_${pa.DisplayName}`, dataType: pa.DataType });
        }
        addParents(parentAttrs, visited);
      }
    };
    addParents(attributes, new Set());
  }

  const currentColNames = cols.map(c => c.name);
  const typeSnapshot = {};
  for (const c of cols) typeSnapshot[c.name] = c.dataType;

  const validExcluded = currentExcluded.filter(c => currentColNames.includes(c));

  // Update metadata via SP
  const updateResult = await execute('usp_IntegrationView_Update', {
    Id: id,
    ExcludedColumns: JSON.stringify(validExcluded),
    ColumnSnapshot: JSON.stringify(currentColNames),
    TypeSnapshot: JSON.stringify(typeSnapshot),
  });

  const view = mapView(updateResult.recordsets[1][0]);

  // Redeploy SQL view
  const deploy = await deployView(view.name, view.entityId, validExcluded, view.viewType);
  res.json({ ...view, sqlDeployed: deploy.deployed, sqlError: deploy.error || null });
}));

export default router;
