import { Router } from 'express';
import { execute, getPool, sql } from '../db.js';
import { asyncHandler } from '../middleware/validate.js';
import { requireAdmin } from '../middleware/authzMiddleware.js';
import logger from '../logger.js';

const router = Router();

// POST /api/model-export/export — Export models as JSON
router.post('/export', requireAdmin, asyncHandler(async (req, res) => {
  const { modelIds = null, entityIds = null, includeData = false, includePermissions = false } = req.body;

  // Validate modelIds if provided
  if (modelIds !== null && modelIds !== undefined) {
    if (!Array.isArray(modelIds) || modelIds.some(id => typeof id !== 'number' || id <= 0)) {
      return res.status(400).json({ error: 'modelIds must be an array of positive integers or null' });
    }
  }

  // Build entity ID filter set (null = no filter, export all entities)
  const entityIdSet = entityIds && Array.isArray(entityIds) ? new Set(entityIds) : null;

  // 1. Get schema (5 result sets)
  const schemaResult = await execute('usp_ModelExport_GetSchema', {
    ModelIdsJson: modelIds ? JSON.stringify(modelIds) : null,
  });

  const dbModels = schemaResult.recordsets[0];       // Models
  const dbDomainWarnings = schemaResult.recordsets[4]; // DomainWarnings

  // Apply entity filter if entityIds were specified
  const dbEntities = entityIdSet
    ? schemaResult.recordsets[1].filter(e => entityIdSet.has(e.EntityId))
    : schemaResult.recordsets[1];
  const dbAttributes = entityIdSet
    ? schemaResult.recordsets[2].filter(a => entityIdSet.has(a.EntityId))
    : schemaResult.recordsets[2];
  const dbDerivedCols = entityIdSet
    ? schemaResult.recordsets[3].filter(d => entityIdSet.has(d.EntityId))
    : schemaResult.recordsets[3];

  // 2. Get permissions if requested
  let permissionsByEntity = new Map();
  if (includePermissions && dbEntities.length > 0) {
    const entityIds = dbEntities.map(e => e.EntityId);
    const permResult = await execute('usp_ModelExport_GetPermissions', {
      EntityIdsJson: JSON.stringify(entityIds),
    });
    for (const p of permResult.recordset) {
      if (!permissionsByEntity.has(p.EntityId)) permissionsByEntity.set(p.EntityId, []);
      permissionsByEntity.get(p.EntityId).push({ userEmail: p.UserEmail, role: p.Role });
    }
  }

  // 3. Get data rows if requested
  let rowsByEntity = new Map();
  if (includeData) {
    for (const entity of dbEntities) {
      const rowResult = await execute('usp_ModelExport_GetEntityRows', {
        EntityId: entity.EntityId,
      });
      // Pivot raw EAV result (one row per EntityRow×EntityValue) to flat objects
      const pivotMap = new Map();
      for (const r of rowResult.recordset) {
        if (!pivotMap.has(r.Id)) pivotMap.set(r.Id, { code: r.Code, name: r.Name });
        if (r.AttributeName) {
          const row = pivotMap.get(r.Id);
          let val;
          if (r.DataType === 'Domain') val = r.DomainCode ?? null;
          else if (r.DataType === 'Int' || r.DataType === 'Boolean') val = r.IntValue ?? null;
          else if (r.DataType === 'Decimal') val = r.DecimalValue ?? null;
          else if (r.DataType === 'DateTime') val = r.DateTimeValue ?? null;
          else val = r.TextValue ?? null;
          row[r.AttributeName] = val;
        }
      }
      rowsByEntity.set(entity.EntityId, [...pivotMap.values()]);
    }
  }

  // 4. Build attribute lookup by EntityId
  const attrsByEntity = new Map();
  for (const attr of dbAttributes) {
    const eid = attr.EntityId;
    if (!attrsByEntity.has(eid)) attrsByEntity.set(eid, []);
    attrsByEntity.get(eid).push({
      displayName: attr.DisplayName,
      name: attr.Name,
      dataType: attr.DataType,
      maxLength: attr.MaxLength ?? null,
      isRequired: !!attr.IsRequired,
      isCode: !!attr.IsCode,
      isName: !!attr.IsName,
      isHidden: !!attr.IsHidden,
      isSystemDate: !!attr.IsSystemDate,
      sortOrder: attr.SortOrder,
      domainEntityName: attr.DomainEntityName ?? null,
      domainEntityModelName: attr.DomainEntityModelName ?? null,
      dateFormat: attr.DateFormat ?? null,
      booleanDisplayFormat: attr.BooleanDisplayFormat ?? null,
      decimalPlaces: attr.DecimalPlaces ?? null,
      allowNegative: attr.AllowNegative ?? null,
      description: attr.Description ?? null,
    });
  }

  // 5. Build derived columns lookup by EntityId
  const derivedByEntity = new Map();
  for (const dc of dbDerivedCols) {
    const eid = dc.EntityId;
    if (!derivedByEntity.has(eid)) derivedByEntity.set(eid, []);
    derivedByEntity.get(eid).push({
      displayName: dc.DisplayName,
      attributePath: dc.AttributePath,
      sortOrder: dc.SortOrder,
    });
  }

  // 6. Build entities lookup by ModelId
  const entitiesByModel = new Map();
  for (const entity of dbEntities) {
    const mid = entity.ModelId;
    const eid = entity.EntityId;
    if (!entitiesByModel.has(mid)) entitiesByModel.set(mid, []);

    const entityObj = {
      name: entity.Name,
      description: entity.Description ?? null,
      tableName: entity.TableName,
      sortOrder: entity.SortOrder,
      isActive: !!entity.IsActive,
      requiresApproval: !!entity.RequiresApproval,
      approvalStrategy: entity.ApprovalStrategy ?? null,
      approverCanApproveOwn: !!entity.ApproverCanApproveOwn,
      sharedAcrossModels: !!entity.SharedAcrossModels,
      autoGenerateCode: !!entity.AutoGenerateCode,
      attributes: attrsByEntity.get(eid) || [],
      derivedColumns: derivedByEntity.get(eid) || [],
      rows: includeData ? (rowsByEntity.get(eid) || []) : null,
    };

    if (includePermissions) {
      entityObj.permissions = permissionsByEntity.get(eid) || [];
    }

    entitiesByModel.get(mid).push(entityObj);
  }

  // 7. Build final response
  const models = dbModels.map(m => ({
    name: m.Name,
    description: m.Description ?? null,
    isActive: !!m.IsActive,
    sortOrder: m.SortOrder,
    entities: entitiesByModel.get(m.ModelId) || [],
  }));

  const domainWarnings = dbDomainWarnings.map(w => w.Warning);

  res.json({
    exportedAt: new Date().toISOString(),
    models,
    domainWarnings,
  });
}));

// POST /api/model-export/import/preview — Preview an import without modifying data
router.post('/import/preview', requireAdmin, asyncHandler(async (req, res) => {
  const { payload } = req.body;

  if (!payload || !Array.isArray(payload.models)) {
    return res.status(400).json({ error: 'payload with models array required' });
  }

  const pool = await getPool();
  const entities = [];

  for (const model of payload.models) {
    for (const entity of (model.entities || [])) {
      const preview = {
        modelName: model.name,
        entityName: entity.name,
        status: 'new',
        suggestedAction: 'create',
        importedAttributeCount: (entity.attributes || []).length,
        importedDerivedColumnCount: (entity.derivedColumns || []).length,
        importedRowCount: Array.isArray(entity.rows) ? entity.rows.length : 0,
        existingRowCount: 0,
        domainMismatches: [],
      };

      // Check if entity exists in DB
      try {
        const checkReq = pool.request();
        checkReq.input('EntityName', sql.NVarChar(200), entity.name);
        checkReq.input('ModelName', sql.NVarChar(200), model.name);
        const checkResult = await checkReq.query(`
          SELECT e.Id, (SELECT COUNT(*) FROM EntityRows WHERE EntityId = e.Id) AS [RowCount]
          FROM Entities e
          INNER JOIN Models m ON e.ModelId = m.Id
          WHERE e.Name = @EntityName AND m.Name = @ModelName
        `);
        if (checkResult.recordset.length > 0) {
          preview.status = 'exists';
          preview.suggestedAction = 'overwrite';
          preview.existingRowCount = checkResult.recordset[0].RowCount;
        }
      } catch (err) {
        logger.error(`Preview entity check failed for "${entity.name}": ${err.message}`, { category: 'model-import' });
      }

      // Check for domain mismatches
      for (const attr of (entity.attributes || [])) {
        if (attr.dataType === 'Domain' && attr.domainEntityName) {
          try {
            const domReq = pool.request();
            domReq.input('EntityName', sql.NVarChar(200), attr.domainEntityName);
            domReq.input('ModelName', sql.NVarChar(200), attr.domainEntityModelName || '');
            const domResult = await domReq.query(`
              SELECT e.Id FROM Entities e
              LEFT JOIN Models m ON e.ModelId = m.Id
              WHERE e.Name = @EntityName AND (m.Name = @ModelName OR @ModelName = '')
            `);
            if (domResult.recordset.length === 0) {
              preview.domainMismatches.push({
                attributeName: attr.displayName || attr.name,
                missingEntity: attr.domainEntityModelName
                  ? `${attr.domainEntityName} (${attr.domainEntityModelName})`
                  : attr.domainEntityName,
              });
            }
          } catch {
            // If query fails, flag as mismatch
            preview.domainMismatches.push({
              attributeName: attr.displayName || attr.name,
              missingEntity: attr.domainEntityName,
            });
          }
        }
      }

      entities.push(preview);
    }
  }

  res.json({
    entities,
    domainWarnings: payload.domainWarnings || [],
  });
}));

// POST /api/model-export/import/execute — Execute model import with NDJSON streaming
router.post('/import/execute', requireAdmin, asyncHandler(async (req, res) => {
  const { payload, actions, importData = false } = req.body;

  if (!payload || !Array.isArray(payload.models)) {
    return res.status(400).json({ error: 'payload with models array required' });
  }
  if (!actions || typeof actions !== 'object') {
    return res.status(400).json({ error: 'actions object required' });
  }

  res.writeHead(200, {
    'Content-Type': 'application/x-ndjson',
    'Cache-Control': 'no-cache',
    'X-Accel-Buffering': 'no',
  });

  const send = (data) => { try { res.write(JSON.stringify(data) + '\n'); } catch { /* connection closed */ } };

  // Flatten entities with their model info
  const allEntities = [];
  for (const model of payload.models) {
    for (const entity of (model.entities || [])) {
      const key = `${model.name}::${entity.name}`;
      const action = actions[key];
      if (!action || action === 'skip') continue;
      allEntities.push({ model, entity, action });
    }
  }

  send({ phase: 'start', totalEntities: allEntities.length });

  const pool = await getPool();
  const transaction = pool.transaction();

  try {
    await transaction.begin();

    const stats = {
      modelsCreated: 0,
      entitiesCreated: 0,
      entitiesUpdated: 0,
      entitiesSkipped: 0,
      rowsImported: 0,
      permissionsSkipped: 0,
    };

    const importedEntityIds = [];
    const entityIdMap = new Map(); // key -> entityId for data/permissions phases
    const modelIdCache = new Map(); // modelName -> modelId

    // ---- Phase 1: Structure ----
    for (let i = 0; i < allEntities.length; i++) {
      const { model, entity, action } = allEntities[i];
      const progress = Math.round(((i + 1) / allEntities.length) * 100);

      send({ phase: 'entity', progress, entityName: entity.name, action });

      // Upsert model
      let modelId = modelIdCache.get(model.name);
      if (modelId === undefined) {
        const modelReq = transaction.request();
        modelReq.input('Name', sql.NVarChar(200), model.name);
        modelReq.input('Description', sql.NVarChar(sql.MAX), model.description || null);
        modelReq.input('IsActive', sql.Bit, model.isActive !== false ? 1 : 0);
        modelReq.input('SortOrder', sql.Int, model.sortOrder ?? 0);
        const modelResult = await modelReq.execute('usp_ModelImport_UpsertModel');
        modelId = modelResult.recordset[0].Id;
        if (modelResult.recordset[0].WasCreated) stats.modelsCreated++;
        modelIdCache.set(model.name, modelId);
      }

      // Upsert entity
      const entReq = transaction.request();
      entReq.input('ModelId', sql.Int, modelId);
      entReq.input('Name', sql.NVarChar(200), entity.name);
      entReq.input('Description', sql.NVarChar(sql.MAX), entity.description || null);
      entReq.input('TableName', sql.NVarChar(200), entity.tableName || entity.name.replace(/\s+/g, '_'));
      entReq.input('SortOrder', sql.Int, entity.sortOrder ?? 0);
      entReq.input('IsActive', sql.Bit, entity.isActive !== false ? 1 : 0);
      entReq.input('RequiresApproval', sql.Bit, entity.requiresApproval ? 1 : 0);
      entReq.input('ApprovalStrategy', sql.NVarChar(50), entity.approvalStrategy || null);
      entReq.input('ApproverCanApproveOwn', sql.Bit, entity.approverCanApproveOwn ? 1 : 0);
      entReq.input('SharedAcrossModels', sql.Bit, entity.sharedAcrossModels ? 1 : 0);
      entReq.input('AutoGenerateCode', sql.Bit, entity.autoGenerateCode ? 1 : 0);
      entReq.input('ConflictAction', sql.NVarChar(20), action);
      const entResult = await entReq.execute('usp_ModelImport_UpsertEntity');
      const entityId = entResult.recordset[0].Id;

      if (entResult.recordset[0].WasSkipped) {
        stats.entitiesSkipped++;
        continue;
      }
      if (entResult.recordset[0].WasCreated) stats.entitiesCreated++;
      else stats.entitiesUpdated++;

      importedEntityIds.push(entityId);
      entityIdMap.set(`${model.name}::${entity.name}`, entityId);

      // Sync attributes (skip domain FKs in phase 1)
      if (entity.attributes && entity.attributes.length > 0) {
        const attrReq = transaction.request();
        attrReq.input('EntityId', sql.Int, entityId);
        attrReq.input('AttributesJson', sql.NVarChar(sql.MAX), JSON.stringify(entity.attributes));
        attrReq.input('SkipDomainFKs', sql.Bit, 1);
        await attrReq.execute('usp_ModelImport_SyncAttributes');
      }

      // Sync derived columns
      if (entity.derivedColumns && entity.derivedColumns.length > 0) {
        const dcReq = transaction.request();
        dcReq.input('EntityId', sql.Int, entityId);
        dcReq.input('DerivedColumnsJson', sql.NVarChar(sql.MAX), JSON.stringify(entity.derivedColumns));
        await dcReq.execute('usp_ModelImport_SyncDerivedColumns');
      }
    }

    // ---- Phase 2: Resolve domain FKs ----
    if (importedEntityIds.length > 0) {
      const fkReq = transaction.request();
      fkReq.input('ImportedEntityIdsJson', sql.NVarChar(sql.MAX), JSON.stringify(importedEntityIds));
      await fkReq.execute('usp_ModelImport_ResolveDomainFKs');
    }

    // ---- Phase 3: Data rows ----
    if (importData) {
      const userId = req.user?.id || null;
      for (const { model, entity, action } of allEntities) {
        if (!Array.isArray(entity.rows) || entity.rows.length === 0) continue;
        const entityId = entityIdMap.get(`${model.name}::${entity.name}`);
        if (!entityId) continue;

        // Get attribute metadata for this entity in the target environment
        // (IDs differ from source; usp_Export_GetEntityData result set 2 has DomainEntityId)
        const metaResult = await transaction.request()
          .input('EntityId', sql.Int, entityId)
          .execute('usp_Export_GetEntityData');
        const attrByName = new Map(
          (metaResult.recordsets[1] || []).map(a => [a.Name, { id: a.Id, dataType: a.DataType, domainEntityId: a.DomainEntityId }])
        );

        // Normalise rows: old export files use raw EAV format (one row per attribute,
        // with capital Code/Name/AttributeName keys). New files use flat format.
        let flatRows = entity.rows;
        if (flatRows.length > 0 && 'AttributeName' in flatRows[0]) {
          const pivotMap = new Map();
          for (const r of flatRows) {
            if (!pivotMap.has(r.Id)) pivotMap.set(r.Id, { code: r.Code, name: r.Name });
            if (r.AttributeName) {
              const row = pivotMap.get(r.Id);
              let val;
              if (r.DataType === 'Domain') val = r.DomainCode ?? null;
              else if (r.DataType === 'Int' || r.DataType === 'Boolean') val = r.IntValue ?? null;
              else if (r.DataType === 'Decimal') val = r.DecimalValue ?? null;
              else if (r.DataType === 'DateTime') val = r.DateTimeValue ?? null;
              else val = r.TextValue ?? null;
              row[r.AttributeName] = val;
            }
          }
          flatRows = [...pivotMap.values()];
        }

        // Collect all domain resolution items across all rows
        const domainItems = [];
        let itemIdx = 0;
        const rowDomainIdxMaps = flatRows.map(flat => {
          const rowMap = new Map();
          for (const [key, val] of Object.entries(flat)) {
            if (key === 'code' || key === 'name' || val == null) continue;
            const attr = attrByName.get(key);
            if (attr?.dataType === 'Domain' && attr.domainEntityId) {
              domainItems.push({ idx: itemIdx, domainEntityId: attr.domainEntityId, textValue: String(val) });
              rowMap.set(key, itemIdx++);
            }
          }
          return rowMap;
        });

        // Batch-resolve domain Code strings → EntityRow IDs
        const resolvedDomain = new Map();
        if (domainItems.length > 0) {
          const resolveResult = await transaction.request()
            .input('ItemsJson', sql.NVarChar(sql.MAX), JSON.stringify(domainItems))
            .execute('usp_Data_ResolveDomainValuesBatch');
          for (const r of resolveResult.recordset) {
            if (r.ResolvedRowId != null) resolvedDomain.set(r.idx, r.ResolvedRowId);
          }
        }

        // Convert flat rows → {code, name, values:[{attributeId,...}]} format
        const convertedRows = flatRows.map((flat, ri) => {
          const values = [];
          const domainMap = rowDomainIdxMaps[ri];
          for (const [key, val] of Object.entries(flat)) {
            if (key === 'code' || key === 'name' || val == null) continue;
            const attr = attrByName.get(key);
            if (!attr) continue;
            const entry = { attributeId: attr.id };
            if (attr.dataType === 'Domain') {
              const resolved = resolvedDomain.get(domainMap.get(key));
              if (resolved != null) entry.domainValue = resolved;
              else continue;
            } else if (attr.dataType === 'Int' || attr.dataType === 'Boolean') {
              entry.intValue = Number(val);
            } else if (attr.dataType === 'Decimal') {
              entry.decimalValue = Number(val);
            } else if (attr.dataType === 'DateTime') {
              entry.dateTimeValue = val;
            } else {
              entry.textValue = String(val);
            }
            values.push(entry);
          }
          return { code: flat.code, name: flat.name, values };
        });

        const conflictAction = action === 'skip' || action === 'create' ? 'import' : action;
        const dataReq = transaction.request();
        dataReq.input('EntityId', sql.Int, entityId);
        dataReq.input('ConflictAction', sql.NVarChar(20), conflictAction);
        dataReq.input('RowsJson', sql.NVarChar(sql.MAX), JSON.stringify(convertedRows));
        dataReq.input('UserId', sql.Int, userId);
        const dataResult = await dataReq.execute('usp_Data_BulkImportRows');
        const rowStats = dataResult.recordset[0];
        stats.rowsImported += (rowStats.inserted || 0) + (rowStats.updated || 0);
      }
    }

    // ---- Phase 4: Permissions ----
    for (const { model, entity } of allEntities) {
      if (!Array.isArray(entity.permissions) || entity.permissions.length === 0) continue;
      const entityId = entityIdMap.get(`${model.name}::${entity.name}`);
      if (!entityId) continue;

      const permReq = transaction.request();
      permReq.input('EntityId', sql.Int, entityId);
      permReq.input('PermissionsJson', sql.NVarChar(sql.MAX), JSON.stringify(entity.permissions));
      const permResult = await permReq.execute('usp_ModelImport_SyncPermissions');
      stats.permissionsSkipped += permResult.recordset[0]?.PermissionsSkipped || 0;
    }

    await transaction.commit();
    send({ phase: 'done', ...stats });
  } catch (err) {
    try { await transaction.rollback(); } catch { /* already rolled back */ }
    logger.error(`Model import execute failed: ${err.message}`, { error: err.message, category: 'model-import' });
    send({ phase: 'error', message: err.message });
  }

  res.end();
}));

export default router;
