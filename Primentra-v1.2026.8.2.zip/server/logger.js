import { appendFileSync, statSync, renameSync, unlinkSync, existsSync, mkdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const LOGS_DIR = join(__dirname, '..', 'logs');
try { mkdirSync(LOGS_DIR, { recursive: true }); } catch { /* ignore */ }
const LOG_FILE = join(LOGS_DIR, 'errorlog.txt');
const MAX_SIZE = 10 * 1024 * 1024; // 10 MB
const MAX_ROTATIONS = 3;

// ---------------------------------------------------------------------------
// Log category settings cache
// ---------------------------------------------------------------------------
let _categorySettings = {
  errorLogHttpErrors: true,
  errorLogClientErrors: true,
  errorLogSlowRequests: false,
  errorLogSlowThresholdMs: 5000,
  errorLogServerEvents: true,
};
let _settingsAge = 0;
const SETTINGS_TTL = 60_000; // refresh every 60 seconds
let _settingsLoader = null;
let _settingsLoading = false;

export function setSettingsLoader(fn) {
  _settingsLoader = fn;
  // Load immediately on registration
  refreshSettings();
}

async function refreshSettings() {
  if (!_settingsLoader || _settingsLoading) return;
  if (Date.now() - _settingsAge < SETTINGS_TTL) return;
  _settingsLoading = true;
  try {
    const settings = await _settingsLoader();
    if (settings) {
      if (settings.errorLogHttpErrors !== undefined)    _categorySettings.errorLogHttpErrors = settings.errorLogHttpErrors;
      if (settings.errorLogClientErrors !== undefined)  _categorySettings.errorLogClientErrors = settings.errorLogClientErrors;
      if (settings.errorLogSlowRequests !== undefined)  _categorySettings.errorLogSlowRequests = settings.errorLogSlowRequests;
      if (settings.errorLogSlowThresholdMs !== undefined) _categorySettings.errorLogSlowThresholdMs = settings.errorLogSlowThresholdMs;
      if (settings.errorLogServerEvents !== undefined)  _categorySettings.errorLogServerEvents = settings.errorLogServerEvents;
    }
    _settingsAge = Date.now();
  } catch { /* settings load failure should never crash the server */ }
  _settingsLoading = false;
}

export function getLogSettings() {
  return { ..._categorySettings };
}

// ---------------------------------------------------------------------------
// File rotation + write
// ---------------------------------------------------------------------------
function rotateIfNeeded() {
  try {
    if (!existsSync(LOG_FILE)) return;
    const stats = statSync(LOG_FILE);
    if (stats.size < MAX_SIZE) return;

    // Shift existing rotations: errorlog.2.txt → errorlog.3.txt, etc.
    for (let i = MAX_ROTATIONS; i >= 1; i--) {
      const from = i === 1 ? LOG_FILE : `${LOG_FILE.replace('.txt', '')}.${i - 1}.txt`;
      const to = `${LOG_FILE.replace('.txt', '')}.${i}.txt`;
      if (existsSync(from)) {
        if (i === MAX_ROTATIONS && existsSync(to)) unlinkSync(to);
        renameSync(from, to);
      }
    }
  } catch { /* rotation failure should never crash the server */ }
}

function writeToFile(entry) {
  try {
    rotateIfNeeded();
    appendFileSync(LOG_FILE, JSON.stringify(entry) + '\n', 'utf8');
  } catch { /* file write failure should never crash the server */ }
}

// ---------------------------------------------------------------------------
// Database write (filtered by category settings)
// ---------------------------------------------------------------------------
let _dbWrite = null;
export function setDbWriter(fn) {
  _dbWrite = fn;
}

function shouldWriteToDb(entry) {
  const status = entry.statusCode;
  const cat = entry.category;

  // Slow request category
  if (cat === 'slow') return _categorySettings.errorLogSlowRequests;

  // Server event category (startup, shutdown, DB changes)
  if (cat === 'server') return _categorySettings.errorLogServerEvents;

  // HTTP 5xx errors
  if (status >= 500) return _categorySettings.errorLogHttpErrors;

  // HTTP 4xx client errors
  if (status >= 400 && status < 500) return _categorySettings.errorLogClientErrors;

  // Default: write errors and warnings without a status code (e.g. unhandled exceptions)
  if (entry.level === 'error') return _categorySettings.errorLogHttpErrors;

  return false;
}

function writeToDb(entry) {
  if (!_dbWrite) return;
  if (!shouldWriteToDb(entry)) return;
  try { _dbWrite(entry).catch(() => {}); } catch { /* ignore */ }
}

// ---------------------------------------------------------------------------
// Main log function
// ---------------------------------------------------------------------------
function log(level, message, context = {}) {
  const entry = {
    timestamp: new Date().toISOString(),
    level,
    message,
    method: context.method || null,
    path: context.path || null,
    statusCode: context.statusCode || null,
    userId: context.userId || null,
    stack: context.stack || null,
    requestBody: context.requestBody ? String(context.requestBody).slice(0, 2000) : null,
    duration: context.duration || null,
    category: context.category || null,
  };

  // Always write to file
  writeToFile(entry);

  // Also write to console for dev visibility
  if (level === 'error') {
    console.error(`[${level.toUpperCase()}] ${entry.method || ''} ${entry.path || ''}: ${message}`);
  }

  // Write to database (filtered by category settings)
  if (level === 'error' || level === 'warn') {
    writeToDb(entry);
  }

  // Periodically refresh settings in the background
  refreshSettings();

  return entry;
}

// ---------------------------------------------------------------------------
// Slow request middleware
// ---------------------------------------------------------------------------
export function slowRequestMiddleware(req, res, next) {
  if (!_categorySettings.errorLogSlowRequests) {
    return next();
  }

  const start = Date.now();
  const originalEnd = res.end;

  res.end = function (...args) {
    const duration = Date.now() - start;
    const threshold = _categorySettings.errorLogSlowThresholdMs || 5000;

    if (duration >= threshold) {
      log('warn', `Slow request: ${duration}ms`, {
        method: req.method,
        path: req.originalUrl || req.path,
        statusCode: res.statusCode,
        userId: req.user?.id || null,
        duration,
        category: 'slow',
      });
    }

    originalEnd.apply(res, args);
  };

  next();
}

// ---------------------------------------------------------------------------
// Exports
// ---------------------------------------------------------------------------
const logger = {
  error: (message, context) => log('error', message, context),
  warn: (message, context) => log('warn', message, context),
  info: (message, context) => log('info', message, context),
  LOG_FILE,
};

export default logger;
