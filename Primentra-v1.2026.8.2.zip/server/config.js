import { readFileSync, writeFileSync, existsSync } from 'fs';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
// MDS_CONFIG_PATH lets a second server instance (e.g. an isolated E2E/test stack)
// point at its own config + database without disturbing the primary install.
export const CONFIG_PATH = process.env.MDS_CONFIG_PATH || resolve(__dirname, '..', 'mds-config.json');

export const DEFAULTS = {
  hostname: "",
  instance: "",
  sqlPort: null,
  database: "",
  username: "",
  password: "",
  trustServerCertificate: true,
  // Public URL of this installation, e.g. "https://mdm.example.com". Used to build the
  // links in password-reset and welcome emails. Must be configured explicitly: deriving
  // it from request headers lets a caller point those links at a host they control.
  appBaseUrl: "",
  theme: "light",
  licenseKey: "",
  licenseOrg: "",
  licenseIssued: "",
  licenseExpiry: "",
  licenseValid: false,
  licenseTrial: false,
  forceSetupScreen: false,
  sessionTimeoutHours: 24,
  auditRetentionDays: 90,
  approvalRetentionDays: 365,
  stagingRetentionDays: 7,
  schedulerLogRetentionDays: 30,
  smtp: {
    host: "",
    port: 587,
    tls: false,
    username: "",
    password: "",
    fromAddress: "",
    fromName: "Primentra",
  },
  licenseNotification: {
    enabled: false,
    daysBeforeExpiry: [30, 14, 7, 3, 1],
    recipients: "",
    frequency: "daily",
  },
};

// Read config from file
export function readConfig() {
  try {
    if (existsSync(CONFIG_PATH)) {
      const raw = readFileSync(CONFIG_PATH, 'utf-8');
      return { ...DEFAULTS, ...JSON.parse(raw) };
    }
  } catch { /* ignore */ }
  return { ...DEFAULTS };
}

// Write config to file
// Merge over the CURRENT config, not over DEFAULTS. Callers routinely send only the fields
// they are changing, and merging over DEFAULTS silently resets everything they left out.
// That is what made a fresh install report "License expired": the setup wizard posts only
// the database fields, which reset licenseValid and licenseTrial to their defaults while the
// trial itself was running perfectly fine.
// readConfig() already layers the stored file over DEFAULTS, so new keys still get a value.
export function writeConfig(data) {
  const merged = { ...readConfig(), ...data };
  writeFileSync(CONFIG_PATH, JSON.stringify(merged, null, 2) + '\n', 'utf-8');
  return merged;
}
