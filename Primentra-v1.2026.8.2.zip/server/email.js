import nodemailer from 'nodemailer';
import { readConfig } from './config.js';
import { escapeHtml } from './utils/html.js';

// Create a transporter from current config (fresh read each call)
function createTransport() {
  const config = readConfig();
  const smtp = config.smtp || {};

  if (!smtp.host) {
    const err = new Error('SMTP is not configured. Configure it under Administration → General Settings → Email.');
    err.status = 422;
    throw err;
  }

  const port = smtp.port || 587;

  return nodemailer.createTransport({
    host: smtp.host,
    port,
    secure: port === 465,              // implicit TLS only on port 465
    requireTLS: smtp.tls === true && port !== 465, // STARTTLS required on 587/25 when TLS enabled
    auth: (smtp.username && smtp.password) ? {
      user: smtp.username,
      pass: smtp.password,
    } : undefined,
    tls: { rejectUnauthorized: false }, // on-prem servers often use self-signed certs
  });
}

// Get "from" address from config
function getFrom() {
  const config = readConfig();
  const smtp = config.smtp || {};
  const name = smtp.fromName || 'Primentra';
  const address = smtp.fromAddress || smtp.username || 'noreply@primentra.com';
  return { name, address };
}

// Send a generic email
export async function sendMail({ to, subject, html, text }) {
  const transporter = createTransport();
  const from = getFrom();
  return transporter.sendMail({ from, to, subject, html, text });
}

// Send a test email to verify SMTP configuration
export async function sendTestEmail(recipientEmail) {
  return sendMail({
    to: recipientEmail,
    subject: 'Primentra — Test Email',
    html: `
      <div style="font-family: 'Segoe UI', sans-serif; max-width: 520px;">
        <h2 style="color: #0f766e; margin-bottom: 8px;">Email Configuration Successful</h2>
        <p style="color: #334155;">
          This is a test email from your Primentra instance. If you received this, your SMTP configuration is working correctly.
        </p>
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 16px 0;" />
        <p style="color: #94a3b8; font-size: 13px;">Sent by Primentra</p>
      </div>
    `,
    text: 'Primentra — Test Email\n\nThis is a test email from your Primentra instance. If you received this, your SMTP configuration is working correctly.',
  });
}

// Send a welcome email to a newly created user
export async function sendWelcomeEmail({ to, displayName, email, password, loginUrl, loginLink, mustChangePassword, roles }) {
  const subject = '👋 Welcome to Primentra';

  const safeDisplay = escapeHtml(displayName);
  const safeEmail = escapeHtml(email);
  const safePassword = escapeHtml(password);
  const safeLoginUrl = escapeHtml(loginUrl);
  const safeLoginLink = escapeHtml(loginLink || loginUrl);

  // Login email row is always shown; password row only when no magic link and password is provided
  const emailRow = `<tr>
        <td style="padding:8px 14px;font-size:13px;color:#64748b;border-bottom:1px solid #f1f5f9">Login email</td>
        <td style="padding:8px 14px;font-size:13px;font-weight:600;color:#0f172a;border-bottom:1px solid #f1f5f9">${safeEmail}</td>
      </tr>`;
  const passwordRow = (!loginLink && password) ? `<tr>
        <td style="padding:8px 14px;font-size:13px;color:#64748b;border-bottom:1px solid #f1f5f9">Temporary password</td>
        <td style="padding:8px 14px;font-size:13px;font-weight:700;color:#0f172a;font-family:'Courier New',monospace;border-bottom:1px solid #f1f5f9">${safePassword}</td>
      </tr>` : '';
  const credRows = emailRow + passwordRow;

  const loginLinkBlock = loginLink
    ? `<div style="background:#f0fdfa;border:1px solid #99f6e4;border-radius:10px;padding:16px 20px;margin:20px 0">
        <div style="font-size:13px;font-weight:700;color:#0f766e;margin-bottom:6px">&#128279; One-click sign-in link</div>
        <p style="font-size:13px;color:#334155;line-height:1.5;margin:0 0 14px">
          Click the button below to sign in and set your personal password. This link is valid for <strong>72 hours</strong> and can only be used once.
        </p>
        <div style="text-align:center">
          <a href="${safeLoginLink}" style="display:inline-block;background:#0f766e;color:#ffffff;text-decoration:none;font-weight:700;font-size:14px;padding:12px 32px;border-radius:8px">Sign in &amp; set password</a>
        </div>
      </div>`
    : '';

  let rolesHtml;
  if (roles && roles.length > 0) {
    const rows = roles.map(g =>
      `<tr><td style="padding:8px 14px;font-size:13px;color:#334155;border-bottom:1px solid #f1f5f9">${escapeHtml(g.roleName)}</td></tr>`
    ).join('');
    rolesHtml = `
      <div style="margin:20px 0">
        <div style="font-size:12px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px">Your role access</div>
        <table style="width:100%;border-collapse:collapse;border:1px solid #e2e8f0;border-radius:8px;overflow:hidden">
          <thead><tr style="background:#f8fafc"><th style="padding:8px 14px;text-align:left;font-size:12px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px">Role</th></tr></thead>
          <tbody>${rows}</tbody>
        </table>
      </div>`;
  } else {
    rolesHtml = `<p style="color:#94a3b8;font-size:13px;font-style:italic;margin:16px 0">No roles assigned yet. Contact your administrator to request access.</p>`;
  }

  // If using loginLink: no mustChangeNote needed (the link itself enforces it)
  const mustChangeNote = (mustChangePassword && !loginLink)
    ? `<div style="background:#fef3c7;border:1px solid #fcd34d;border-radius:8px;padding:12px 16px;font-size:13px;color:#92400e;margin:16px 0">
        &#9888;&#65039; You will be prompted to set a new password on first sign-in.
       </div>`
    : '';

  const html = `
    <div style="font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;max-width:560px;margin:0 auto">
      <div style="background:#0f766e;padding:28px 32px;border-radius:12px 12px 0 0">
        <div style="font-size:22px;font-weight:700;color:#fff;letter-spacing:-0.5px">Primentra</div>
        <div style="font-size:13px;color:#99f6e4;margin-top:4px">Master Data Management</div>
      </div>
      <div style="background:#ffffff;padding:32px;border-left:1px solid #e2e8f0;border-right:1px solid #e2e8f0">
        <h2 style="font-size:20px;font-weight:700;color:#0f172a;margin:0 0 8px">Welcome, ${safeDisplay}!</h2>
        <p style="font-size:14px;color:#334155;line-height:1.6;margin:0 0 24px">
          Your account is ready. Sign in to browse your organization&rsquo;s master data, edit records, and keep everything in sync.
        </p>
        <table style="width:100%;border-collapse:collapse;border:1px solid #e2e8f0;border-radius:8px;overflow:hidden;margin-bottom:8px">
          <tbody>${credRows}</tbody>
        </table>
        ${mustChangeNote}
        ${loginLinkBlock}
        ${rolesHtml}
        <p style="font-size:13px;color:#475569;line-height:1.6;margin:20px 0 0">
          Your first step: open an entity from the sidebar and explore the data grid. You can view, filter, and edit records right away.
        </p>
        ${!loginLink ? `<div style="text-align:center;margin:28px 0 8px">
          <a href="${safeLoginUrl}" style="display:inline-block;background:#0f766e;color:#ffffff;text-decoration:none;font-weight:700;font-size:14px;padding:14px 36px;border-radius:8px">Explore your data</a>
        </div>` : ''}
      </div>
      <div style="padding:16px 32px;background:#f8fafc;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 12px 12px">
        <p style="font-size:12px;color:#94a3b8;margin:0">
          <a href="https://primentra.com/docs" style="color:#0f766e;text-decoration:none">Documentation</a>
          &nbsp;&middot;&nbsp;
          <a href="${safeLoginUrl}" style="color:#0f766e;text-decoration:none">${safeLoginUrl}</a>
        </p>
      </div>
    </div>`;

  const actionText = loginLink
    ? `Use this one-time sign-in link (valid 72 hours) to set your password:\n${loginLink}`
    : `${password ? `Temporary password: ${password}\n` : ''}${mustChangePassword ? 'You will be prompted to change your password on first sign-in.\n' : ''}Sign in at: ${loginUrl}`;

  const text = `Welcome to Primentra, ${displayName}!\n\nYour account is ready.\nEmail: ${email}\n${actionText}\n\nRoles: ${roles && roles.length > 0 ? roles.map(g => g.roleName).join(', ') : 'None assigned'}\n\nYour first step: open an entity from the sidebar and explore the data grid.\n\nDocs: https://primentra.com/docs`;

  return sendMail({ to, subject, html, text });
}

// Send an approval request notification email to approvers
export async function sendApprovalRequestEmail({ to, submitterName, entityName, countNew, countEdit, countDelete, submitterNote, appUrl, otherApprovers = [] }) {
  const safeSubmitter = escapeHtml(String(submitterName || ''));
  const safeEntity = escapeHtml(String(entityName || ''));
  const safeAppUrl = escapeHtml(String(appUrl || ''));
  const safeNote = submitterNote ? escapeHtml(String(submitterNote)) : null;

  const totalCount = (countNew || 0) + (countEdit || 0) + (countDelete || 0);
  const subject = `\uD83D\uDD14 Action required: ${totalCount} ${safeEntity} change${totalCount !== 1 ? 's' : ''} awaiting your approval`;

  const summaryLines = [
    countNew > 0 ? `<div style="font-size:13px;color:#0f172a;padding:4px 0">\uD83C\uDD95 <strong>${countNew}</strong> new record${countNew !== 1 ? 's' : ''}</div>` : '',
    countEdit > 0 ? `<div style="font-size:13px;color:#0f172a;padding:4px 0">\u270F\uFE0F <strong>${countEdit}</strong> update${countEdit !== 1 ? 's' : ''}</div>` : '',
    countDelete > 0 ? `<div style="font-size:13px;color:#0f172a;padding:4px 0">\uD83D\uDDD1\uFE0F <strong>${countDelete}</strong> deletion${countDelete !== 1 ? 's' : ''}</div>` : '',
  ].filter(Boolean).join('');

  const noteBlock = safeNote
    ? `<div style="background:#fef3c7;border:1px solid #fcd34d;border-radius:8px;padding:14px 18px;margin:20px 0">
        <div style="font-size:12px;font-weight:700;color:#92400e;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px">Note from submitter</div>
        <div style="font-size:13px;color:#78350f;line-height:1.5">${safeNote}</div>
      </div>`
    : '';

  const otherApproversBlock = otherApprovers.length > 0
    ? `<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:14px 18px;margin:20px 0">
        <div style="font-size:12px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px">Also notified</div>
        <div style="font-size:13px;color:#475569;line-height:1.8">${otherApprovers.map(n => escapeHtml(String(n))).join('<br/>')}</div>
      </div>`
    : '';

  const html = `
    <div style="font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;max-width:560px;margin:0 auto">
      <div style="background:#0f766e;padding:28px 32px;border-radius:12px 12px 0 0">
        <div style="font-size:22px;font-weight:700;color:#fff;letter-spacing:-0.5px">Primentra</div>
        <div style="font-size:13px;color:#99f6e4;margin-top:4px">Master Data Management</div>
      </div>
      <div style="background:#ffffff;padding:32px;border-left:1px solid #e2e8f0;border-right:1px solid #e2e8f0">
        <h2 style="font-size:20px;font-weight:700;color:#0f172a;margin:0 0 8px">Approval required</h2>
        <p style="font-size:14px;color:#334155;line-height:1.6;margin:0 0 24px">
          <strong>${safeSubmitter}</strong> has submitted changes to <strong>${safeEntity}</strong> that require your approval.
        </p>
        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:16px 20px;margin-bottom:20px">
          <div style="font-size:12px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:10px">Change summary</div>
          ${summaryLines}
        </div>
        ${noteBlock}
        ${otherApproversBlock}
        <div style="text-align:center;margin:28px 0 8px">
          <a href="${safeAppUrl}/approvals" style="display:inline-block;background:#0f766e;color:#ffffff;text-decoration:none;font-weight:700;font-size:14px;padding:12px 32px;border-radius:8px">Review and decide</a>
        </div>
      </div>
      <div style="padding:16px 32px;background:#f8fafc;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 12px 12px">
        <p style="font-size:12px;color:#94a3b8;margin:0">Sent by Primentra &mdash; <a href="${safeAppUrl}" style="color:#0f766e;text-decoration:none">${safeAppUrl}</a></p>
      </div>
    </div>`;

  const text = `Approval required — Primentra\n\n${submitterName} has submitted changes to ${entityName}.\n\nSummary:\n- ${countNew} new record(s)\n- ${countEdit} update(s)\n- ${countDelete} deletion(s)\n${submitterNote ? `\nNote: ${submitterNote}\n` : ''}${otherApprovers.length > 0 ? `\nAlso notified: ${otherApprovers.join(', ')}\n` : ''}\nReview and decide: ${appUrl}/approvals`;

  return sendMail({ to, subject, html, text });
}

// Send an approval decision notification email to the submitter
export async function sendApprovalDecisionEmail({ to, submitterName, entityName, decision, reviewerName, comment, appUrl }) {
  const safeSubmitter = escapeHtml(String(submitterName || ''));
  const safeEntity = escapeHtml(String(entityName || ''));
  const safeReviewer = escapeHtml(String(reviewerName || ''));
  const safeAppUrl = escapeHtml(String(appUrl || ''));
  const safeComment = comment ? escapeHtml(String(comment)) : null;

  let subject, decisionLabel, decisionBox;

  let nextStepsBlock = '';

  if (decision === 'approved') {
    subject = `\u2705 Approved: your ${safeEntity} changes have been approved`;
    decisionLabel = 'Approved';
    decisionBox = `<div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:14px 18px;margin:20px 0">
      <div style="font-size:13px;font-weight:700;color:#166534;margin-bottom:4px">\u2705 ${decisionLabel}</div>
      <div style="font-size:13px;color:#15803d;line-height:1.5">Your changes to <strong>${safeEntity}</strong> have been approved by <strong>${safeReviewer}</strong> and are now live.</div>
    </div>`;
  } else if (decision === 'rejected') {
    subject = `\u274C Rejected: your ${safeEntity} changes have been rejected`;
    decisionLabel = 'Rejected';
    decisionBox = `<div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:14px 18px;margin:20px 0">
      <div style="font-size:13px;font-weight:700;color:#991b1b;margin-bottom:4px">\u274C ${decisionLabel}</div>
      <div style="font-size:13px;color:#b91c1c;line-height:1.5">Your changes to <strong>${safeEntity}</strong> have been rejected by <strong>${safeReviewer}</strong>.</div>
    </div>`;
    nextStepsBlock = `<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:16px 20px;margin:20px 0">
      <div style="font-size:12px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:10px">What happens next</div>
      <div style="font-size:13px;color:#334155;line-height:1.8">
        <div style="margin-bottom:6px">\uD83D\uDD13 <strong>The affected rows have been unlocked</strong> and are available for editing again.</div>
        <div>If the changes are still needed, open <strong>${safeEntity}</strong> in Primentra, make any necessary adjustments, and submit a new approval request.</div>
      </div>
    </div>`;
  } else {
    // sent_back
    subject = `\u21A9\uFE0F Returned for revision: your ${safeEntity} changes require adjustments`;
    decisionLabel = 'Returned for revision';
    decisionBox = `<div style="background:#fef3c7;border:1px solid #fcd34d;border-radius:8px;padding:14px 18px;margin:20px 0">
      <div style="font-size:13px;font-weight:700;color:#92400e;margin-bottom:4px">\u21A9\uFE0F ${decisionLabel}</div>
      <div style="font-size:13px;color:#78350f;line-height:1.5">Your changes to <strong>${safeEntity}</strong> have been returned for revision by <strong>${safeReviewer}</strong>.</div>
    </div>`;
    nextStepsBlock = `<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:16px 20px;margin:20px 0">
      <div style="font-size:12px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:10px">What happens next</div>
      <div style="font-size:13px;color:#334155;line-height:1.8">
        <div style="margin-bottom:6px">\uD83D\uDD13 <strong>The affected rows have been unlocked</strong> and are ready for editing.</div>
        <div style="margin-bottom:6px">Open <strong>${safeEntity}</strong> in Primentra, make your corrections based on the reviewer&rsquo;s feedback, and submit the changes again for approval.</div>
        <div>Your previous submission is visible under <em>My Submissions</em> for reference.</div>
      </div>
    </div>`;
  }

  const commentBlock = safeComment
    ? `<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:14px 18px;margin:20px 0">
        <div style="font-size:12px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px">Reviewer comment</div>
        <div style="font-size:13px;color:#334155;line-height:1.5">${safeComment}</div>
      </div>`
    : '';

  const html = `
    <div style="font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;max-width:560px;margin:0 auto">
      <div style="background:#0f766e;padding:28px 32px;border-radius:12px 12px 0 0">
        <div style="font-size:22px;font-weight:700;color:#fff;letter-spacing:-0.5px">Primentra</div>
        <div style="font-size:13px;color:#99f6e4;margin-top:4px">Master Data Management</div>
      </div>
      <div style="background:#ffffff;padding:32px;border-left:1px solid #e2e8f0;border-right:1px solid #e2e8f0">
        <h2 style="font-size:20px;font-weight:700;color:#0f172a;margin:0 0 8px">Decision on your changes</h2>
        <p style="font-size:14px;color:#334155;line-height:1.6;margin:0 0 24px">
          Hi <strong>${safeSubmitter}</strong>, a decision has been made on your submitted changes.
        </p>
        ${decisionBox}
        ${commentBlock}
        ${nextStepsBlock}
        <div style="text-align:center;margin:28px 0 8px">
          <a href="${safeAppUrl}/approvals" style="display:inline-block;background:#0f766e;color:#ffffff;text-decoration:none;font-weight:700;font-size:14px;padding:12px 32px;border-radius:8px">View details</a>
        </div>
      </div>
      <div style="padding:16px 32px;background:#f8fafc;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 12px 12px">
        <p style="font-size:12px;color:#94a3b8;margin:0">Sent by Primentra &mdash; <a href="${safeAppUrl}" style="color:#0f766e;text-decoration:none">${safeAppUrl}</a></p>
      </div>
    </div>`;

  const nextStepsText = decision === 'sent_back'
    ? `\n\nWhat happens next:\n- The affected rows have been unlocked and are ready for editing.\n- Open ${entityName} in Primentra, make your corrections, and submit again for approval.\n- Your previous submission is visible under My Submissions for reference.`
    : decision === 'rejected'
    ? `\n\nWhat happens next:\n- The affected rows have been unlocked and are available for editing again.\n- If the changes are still needed, open ${entityName} in Primentra and submit a new approval request.`
    : '';

  const text = `Decision on your changes — Primentra\n\nHi ${submitterName},\n\n${decisionLabel}: your changes to ${entityName} have been ${decision === 'approved' ? 'approved and are now live' : decision === 'rejected' ? 'rejected' : 'returned for revision'} by ${reviewerName}.${comment ? `\n\nReviewer comment: ${comment}` : ''}${nextStepsText}\n\nView details: ${appUrl}/approvals`;

  return sendMail({ to, subject, html, text });
}

// Send a license expiry warning email
export async function sendLicenseExpiryWarning({ recipients, daysLeft, expiryDate, orgName }) {
  const subject = daysLeft <= 1
    ? 'Primentra — License Expires Tomorrow!'
    : `Primentra — License Expires in ${daysLeft} Days`;

  let urgencyColor = '#0f766e';
  if (daysLeft <= 3) urgencyColor = '#dc2626';
  else if (daysLeft <= 7) urgencyColor = '#d97706';

  return sendMail({
    to: recipients,
    subject,
    html: `
      <div style="font-family: 'Segoe UI', sans-serif; max-width: 520px;">
        <h2 style="color: ${urgencyColor}; margin-bottom: 8px;">License Expiry Warning</h2>
        <p style="color: #334155;">
          Your Primentra license for <strong>${orgName || 'your organization'}</strong> will expire
          on <strong>${expiryDate}</strong> (${daysLeft} day${daysLeft === 1 ? '' : 's'} remaining).
        </p>
        <p style="color: #334155;">
          Please renew your license to avoid interruption. After expiry, the application will become read-only.
        </p>
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 16px 0;" />
        <p style="color: #94a3b8; font-size: 13px;">Sent by Primentra</p>
      </div>
    `,
    text: `Primentra — License Expiry Warning\n\nYour license for ${orgName || 'your organization'} will expire on ${expiryDate} (${daysLeft} days remaining).\n\nPlease renew your license to avoid interruption.`,
  });
}
