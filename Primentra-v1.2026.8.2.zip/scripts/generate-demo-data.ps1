#Requires -Version 5.1
<#
.SYNOPSIS
    Generate realistic demo data for Primentra.
.DESCRIPTION
    Interactive script that creates models, entities (with all attribute types,
    domain references, cascading filters, derived columns), and realistic row data.
    Cleans existing data first, then generates and executes via sqlcmd.
.EXAMPLE
    .\generate-demo-data.ps1
    .\generate-demo-data.ps1 -Models 5 -EntitiesPerModel 6 -MaxRecords 200
#>

param(
    [ValidateRange(1,10)][int]$Models = 0,
    [ValidateRange(1,8)][int]$EntitiesPerModel = 0,
    [int]$MinRecords = -1,
    [int]$MaxRecords = -1,
    [ValidateRange(1,30)][int]$AvgAttributes = 0,
    [string]$Server = "127.0.0.1",
    [switch]$NonInteractive
)

$LargeThreshold = 5000  # Above this, use SQL CTE instead of PS arrays

$ErrorActionPreference = "Stop"

# Locate sqlcmd: prefer the ODBC Client SDK tools (highest version), else PATH
$SqlcmdPath = Get-ChildItem "C:\Program Files\Microsoft SQL Server\Client SDK\ODBC\*\Tools\Binn\SQLCMD.EXE" -ErrorAction SilentlyContinue |
    Sort-Object { [int]($_.FullName -replace '.*\\ODBC\\(\d+)\\.*', '$1') } -Descending |
    Select-Object -First 1 -ExpandProperty FullName
if (-not $SqlcmdPath) {
    $SqlcmdPath = (Get-Command sqlcmd -ErrorAction SilentlyContinue).Source
}
if (-not $SqlcmdPath) {
    throw "sqlcmd not found. Install the SQL Server command-line tools (sqlcmd) or add it to PATH."
}
$Database = "Primentra"

# ════════════════════════════════════════════════════════════════════
# PROMPTS
# ════════════════════════════════════════════════════════════════════

Write-Host ""
Write-Host "  Primentra Demo Data Generator" -ForegroundColor Cyan
Write-Host "  =============================" -ForegroundColor Cyan
Write-Host ""

if ($Models -eq 0) {
    if ($NonInteractive) {
        $Models = 3
    } else {
        $in = Read-Host "  How many models? (1-10, default: 3)"
        $Models = if ($in -and $in -match '^\d+$') { [Math]::Max(1, [Math]::Min(10, [int]$in)) } else { 3 }
    }
}
if ($EntitiesPerModel -eq 0) {
    if ($NonInteractive) {
        $EntitiesPerModel = 4
    } else {
        $in = Read-Host "  How many entities per model? (1-8, default: 4)"
        $EntitiesPerModel = if ($in -and $in -match '^\d+$') { [Math]::Max(1, [Math]::Min(8, [int]$in)) } else { 4 }
    }
}
if ($MinRecords -lt 0) {
    if ($NonInteractive) {
        $MinRecords = 0
    } else {
        $in = Read-Host "  Minimum records per entity? (0-1000000, default: 0)"
        $MinRecords = if ($in -and $in -match '^\d+$') { [Math]::Max(0, [Math]::Min(1000000, [int]$in)) } else { 0 }
    }
}
if ($MaxRecords -lt 0) {
    $defMax = if ($MinRecords -gt 50) { $MinRecords } else { 50 }
    if ($NonInteractive) {
        $MaxRecords = $defMax
    } else {
        $in = Read-Host "  Maximum records per entity? ($MinRecords-1000000, default: $defMax)"
        $MaxRecords = if ($in -and $in -match '^\d+$') { [Math]::Max($MinRecords, [Math]::Min(1000000, [int]$in)) } else { $defMax }
    }
}
if ($MaxRecords -lt $MinRecords) { $MaxRecords = $MinRecords }
# Blank input / NonInteractive leaves $AvgAttributes at 0, the sentinel for "use theme".
# Never assign 0 here: the [ValidateRange(1,30)] attribute rejects it on assignment.
if ($AvgAttributes -eq 0 -and -not $NonInteractive) {
    $in = Read-Host "  Average attributes per entity? (1-30, default: use theme, press Enter)"
    if ($in -and $in -match '^\d+$') { $AvgAttributes = [Math]::Max(1, [Math]::Min(30, [int]$in)) }
}
if ($NonInteractive) {
    $CleanFirst = $false
} else {
    $in = Read-Host "  Delete existing data first? (y/N, default: N)"
    $CleanFirst = $in -match '^[yYjJ]'
}

$attrLabel = if ($AvgAttributes -gt 0) { "~$AvgAttributes attrs" } else { "theme attrs" }
$cleanLabel = if ($CleanFirst) { ", clean first" } else { ", additive" }
Write-Host ""
$rowsLabel = if ($MinRecords -gt 0) { "$MinRecords-$MaxRecords rows" } else { "up to $MaxRecords rows" }
Write-Host "  Config: $Models models x $EntitiesPerModel entities, $rowsLabel each, $attrLabel$cleanLabel" -ForegroundColor Yellow
Write-Host ""

# ════════════════════════════════════════════════════════════════════
# HELPERS
# ════════════════════════════════════════════════════════════════════

function Esc([string]$s) { $s -replace "'", "''" }
function SqlStr([string]$s) { if ($null -eq $s -or $s -eq '') { "NULL" } else { "N'$(Esc $s)'" } }
function SqlInt($v) { if ($null -eq $v) { "NULL" } else { "$v" } }
function SqlDec($v) { if ($null -eq $v) { "NULL" } else { "$v" } }
function SqlDate($v) { if ($null -eq $v) { "NULL" } else { "'$v'" } }
function RandItem([array]$arr) { $arr[(Get-Random -Minimum 0 -Maximum $arr.Count)] }
function RandInt([int]$min, [int]$max) { Get-Random -Minimum $min -Maximum ($max + 1) }
function RandDec([double]$min, [double]$max, [int]$dp = 2) { [Math]::Round($min + (Get-Random -Minimum 0 -Maximum 10000) / 10000 * ($max - $min), $dp) }
function RandDate([string]$from = "2020-01-01", [string]$to = "2026-12-31") {
    $d1 = [DateTime]::Parse($from); $d2 = [DateTime]::Parse($to)
    $d1.AddDays((Get-Random -Minimum 0 -Maximum (($d2 - $d1).Days + 1))).ToString("yyyy-MM-dd")
}
function RandBool() { if ((Get-Random -Minimum 0 -Maximum 100) -lt 70) { 1 } else { 0 } }
function CodePrefix([string]$name) {
    $parts = $name -split '\s+'
    if ($parts.Count -ge 2) { ($parts[0].Substring(0,1) + $parts[1].Substring(0,1)).ToUpper() }
    else { $name.Substring(0, [Math]::Min(3, $name.Length)).ToUpper() }
}

# ════════════════════════════════════════════════════════════════════
# NAME POOLS
# ════════════════════════════════════════════════════════════════════

$Regions = @("Europe","North America","Asia Pacific","Middle East","Africa","Latin America","Oceania","Nordic","Southern Europe","Central Asia","Southeast Asia","Caribbean","Eastern Europe","Western Europe","Sub-Saharan Africa")
$Countries = @("Netherlands","Germany","France","United Kingdom","United States","Canada","Japan","Australia","Brazil","India","China","South Africa","Mexico","Italy","Spain","Sweden","Norway","Denmark","Belgium","Switzerland","Austria","Poland","Portugal","Ireland","New Zealand","Singapore","South Korea","Argentina","Chile","Colombia")
$CountryCodes = @("NL","DE","FR","GB","US","CA","JP","AU","BR","IN","CN","ZA","MX","IT","ES","SE","NO","DK","BE","CH","AT","PL","PT","IE","NZ","SG","KR","AR","CL","CO")
$Cities = @("Amsterdam","Berlin","Paris","London","New York","Toronto","Tokyo","Sydney","Sao Paulo","Mumbai","Shanghai","Cape Town","Mexico City","Rome","Madrid","Stockholm","Oslo","Copenhagen","Brussels","Zurich","Vienna","Warsaw","Lisbon","Dublin","Auckland","Singapore","Seoul","Buenos Aires","Santiago","Bogota","Prague","Budapest","Helsinki","Bucharest","Athens","Bangkok","Jakarta","Manila","Kuala Lumpur","Dubai")
$Departments = @("Engineering","Marketing","Sales","Finance","Human Resources","Operations","Legal","Research & Development","Customer Support","Product Management","Design","Quality Assurance","Procurement","Logistics","IT Infrastructure","Data Analytics","Compliance","Public Relations","Training","Facilities")
$Positions = @("Software Engineer","Product Manager","Data Analyst","Sales Representative","Marketing Specialist","HR Coordinator","Financial Analyst","Operations Manager","Legal Counsel","UX Designer","QA Engineer","Procurement Officer","Logistics Coordinator","IT Administrator","Compliance Officer","Project Manager","Business Analyst","Account Executive","Technical Writer","Support Engineer")
$FirstNames = @("James","Emma","Oliver","Sophia","Liam","Isabella","Noah","Mia","William","Charlotte","Lucas","Amelia","Henry","Harper","Alexander","Evelyn","Benjamin","Aria","Theodore","Luna","Sebastian","Chloe","Daniel","Penelope","Matthew","Layla","Jack","Riley","Owen","Zoey")
$LastNames = @("Smith","Johnson","Williams","Brown","Jones","Garcia","Miller","Davis","Rodriguez","Martinez","Hernandez","Lopez","Wilson","Anderson","Thomas","Taylor","Moore","Jackson","Martin","Lee","Perez","Thompson","White","Harris","Sanchez","Clark","Ramirez","Lewis","Robinson","Walker")
$Products = @("Alpha Widget","Beta Connector","Gamma Sensor","Delta Module","Epsilon Board","Zeta Cable","Eta Bracket","Theta Valve","Iota Filter","Kappa Bearing","Lambda Pump","Mu Actuator","Nu Regulator","Xi Transformer","Omicron Relay","Pi Controller","Rho Adapter","Sigma Converter","Tau Switch","Upsilon Panel")
$Categories = @("Electronics","Mechanical","Hydraulic","Pneumatic","Electrical","Software","Consumable","Raw Material","Finished Goods","Semi-Finished","Packaging","Safety Equipment","Office Supplies","Laboratory","Maintenance","Transportation","Communication","Measurement","Automation","Custom")
$Skills = @("Python","JavaScript","SQL","Project Management","Data Analysis","Machine Learning","Cloud Architecture","DevOps","Agile","Leadership","Communication","Negotiation","Excel","SAP","Salesforce","Cybersecurity","UX Research","Financial Modeling","Supply Chain","Six Sigma")
$Currencies = @("EUR","USD","GBP","JPY","AUD","CAD","CHF","CNY","INR","BRL","ZAR","MXN","SEK","NOK","DKK","PLN","CZK","HUF","SGD","KRW")
$CurrencyNames = @("Euro","US Dollar","British Pound","Japanese Yen","Australian Dollar","Canadian Dollar","Swiss Franc","Chinese Yuan","Indian Rupee","Brazilian Real","South African Rand","Mexican Peso","Swedish Krona","Norwegian Krone","Danish Krone","Polish Zloty","Czech Koruna","Hungarian Forint","Singapore Dollar","South Korean Won")
$Warehouses = @("Central Hub","North Depot","South Terminal","East Warehouse","West Storage","Metro Distribution","Regional Center","Express Dock","Overflow Facility","Cold Storage","Dry Goods Vault","Hazmat Bay","Returns Processing","Cross-Dock Alpha","Bulk Reserve")
$Carriers = @("FastFreight","GlobalShip","SwiftLogistics","PrimeCargo","OceanBridge","AirExpress","RailConnect","TruckNet","GreenTransport","ReliableHaul","SpeedWay","CargoMaster","TransGlobal","DirectLine","FlexiShip")

# Extra attribute pool for padding entities when AvgAttributes > theme attrs
$ExtraAttrPool = @(
    @{N="Notes";T="Text";L=500}, @{N="Reference Code";T="Text";L=50}, @{N="External ID";T="Text";L=100},
    @{N="Tag";T="Text";L=100}, @{N="Category";T="Text";L=100}, @{N="Label";T="Text";L=200},
    @{N="Source";T="Text";L=200}, @{N="Owner";T="Text";L=200}, @{N="Comments";T="Text";L=500},
    @{N="URL";T="Text";L=300}, @{N="Remarks";T="Text";L=500}, @{N="Location";T="Text";L=200},
    @{N="Count";T="Int"}, @{N="Quantity";T="Int"}, @{N="Priority";T="Int"},
    @{N="Score";T="Int"}, @{N="Rating";T="Int"}, @{N="Level";T="Int"},
    @{N="Rank";T="Int"}, @{N="Sequence";T="Int"}, @{N="Batch Size";T="Int"},
    @{N="Amount";T="Decimal";Dp=2}, @{N="Total Value";T="Decimal";Dp=2}, @{N="Unit Cost";T="Decimal";Dp=2},
    @{N="Percentage";T="Decimal";Dp=1}, @{N="Weight (kg)";T="Decimal";Dp=2}, @{N="Rate";T="Decimal";Dp=4},
    @{N="Discount (%)";T="Decimal";Dp=1}, @{N="Margin";T="Decimal";Dp=2}, @{N="Tax";T="Decimal";Dp=2},
    @{N="Is Active";T="Boolean"}, @{N="Is Verified";T="Boolean"}, @{N="Is Archived";T="Boolean"},
    @{N="Is Public";T="Boolean"}, @{N="Is Approved";T="Boolean"}, @{N="Is Flagged";T="Boolean"},
    @{N="Is Locked";T="Boolean"}, @{N="Is Draft";T="Boolean"},
    @{N="Start Date";T="DateTime"}, @{N="End Date";T="DateTime"}, @{N="Review Date";T="DateTime"},
    @{N="Due Date";T="DateTime"}, @{N="Last Updated";T="DateTime"}, @{N="Expiry Date";T="DateTime"}
)

# ════════════════════════════════════════════════════════════════════
# THEME DEFINITIONS
# ════════════════════════════════════════════════════════════════════
# Each theme has up to 8 entities. Entities are ordered so that domain
# references only point to earlier entities (by index within the model).
#
# Attr spec: @{ N=DisplayName; T=DataType; L=MaxLength; R=RefEntityIdx(1-based);
#              C=CascadeFromAttrName; Dp=DecimalPlaces; Req=$true }
# Names: function that generates Name for row i (0-based)

$Themes = @(
    # ── 1. Organisation ─────────────────────────────────────────────
    @{
        Name = "Organisation"
        Desc = "Organizational structure and locations"
        Entities = @(
            @{ Name="Region"; Desc="Geographic regions"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=500} )
               GenName={ param($i) $Regions[$i % $Regions.Count] } }

            @{ Name="Country"; Desc="Countries and territories"; Type="lookup"
               Attrs=@( @{N="Region";T="Domain";R=1}, @{N="Population (M)";T="Decimal";Dp=1} )
               GenName={ param($i) $Countries[$i % $Countries.Count] }
               GenCode={ param($i) $CountryCodes[$i % $CountryCodes.Count] } }

            @{ Name="City"; Desc="Major cities"; Type="lookup"
               Attrs=@( @{N="Country";T="Domain";R=2}, @{N="Postal Code";T="Text";L=20} )
               GenName={ param($i) $Cities[$i % $Cities.Count] } }

            @{ Name="Office"; Desc="Company offices and branches"; Type="rich"
               Attrs=@( @{N="City";T="Domain";R=3}, @{N="Address";T="Text";L=300}, @{N="Phone";T="Text";L=30}, @{N="Is Headquarters";T="Boolean"}, @{N="Capacity";T="Int"}, @{N="Monthly Rent";T="Decimal";Dp=2} )
               GenName={ param($i) "$(RandItem $Cities) Office $($i+1)" } }

            @{ Name="Department"; Desc="Organizational departments"; Type="rich"
               Attrs=@( @{N="Office";T="Domain";R=4}, @{N="Description";T="Text";L=500}, @{N="Budget";T="Decimal";Dp=2}, @{N="Head Count";T="Int"}, @{N="Is Active";T="Boolean"} )
               GenName={ param($i) $Departments[$i % $Departments.Count] } }

            @{ Name="Cost Center"; Desc="Financial cost centers"; Type="rich"
               Attrs=@( @{N="Department";T="Domain";R=5}, @{N="Annual Budget";T="Decimal";Dp=2}, @{N="Spent YTD";T="Decimal";Dp=2}, @{N="Is Active";T="Boolean"}, @{N="Start Date";T="DateTime"} )
               GenName={ param($i) "CC-$('{0:D3}' -f ($i+1)) $(RandItem @('Operations','Marketing','Engineering','Sales','Support','IT','Finance','HR','Legal','R&D'))" } }

            @{ Name="Project"; Desc="Active projects"; Type="rich"
               Attrs=@( @{N="Department";T="Domain";R=5}, @{N="Start Date";T="DateTime"}, @{N="End Date";T="DateTime"}, @{N="Budget";T="Decimal";Dp=2}, @{N="Status";T="Text";L=50}, @{N="Is Active";T="Boolean"} )
               GenName={ param($i) "$(RandItem @('Alpha','Beta','Gamma','Delta','Epsilon','Phoenix','Atlas','Nova','Orion','Titan','Zenith','Apex','Horizon','Vertex','Summit')) $(RandItem @('Initiative','Program','Rollout','Migration','Upgrade','Integration','Platform','Framework','Pipeline','System'))" } }

            @{ Name="Meeting Room"; Desc="Conference and meeting rooms"; Type="rich"
               Attrs=@( @{N="Office";T="Domain";R=4}, @{N="Floor";T="Int"}, @{N="Capacity";T="Int"}, @{N="Has Video Conference";T="Boolean"}, @{N="Notes";T="Text";L=300} )
               GenName={ param($i) "$(RandItem @('Maple','Oak','Cedar','Pine','Birch','Elm','Willow','Aspen','Magnolia','Sequoia','Redwood','Cypress','Spruce','Walnut','Cherry')) Room" } }
        )
    }

    # ── 2. HR ────────────────────────────────────────────────────────
    @{
        Name = "Human Resources"
        Desc = "Personnel and workforce management"
        Entities = @(
            @{ Name="Job Level"; Desc="Career levels and grades"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=500}, @{N="Min Salary";T="Decimal";Dp=2} )
               GenName={ param($i) @("Intern","Junior","Associate","Mid-Level","Senior","Lead","Principal","Staff","Director","VP","SVP","C-Suite")[$i % 12] } }

            @{ Name="Employment Type"; Desc="Types of employment"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=500} )
               GenName={ param($i) @("Full-Time","Part-Time","Contract","Temporary","Freelance","Internship","Apprenticeship","Seasonal","On-Call","Probation","Permanent","Fixed-Term","Zero-Hours","Consultancy","Secondment")[$i % 15] } }

            @{ Name="Skill Category"; Desc="Skill classifications"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=300} )
               GenName={ param($i) @("Technical","Management","Communication","Analytical","Creative","Leadership","Domain Expertise","Tools & Software","Certification","Language","Interpersonal","Strategic","Operational","Financial","Compliance")[$i % 15] } }

            @{ Name="Position"; Desc="Job positions"; Type="rich"
               Attrs=@( @{N="Job Level";T="Domain";R=1}, @{N="Employment Type";T="Domain";R=2}, @{N="Description";T="Text";L=500}, @{N="Min Salary";T="Decimal";Dp=2}, @{N="Max Salary";T="Decimal";Dp=2}, @{N="Is Active";T="Boolean"} )
               GenName={ param($i) $Positions[$i % $Positions.Count] } }

            @{ Name="Certificate"; Desc="Professional certifications"; Type="rich"
               Attrs=@( @{N="Skill Category";T="Domain";R=3}, @{N="Description";T="Text";L=500}, @{N="Valid Months";T="Int"}, @{N="Is Required";T="Boolean"}, @{N="Cost";T="Decimal";Dp=2} )
               GenName={ param($i) @("PMP","AWS Solutions Architect","Azure Administrator","CISSP","Scrum Master","ITIL Foundation","Six Sigma Green Belt","CPA","SHRM-CP","Google Cloud Professional","Kubernetes Administrator","Tableau Desktop","Power BI Analyst","SAP Certified","Oracle Database","Cisco CCNA","CompTIA Security+","PRINCE2","Lean Practitioner","ISO 27001 Auditor")[$i % 20] } }

            @{ Name="Training Program"; Desc="Training and development programs"; Type="rich"
               Attrs=@( @{N="Skill Category";T="Domain";R=3}, @{N="Duration (Hours)";T="Int"}, @{N="Cost";T="Decimal";Dp=2}, @{N="Is Online";T="Boolean"}, @{N="Start Date";T="DateTime"}, @{N="Description";T="Text";L=500} )
               GenName={ param($i) "$(RandItem @('Advanced','Fundamentals of','Introduction to','Masterclass:','Workshop:','Bootcamp:','Essentials of','Deep Dive:')) $(RandItem $Skills)" } }

            @{ Name="Employee"; Desc="Employee master data"; Type="rich"
               Attrs=@( @{N="Position";T="Domain";R=4}, @{N="Hire Date";T="DateTime"}, @{N="Salary";T="Decimal";Dp=2}, @{N="Is Active";T="Boolean"}, @{N="Phone";T="Text";L=30}, @{N="Email";T="Text";L=200} )
               GenName={ param($i) "$($FirstNames[$i % $FirstNames.Count]) $($LastNames[($i * 7 + 3) % $LastNames.Count])" } }

            @{ Name="Leave Balance"; Desc="Employee leave balances"; Type="rich"
               Attrs=@( @{N="Employee";T="Domain";R=7}, @{N="Year";T="Int"}, @{N="Total Days";T="Int"}, @{N="Used Days";T="Int"}, @{N="Carry Over";T="Decimal";Dp=1} )
               GenName={ param($i) "Leave $(2024 + [Math]::Floor($i / 15)) - $($FirstNames[$i % $FirstNames.Count])" } }
        )
    }

    # ── 3. Finance ───────────────────────────────────────────────────
    @{
        Name = "Finance"
        Desc = "Financial management and accounting"
        Entities = @(
            @{ Name="Currency"; Desc="Currencies"; Type="lookup"
               Attrs=@( @{N="Symbol";T="Text";L=5}, @{N="Exchange Rate";T="Decimal";Dp=4} )
               GenName={ param($i) $CurrencyNames[$i % $CurrencyNames.Count] }
               GenCode={ param($i) $Currencies[$i % $Currencies.Count] } }

            @{ Name="Payment Term"; Desc="Payment conditions"; Type="lookup"
               Attrs=@( @{N="Days";T="Int"}, @{N="Description";T="Text";L=300} )
               GenName={ param($i) @("Net 30","Net 60","Net 90","Due on Receipt","Net 15","2/10 Net 30","Net 45","Prepaid","COD","Net 120","50% Advance","Monthly","Quarterly","End of Month","Net 7")[$i % 15] } }

            @{ Name="Tax Rate"; Desc="Applicable tax rates"; Type="lookup"
               Attrs=@( @{N="Percentage";T="Decimal";Dp=2}, @{N="Is Active";T="Boolean"} )
               GenName={ param($i) @("Standard VAT","Reduced VAT","Zero Rate","Exempt","Luxury Tax","Import Duty","Service Tax","Withholding Tax","Capital Gains","Eco Tax","Digital Tax","Property Tax","Sales Tax","Excise Duty","Flat Rate")[$i % 15] } }

            @{ Name="Account"; Desc="Chart of accounts"; Type="rich"
               Attrs=@( @{N="Currency";T="Domain";R=1}, @{N="Type";T="Text";L=50}, @{N="Balance";T="Decimal";Dp=2}, @{N="Is Active";T="Boolean"}, @{N="Description";T="Text";L=500} )
               GenName={ param($i) @("Cash & Equivalents","Accounts Receivable","Inventory","Prepaid Expenses","Fixed Assets","Accounts Payable","Accrued Liabilities","Revenue","Cost of Goods Sold","Operating Expenses","Payroll","Marketing Expense","R&D Expense","Depreciation","Interest Income","Tax Payable","Retained Earnings","Capital Stock","Goodwill","Deferred Revenue")[$i % 20] } }

            @{ Name="Supplier"; Desc="Suppliers and vendors"; Type="rich"
               Attrs=@( @{N="Currency";T="Domain";R=1}, @{N="Payment Term";T="Domain";R=2}, @{N="Contact";T="Text";L=200}, @{N="Phone";T="Text";L=30}, @{N="Is Active";T="Boolean"}, @{N="Credit Limit";T="Decimal";Dp=2} )
               GenName={ param($i) "$(RandItem @('Global','National','Premier','Elite','Pacific','Atlantic','Nordic','Alpine','Metro','Continental')) $(RandItem @('Supply Co','Industries','Services','Solutions','Trading','Partners','Group','Corp','Ltd','International'))" } }

            @{ Name="Budget"; Desc="Department budgets"; Type="rich"
               Attrs=@( @{N="Currency";T="Domain";R=1}, @{N="Fiscal Year";T="Int"}, @{N="Amount";T="Decimal";Dp=2}, @{N="Spent";T="Decimal";Dp=2}, @{N="Is Approved";T="Boolean"}, @{N="Notes";T="Text";L=500} )
               GenName={ param($i) "$(RandItem $Departments) Budget $(2024 + ($i % 3))" } }

            @{ Name="Invoice"; Desc="Invoices"; Type="rich"
               Attrs=@( @{N="Supplier";T="Domain";R=5}, @{N="Currency";T="Domain";R=1}, @{N="Tax Rate";T="Domain";R=3}, @{N="Amount";T="Decimal";Dp=2}, @{N="Invoice Date";T="DateTime"}, @{N="Due Date";T="DateTime"}, @{N="Is Paid";T="Boolean"} )
               GenName={ param($i) "INV-$('{0:D6}' -f ($i+10000))" } }

            @{ Name="Expense Report"; Desc="Employee expense reports"; Type="rich"
               Attrs=@( @{N="Currency";T="Domain";R=1}, @{N="Amount";T="Decimal";Dp=2}, @{N="Submit Date";T="DateTime"}, @{N="Category";T="Text";L=100}, @{N="Is Approved";T="Boolean"}, @{N="Description";T="Text";L=500} )
               GenName={ param($i) "EXP-$('{0:D5}' -f ($i+1000)) $(RandItem @('Travel','Meals','Equipment','Software','Conference','Training','Office Supplies','Client Entertainment'))" } }
        )
    }

    # ── 4. Logistics ─────────────────────────────────────────────────
    @{
        Name = "Logistics"
        Desc = "Warehousing, shipping, and supply chain"
        Entities = @(
            @{ Name="Warehouse"; Desc="Storage facilities"; Type="lookup"
               Attrs=@( @{N="Location";T="Text";L=200}, @{N="Capacity (m2)";T="Int"} )
               GenName={ param($i) $Warehouses[$i % $Warehouses.Count] } }

            @{ Name="Transport Mode"; Desc="Shipping methods"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=300}, @{N="Avg Days";T="Int"} )
               GenName={ param($i) @("Road Freight","Air Freight","Sea Freight","Rail Freight","Express Courier","Same-Day Delivery","Intermodal","Bulk Carrier","Pipeline","Drone Delivery","LTL Freight","Full Truckload","Refrigerated","Parcel Post","Flatbed")[$i % 15] } }

            @{ Name="Unit of Measure"; Desc="Measurement units"; Type="lookup"
               Attrs=@( @{N="Abbreviation";T="Text";L=10} )
               GenName={ param($i) @("Piece","Kilogram","Liter","Meter","Box","Pallet","Ton","Cubic Meter","Roll","Sheet","Bundle","Bag","Drum","Carton","Container")[$i % 15] }
               GenCode={ param($i) @("PCS","KG","L","M","BOX","PAL","TON","M3","ROLL","SHT","BDL","BAG","DRM","CTN","CNT")[$i % 15] } }

            @{ Name="Product Category"; Desc="Product classifications"; Type="rich"
               Attrs=@( @{N="Description";T="Text";L=500}, @{N="Is Active";T="Boolean"}, @{N="Margin Target (%)";T="Decimal";Dp=1} )
               GenName={ param($i) $Categories[$i % $Categories.Count] } }

            @{ Name="Product"; Desc="Products and materials"; Type="rich"
               Attrs=@( @{N="Category";T="Domain";R=4}, @{N="Unit";T="Domain";R=3}, @{N="Unit Price";T="Decimal";Dp=2}, @{N="Weight (kg)";T="Decimal";Dp=2}, @{N="Min Stock";T="Int"}, @{N="Is Active";T="Boolean"} )
               GenName={ param($i) $Products[$i % $Products.Count] } }

            @{ Name="Carrier"; Desc="Shipping carriers"; Type="rich"
               Attrs=@( @{N="Transport Mode";T="Domain";R=2}, @{N="Contact";T="Text";L=200}, @{N="Phone";T="Text";L=30}, @{N="Rating";T="Decimal";Dp=1}, @{N="Is Active";T="Boolean"} )
               GenName={ param($i) $Carriers[$i % $Carriers.Count] } }

            @{ Name="Shipment"; Desc="Outbound shipments"; Type="rich"
               Attrs=@( @{N="Warehouse";T="Domain";R=1}, @{N="Carrier";T="Domain";R=6}, @{N="Ship Date";T="DateTime"}, @{N="Delivery Date";T="DateTime"}, @{N="Weight (kg)";T="Decimal";Dp=2}, @{N="Cost";T="Decimal";Dp=2}, @{N="Status";T="Text";L=50} )
               GenName={ param($i) "SHP-$('{0:D6}' -f ($i+100000))" } }

            @{ Name="Inventory Count"; Desc="Stock level records"; Type="rich"
               Attrs=@( @{N="Warehouse";T="Domain";R=1}, @{N="Product";T="Domain";R=5}, @{N="Quantity";T="Int"}, @{N="Count Date";T="DateTime"}, @{N="Discrepancy";T="Int"}, @{N="Notes";T="Text";L=300} )
               GenName={ param($i) "COUNT-$('{0:D5}' -f ($i+1)) $(RandDate '2025-01-01' '2026-12-31')" } }
        )
    }

    # ── 5. Sales ─────────────────────────────────────────────────────
    @{
        Name = "Sales"
        Desc = "Sales pipeline and customer management"
        Entities = @(
            @{ Name="Territory"; Desc="Sales territories"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=300} )
               GenName={ param($i) $Regions[$i % $Regions.Count] } }

            @{ Name="Channel"; Desc="Sales channels"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=300} )
               GenName={ param($i) @("Direct Sales","Online Store","Reseller","Distributor","Marketplace","Referral Partner","OEM","Government Tender","Franchise","Telemarketing","Field Sales","Inside Sales","Social Commerce","Wholesale","Retail")[$i % 15] } }

            @{ Name="Lead Source"; Desc="Where leads originate"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=300} )
               GenName={ param($i) @("Website","Trade Show","Referral","Cold Call","LinkedIn","Google Ads","Email Campaign","Webinar","Conference","Partner","Content Marketing","PR","Social Media","Direct Mail","Word of Mouth")[$i % 15] } }

            @{ Name="Customer"; Desc="Customer accounts"; Type="rich"
               Attrs=@( @{N="Territory";T="Domain";R=1}, @{N="Channel";T="Domain";R=2}, @{N="Contact";T="Text";L=200}, @{N="Phone";T="Text";L=30}, @{N="Revenue YTD";T="Decimal";Dp=2}, @{N="Is Active";T="Boolean"} )
               GenName={ param($i) "$(RandItem @('Acme','Globex','Initech','Umbrella','Stark','Wayne','Oscorp','Cyberdyne','Weyland','Aperture','Massive','Axiom','Pinnacle','Nexus','Vertex','Quantum','Zenith','Helix','Catalyst','Forge')) $(RandItem @('Corp','Inc','Ltd','GmbH','BV','SA','AG','Group','Holdings','Technologies','Solutions','Systems','Industries','Enterprises','Partners'))" } }

            @{ Name="Opportunity"; Desc="Sales opportunities"; Type="rich"
               Attrs=@( @{N="Customer";T="Domain";R=4}, @{N="Lead Source";T="Domain";R=3}, @{N="Value";T="Decimal";Dp=2}, @{N="Probability (%)";T="Int"}, @{N="Close Date";T="DateTime"}, @{N="Stage";T="Text";L=50}, @{N="Is Won";T="Boolean"} )
               GenName={ param($i) "OPP-$('{0:D5}' -f ($i+1000)) $(RandItem @('Enterprise License','Platform Upgrade','Cloud Migration','Annual Renewal','Expansion Deal','Pilot Project','POC','Strategic Partnership','Managed Services','Training Package'))" } }

            @{ Name="Quote"; Desc="Price quotes"; Type="rich"
               Attrs=@( @{N="Customer";T="Domain";R=4}, @{N="Amount";T="Decimal";Dp=2}, @{N="Valid Until";T="DateTime"}, @{N="Discount (%)";T="Decimal";Dp=1}, @{N="Status";T="Text";L=30}, @{N="Is Accepted";T="Boolean"} )
               GenName={ param($i) "QUO-$('{0:D5}' -f ($i+5000))" } }

            @{ Name="Contract"; Desc="Customer contracts"; Type="rich"
               Attrs=@( @{N="Customer";T="Domain";R=4}, @{N="Start Date";T="DateTime"}, @{N="End Date";T="DateTime"}, @{N="Annual Value";T="Decimal";Dp=2}, @{N="Is Active";T="Boolean"}, @{N="Auto Renew";T="Boolean"} )
               GenName={ param($i) "CTR-$('{0:D5}' -f ($i+2000))" } }

            @{ Name="Activity"; Desc="Sales activities and touchpoints"; Type="rich"
               Attrs=@( @{N="Customer";T="Domain";R=4}, @{N="Activity Date";T="DateTime"}, @{N="Type";T="Text";L=50}, @{N="Duration (Min)";T="Int"}, @{N="Notes";T="Text";L=500}, @{N="Follow Up";T="Boolean"} )
               GenName={ param($i) "ACT-$('{0:D5}' -f ($i+1)) $(RandItem @('Call','Meeting','Email','Demo','Proposal','Negotiation','Follow-up','Site Visit','Webinar','Review'))" } }
        )
    }

    # ── 6. IT Infrastructure ─────────────────────────────────────────
    @{
        Name = "IT Infrastructure"
        Desc = "IT assets, applications, and operations"
        Entities = @(
            @{ Name="Vendor"; Desc="Technology vendors"; Type="lookup"
               Attrs=@( @{N="Website";T="Text";L=200}, @{N="Support Phone";T="Text";L=30} )
               GenName={ param($i) @("Microsoft","Amazon","Google","Oracle","SAP","IBM","Cisco","Dell","HP","VMware","Salesforce","ServiceNow","Atlassian","Slack","Datadog","Cloudflare","Palo Alto","CrowdStrike","Okta","Snowflake")[$i % 20] } }

            @{ Name="License Type"; Desc="Software license categories"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=300} )
               GenName={ param($i) @("Per Seat","Per Core","Enterprise","Site License","Subscription Monthly","Subscription Annual","Perpetual","Freemium","Usage-Based","Floating","Named User","Concurrent","Open Source","Academic","Government")[$i % 15] } }

            @{ Name="Server Type"; Desc="Server classifications"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=300} )
               GenName={ param($i) @("Web Server","Database Server","Application Server","File Server","Mail Server","DNS Server","Proxy Server","Load Balancer","Cache Server","Queue Server","CI/CD Server","Monitoring Server","Backup Server","GPU Compute","Edge Node")[$i % 15] } }

            @{ Name="Application"; Desc="Business applications"; Type="rich"
               Attrs=@( @{N="Vendor";T="Domain";R=1}, @{N="License Type";T="Domain";R=2}, @{N="Version";T="Text";L=30}, @{N="Annual Cost";T="Decimal";Dp=2}, @{N="Users";T="Int"}, @{N="Is Critical";T="Boolean"} )
               GenName={ param($i) @("ERP System","CRM Platform","HRIS","Email Suite","Project Tracker","Monitoring Stack","CI/CD Pipeline","Data Warehouse","BI Dashboard","SSO Gateway","Helpdesk Portal","Document Management","Video Conferencing","Code Repository","Wiki & Knowledge Base","Backup Solution","Endpoint Security","Network Monitor","API Gateway","Log Aggregator")[$i % 20] } }

            @{ Name="Server"; Desc="Physical and virtual servers"; Type="rich"
               Attrs=@( @{N="Server Type";T="Domain";R=3}, @{N="Vendor";T="Domain";R=1}, @{N="IP Address";T="Text";L=50}, @{N="CPU Cores";T="Int"}, @{N="RAM (GB)";T="Int"}, @{N="Storage (TB)";T="Decimal";Dp=1}, @{N="Is Production";T="Boolean"} )
               GenName={ param($i) "$(RandItem @('web','app','db','cache','queue','api','worker','proxy','mon','ci'))$('{0:D2}' -f (($i % 20)+1)).$(RandItem @('prod','staging','dev','test')).internal" } }

            @{ Name="Incident"; Desc="IT incidents and outages"; Type="rich"
               Attrs=@( @{N="Application";T="Domain";R=4}, @{N="Severity";T="Text";L=20}, @{N="Reported Date";T="DateTime"}, @{N="Resolved Date";T="DateTime"}, @{N="Downtime (Min)";T="Int"}, @{N="Is Resolved";T="Boolean"}, @{N="Description";T="Text";L=500} )
               GenName={ param($i) "INC-$('{0:D5}' -f ($i+1000)) $(RandItem @('Performance degradation','Service unavailable','Authentication failure','Data sync error','Network timeout','Certificate expired','Disk full','Memory leak','CPU spike','Connection pool exhaustion'))" } }

            @{ Name="Change Request"; Desc="IT change management"; Type="rich"
               Attrs=@( @{N="Application";T="Domain";R=4}, @{N="Requested Date";T="DateTime"}, @{N="Planned Date";T="DateTime"}, @{N="Risk Level";T="Text";L=20}, @{N="Is Approved";T="Boolean"}, @{N="Description";T="Text";L=500} )
               GenName={ param($i) "CHG-$('{0:D5}' -f ($i+3000)) $(RandItem @('Upgrade','Patch','Migration','Configuration','Scaling','Security fix','Integration','Rollback','Decommission','Provisioning'))" } }

            @{ Name="License Allocation"; Desc="License assignments to applications"; Type="rich"
               Attrs=@( @{N="Application";T="Domain";R=4}, @{N="License Type";T="Domain";R=2}, @{N="Quantity";T="Int"}, @{N="Annual Cost";T="Decimal";Dp=2}, @{N="Renewal Date";T="DateTime"}, @{N="Is Auto Renew";T="Boolean"} )
               GenName={ param($i) "LIC-$('{0:D4}' -f ($i+100))" } }
        )
    }

    # ── 7. Quality ───────────────────────────────────────────────────
    @{
        Name = "Quality Management"
        Desc = "Quality control and compliance"
        Entities = @(
            @{ Name="Standard"; Desc="Quality standards and regulations"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=500}, @{N="Version";T="Text";L=20} )
               GenName={ param($i) @("ISO 9001","ISO 14001","ISO 27001","ISO 45001","ISO 22000","GDPR","SOX","HIPAA","PCI DSS","SOC 2","CMMI Level 3","GMP","FDA 21 CFR","IEC 62443","AS9100")[$i % 15] } }

            @{ Name="Severity Level"; Desc="Issue severity classifications"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=300}, @{N="Response Hours";T="Int"} )
               GenName={ param($i) @("Critical","High","Medium","Low","Informational","Blocker","Major","Minor","Trivial","Cosmetic","Safety","Regulatory","Process","Documentation","Enhancement")[$i % 15] } }

            @{ Name="Inspector"; Desc="Quality inspectors and auditors"; Type="lookup"
               Attrs=@( @{N="Department";T="Text";L=100}, @{N="Certification";T="Text";L=100} )
               GenName={ param($i) "$($FirstNames[($i*3) % $FirstNames.Count]) $($LastNames[($i*5+2) % $LastNames.Count])" } }

            @{ Name="Audit"; Desc="Quality audits"; Type="rich"
               Attrs=@( @{N="Standard";T="Domain";R=1}, @{N="Inspector";T="Domain";R=3}, @{N="Audit Date";T="DateTime"}, @{N="Score";T="Decimal";Dp=1}, @{N="Is Passed";T="Boolean"}, @{N="Notes";T="Text";L=500} )
               GenName={ param($i) "AUD-$('{0:D4}' -f ($i+100)) $(RandItem @('Annual Review','Surveillance','Re-certification','Supplier Audit','Internal Audit','Process Audit','Product Audit','System Audit','Follow-up','Pre-assessment'))" } }

            @{ Name="Inspection"; Desc="Product/process inspections"; Type="rich"
               Attrs=@( @{N="Inspector";T="Domain";R=3}, @{N="Severity Level";T="Domain";R=2}, @{N="Inspection Date";T="DateTime"}, @{N="Sample Size";T="Int"}, @{N="Defects Found";T="Int"}, @{N="Is Accepted";T="Boolean"}, @{N="Description";T="Text";L=500} )
               GenName={ param($i) "INS-$('{0:D5}' -f ($i+2000))" } }

            @{ Name="Finding"; Desc="Audit and inspection findings"; Type="rich"
               Attrs=@( @{N="Standard";T="Domain";R=1}, @{N="Severity Level";T="Domain";R=2}, @{N="Found Date";T="DateTime"}, @{N="Due Date";T="DateTime"}, @{N="Is Resolved";T="Boolean"}, @{N="Description";T="Text";L=500} )
               GenName={ param($i) "FND-$('{0:D4}' -f ($i+500)) $(RandItem @('Non-conformance','Observation','Opportunity for improvement','Major deviation','Minor deviation','Best practice gap','Documentation gap','Training gap','Process gap','Control weakness'))" } }

            @{ Name="CAPA"; Desc="Corrective and preventive actions"; Type="rich"
               Attrs=@( @{N="Standard";T="Domain";R=1}, @{N="Severity Level";T="Domain";R=2}, @{N="Open Date";T="DateTime"}, @{N="Target Date";T="DateTime"}, @{N="Is Closed";T="Boolean"}, @{N="Root Cause";T="Text";L=500}, @{N="Action Plan";T="Text";L=500} )
               GenName={ param($i) "CAPA-$('{0:D4}' -f ($i+100))" } }

            @{ Name="Document Control"; Desc="Controlled documents"; Type="rich"
               Attrs=@( @{N="Standard";T="Domain";R=1}, @{N="Version";T="Text";L=20}, @{N="Effective Date";T="DateTime"}, @{N="Review Date";T="DateTime"}, @{N="Is Current";T="Boolean"}, @{N="Owner";T="Text";L=100} )
               GenName={ param($i) "DOC-$('{0:D4}' -f ($i+1000)) $(RandItem @('Quality Manual','Work Instruction','SOP','Policy','Procedure','Form Template','Checklist','Specification','Drawing','Test Protocol'))" } }
        )
    }

    # ── 8. Procurement ───────────────────────────────────────────────
    @{
        Name = "Procurement"
        Desc = "Purchasing and vendor management"
        Entities = @(
            @{ Name="Material Group"; Desc="Material classifications"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=300} )
               GenName={ param($i) @("Raw Materials","Components","Packaging","Chemicals","Electronics","Fasteners","Adhesives","Textiles","Metals","Plastics","Glass","Ceramics","Composites","Lubricants","Consumables")[$i % 15] } }

            @{ Name="Supplier Tier"; Desc="Supplier classification tiers"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=300}, @{N="Min Order Value";T="Decimal";Dp=2} )
               GenName={ param($i) @("Strategic","Preferred","Approved","Conditional","New","Legacy","Single Source","Backup","Spot Buy","Consignment","Blanket Order","Framework","Local","International","Critical")[$i % 15] } }

            @{ Name="Origin"; Desc="Country/region of origin"; Type="lookup"
               Attrs=@( @{N="Region";T="Text";L=100} )
               GenName={ param($i) $Countries[$i % $Countries.Count] }
               GenCode={ param($i) $CountryCodes[$i % $CountryCodes.Count] } }

            @{ Name="Commodity"; Desc="Commodity items"; Type="rich"
               Attrs=@( @{N="Material Group";T="Domain";R=1}, @{N="Origin";T="Domain";R=3}, @{N="Unit Price";T="Decimal";Dp=4}, @{N="Lead Time (Days)";T="Int"}, @{N="Is Active";T="Boolean"} )
               GenName={ param($i) "$(RandItem @('Standard','Premium','Industrial','Certified','Recycled','Organic','Synthetic','High-Grade','Technical','Food-Grade')) $(RandItem @('Steel','Copper Wire','Polymer','Silicon','Aluminum','Carbon Fiber','Rubber','Glass Fiber','Titanium','Nylon','Ceramic','Graphite','Resin','Foam','Cotton'))" } }

            @{ Name="Vendor"; Desc="Procurement vendors"; Type="rich"
               Attrs=@( @{N="Supplier Tier";T="Domain";R=2}, @{N="Origin";T="Domain";R=3}, @{N="Contact";T="Text";L=200}, @{N="Phone";T="Text";L=30}, @{N="Lead Time (Days)";T="Int"}, @{N="Is Active";T="Boolean"}, @{N="Rating";T="Decimal";Dp=1} )
               GenName={ param($i) "$(RandItem @('Prime','Apex','Summit','Core','Vertex','Atlas','Forge','Nexus','Pinnacle','Sterling')) $(RandItem @('Materials','Supply','Manufacturing','Components','Trading','Fabrication','Sourcing','Metals','Polymers','Chemicals'))" } }

            @{ Name="Purchase Order"; Desc="Purchase orders"; Type="rich"
               Attrs=@( @{N="Vendor";T="Domain";R=5}, @{N="Material Group";T="Domain";R=1}, @{N="Order Date";T="DateTime"}, @{N="Total Value";T="Decimal";Dp=2}, @{N="Quantity";T="Int"}, @{N="Is Received";T="Boolean"}, @{N="Status";T="Text";L=30} )
               GenName={ param($i) "PO-$('{0:D6}' -f ($i+200000))" } }

            @{ Name="Goods Receipt"; Desc="Incoming goods receipts"; Type="rich"
               Attrs=@( @{N="Vendor";T="Domain";R=5}, @{N="Receipt Date";T="DateTime"}, @{N="Quantity";T="Int"}, @{N="Is Accepted";T="Boolean"}, @{N="Rejection Reason";T="Text";L=300}, @{N="Quality Score";T="Decimal";Dp=1} )
               GenName={ param($i) "GRN-$('{0:D5}' -f ($i+10000))" } }

            @{ Name="Contract"; Desc="Procurement contracts"; Type="rich"
               Attrs=@( @{N="Vendor";T="Domain";R=5}, @{N="Supplier Tier";T="Domain";R=2}, @{N="Start Date";T="DateTime"}, @{N="End Date";T="DateTime"}, @{N="Annual Value";T="Decimal";Dp=2}, @{N="Is Active";T="Boolean"} )
               GenName={ param($i) "CTR-$('{0:D5}' -f ($i+50000))" } }
        )
    }

    # ── 9. Marketing ─────────────────────────────────────────────────
    @{
        Name = "Marketing"
        Desc = "Marketing campaigns and content"
        Entities = @(
            @{ Name="Audience Segment"; Desc="Target audience segments"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=300}, @{N="Size Estimate";T="Int"} )
               GenName={ param($i) @("Enterprise Decision Makers","SMB Owners","Technical Leads","C-Suite Executives","Marketing Managers","IT Administrators","Developers","Startup Founders","Government Officials","Healthcare Professionals","Financial Analysts","Educators","Retail Managers","Supply Chain Leaders","Data Scientists")[$i % 15] } }

            @{ Name="Content Type"; Desc="Content format types"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=300} )
               GenName={ param($i) @("Blog Post","White Paper","Case Study","Webinar","Video","Infographic","Podcast","eBook","Newsletter","Social Post","Press Release","Product Demo","Template","Research Report","Interactive Tool")[$i % 15] } }

            @{ Name="Platform"; Desc="Marketing platforms and channels"; Type="lookup"
               Attrs=@( @{N="Monthly Cost";T="Decimal";Dp=2}, @{N="Is Active";T="Boolean"} )
               GenName={ param($i) @("LinkedIn","Google Ads","Meta Ads","Twitter/X","YouTube","HubSpot","Mailchimp","SEMrush","Ahrefs","Google Analytics","Hootsuite","Canva","WordPress","Webflow","Intercom")[$i % 15] } }

            @{ Name="Campaign"; Desc="Marketing campaigns"; Type="rich"
               Attrs=@( @{N="Audience";T="Domain";R=1}, @{N="Platform";T="Domain";R=3}, @{N="Start Date";T="DateTime"}, @{N="End Date";T="DateTime"}, @{N="Budget";T="Decimal";Dp=2}, @{N="Is Active";T="Boolean"} )
               GenName={ param($i) "$(RandItem @('Q1','Q2','Q3','Q4','Spring','Summer','Fall','Winter','Annual','Launch')) $(RandItem @('Brand Awareness','Lead Gen','Product Launch','Retention','Upsell','Reactivation','ABM','Content Push','Event','Demand Gen')) $(2024 + ($i % 3))" } }

            @{ Name="Content Asset"; Desc="Marketing content pieces"; Type="rich"
               Attrs=@( @{N="Content Type";T="Domain";R=2}, @{N="Audience";T="Domain";R=1}, @{N="Published Date";T="DateTime"}, @{N="Views";T="Int"}, @{N="Leads Generated";T="Int"}, @{N="Is Published";T="Boolean"} )
               GenName={ param($i) "$(RandItem @('The Ultimate Guide to','How to','Why','Top 10','Best Practices for','Introduction to','Deep Dive:','The Future of','Understanding','Maximizing')) $(RandItem @('Data Management','Cloud Migration','Digital Transformation','Master Data','Process Automation','AI Integration','Compliance','Security','Analytics','Scalability'))" } }

            @{ Name="Event"; Desc="Marketing events"; Type="rich"
               Attrs=@( @{N="Platform";T="Domain";R=3}, @{N="Event Date";T="DateTime"}, @{N="Attendees";T="Int"}, @{N="Cost";T="Decimal";Dp=2}, @{N="Leads";T="Int"}, @{N="Is Virtual";T="Boolean"}, @{N="Location";T="Text";L=200} )
               GenName={ param($i) "$(RandItem @('Summit','Conference','Workshop','Meetup','Roundtable','Forum','Expo','Symposium','Hackathon','Masterclass')) $(RandItem @('2025','2026','Q1','Q2','Spring','Fall')) - $(RandItem $Cities)" } }

            @{ Name="Lead"; Desc="Marketing qualified leads"; Type="rich"
               Attrs=@( @{N="Audience";T="Domain";R=1}, @{N="Campaign";T="Domain";R=4}, @{N="Score";T="Int"}, @{N="Created Date";T="DateTime"}, @{N="Is Converted";T="Boolean"}, @{N="Company";T="Text";L=200}, @{N="Email";T="Text";L=200} )
               GenName={ param($i) "$($FirstNames[($i*2) % $FirstNames.Count]) $($LastNames[($i*3+1) % $LastNames.Count])" } }

            @{ Name="A/B Test"; Desc="Marketing experiments"; Type="rich"
               Attrs=@( @{N="Campaign";T="Domain";R=4}, @{N="Content Type";T="Domain";R=2}, @{N="Start Date";T="DateTime"}, @{N="Variant A Conversions";T="Int"}, @{N="Variant B Conversions";T="Int"}, @{N="Is Significant";T="Boolean"}, @{N="Winner";T="Text";L=20} )
               GenName={ param($i) "TEST-$('{0:D3}' -f ($i+1)) $(RandItem @('CTA Color','Headline','Layout','Image','Copy','Pricing','Form Length','Social Proof','Urgency','Personalization'))" } }
        )
    }

    # ── 10. Facilities ───────────────────────────────────────────────
    @{
        Name = "Facilities Management"
        Desc = "Buildings, maintenance, and workspace management"
        Entities = @(
            @{ Name="Building Type"; Desc="Building classifications"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=300} )
               GenName={ param($i) @("Office Tower","Warehouse","Manufacturing Plant","Data Center","Research Lab","Retail Store","Distribution Center","Call Center","Training Facility","Executive Suite","Co-working Space","Parking Structure","Cafeteria Building","Medical Facility","Storage Unit")[$i % 15] } }

            @{ Name="Floor"; Desc="Building floors"; Type="lookup"
               Attrs=@( @{N="Area (m2)";T="Int"}, @{N="Is Accessible";T="Boolean"} )
               GenName={ param($i) @("Ground Floor","1st Floor","2nd Floor","3rd Floor","4th Floor","5th Floor","6th Floor","7th Floor","8th Floor","Basement","Mezzanine","Rooftop","Penthouse","Sub-Basement","Attic")[$i % 15] } }

            @{ Name="Room Type"; Desc="Room classifications"; Type="lookup"
               Attrs=@( @{N="Description";T="Text";L=300}, @{N="Default Capacity";T="Int"} )
               GenName={ param($i) @("Office","Meeting Room","Conference Hall","Kitchen","Server Room","Storage","Bathroom","Reception","Lounge","Lab","Workshop","Print Room","Phone Booth","Meditation Room","Gym")[$i % 15] } }

            @{ Name="Location"; Desc="Specific rooms and spaces"; Type="rich"
               Attrs=@( @{N="Building Type";T="Domain";R=1}, @{N="Floor";T="Domain";R=2}, @{N="Room Type";T="Domain";R=3}, @{N="Capacity";T="Int"}, @{N="Area (m2)";T="Decimal";Dp=1}, @{N="Is Available";T="Boolean"} )
               GenName={ param($i) "$(RandItem @('A','B','C','D','E'))$(RandInt 1 9)-$('{0:D3}' -f (RandInt 100 999))" } }

            @{ Name="Asset"; Desc="Facility assets and equipment"; Type="rich"
               Attrs=@( @{N="Location";T="Domain";R=4}, @{N="Purchase Date";T="DateTime"}, @{N="Value";T="Decimal";Dp=2}, @{N="Serial Number";T="Text";L=100}, @{N="Is Operational";T="Boolean"}, @{N="Warranty Expires";T="DateTime"} )
               GenName={ param($i) "$(RandItem @('HVAC Unit','Fire Extinguisher','UPS Battery','Access Panel','Elevator','Generator','Security Camera','Smart Lock','Air Purifier','Projector','Standing Desk','Ergonomic Chair','Whiteboard','Display Screen','Coffee Machine'))" } }

            @{ Name="Work Order"; Desc="Maintenance work orders"; Type="rich"
               Attrs=@( @{N="Location";T="Domain";R=4}, @{N="Priority";T="Text";L=20}, @{N="Requested Date";T="DateTime"}, @{N="Completed Date";T="DateTime"}, @{N="Cost";T="Decimal";Dp=2}, @{N="Is Completed";T="Boolean"}, @{N="Description";T="Text";L=500} )
               GenName={ param($i) "WO-$('{0:D5}' -f ($i+5000)) $(RandItem @('Plumbing repair','HVAC maintenance','Electrical fix','Painting','Carpet replacement','Lock change','Light replacement','Roof repair','Window cleaning','Pest control'))" } }

            @{ Name="Space Booking"; Desc="Room and space reservations"; Type="rich"
               Attrs=@( @{N="Location";T="Domain";R=4}, @{N="Booking Date";T="DateTime"}, @{N="Duration (Hours)";T="Decimal";Dp=1}, @{N="Attendees";T="Int"}, @{N="Is Recurring";T="Boolean"}, @{N="Organizer";T="Text";L=100} )
               GenName={ param($i) "BK-$('{0:D5}' -f ($i+1000)) $(RandItem @('Team Standup','Board Meeting','Client Presentation','Training Session','Interview','Workshop','Town Hall','Sprint Review','Brainstorm','1-on-1'))" } }

            @{ Name="Inspection"; Desc="Facility inspections"; Type="rich"
               Attrs=@( @{N="Building Type";T="Domain";R=1}, @{N="Inspector";T="Text";L=100}, @{N="Inspection Date";T="DateTime"}, @{N="Score";T="Decimal";Dp=1}, @{N="Is Passed";T="Boolean"}, @{N="Next Due";T="DateTime"}, @{N="Notes";T="Text";L=500} )
               GenName={ param($i) "FINSP-$('{0:D4}' -f ($i+200)) $(RandItem @('Fire Safety','Health & Safety','Electrical','Structural','Environmental','Accessibility','Security','HVAC','Plumbing','General'))" } }
        )
    }
)

# ════════════════════════════════════════════════════════════════════
# SCHEMA GENERATION
# ════════════════════════════════════════════════════════════════════

Write-Host "  [1/5] Planning schema..." -ForegroundColor Gray

# Row count randomizer — varied distribution per entity
function RandRowCount([bool]$isLookup, [int]$minRec, [int]$maxRec) {
    if ($maxRec -eq 0) { return 0 }
    $minRec = [Math]::Max(1, $minRec)  # Always generate at least 1 row per entity
    if ($isLookup -and $maxRec -le 100) { return RandInt ([Math]::Max(5, $minRec)) $maxRec }
    if ($maxRec -le 100) { return RandInt $minRec $maxRec }
    if ($maxRec -le 10000) {
        $lo = [Math]::Ceiling($minRec / 10) * 10
        return (RandInt ($lo / 10) ($maxRec / 10)) * 10
    }
    if ($maxRec -le 100000) {
        $lo = [Math]::Ceiling($minRec / 100) * 100
        return (RandInt ($lo / 100) ($maxRec / 100)) * 100
    }
    $lo = [Math]::Ceiling($minRec / 1000) * 1000
    return (RandInt ($lo / 1000) ($maxRec / 1000)) * 1000
}

# ID counters — either start fresh (clean) or continue from existing max
if ($CleanFirst) {
    $nextModelId = 1; $nextEntityId = 1; $nextAttrId = 1; $nextRowId = 1
    $existingModelNames = @()
    Write-Host "  Clean mode: IDs start at 1" -ForegroundColor DarkGray
} else {
    Write-Host "  Querying existing data..." -ForegroundColor Gray
    $maxIdSql = "SET NOCOUNT ON; SELECT ISNULL(MAX(Id),0) FROM Models; SELECT ISNULL(MAX(Id),0) FROM Entities; SELECT ISNULL(MAX(Id),0) FROM Attributes; SELECT ISNULL(MAX(Id),0) FROM EntityRows;"
    $maxIdResult = & $SqlcmdPath -S $Server -d $Database -E -C -h -1 -W -Q $maxIdSql 2>&1 | Out-String
    $maxIds = @($maxIdResult -split "`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ -match '^\d+$' } | ForEach-Object { [int]$_ })
    $nextModelId  = $(if ($maxIds.Count -ge 1) { $maxIds[0] } else { 0 }) + 1
    $nextEntityId = $(if ($maxIds.Count -ge 2) { $maxIds[1] } else { 0 }) + 1
    $nextAttrId   = $(if ($maxIds.Count -ge 3) { $maxIds[2] } else { 0 }) + 1
    $nextRowId    = $(if ($maxIds.Count -ge 4) { $maxIds[3] } else { 0 }) + 1
    Write-Host "  Additive mode: starting IDs at Model=$nextModelId, Entity=$nextEntityId, Attr=$nextAttrId, Row=$nextRowId" -ForegroundColor DarkGray
    # Query existing model names to avoid duplicates
    $namesSql = "SET NOCOUNT ON; SELECT Name FROM Models;"
    $namesResult = & $SqlcmdPath -S $Server -d $Database -E -C -h -1 -W -Q $namesSql 2>&1 | Out-String
    $existingModelNames = @($namesResult -split "`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" -and $_ -notmatch '^\(' })
}

# Storage — use ArrayList for performance (regular += copies entire array each time)
$allModels = [System.Collections.ArrayList]::new()
$allEntities = [System.Collections.ArrayList]::new()
$allAttrs = [System.Collections.ArrayList]::new()
$allDerivedCols = [System.Collections.ArrayList]::new()

# Entity row ID ranges for domain references: entityId -> @{ Start; Count }
$entityRowRange = @{}

# Select themes (random, no duplicates, skip existing model names in additive mode)
$availableThemes = if ($existingModelNames.Count -gt 0) {
    @($Themes | Where-Object { $_.Name -notin $existingModelNames })
} else { $Themes }
if ($availableThemes.Count -eq 0) {
    Write-Host "  ERROR: All themes already exist. Use clean mode or fewer models." -ForegroundColor Red
    exit 1
}
$selectedThemes = if ($Models -ge $availableThemes.Count) { $availableThemes } else { $availableThemes | Get-Random -Count $Models }

foreach ($theme in $selectedThemes) {
    $modelId = $nextModelId++
    [void]$allModels.Add(@{ Id=$modelId; Name=$theme.Name; Desc=$theme.Desc; SortOrder=$modelId })

    $themeEntities = @($theme.Entities | Select-Object -First $EntitiesPerModel)

    $localEntityMap = @{}
    $entityAttrMap = @{}

    for ($ei = 0; $ei -lt $themeEntities.Count; $ei++) {
        $localEntityMap[($ei + 1)] = $nextEntityId + $ei
    }

    foreach ($entDef in $themeEntities) {
        $entityId = $nextEntityId++
        $localIdx = $themeEntities.IndexOf($entDef) + 1
        $isLookup = $entDef.Type -eq "lookup"
        $rowCount = RandRowCount $isLookup $MinRecords $MaxRecords

        # Pre-calculate row ID range for this entity
        $startRowId = $nextRowId
        $nextRowId += $rowCount
        $entityRowRange[$entityId] = @{ Start=$startRowId; Count=$rowCount }

        [void]$allEntities.Add(@{
            Id=$entityId; ModelId=$modelId; Name=$entDef.Name; Desc=$entDef.Desc
            SortOrder=$localIdx; IsLookup=$isLookup; RowCount=$rowCount
            StartRowId=$startRowId; GenName=$entDef.GenName; GenCode=$entDef.GenCode
        })

        $entityAttrMap[$entityId] = @{}
        $attrs = [System.Collections.ArrayList]::new()

        # Code attribute
        $codeId = $nextAttrId++
        [void]$attrs.Add(@{ Id=$codeId; EntityId=$entityId; DisplayName="Code"; Name="Code"; DataType="Text"; MaxLength=50; IsRequired=1; IsCode=1; IsName=0; IsHidden=0; IsSystemDate=0; SortOrder=1; DomainEntityId=$null; DomainParentAttributeId=$null; DateFormat=$null; BooleanDisplayFormat=$null; DecimalPlaces=$null; AllowNegative=$null })
        $entityAttrMap[$entityId]["Code"] = $codeId

        # Name attribute
        $nameId = $nextAttrId++
        [void]$attrs.Add(@{ Id=$nameId; EntityId=$entityId; DisplayName="Name"; Name="Name"; DataType="Text"; MaxLength=200; IsRequired=1; IsCode=0; IsName=1; IsHidden=0; IsSystemDate=0; SortOrder=2; DomainEntityId=$null; DomainParentAttributeId=$null; DateFormat=$null; BooleanDisplayFormat=$null; DecimalPlaces=$null; AllowNegative=$null })
        $entityAttrMap[$entityId]["Name"] = $nameId

        # Adjust attribute list based on AvgAttributes setting
        $customAttrDefs = @($entDef.Attrs)
        if ($AvgAttributes -gt 0) {
            $targetCount = RandInt ([Math]::Max(1, [Math]::Floor($AvgAttributes * 0.5))) ([Math]::Ceiling($AvgAttributes * 1.5))
            $domainDefs = @($customAttrDefs | Where-Object { $_.T -eq "Domain" })
            $nonDomainDefs = @($customAttrDefs | Where-Object { $_.T -ne "Domain" })

            if ($customAttrDefs.Count -gt $targetCount) {
                # Trim: keep all domain attrs, randomly drop non-domain attrs
                $keepNonDomain = [Math]::Max(0, $targetCount - $domainDefs.Count)
                if ($keepNonDomain -lt $nonDomainDefs.Count -and $nonDomainDefs.Count -gt 0) {
                    $nonDomainDefs = @($nonDomainDefs | Get-Random -Count ([Math]::Max(1, $keepNonDomain)))
                }
                $customAttrDefs = @($domainDefs) + @($nonDomainDefs)
            }
            elseif ($customAttrDefs.Count -lt $targetCount) {
                # Pad: add random attrs from the pool
                $existingNames = @($customAttrDefs | ForEach-Object { $_.N })
                $available = @($ExtraAttrPool | Where-Object { $_.N -notin $existingNames })
                $needed = $targetCount - $customAttrDefs.Count
                if ($needed -gt $available.Count) { $needed = $available.Count }
                if ($needed -gt 0) {
                    $extras = @($available | Get-Random -Count $needed)
                    $customAttrDefs = @($customAttrDefs) + @($extras)
                }
            }
        }

        # Custom attributes
        $sortOrder = 3
        foreach ($aDef in $customAttrDefs) {
            $aId = $nextAttrId++
            $attrName = ($aDef.N -replace '[^a-zA-Z0-9]', '').ToLower()
            if ($attrName.Length -gt 128) { $attrName = $attrName.Substring(0, 128) }

            $domEntId = $null; $domParentId = $null
            if ($aDef.T -eq "Domain" -and $aDef.R) {
                $targetEId = $localEntityMap[$aDef.R]
                if ($targetEId) { $domEntId = $targetEId }
                if ($aDef.C) {
                    $parentAttr = $attrs | Where-Object { $_.DisplayName -eq $aDef.C -and $_.DataType -eq "Domain" }
                    if ($parentAttr) { $domParentId = $parentAttr.Id }
                }
            }

            [void]$attrs.Add(@{
                Id=$aId; EntityId=$entityId; DisplayName=$aDef.N; Name=$attrName; DataType=$aDef.T
                MaxLength = if ($aDef.L) { $aDef.L } elseif ($aDef.T -eq "Text") { 200 } else { $null }
                IsRequired = if ($aDef.Req) { 1 } else { 0 }
                IsCode=0; IsName=0; IsHidden=0; IsSystemDate=0; SortOrder=$sortOrder++
                DomainEntityId=$domEntId; DomainParentAttributeId=$domParentId
                DateFormat = if ($aDef.T -eq "DateTime") { "YYYY-MM-DD" } else { $null }
                BooleanDisplayFormat = if ($aDef.T -eq "Boolean") { "Yes/No" } else { $null }
                DecimalPlaces = if ($aDef.Dp) { $aDef.Dp } elseif ($aDef.T -eq "Decimal") { 2 } else { $null }
                AllowNegative = if ($aDef.T -in @("Int","Decimal")) { 0 } else { $null }
            })
            $entityAttrMap[$entityId][$aDef.N] = $aId
        }

        # System date attributes
        $crId = $nextAttrId++
        [void]$attrs.Add(@{ Id=$crId; EntityId=$entityId; DisplayName="Created"; Name="createdAt"; DataType="DateTime"; MaxLength=$null; IsRequired=0; IsCode=0; IsName=0; IsHidden=1; IsSystemDate=1; SortOrder=9998; DomainEntityId=$null; DomainParentAttributeId=$null; DateFormat=$null; BooleanDisplayFormat=$null; DecimalPlaces=$null; AllowNegative=$null })
        $modAttrId = $nextAttrId++
        [void]$attrs.Add(@{ Id=$modAttrId; EntityId=$entityId; DisplayName="Last Modified"; Name="modifiedAt"; DataType="DateTime"; MaxLength=$null; IsRequired=0; IsCode=0; IsName=0; IsHidden=1; IsSystemDate=1; SortOrder=9999; DomainEntityId=$null; DomainParentAttributeId=$null; DateFormat=$null; BooleanDisplayFormat=$null; DecimalPlaces=$null; AllowNegative=$null })

        $allAttrs.AddRange($attrs)

        # Derived columns
        $domainAttrs = $attrs | Where-Object { $_.DataType -eq "Domain" -and $_.DomainEntityId -and -not $_.IsSystemDate }
        foreach ($dAttr in $domainAttrs) {
            $targetEntId = $dAttr.DomainEntityId
            $targetAttrs = $allAttrs | Where-Object { $_.EntityId -eq $targetEntId -and $_.DataType -eq "Domain" -and -not $_.IsSystemDate }
            foreach ($tAttr in $targetAttrs) {
                $grandparentId = $tAttr.DomainEntityId
                $gpNameAttr = $allAttrs | Where-Object { $_.EntityId -eq $grandparentId -and $_.IsName -eq 1 } | Select-Object -First 1
                if ($gpNameAttr) {
                    $gpEntity = $allEntities | Where-Object { $_.Id -eq $grandparentId }
                    if ($gpEntity) {
                        [void]$allDerivedCols.Add(@{
                            EntityId=$entityId
                            DisplayName="$($gpEntity.Name) Name"
                            AttributePath="[$($dAttr.Id), $($tAttr.Id), $($gpNameAttr.Id)]"
                            SortOrder=$allDerivedCols.Count + 1
                        })
                    }
                }
            }
        }
    }
}

$totalEntities = $allEntities.Count
$totalRows = 0; foreach ($e in $allEntities) { $totalRows += $e.RowCount }
$totalRowsFmt = "{0:N0}" -f $totalRows

# Show per-entity row distribution
Write-Host "  [1/5] Schema planned: $($allModels.Count) models, $totalEntities entities, $($allAttrs.Count) attributes" -ForegroundColor Green
Write-Host ""
foreach ($e in $allEntities) {
    $rc = "{0:N0}" -f $e.RowCount
    $tag = if ($e.RowCount -gt $LargeThreshold) { " [CTE]" } else { "" }
    Write-Host ("    {0,-30} {1,12} rows{2}" -f $e.Name, $rc, $tag) -ForegroundColor DarkGray
}
Write-Host ("    {0,-30} {1,12} total" -f "---", $totalRowsFmt) -ForegroundColor Gray
Write-Host ""

# ════════════════════════════════════════════════════════════════════
# DATA GENERATION (small entities only, ≤ $LargeThreshold rows)
# Large entities are generated server-side via SQL CTEs.
# ════════════════════════════════════════════════════════════════════

Write-Host "  [2/5] Generating data for small entities..." -ForegroundColor Gray

# Only small entities store rows/values in memory
$smallRows = [System.Collections.ArrayList]::new()
$smallValues = [System.Collections.ArrayList]::new()

foreach ($entity in $allEntities) {
    if ($entity.RowCount -eq 0 -or $entity.RowCount -gt $LargeThreshold) { continue }

    $eId = $entity.Id
    $attrs = $allAttrs | Where-Object { $_.EntityId -eq $eId -and -not $_.IsSystemDate -and -not $_.IsCode -and -not $_.IsName }
    $startId = $entity.StartRowId

    for ($i = 0; $i -lt $entity.RowCount; $i++) {
        $rowId = $startId + $i

        $code = if ($entity.GenCode) { & $entity.GenCode $i } else { "$(CodePrefix $entity.Name)-$('{0:D4}' -f ($i+1))" }
        if ($entity.GenCode -and $i -ge 15) { $code = "$code-$($i+1)" }
        $name = if ($entity.GenName) { & $entity.GenName $i } else { "$($entity.Name) $($i+1)" }

        [void]$smallRows.Add(@{ Id=$rowId; EntityId=$eId; Code=$code; Name=$name })

        foreach ($attr in $attrs) {
            $val = @{ RowId=$rowId; AttrId=$attr.Id; TextValue=$null; IntValue=$null; DecimalValue=$null; DateTimeValue=$null; DomainValue=$null }
            $skipNull = $attr.IsRequired -or (RandInt 1 10) -gt 1

            if ($skipNull) {
                switch ($attr.DataType) {
                    "Text" {
                        $dn = $attr.DisplayName.ToLower()
                        if ($dn -match "email") { $val.TextValue = "$($FirstNames[(RandInt 0 ($FirstNames.Count-1))].ToLower()).$($LastNames[(RandInt 0 ($LastNames.Count-1))].ToLower())@$(RandItem @('company.com','org.net','corp.io','mail.com','work.nl'))" }
                        elseif ($dn -match "phone") { $val.TextValue = "+$(RandInt 1 99) $(RandInt 100 999) $(RandInt 1000000 9999999)" }
                        elseif ($dn -match "address") { $val.TextValue = "$(RandInt 1 999) $(RandItem @('Main St','High St','Park Ave','Oak Lane','Elm Drive','King St','Queen Blvd','River Rd','Market St','Church Lane')), $(RandItem $Cities)" }
                        elseif ($dn -match "status") { $val.TextValue = RandItem @("Active","Pending","Completed","Cancelled","In Progress","On Hold","Draft","Approved","Rejected","Closed") }
                        elseif ($dn -match "description|notes|root cause|action plan") { $val.TextValue = RandItem @("Standard processing applies.","Requires review before next quarter.","Updated per latest compliance requirements.","No issues identified during last review.","Follow up scheduled for next month.","Pending additional documentation.","Approved with minor conditions.","High priority item.","Regular maintenance cycle applies.","See related documentation for details.") }
                        elseif ($dn -match "version") { $val.TextValue = "$(RandInt 1 12).$(RandInt 0 9).$(RandInt 0 99)" }
                        elseif ($dn -match "ip address") { $val.TextValue = "10.$(RandInt 0 255).$(RandInt 0 255).$(RandInt 1 254)" }
                        elseif ($dn -match "serial") { $val.TextValue = "SN-$('{0:X8}' -f (RandInt 100000 99999999))" }
                        elseif ($dn -match "priority|risk|severity|winner") { $val.TextValue = RandItem @("Low","Medium","High","Critical") }
                        elseif ($dn -match "category|type") { $val.TextValue = RandItem @("General","Standard","Premium","Custom","Special","Basic") }
                        elseif ($dn -match "symbol") { $val.TextValue = RandItem @("E","$","L","Y","A","C","F","R","K","W") }
                        elseif ($dn -match "abbreviation") { $val.TextValue = $code }
                        elseif ($dn -match "website") { $val.TextValue = "https://www.$(RandItem @('vendor','supplier','partner','service','platform'))$(RandInt 1 100).com" }
                        elseif ($dn -match "region|department|certification|owner|organizer|inspector|contact|company|location") { $val.TextValue = RandItem @("$($FirstNames[(RandInt 0 29)]) $($LastNames[(RandInt 0 29)])","$(RandItem $Departments)","$(RandItem $Cities)") }
                        else { $val.TextValue = "$($attr.DisplayName) value $($i+1)" }
                    }
                    "Int" {
                        $dn = $attr.DisplayName.ToLower()
                        if ($dn -match "year|fiscal") { $val.IntValue = RandInt 2020 2026 }
                        elseif ($dn -match "capacity|head count|attendees|quantity|sample|users") { $val.IntValue = RandInt 1 500 }
                        elseif ($dn -match "floor") { $val.IntValue = RandInt 0 20 }
                        elseif ($dn -match "days|hours|duration|month|response|lead time|valid|downtime") { $val.IntValue = RandInt 1 365 }
                        elseif ($dn -match "cpu|core|ram") { $val.IntValue = RandItem @(2,4,8,16,32,64,128) }
                        elseif ($dn -match "view|leads|conversion|score|rating|defect|discrepancy") { $val.IntValue = RandInt 0 10000 }
                        elseif ($dn -match "population") { $val.IntValue = RandInt 1 1400 }
                        elseif ($dn -match "probability") { $val.IntValue = RandInt 5 95 }
                        else { $val.IntValue = RandInt 1 1000 }
                    }
                    "Decimal" {
                        $dn = $attr.DisplayName.ToLower()
                        $dp = if ($attr.DecimalPlaces) { $attr.DecimalPlaces } else { 2 }
                        if ($dn -match "salary|budget|value|cost|amount|rent|price|revenue|annual|spent|credit") { $val.DecimalValue = RandDec 1000 500000 $dp }
                        elseif ($dn -match "exchange rate") { $val.DecimalValue = RandDec 0.01 150 4 }
                        elseif ($dn -match "percentage|margin|score|rating|discount|quality|carry|storage") { $val.DecimalValue = RandDec 0 100 $dp }
                        elseif ($dn -match "weight|area") { $val.DecimalValue = RandDec 0.1 5000 $dp }
                        elseif ($dn -match "population") { $val.DecimalValue = RandDec 0.1 1400 $dp }
                        elseif ($dn -match "duration") { $val.DecimalValue = RandDec 0.5 8 $dp }
                        else { $val.DecimalValue = RandDec 1 10000 $dp }
                    }
                    "DateTime" {
                        $dn = $attr.DisplayName.ToLower()
                        if ($dn -match "end|expir|due|target|next|warranty|renewal|review") { $val.DateTimeValue = RandDate "2026-01-01" "2028-12-31" }
                        elseif ($dn -match "start|hire|open|purchase|signed|submit|request|report|booking|inspect|found|effective|publish|creat") { $val.DateTimeValue = RandDate "2020-01-01" "2026-06-30" }
                        else { $val.DateTimeValue = RandDate }
                    }
                    "Boolean" { $val.IntValue = RandBool }
                    "Domain" {
                        $tgtId = $attr.DomainEntityId
                        if ($tgtId -and $entityRowRange.ContainsKey($tgtId) -and $entityRowRange[$tgtId].Count -gt 0) {
                            $r = $entityRowRange[$tgtId]
                            $val.DomainValue = $r.Start + (RandInt 0 ($r.Count - 1))
                        }
                    }
                }
            }
            if ($null -ne $val.TextValue -or $null -ne $val.IntValue -or $null -ne $val.DecimalValue -or $null -ne $val.DateTimeValue -or $null -ne $val.DomainValue) {
                [void]$smallValues.Add($val)
            }
        }
    }
    Write-Host "    $($entity.Name): $($entity.RowCount) rows generated in memory" -ForegroundColor DarkGray
}

Write-Host "  [2/5] Small entities: $($smallRows.Count) rows, $($smallValues.Count) values in memory" -ForegroundColor Green

# ════════════════════════════════════════════════════════════════════
# SQL GENERATION — streaming to file
# ════════════════════════════════════════════════════════════════════

Write-Host "  [3/5] Building SQL script..." -ForegroundColor Gray

$sqlFile = Join-Path $PSScriptRoot "temp-demo-data.sql"
$writer = [System.IO.StreamWriter]::new($sqlFile, $false, [System.Text.Encoding]::UTF8)

function W([string]$line) { $writer.WriteLine($line) }

W "SET QUOTED_IDENTIFIER ON;"
W "SET ANSI_NULLS ON;"
W "SET NOCOUNT ON;"
W ""

# ── Cleanup (only if CleanFirst) ─────────────────────────────────
if ($CleanFirst) {
    W "-- ================================================================"
    W "-- CLEANUP"
    W "-- ================================================================"
    W "UPDATE EntityValues SET DomainValue = NULL WHERE DomainValue IS NOT NULL;"
    W "DELETE FROM ApprovalReviews;"
    W "DELETE FROM ApprovalRows;"
    W "DELETE FROM ApprovalRequests;"
    W "DELETE FROM EntityValues;"
    W "DELETE FROM EntityRows;"
    W "DELETE FROM EntityDerivedColumns;"
    W "DELETE FROM IntegrationViews;"
    W "DELETE FROM Permissions WHERE Scope IN ('attribute','entity','model');"
    W "DELETE FROM EntityApprovers;"
    W "DELETE FROM UserFavorites;"
    W "DELETE FROM UserSettings;"
    W "DELETE FROM AuditLog;"
    W "DELETE FROM StagingFieldRules;"
    W "DELETE FROM StagingImport;"
    W "DELETE FROM StagingBatches;"
    W "DELETE FROM StagingConfigurations;"
    W "DELETE FROM SchedulerConfigurations;"
    W "DELETE FROM Attributes;"
    W "DELETE FROM Entities;"
    W "DELETE FROM Models;"
    W "DBCC CHECKIDENT ('Models', RESEED, 0);"
    W "DBCC CHECKIDENT ('Entities', RESEED, 0);"
    W "DBCC CHECKIDENT ('Attributes', RESEED, 0);"
    W "DBCC CHECKIDENT ('EntityRows', RESEED, 0);"
    W "DBCC CHECKIDENT ('EntityValues', RESEED, 0);"
    W "DBCC CHECKIDENT ('EntityDerivedColumns', RESEED, 0);"
    W "DBCC CHECKIDENT ('IntegrationViews', RESEED, 0);"
    W "DBCC CHECKIDENT ('Permissions', RESEED, 0);"
    W "DBCC CHECKIDENT ('AuditLog', RESEED, 0);"
    W "DBCC CHECKIDENT ('ApprovalRequests', RESEED, 0);"
    W "DBCC CHECKIDENT ('ApprovalRows', RESEED, 0);"
    W "DBCC CHECKIDENT ('ApprovalReviews', RESEED, 0);"
    W "DBCC CHECKIDENT ('StagingImport', RESEED, 0);"
    W "PRINT 'Cleanup complete.';"
    W "GO"
    W ""
} else {
    W "-- Additive mode: appending to existing data"
    W ""
}

# ── Models ───────────────────────────────────────────────────────
W "SET IDENTITY_INSERT Models ON;"
foreach ($m in $allModels) { W "INSERT INTO Models (Id,Name,Description,IsActive,SortOrder,CreatedAt,ModifiedAt) VALUES ($($m.Id),$(SqlStr $m.Name),$(SqlStr $m.Desc),1,$($m.SortOrder),GETUTCDATE(),GETUTCDATE());" }
W "SET IDENTITY_INSERT Models OFF;"
W "PRINT 'Models: $($allModels.Count)';"
W "GO"
W ""

# ── Entities ─────────────────────────────────────────────────────
W "SET IDENTITY_INSERT Entities ON;"
foreach ($e in $allEntities) {
    $tn = ($e.Name -replace '[^a-zA-Z0-9]', '')
    W "INSERT INTO Entities (Id,ModelId,Name,Description,TableName,SortOrder,IsActive,RequiresApproval,SharedAcrossModels,AutoGenerateCode,CreatedAt,ModifiedAt) VALUES ($($e.Id),$($e.ModelId),$(SqlStr $e.Name),$(SqlStr $e.Desc),$(SqlStr $tn),$($e.SortOrder),1,0,0,0,GETUTCDATE(),GETUTCDATE());"
}
W "SET IDENTITY_INSERT Entities OFF;"
W "PRINT 'Entities: $totalEntities';"
W "GO"
W ""

# ── Attributes ───────────────────────────────────────────────────
W "SET IDENTITY_INSERT Attributes ON;"
foreach ($a in $allAttrs) {
    W "INSERT INTO Attributes (Id,EntityId,DisplayName,Name,DataType,MaxLength,IsRequired,IsCode,IsName,IsHidden,IsSystemDate,SortOrder,DomainEntityId,DomainParentAttributeId,DateFormat,BooleanDisplayFormat,DecimalPlaces,AllowNegative,CreatedAt,ModifiedAt) VALUES ($($a.Id),$($a.EntityId),$(SqlStr $a.DisplayName),$(SqlStr $a.Name),$(SqlStr $a.DataType),$(SqlInt $a.MaxLength),$($a.IsRequired),$($a.IsCode),$($a.IsName),$($a.IsHidden),$($a.IsSystemDate),$($a.SortOrder),$(SqlInt $a.DomainEntityId),$(SqlInt $a.DomainParentAttributeId),$(SqlStr $a.DateFormat),$(SqlStr $a.BooleanDisplayFormat),$(SqlInt $a.DecimalPlaces),$(SqlInt $a.AllowNegative),GETUTCDATE(),GETUTCDATE());"
}
W "SET IDENTITY_INSERT Attributes OFF;"
W "PRINT 'Attributes: $($allAttrs.Count)';"
W "GO"
W ""

# ── Derived Columns ──────────────────────────────────────────────
if ($allDerivedCols.Count -gt 0) {
    foreach ($dc in $allDerivedCols) { W "INSERT INTO EntityDerivedColumns (EntityId,DisplayName,AttributePath,SortOrder,CreatedAt) VALUES ($($dc.EntityId),$(SqlStr $dc.DisplayName),N'$($dc.AttributePath)',$($dc.SortOrder),GETUTCDATE());" }
    W "PRINT 'Derived columns: $($allDerivedCols.Count)';"
    W "GO"
    W ""
}

# ── Entity Rows + Values per entity ─────────────────────────────
W "SET IDENTITY_INSERT EntityRows ON;"
W "GO"
W ""

foreach ($entity in $allEntities) {
    if ($entity.RowCount -eq 0) { continue }

    $eId = $entity.Id
    $rc = $entity.RowCount
    $startId = $entity.StartRowId
    $prefix = CodePrefix $entity.Name
    $customAttrs = $allAttrs | Where-Object { $_.EntityId -eq $eId -and -not $_.IsSystemDate -and -not $_.IsCode -and -not $_.IsName }

    W "-- ════ $($entity.Name) (Entity $eId): $rc rows, IDs $startId..$(($startId+$rc-1)) ════"

    if ($rc -le $LargeThreshold) {
        # ── SMALL ENTITY: INSERT...VALUES from PS arrays ─────────
        $entityRows = $smallRows | Where-Object { $_.EntityId -eq $eId }
        $bc = 0
        foreach ($r in $entityRows) {
            W "INSERT INTO EntityRows (Id,EntityId,Code,Name,CreatedAt,ModifiedAt,CreatedBy,ModifiedBy) VALUES ($($r.Id),$eId,$(SqlStr $r.Code),$(SqlStr $r.Name),GETUTCDATE(),GETUTCDATE(),1,1);"
            $bc++
            if ($bc % 500 -eq 0) { W "GO" }
        }
        W "GO"

        # Values in batches of 500
        $entityVals = $smallValues | Where-Object { $_.RowId -ge $startId -and $_.RowId -lt ($startId + $rc) }
        $batch = [System.Collections.ArrayList]::new()
        foreach ($v in $entityVals) {
            [void]$batch.Add("($($v.RowId),$($v.AttrId),$(SqlStr $v.TextValue),$(SqlInt $v.IntValue),$(SqlDec $v.DecimalValue),$(SqlDate $v.DateTimeValue),$(SqlInt $v.DomainValue))")
            if ($batch.Count -ge 500) {
                W "INSERT INTO EntityValues (EntityRowId,AttributeId,TextValue,IntValue,DecimalValue,DateTimeValue,DomainValue) VALUES"
                W (($batch -join ",`n") + ";")
                W "GO"
                $batch.Clear()
            }
        }
        if ($batch.Count -gt 0) {
            W "INSERT INTO EntityValues (EntityRowId,AttributeId,TextValue,IntValue,DecimalValue,DateTimeValue,DomainValue) VALUES"
            W (($batch -join ",`n") + ";")
            W "GO"
        }
    }
    else {
        # ── LARGE ENTITY: batched CTE generation with progress ─
        $batchSize = 10000

        # EntityRows in batches of 10k with progress
        W "DECLARE @batch INT = 0, @done INT = 0;"
        W "WHILE @batch * $batchSize < $rc"
        W "BEGIN"
        W "    ;WITH E1(n) AS (SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1 UNION ALL SELECT 1)"
        W "        ,E2(n) AS (SELECT 1 FROM E1 a CROSS JOIN E1 b)"
        W "        ,E4(n) AS (SELECT 1 FROM E2 a CROSS JOIN E2 b)"
        W "        ,Nums AS (SELECT TOP(CASE WHEN ($rc - @batch * $batchSize) < $batchSize THEN ($rc - @batch * $batchSize) ELSE $batchSize END) ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) + @batch * $batchSize AS n FROM E4)"
        W "    INSERT INTO EntityRows (Id,EntityId,Code,Name,CreatedAt,ModifiedAt,CreatedBy,ModifiedBy)"
        W "    SELECT $startId + n - 1, $eId,"
        W "        N'$prefix-' + RIGHT('000000' + CAST(n AS VARCHAR(10)), 6),"
        W "        N'$($entity.Name) ' + CAST(n AS NVARCHAR(20)),"
        W "        GETUTCDATE(), GETUTCDATE(), 1, 1"
        W "    FROM Nums;"
        W "    SET @batch = @batch + 1;"
        W "    SET @done = CASE WHEN @batch * $batchSize > $rc THEN $rc ELSE @batch * $batchSize END;"
        W "    RAISERROR('    Rows: %d / $rc', 0, 1, @done) WITH NOWAIT;"
        W "END"
        W "GO"

        # EntityValues — one INSERT...SELECT per attribute
        foreach ($attr in $customAttrs) {
            $aId = $attr.Id
            $dn = $attr.DisplayName.ToLower()

            # Build the value expression based on data type
            switch ($attr.DataType) {
                "Text" {
                    if ($dn -match "email") {
                        $expr = "N'user' + CAST(er.Id AS NVARCHAR(20)) + N'@company.com', NULL, NULL, NULL, NULL"
                    } elseif ($dn -match "phone") {
                        $expr = "N'+' + CAST((er.Id % 99 + 1) AS NVARCHAR(5)) + N' ' + CAST((er.Id % 900 + 100) AS NVARCHAR(5)) + N' ' + CAST((er.Id % 9000000 + 1000000) AS NVARCHAR(10)), NULL, NULL, NULL, NULL"
                    } elseif ($dn -match "address") {
                        $expr = "CAST((er.Id % 999 + 1) AS NVARCHAR(5)) + N' ' + (SELECT v FROM (VALUES (0,N'Main St'),(1,N'High St'),(2,N'Park Ave'),(3,N'Oak Lane'),(4,N'Elm Drive'),(5,N'King St'),(6,N'Queen Blvd'),(7,N'River Rd'),(8,N'Market St'),(9,N'Church Lane')) AS t(i,v) WHERE i = er.Id % 10), NULL, NULL, NULL, NULL"
                    } elseif ($dn -match "status") {
                        $expr = "(SELECT v FROM (VALUES (0,N'Active'),(1,N'Pending'),(2,N'Completed'),(3,N'Cancelled'),(4,N'In Progress'),(5,N'On Hold'),(6,N'Draft'),(7,N'Approved'),(8,N'Rejected'),(9,N'Closed')) AS t(i,v) WHERE i = er.Id % 10), NULL, NULL, NULL, NULL"
                    } elseif ($dn -match "description|notes|root cause|action plan") {
                        $expr = "(SELECT v FROM (VALUES (0,N'Standard processing applies.'),(1,N'Requires review before next quarter.'),(2,N'Updated per compliance requirements.'),(3,N'No issues identified.'),(4,N'Follow up scheduled.'),(5,N'Pending documentation.'),(6,N'Approved with conditions.'),(7,N'High priority item.'),(8,N'Regular maintenance cycle.'),(9,N'See related docs.')) AS t(i,v) WHERE i = er.Id % 10), NULL, NULL, NULL, NULL"
                    } elseif ($dn -match "priority|risk|severity|winner") {
                        $expr = "(SELECT v FROM (VALUES (0,N'Low'),(1,N'Medium'),(2,N'High'),(3,N'Critical')) AS t(i,v) WHERE i = er.Id % 4), NULL, NULL, NULL, NULL"
                    } elseif ($dn -match "ip address") {
                        $expr = "N'10.' + CAST(er.Id % 256 AS NVARCHAR(5)) + N'.' + CAST((er.Id / 256) % 256 AS NVARCHAR(5)) + N'.' + CAST(er.Id % 254 + 1 AS NVARCHAR(5)), NULL, NULL, NULL, NULL"
                    } elseif ($dn -match "serial") {
                        $expr = "N'SN-' + RIGHT('00000000' + CAST(er.Id AS VARCHAR(10)), 8), NULL, NULL, NULL, NULL"
                    } else {
                        $expr = "N'$(Esc $attr.DisplayName) ' + CAST(er.Id AS NVARCHAR(20)), NULL, NULL, NULL, NULL"
                    }
                }
                "Int" {
                    if ($dn -match "year|fiscal") { $expr = "NULL, 2020 + ABS(CHECKSUM(NEWID())) % 7, NULL, NULL, NULL" }
                    elseif ($dn -match "capacity|head count|attendees|quantity|sample|users") { $expr = "NULL, ABS(CHECKSUM(NEWID())) % 500 + 1, NULL, NULL, NULL" }
                    elseif ($dn -match "floor") { $expr = "NULL, ABS(CHECKSUM(NEWID())) % 21, NULL, NULL, NULL" }
                    elseif ($dn -match "days|hours|duration|month|response|lead time|valid|downtime") { $expr = "NULL, ABS(CHECKSUM(NEWID())) % 365 + 1, NULL, NULL, NULL" }
                    elseif ($dn -match "cpu|core|ram") { $expr = "NULL, POWER(2, ABS(CHECKSUM(NEWID())) % 7 + 1), NULL, NULL, NULL" }
                    elseif ($dn -match "probability") { $expr = "NULL, ABS(CHECKSUM(NEWID())) % 91 + 5, NULL, NULL, NULL" }
                    else { $expr = "NULL, ABS(CHECKSUM(NEWID())) % 1000 + 1, NULL, NULL, NULL" }
                }
                "Decimal" {
                    $dp = if ($attr.DecimalPlaces) { $attr.DecimalPlaces } else { 2 }
                    $scale = [Math]::Pow(10, $dp)
                    if ($dn -match "salary|budget|value|cost|amount|rent|price|revenue|annual|spent|credit") {
                        $expr = "NULL, NULL, CAST(ABS(CHECKSUM(NEWID())) % $([long](499000 * $scale)) + $([long](1000 * $scale)) AS DECIMAL(18,$dp)) / $scale, NULL, NULL"
                    } elseif ($dn -match "exchange rate") {
                        $expr = "NULL, NULL, CAST(ABS(CHECKSUM(NEWID())) % 150000 + 10 AS DECIMAL(18,4)) / 1000.0, NULL, NULL"
                    } elseif ($dn -match "percentage|margin|score|rating|discount|quality|carry|storage") {
                        $expr = "NULL, NULL, CAST(ABS(CHECKSUM(NEWID())) % $([long](100 * $scale)) AS DECIMAL(18,$dp)) / $scale, NULL, NULL"
                    } else {
                        $expr = "NULL, NULL, CAST(ABS(CHECKSUM(NEWID())) % $([long](10000 * $scale)) + $([long]$scale) AS DECIMAL(18,$dp)) / $scale, NULL, NULL"
                    }
                }
                "DateTime" {
                    if ($dn -match "end|expir|due|target|next|warranty|renewal|review") {
                        $expr = "NULL, NULL, NULL, DATEADD(DAY, ABS(CHECKSUM(NEWID())) % 1095, '2026-01-01'), NULL"
                    } elseif ($dn -match "start|hire|open|purchase|signed|submit|request|report|booking|inspect|found|effective|publish|creat") {
                        $expr = "NULL, NULL, NULL, DATEADD(DAY, ABS(CHECKSUM(NEWID())) % 2373, '2020-01-01'), NULL"
                    } else {
                        $expr = "NULL, NULL, NULL, DATEADD(DAY, ABS(CHECKSUM(NEWID())) % 2557, '2020-01-01'), NULL"
                    }
                }
                "Boolean" {
                    $expr = "NULL, CASE WHEN ABS(CHECKSUM(NEWID())) % 100 < 70 THEN 1 ELSE 0 END, NULL, NULL, NULL"
                }
                "Domain" {
                    $tgtId = $attr.DomainEntityId
                    if ($tgtId -and $entityRowRange.ContainsKey($tgtId) -and $entityRowRange[$tgtId].Count -gt 0) {
                        $tr = $entityRowRange[$tgtId]
                        $expr = "NULL, NULL, NULL, NULL, $($tr.Start) + ABS(CHECKSUM(NEWID())) % $($tr.Count)"
                    } else {
                        continue  # skip if no target rows
                    }
                }
            }

            W "INSERT INTO EntityValues (EntityRowId,AttributeId,TextValue,IntValue,DecimalValue,DateTimeValue,DomainValue)"
            W "SELECT er.Id, $aId, $expr"
            W "FROM EntityRows er WHERE er.EntityId = $eId;"
            W "RAISERROR('    Values: $($attr.DisplayName) [$rc rows]', 0, 1) WITH NOWAIT;"
            W "GO"
        }
    }

    W "PRINT '  $($entity.Name): $rc rows';"
    W "GO"
    W ""
}

W "SET IDENTITY_INSERT EntityRows OFF;"
W "GO"
W ""

# ── Summary ──────────────────────────────────────────────────────
W "PRINT '';"
W "PRINT '=== DEMO DATA GENERATION COMPLETE ===';"
W "PRINT 'Models:          $($allModels.Count)';"
W "PRINT 'Entities:        $totalEntities';"
W "PRINT 'Total Rows:      $totalRowsFmt';"

$writer.Flush()
$writer.Close()

$sizeMB = [Math]::Round((Get-Item $sqlFile).Length / 1MB, 2)
Write-Host "  [3/5] SQL script: $sqlFile ($sizeMB MB)" -ForegroundColor Green

# ════════════════════════════════════════════════════════════════════
# EXECUTION
# ════════════════════════════════════════════════════════════════════

Write-Host "  [4/5] Executing via sqlcmd (this may take a while for large datasets)..." -ForegroundColor Gray

$sw = [System.Diagnostics.Stopwatch]::StartNew()
$sqlcmdArgs = @("-S", $Server, "-d", $Database, "-E", "-C", "-i", $sqlFile, "-b")
$result = & $SqlcmdPath @sqlcmdArgs 2>&1
$sw.Stop()

$exitCode = $LASTEXITCODE
$output = $result | Out-String

if ($exitCode -ne 0) {
    Write-Host ""
    Write-Host "  ERROR: sqlcmd failed with exit code $exitCode" -ForegroundColor Red
    Write-Host $output -ForegroundColor Red
    Write-Host ""
    Write-Host "  SQL file preserved at: $sqlFile" -ForegroundColor Yellow
    Write-Host ""
    if (-not $NonInteractive) { Read-Host "  Press Enter to close" }
    exit 1
}

# Print sqlcmd output
$output -split "`n" | ForEach-Object {
    $line = $_.Trim()
    if ($line -and $line -notmatch "^Changed database|^Checking identity|^DBCC exec") {
        Write-Host "    $line" -ForegroundColor DarkGray
    }
}

# ════════════════════════════════════════════════════════════════════
# CLEANUP & SUMMARY
# ════════════════════════════════════════════════════════════════════

Remove-Item $sqlFile -Force -ErrorAction SilentlyContinue

$elapsed = "{0:mm\:ss}" -f $sw.Elapsed
Write-Host ""
Write-Host "  [5/5] Done in $elapsed!" -ForegroundColor Green
Write-Host ""
Write-Host "  +-------------------------------------------+" -ForegroundColor Cyan
Write-Host "  |  Demo Data Summary                        |" -ForegroundColor Cyan
Write-Host "  +-------------------------------------------+" -ForegroundColor Cyan
Write-Host ("  |  Models:          {0,-23}|" -f $allModels.Count) -ForegroundColor Cyan
Write-Host ("  |  Entities:        {0,-23}|" -f $totalEntities) -ForegroundColor Cyan
Write-Host ("  |  Attributes:      {0,-23}|" -f $allAttrs.Count) -ForegroundColor Cyan
Write-Host ("  |  Derived Columns: {0,-23}|" -f $allDerivedCols.Count) -ForegroundColor Cyan
Write-Host ("  |  Data Rows:       {0,-23}|" -f $totalRowsFmt) -ForegroundColor Cyan
Write-Host ("  |  Execution Time:  {0,-23}|" -f $elapsed) -ForegroundColor Cyan
Write-Host "  +-------------------------------------------+" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Restart the API server to pick up the new data." -ForegroundColor Yellow
Write-Host ""
if (-not $NonInteractive) { Read-Host "  Press Enter to close" }
