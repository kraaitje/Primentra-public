@echo off
:: repair-service.bat — Reinstall the Primentra Windows Service
:: Run as Administrator if the service is stuck, paused, or failing to start.

echo Repairing Primentra service...
echo.

set "APP=%~dp0.."
set "NSSM=%APP%\nssm.exe"
set "LOGS=%APP%\logs"

:: Detect Node.js dynamically (supports nvm, Chocolatey, winget installs)
set "NODE="
for /f "delims=" %%i in ('where node 2^>nul') do if not defined NODE set "NODE=%%i"
if not defined NODE set "NODE=C:\Program Files\nodejs\node.exe"
if not exist "%NODE%" (
  echo ERROR: Node.js not found at %NODE%
  echo Install Node.js v18 or later from https://nodejs.org
  pause
  exit /b 1
)
echo Using Node.js: %NODE%

:: Read port from registry (falls back to 3001)
set "PORT=3001"
for /f "tokens=3" %%a in ('reg query "HKLM\SOFTWARE\Primentra" /v Port 2^>nul ^| findstr Port') do set "PORT=%%a"
echo Using port: %PORT%
echo.

mkdir "%LOGS%" 2>nul

echo Removing existing service (if any)...
"%NSSM%" stop Primentra 2>nul
"%NSSM%" remove Primentra confirm 2>nul
timeout /t 2 /nobreak >nul

echo Installing service...
"%NSSM%" install Primentra "%NODE%"
"%NSSM%" set Primentra AppParameters server.js
"%NSSM%" set Primentra AppDirectory "%APP%"
"%NSSM%" set Primentra Description "Primentra Master Data Management"
"%NSSM%" set Primentra Start SERVICE_AUTO_START
"%NSSM%" set Primentra AppEnvironmentExtra "PORT=%PORT%"
"%NSSM%" set Primentra AppStdout "%LOGS%\service.log"
"%NSSM%" set Primentra AppStderr "%LOGS%\service.err.log"
"%NSSM%" set Primentra AppRotateFiles 1
"%NSSM%" set Primentra AppRotateBytes 10485760
"%NSSM%" set Primentra AppExit Default Restart
"%NSSM%" set Primentra AppExit 0 Exit
"%NSSM%" set Primentra AppRestartDelay 5000
"%NSSM%" set Primentra AppThrottle 3000

:: Grant write permissions before starting the service (same as installer)
icacls "%APP%" /grant "LOCAL SERVICE:(OI)(CI)M" /T /Q 2>nul
icacls "%APP%" /grant "SYSTEM:(OI)(CI)M" /T /Q 2>nul

echo.
echo Starting service...
"%NSSM%" start Primentra
timeout /t 3 /nobreak >nul

sc query Primentra
echo.
echo Done. Open http://localhost:%PORT% in your browser.
echo Logs: %LOGS%
pause
