/**
 * Primentra — Admin Account Recovery
 *
 * Standalone CLI script to reset an admin password when locked out.
 * Reads database connection settings from mds-config.json.
 *
 * Usage (production — from install folder):
 *   node scripts/recover-admin.js
 *
 * Usage (development — from repo root):
 *   node scripts/recover-admin.js
 *
 * The script will:
 *   1. Connect to the database using saved config
 *   2. List all active users
 *   3. Prompt you to select a user and enter a new password
 *   4. Reset the password and clear any lockout
 *   5. Optionally grant administrator access
 */

import { readFileSync, appendFileSync, existsSync, mkdirSync } from 'fs';
import { resolve, dirname } from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import { createInterface } from 'readline';
import crypto from 'crypto';

const __dirname = dirname(fileURLToPath(import.meta.url));
const installDir = resolve(__dirname, '..');
const logsDir = resolve(installDir, 'logs');
const errorLogPath = resolve(logsDir, 'errorlog.txt');

function logError(msg) {
  console.error(msg);
  try {
    if (!existsSync(logsDir)) mkdirSync(logsDir, { recursive: true });
    appendFileSync(errorLogPath, `[${new Date().toISOString()}] [recover-admin] ${msg.trim()}\n`);
  } catch {}
}

// Import mssql — in production it's in ../node_modules, in dev it's in ../app/node_modules
let sql;
try {
  sql = (await import('mssql')).default;
} catch {
  const devPkg = resolve(__dirname, '..', 'app', 'node_modules', 'mssql', 'index.js');
  if (existsSync(devPkg)) {
    sql = (await import(pathToFileURL(devPkg).href)).default;
  } else {
    logError('  Error: mssql package not found. Run "npm install" in the app directory first.\n');
    process.exit(1);
  }
}

// Find config file — works in both production and development layouts
// Production: install_dir/scripts/recover-admin.js → install_dir/mds-config.json
// Development: repo/scripts/recover-admin.js → repo/app/mds-config.json
function findConfig() {
  const prodPath = resolve(__dirname, '..', 'mds-config.json');
  const devPath = resolve(__dirname, '..', 'app', 'mds-config.json');
  if (existsSync(prodPath)) return prodPath;
  if (existsSync(devPath)) return devPath;
  return null;
}

// Same hash function as server/utils/crypto.js
function hashPassword(password) {
  const salt = crypto.randomBytes(32).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function prompt(rl, question) {
  return new Promise(res => rl.question(question, res));
}

async function main() {
  console.log('\n  Primentra — Admin Account Recovery\n');

  // Read config
  const configPath = findConfig();
  if (!configPath) {
    logError(`  Error: Could not find mds-config.json.\n  Checked:\n    ${resolve(__dirname, '..', 'mds-config.json')}\n    ${resolve(__dirname, '..', 'app', 'mds-config.json')}\n  Make sure the application has been configured first.\n`);
    process.exit(1);
  }

  let config;
  try {
    config = JSON.parse(readFileSync(configPath, 'utf-8'));
  } catch {
    logError(`  Error: Could not read config file at: ${configPath}\n  The file may be corrupted.\n`);
    process.exit(1);
  }

  if (!config.hostname || !config.database || !config.username) {
    logError('  Error: Database connection is not configured in the config file.\n');
    process.exit(1);
  }

  console.log(`  Config:   ${configPath}`);
  console.log(`  Server:   ${config.hostname}${config.instance ? '\\' + config.instance : ''}`);
  console.log(`  Database: ${config.database}`);
  console.log('');

  // Connect
  let pool;
  try {
    const sqlConfig = {
      server: config.hostname,
      database: config.database,
      user: config.username,
      password: config.password || '',
      options: {
        encrypt: false,
        trustServerCertificate: true,
        connectTimeout: 10000,
      },
    };
    if (config.instance) sqlConfig.options.instanceName = config.instance;
    if (config.sqlPort) sqlConfig.port = parseInt(config.sqlPort, 10);

    pool = await sql.connect(sqlConfig);
    console.log('  Connected to database.\n');
  } catch (err) {
    logError(`  Error: Could not connect to database: ${err?.message || err?.originalError?.message || JSON.stringify(err)}\n`);
    process.exit(1);
  }

  // List users
  try {
    const result = await pool.request().query(
      `SELECT u.Id, u.Email, u.DisplayName, u.IsActive, u.FailedLoginAttempts,
              CASE WHEN EXISTS (
                SELECT 1 FROM RoleMembers rm JOIN Roles r ON r.Id = rm.RoleId
                WHERE rm.UserId = u.Id AND r.IsAdmin = 1
              ) THEN 1 ELSE 0 END AS IsAdmin
       FROM Users u
       WHERE u.IsDeleted = 0 AND u.IsSystem = 0
       ORDER BY u.Id`
    );

    if (result.recordset.length === 0) {
      console.log('  No users found in the database.\n');

      const rl = createInterface({ input: process.stdin, output: process.stdout });
      const createNew = await prompt(rl, '  Create a new administrator account? (Y/n): ');

      if (createNew.trim().toLowerCase() === 'n') {
        rl.close();
        process.exit(0);
      }

      const newEmail = await prompt(rl, '  Email: ');
      if (!newEmail || !newEmail.includes('@')) {
        console.log('  Invalid email.\n');
        rl.close();
        process.exit(1);
      }

      const newName = await prompt(rl, '  Display name: ');
      if (!newName?.trim()) {
        console.log('  Display name is required.\n');
        rl.close();
        process.exit(1);
      }

      const newPassword = await prompt(rl, '  Password (min 8 chars): ');
      if (!newPassword || newPassword.length < 8) {
        console.log('  Password must be at least 8 characters.\n');
        rl.close();
        process.exit(1);
      }

      const passwordHash = hashPassword(newPassword);

      // Create user
      const insertResult = await pool.request()
        .input('Email', sql.NVarChar(320), newEmail.trim())
        .input('DisplayName', sql.NVarChar(200), newName.trim())
        .input('PasswordHash', sql.NVarChar(500), passwordHash)
        .query(`INSERT INTO Users (Email, DisplayName, PasswordHash, MustChangePassword, IsActive, IsDeleted, IsSystem, UserType)
                VALUES (@Email, @DisplayName, @PasswordHash, 0, 1, 0, 0, 'standard');
                SELECT SCOPE_IDENTITY() AS Id`);
      const newUserId = insertResult.recordset[0].Id;

      // Find or create admin role
      const roleResult = await pool.request().query(
        `SELECT TOP 1 Id FROM Roles WHERE IsAdmin = 1 ORDER BY Id`
      );
      let adminRoleId;
      if (roleResult.recordset.length > 0) {
        adminRoleId = roleResult.recordset[0].Id;
      } else {
        const createResult = await pool.request().query(
          `INSERT INTO Roles (Name, Description, IsAdmin, CanApprove)
           VALUES ('Administrators', 'Full system access', 1, 0);
           SELECT SCOPE_IDENTITY() AS Id`
        );
        adminRoleId = createResult.recordset[0].Id;
      }

      // Add to admin role
      await pool.request().query(
        `INSERT INTO RoleMembers (RoleId, UserId) VALUES (${adminRoleId}, ${newUserId})`
      );

      console.log(`\n  Administrator account created: ${newEmail.trim()}`);
      console.log('  You can now log in with this account.\n');
      rl.close();
      await pool.close();
      process.exit(0);
    }

    console.log('  Available users:\n');
    console.log('  #   Email                          Name                    Status              Admin');
    console.log('  ' + '-'.repeat(95));

    result.recordset.forEach((u, i) => {
      const status = u.IsActive ? 'Active' : `Locked (${u.FailedLoginAttempts} fails)`;
      const admin = u.IsAdmin ? 'Yes' : 'No';
      console.log(`  ${String(i + 1).padStart(2)}  ${(u.Email || '').padEnd(30)} ${(u.DisplayName || '').padEnd(23)} ${status.padEnd(19)} ${admin}`);
    });
    console.log('');

    const rl = createInterface({ input: process.stdin, output: process.stdout });

    const indexStr = await prompt(rl, '  Enter user number to reset: ');
    const index = parseInt(indexStr, 10) - 1;

    if (isNaN(index) || index < 0 || index >= result.recordset.length) {
      console.log('  Invalid selection.\n');
      rl.close();
      process.exit(1);
    }

    const selectedUser = result.recordset[index];
    console.log(`\n  Selected: ${selectedUser.Email} (${selectedUser.DisplayName})\n`);

    const newPassword = await prompt(rl, '  Enter new password (min 8 chars): ');

    if (!newPassword || newPassword.length < 8) {
      console.log('  Password must be at least 8 characters.\n');
      rl.close();
      process.exit(1);
    }

    const confirmPassword = await prompt(rl, '  Confirm new password: ');

    if (newPassword !== confirmPassword) {
      console.log('  Passwords do not match.\n');
      rl.close();
      process.exit(1);
    }

    // Reset password using stored procedure
    const passwordHash = hashPassword(newPassword);
    const resetResult = await pool.request()
      .input('Email', sql.NVarChar(320), selectedUser.Email)
      .input('NewPasswordHash', sql.NVarChar(500), passwordHash)
      .execute('usp_User_ResetPassword');

    const outcome = resetResult.recordset[0];
    if (outcome && outcome.Id) {
      console.log(`\n  Password reset successfully for ${selectedUser.Email}.`);
      if (!selectedUser.IsActive) {
        console.log('  Account lockout has been cleared.');
      }
      console.log('  The user can now log in with the new password.');
    } else {
      console.log(`\n  Error: Password reset failed — no result returned from database.\n`);
      rl.close();
      return;
    }

    // Optionally grant administrator access
    if (selectedUser.IsAdmin) {
      console.log('  This user is already an administrator.\n');
    } else {
      const makeAdmin = await prompt(rl, '\n  Make this user an administrator? (y/N): ');

      if (makeAdmin.trim().toLowerCase() === 'y') {
        // Find existing admin role, or create one
        const roleResult = await pool.request().query(
          `SELECT TOP 1 Id, Name FROM Roles WHERE IsAdmin = 1 ORDER BY Id`
        );

        let adminRoleId;
        if (roleResult.recordset.length > 0) {
          adminRoleId = roleResult.recordset[0].Id;
        } else {
          // No admin role exists — create the default "Administrators" role
          const createResult = await pool.request().query(
            `INSERT INTO Roles (Name, Description, IsAdmin, CanApprove)
             VALUES ('Administrators', 'Full system access', 1, 0);
             SELECT SCOPE_IDENTITY() AS Id`
          );
          adminRoleId = createResult.recordset[0].Id;
          console.log('  Created "Administrators" role (none existed).');
        }

        // Add user to admin role (idempotent — skip if already a member)
        await pool.request().query(
          `IF NOT EXISTS (SELECT 1 FROM RoleMembers WHERE RoleId = ${adminRoleId} AND UserId = ${selectedUser.Id})
             INSERT INTO RoleMembers (RoleId, UserId) VALUES (${adminRoleId}, ${selectedUser.Id})`
        );

        console.log(`  ${selectedUser.Email} is now an administrator.`);
        console.log('  Note: changes take effect on the next login.\n');
      } else {
        console.log('');
      }
    }

    rl.close();

  } catch (err) {
    logError(`  Error: ${err?.message || err?.originalError?.message || JSON.stringify(err)}\n`);
  } finally {
    await pool.close();
  }
}

main().catch(err => {
  logError(`  Unexpected error: ${err?.message || err?.originalError?.message || JSON.stringify(err)}`);
  process.exit(1);
});
