@echo off
:: change-port.bat — Change the port Primentra listens on
:: Run as Administrator from the Primentra install folder
::
:: Usage: scripts\change-port.bat 3002

setlocal

set "NSSM=%~dp0..\nssm.exe"
set "NEW_PORT=%~1"

if "%NEW_PORT%"=="" (
  echo Usage: change-port.bat [port]
  echo Example: change-port.bat 3002
  exit /b 1
)

echo Stopping Primentra service...
"%NSSM%" stop Primentra

echo Updating port to %NEW_PORT%...
"%NSSM%" set Primentra AppEnvironmentExtra "PORT=%NEW_PORT%"
reg add "HKLM\SOFTWARE\Primentra" /v Port /t REG_SZ /d "%NEW_PORT%" /f >nul

echo Starting Primentra service...
"%NSSM%" start Primentra

echo Done. Primentra is now listening on port %NEW_PORT%.
echo Users can access it at: http://YOUR-SERVER-IP:%NEW_PORT%
endlocal
