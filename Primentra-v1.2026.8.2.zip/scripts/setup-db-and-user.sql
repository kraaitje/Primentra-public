-- ============================================
-- Primentra — Create Service Account
-- ============================================
-- Run this script as a sysadmin (sa) on the SQL Server instance.
-- It creates the Primentra database, a dedicated login/user,
-- and grants the minimal permissions needed by the application.
--
-- IMPORTANT: Change the password below before running!
--
-- DATABASE NAME: this script creates the database, so the name is written out here.
-- To install under a different name, change every "Primentra" occurrence below and enter
-- that same name during setup. setup-database.sql needs no change — it deploys into
-- whichever database the connection points at.
-- ============================================

-- ============================================
-- PRE-FLIGHT CHECK: Ensure password has been changed
-- ============================================
-- IMPORTANT: Uncomment the block below after changing the password above.
-- This script will not run until the default password is changed.

-- 1. Create database if not exists
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'Primentra')
BEGIN
    CREATE DATABASE Primentra;
    PRINT 'Database [Primentra] created.';
END
ELSE
    PRINT 'Database [Primentra] already exists.';
GO

-- 2. Create login (server-level) if not exists
IF NOT EXISTS (SELECT name FROM sys.server_principals WHERE name = 'primentra_svc')
BEGIN
    CREATE LOGIN primentra_svc WITH PASSWORD = 'CHANGE_THIS_PASSWORD', DEFAULT_DATABASE = Primentra;
    PRINT 'Login [primentra_svc] created.';
END
ELSE
    PRINT 'Login [primentra_svc] already exists.';
GO

USE Primentra;
GO

-- 3. Create database user if not exists
IF NOT EXISTS (SELECT name FROM sys.database_principals WHERE name = 'primentra_svc')
BEGIN
    CREATE USER primentra_svc FOR LOGIN primentra_svc;
    PRINT 'User [primentra_svc] created in [Primentra].';
END
ELSE
    PRINT 'User [primentra_svc] already exists in [Primentra].';
GO

-- 4. Create application role
IF NOT EXISTS (SELECT name FROM sys.database_principals WHERE name = 'primentra_app' AND type = 'R')
BEGIN
    CREATE ROLE primentra_app;
    PRINT 'Role [primentra_app] created.';
END
ELSE
    PRINT 'Role [primentra_app] already exists.';
GO

-- 5. Add user to role
ALTER ROLE primentra_app ADD MEMBER primentra_svc;
PRINT 'User [primentra_svc] added to role [primentra_app].';
GO

-- ============================================
-- 6. Grant permissions
-- ============================================

-- CRUD on all tables (SELECT, INSERT, UPDATE, DELETE)
GRANT SELECT, INSERT, UPDATE, DELETE ON SCHEMA::dbo TO primentra_app;

-- Execute stored procedures
GRANT EXECUTE ON SCHEMA::dbo TO primentra_app;

-- REFERENCES — needed for FOREIGN KEY constraints during schema setup
GRANT REFERENCES ON SCHEMA::dbo TO primentra_app;

-- CREATE/DROP TABLE — needed for staging tables during import
GRANT CREATE TABLE TO primentra_app;
GRANT ALTER ON SCHEMA::dbo TO primentra_app;

-- CREATE PROCEDURE + VIEW + FUNCTION — needed for setup and integration views
GRANT CREATE PROCEDURE TO primentra_app;
GRANT CREATE VIEW TO primentra_app;
GRANT CREATE FUNCTION TO primentra_app;

-- CREATE SCHEMA — needed for initial [mdm] schema creation during setup
GRANT CREATE SCHEMA TO primentra_app;

-- mdm schema permissions — integration views are deployed to [mdm] schema
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'mdm')
    EXEC('CREATE SCHEMA [mdm]');
GRANT SELECT, INSERT, UPDATE, DELETE ON SCHEMA::mdm TO primentra_app;
GRANT REFERENCES ON SCHEMA::mdm TO primentra_app;
GRANT ALTER ON SCHEMA::mdm TO primentra_app;

-- Full-Text Search — needed for FTS catalog + index creation (optional feature)
-- db_ddladmin role grants CREATE FULLTEXT CATALOG permission
ALTER ROLE db_ddladmin ADD MEMBER primentra_app;

PRINT 'Permissions granted to [primentra_app]:';
PRINT '  - SELECT, INSERT, UPDATE, DELETE on dbo + mdm schema';
PRINT '  - EXECUTE on dbo schema (stored procedures)';
PRINT '  - REFERENCES on dbo + mdm schema (foreign key constraints)';
PRINT '  - CREATE TABLE + ALTER on dbo schema (staging tables)';
PRINT '  - CREATE PROCEDURE + CREATE VIEW + CREATE FUNCTION (setup + integration views)';
PRINT '  - CREATE SCHEMA (initial mdm schema creation)';
PRINT '  - ALTER on mdm schema (deploy integration views)';
PRINT '  - db_ddladmin role (Full-Text Search catalog + indexes)';
GO

-- ============================================
-- Summary
-- ============================================
PRINT '';
PRINT '============================================';
PRINT ' Setup complete!';
PRINT '============================================';
PRINT ' Login:    primentra_svc';
PRINT ' Database: Primentra';
PRINT ' Role:     primentra_app';
PRINT '';
PRINT ' Connection settings for Primentra app:';
PRINT '   Username: primentra_svc';
PRINT '   Password: (as configured above)';
PRINT '   Database: Primentra';
PRINT '';
PRINT ' IMPORTANT: You MUST change the password above before running this script!';
PRINT '============================================';
GO
