import express from 'express';
import helmet from 'helmet';
import { rateLimit } from 'express-rate-limit';
import sql from 'mssql';
import cors from 'cors';
import compression from 'compression';
import crypto from 'crypto';
import { existsSync, readFileSync as readFS, writeFileSync as writeFS, appendFileSync, unlinkSync, mkdirSync } from 'fs';
import { dirname, join as pathJoin } from 'path';
import { fileURLToPath } from 'url';
import { execFileSync, execFile } from 'child_process';
import { promisify } from 'util';
// execFile (not exec) — arguments are passed as an array and never reach a shell,
// so config-supplied values like the SQL instance name cannot inject commands.
const execFileAsync = promisify(execFile);
import { readConfig, writeConfig, CONFIG_PATH, DEFAULTS } from './server/config.js';
import { splitBatches, selectUpgradeBatches, isSkippableFtsFailure, describeBatch } from './server/schemaUpgrade.js';

// Route imports
import modelsRouter from './server/routes/models.js';
import entitiesRouter from './server/routes/entities.js';
import dataRouter from './server/routes/data.js';
import rolesRouter from './server/routes/roles.js';
import auditRouter from './server/routes/audit.js';
import importRouter from './server/routes/import.js';
import settingsRouter from './server/routes/settings.js';
import integrationViewsRouter from './server/routes/integrationViews.js';
import usersRouter from './server/routes/users.js';
import favoritesRouter from './server/routes/favorites.js';
import hiddenEntitiesRouter from './server/routes/hiddenEntities.js';
import authRouter from './server/routes/auth.js';
import emailRouter from './server/routes/email.js';
import approvalRouter from './server/routes/approvals.js';
import { sendLicenseExpiryWarning } from './server/email.js';
import errorlogRouter from './server/routes/errorlog.js';
import stagingRouter from './server/routes/staging.js';
import modelExportRouter from './server/routes/modelExport.js';
import apiKeysRouter from './server/routes/apiKeys.js';
import v1Router from './server/routes/v1.js';
import { authMiddleware, PUBLIC_PATHS } from './server/middleware/authMiddleware.js';
import { errorHandler } from './server/middleware/errorHandler.js';
import logger, { setDbWriter, setSettingsLoader, slowRequestMiddleware } from './server/logger.js';
import { execute as dbExecute, sql as dbSql, buildSqlConfig, hasInstanceAndPort } from './server/db.js';
import { checkTrialStatus, activateTrial, writeTrialRecord, getTrialRecord, markUpgraded, getMachineId } from './server/trial.js';
import { clientKey } from './server/utils/clientKey.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

// Central app version — must match APP_VERSION in data/version.js
const APP_VERSION = "1.2026.8.2";

// ─── Windows Event Log ──────────────────────────────────────────────────────
// Writes to the Windows Application Event Log so admins can diagnose service
// issues via Event Viewer without needing access to text log files.
// Event IDs:
//   100 = Service starting        101 = Service started
//   200 = Startup error           201 = Uncaught exception
//   202 = Unhandled rejection     203 = Server listen error
//   300 = Repeated crash detected

function writeEventLog(type, id, message) {
  if (process.platform !== 'win32') return;
  try {
    const safe = message.replace(/"/g, "'").replace(/\r?\n/g, ' ').slice(0, 1500);
    execFileSync('eventcreate', [
      '/L', 'Application', '/T', type, '/SO', 'Primentra', '/ID', String(id), '/D', safe,
    ], { stdio: 'ignore', timeout: 5000 });
  } catch { /* Event log write failure should never block the server */ }
}

// Log startup attempt to Event Log immediately (before anything that could fail)
writeEventLog('INFORMATION', 100,
  `Primentra v${APP_VERSION} starting — Node.js ${process.version}, PID ${process.pid}, ` +
  `cwd: ${process.cwd()}, script: ${import.meta.url}`);

// ─── Ensure logs directory exists ─────────────────────────────────────────────
const LOGS_DIR = pathJoin(__dirname, 'logs');
try { mkdirSync(LOGS_DIR, { recursive: true }); } catch { /* ignore */ }

// ─── Crash detection ─────────────────────────────────────────────────────────
// NSSM will restart the process on crash. If the server crashes repeatedly,
// write a clear Event Log entry so the admin knows to check errorlog.txt
// instead of silently retrying forever.
const CRASH_MARKER = pathJoin(LOGS_DIR, '.crash-count');
let crashCount = 0;
try {
  if (existsSync(CRASH_MARKER)) {
    const data = JSON.parse(readFS(CRASH_MARKER, 'utf-8'));
    // Only count crashes within the last 5 minutes as a rapid-crash sequence
    if (Date.now() - data.lastCrash < 5 * 60 * 1000) {
      crashCount = data.count;
    }
  }
} catch { /* ignore corrupt marker */ }

function recordCrash() {
  try {
    crashCount++;
    writeFS(CRASH_MARKER, JSON.stringify({ count: crashCount, lastCrash: Date.now() }), 'utf-8');
  } catch { /* ignore */ }
}

function clearCrashCount() {
  try { if (existsSync(CRASH_MARKER)) unlinkSync(CRASH_MARKER); } catch { /* ignore */ }
}

// Write crash errors to errorlog.txt so they're visible when running as a Windows Service
// (stdout/stderr may not be captured if the service manager isn't logging yet)
function writeCrashLog(label, err) {
  try {
    const line = `[${new Date().toISOString()}] ${label}: ${err?.stack || err}\n`;
    appendFileSync(pathJoin(LOGS_DIR, 'errorlog.txt'), line, 'utf-8');
  } catch { /* if we can't write the log, there's nothing we can do */ }
}

// Max rapid crashes before the service gives up and stays stopped.
// NSSM is configured with AppExit 0 = Exit, so exiting with code 0
// tells NSSM to stop the service instead of restarting it.
const MAX_RAPID_CRASHES = 5;

function handleFatalError(label, err) {
  writeCrashLog(label, err);
  recordCrash();

  const eventType = label === 'UNCAUGHT EXCEPTION' ? 201 : 202;
  writeEventLog('ERROR', eventType,
    `[v${APP_VERSION}] ${label}: ${err?.message || err}. Check logs\\errorlog.txt for the full stack trace.`);

  if (crashCount >= MAX_RAPID_CRASHES) {
    const msg = `Primentra v${APP_VERSION} has crashed ${crashCount} times in the last 5 minutes. ` +
      `The service will now stop to prevent an infinite restart loop. ` +
      `Last error: ${err?.message || err}. ` +
      `Fix the issue, then restart the service manually (net start Primentra). ` +
      `Full details in logs\\errorlog.txt in the install folder.`;
    writeCrashLog('SERVICE STOPPED — TOO MANY CRASHES', new Error(msg));
    writeEventLog('ERROR', 300, msg);
    process.exit(0); // Exit 0 = NSSM stops the service (no restart)
  }

  process.exit(1); // Exit non-zero = NSSM will restart
}

process.on('uncaughtException', (err) => handleFatalError('UNCAUGHT EXCEPTION', err));
process.on('unhandledRejection', (reason) => {
  handleFatalError('UNHANDLED REJECTION', reason instanceof Error ? reason : new Error(String(reason)));
});

// Ed25519 PUBLIC key. Verification only — signing requires the private key, which
// never ships with the application, so possession of this source does not allow
// anyone to mint a license. Generated by: node scripts/generate-license.js public-key
const LICENSE_PUBLIC_KEY = crypto.createPublicKey(`-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEA1sZWCc1CSqiYl9WX5O6aeobKKfUzU/2IXZg2HdVtH5E=
-----END PUBLIC KEY-----`);
const LICENSE_EPOCH = new Date('2024-01-01').getTime();

// License key layout: 4-byte payload + 64-byte Ed25519 signature = 68 bytes,
// base36-encoded to a fixed 110 chars and grouped as PRIM- plus 22 blocks of 5.
// An Ed25519 signature cannot be truncated, so the key is long by necessity —
// it is meant to be pasted, never typed.
const LICENSE_PAYLOAD_BYTES = 4;
const LICENSE_KEY_BYTES = 68;
const LICENSE_KEY_CHARS = 110;

const B36 = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
function base36ToBytes(str, byteLen) {
  let n = 0n;
  for (const ch of str) { const i = B36.indexOf(ch.toUpperCase()); if (i < 0) throw new Error('Invalid char'); n = n * 36n + BigInt(i); }
  const buf = Buffer.alloc(byteLen);
  for (let i = byteLen - 1; i >= 0; i--) { buf[i] = Number(n & 0xFFn); n >>= 8n; }
  return buf;
}

function decodeLicense(key, org) {
  try {
    if (!org) return { valid: false, message: 'Organization name is required' };
    const raw = key.replace(/^PRIM-/i, '').replace(/-/g, '').toUpperCase();
    if (raw.length !== LICENSE_KEY_CHARS) return { valid: false, message: 'Invalid license key format' };
    const combined = base36ToBytes(raw, LICENSE_KEY_BYTES);
    const payload = combined.subarray(0, LICENSE_PAYLOAD_BYTES);
    const sig = combined.subarray(LICENSE_PAYLOAD_BYTES);
    // Signature covers payload + org name, so a key issued to one organisation
    // does not validate under another.
    const signedMessage = Buffer.concat([payload, Buffer.from(org, 'utf-8')]);
    if (!crypto.verify(null, signedMessage, LICENSE_PUBLIC_KEY, sig)) return { valid: false, message: 'Invalid license key' };
    const startDays = payload.readUInt16BE(0);
    const duration = payload.readUInt16BE(2);
    const issuedDate = new Date(LICENSE_EPOCH + startDays * 24 * 60 * 60 * 1000);
    const expiryDate = new Date(issuedDate.getTime() + duration * 24 * 60 * 60 * 1000);
    const now = new Date();
    const daysLeft = Math.ceil((expiryDate - now) / (1000 * 60 * 60 * 24));
    return {
      valid: now <= expiryDate,
      org,
      issued: issuedDate.toISOString().slice(0, 10),
      expiry: expiryDate.toISOString().slice(0, 10),
      daysLeft: Math.max(0, daysLeft),
      trial: false,
    };
  } catch {
    return { valid: false, message: 'Invalid license key format' };
  }
}

// Ensure config file exists on startup
if (!existsSync(CONFIG_PATH)) {
  writeConfig(DEFAULTS);
  console.log(`Created config file: ${CONFIG_PATH}`);
}

const app = express();

// Security headers. The CSP is deliberately narrow but must allow inline styles: the whole
// UI is built with inline style objects (no stylesheet), so 'unsafe-inline' for styles is
// load-bearing here — removing it renders the application unusable.
// HSTS is off: on-prem installs are commonly served over plain HTTP on an internal network,
// and sending HSTS there would lock browsers out of the very host they need to reach.
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'blob:'],
      fontSrc: ["'self'", 'data:'],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],   // clickjacking
      baseUri: ["'self'"],
      formAction: ["'self'"],
      upgradeInsecureRequests: null, // would break plain-HTTP on-prem installs
    },
  },
  hsts: false,
  crossOriginEmbedderPolicy: false, // not needed, and blocks legitimate asset loading
}));

app.use(compression());

// Host headers are case-insensitive and a trailing root dot ('server.') addresses the same
// machine, so both are normalised away before any comparison — otherwise 'SERVER.' and
// 'server' would read as different hosts.
function normalizeHost(hostHeader) {
  return String(hostHeader || '').toLowerCase().replace(/\.(?=:|$)/, '');
}

// Whether a Host header could only have come from inside the network. This is what keeps the
// same-origin rule below from becoming a DNS-rebinding hole: a page that rebinds its own
// domain onto an internal address still reports that domain in Host, and a domain anyone can
// register necessarily contains a dot. Loopback, a bare IP address and a single-label
// intranet name cannot be obtained that way. A dotted name is trusted only by being named in
// appBaseUrl, which is the setting that exists for exactly that case.
function isSelfAddressableHost(hostHeader) {
  const host = normalizeHost(hostHeader).replace(/:\d+$/, '');
  if (!host) return false;
  if (host.startsWith('[')) return true;                  // IPv6 literal, e.g. [::1]
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) return true;  // IPv4 literal
  return !host.includes('.');                             // localhost, or an intranet name
}

// CORS: allow the configured app origin (or localhost dev ports) only.
// In production, appBaseUrl should be set in mds-config.json.
app.use(cors((req, callback) => {
  const origin = req.headers.origin;
  const options = { origin: true, credentials: true };

  // Non-browser requests (curl, server-to-server) have no origin — allow them.
  if (!origin) return callback(null, options);

  // Same-origin requests. Browsers send Origin on every POST/PUT/DELETE, including ones
  // the page makes to its own host, and on the crossorigin script/link tags the build
  // emits, so this branch is what a normal install runs on: the built frontend is served
  // by this same Express process, and in dev the Vite proxy forwards the browser's Host
  // untouched. No allow-list can enumerate every address (LAN IP, machine name) a server
  // is reached by, so the Host the request arrived on is what it is compared against.
  // Only the host is compared, not the scheme: behind a TLS-terminating IIS the browser's
  // origin is https while the proxied request reaches Express over plain http.
  try {
    if (isSelfAddressableHost(req.headers.host) &&
        normalizeHost(new URL(origin).host) === normalizeHost(req.headers.host)) {
      return callback(null, options);
    }
  } catch { /* malformed Origin header — fall through to the allow-list */ }

  const config = readConfig();
  const allowed = new Set();

  // Configured production URL
  if (config.appBaseUrl) allowed.add(config.appBaseUrl.replace(/\/$/, ''));

  // Always allow common local development origins
  for (const port of [5173, 5174, 5175, 5176, 3001]) {
    allowed.add(`http://localhost:${port}`);
    allowed.add(`http://127.0.0.1:${port}`);
  }

  // An isolated E2E stack may run on any free port so that several can run side by side.
  // Opt-in via env var, exactly like E2E_DISABLE_RATE_LIMIT — production never sets it.
  if (process.env.E2E_WEB_ORIGIN) {
    allowed.add(process.env.E2E_WEB_ORIGIN.replace(/\/$/, ''));
  }

  if (allowed.has(origin.replace(/\/$/, ''))) return callback(null, options);

  // Reject anything else in production; allow all in development for convenience
  if (process.env.NODE_ENV === 'development') return callback(null, options);
  // Behind a reverse proxy this is the first thing an administrator hits, and the cause is never
  // guessable from a generic 500 — so say what is wrong and what to change. 403 (not 500) makes
  // the errorHandler pass this message through to the browser instead of swallowing it.
  // "restart if it runs as a service": under iisnode there is no service to restart, and the
  // config is re-read per request, so telling every administrator to restart one is wrong.
  const corsError = new Error(
    `This address is not configured. Primentra received a request from '${origin}', which is not ` +
    `its configured address. Set "appBaseUrl" to '${origin}' in mds-config.json — then restart ` +
    `the Primentra service if you run it as one (not needed under IIS/iisnode).`
  );
  corsError.status = 403;
  return callback(corsError);
}));

// ── Guards for the endpoints reachable without signing in ────────────────────
// The 50 MB body limit below exists for imports, which are all authenticated. Public
// endpoints send small JSON, so cap them before the parser buffers anything, and throttle
// them so an anonymous caller cannot hammer routes that hit the database or shell out.
function isPublicApiPath(path) {
  return PUBLIC_PATHS.some(p => path === p || path.startsWith(p + '/'));
}

const PUBLIC_BODY_LIMIT_BYTES = 64 * 1024;
app.use((req, res, next) => {
  if (!isPublicApiPath(req.path)) return next();
  if (Number(req.headers['content-length'] || 0) > PUBLIC_BODY_LIMIT_BYTES) {
    return res.status(413).json({ success: false, message: 'Request body too large.' });
  }
  next();
});

// E2E_DISABLE_RATE_LIMIT=1 also lifts this limiter, for the same reason the auth-route
// limiters honour it (see server/routes/auth.js): a serial E2E suite authenticates dozens of
// times per run and would otherwise saturate it. Opt-in via env var — production is unchanged.
const publicEndpointLimiter = process.env.E2E_DISABLE_RATE_LIMIT === '1'
  ? (req, res, next) => next()
  : rateLimit({
      windowMs: 15 * 60 * 1000,
      max: 200,
      standardHeaders: true,
      legacyHeaders: false,
      keyGenerator: clientKey,
      message: { success: false, message: 'Too many requests. Please wait before trying again.' },
    });
app.use((req, res, next) => (isPublicApiPath(req.path) ? publicEndpointLimiter(req, res, next) : next()));

app.use(express.json({ limit: '50mb' }));

// ==========================================
// Config/License endpoints (file-based, no DB needed)
// ==========================================

// GET /api/settings — unauthenticated callers receive only public (non-sensitive) fields
app.get('/api/settings', async (req, res) => {
  const config = readConfig();
  if (config.licenseKey && config.licenseOrg) {
    const info = decodeLicense(config.licenseKey, config.licenseOrg);
    if (info.valid !== undefined) {
      config.licenseValid = info.valid;
      config.licenseExpiry = info.expiry || config.licenseExpiry;
      writeConfig(config);
    }
  }

  // Enrich with live trial data when in trial mode
  if (config.licenseTrial && !config.licenseKey) {
    try {
      let pool = null;
      try {
        const { getPool } = await import('./server/db.js');
        pool = await getPool();
      } catch { /* DB not connected */ }
      const trialStatus = await checkTrialStatus(pool);
      config.trialDaysLeft = trialStatus.daysLeft;
      config.trialStatus = trialStatus.status;
      config.trialStart = trialStatus.trialStart;
      if (trialStatus.status === 'expired') {
        config.licenseValid = false;
        writeConfig(config);
      }
    } catch { /* non-critical */ }
  }

  // Strip credentials from the response for unauthenticated callers.
  // Authenticated admins receive the full config (needed by GeneralSettings panel).
  const auth = req.headers.authorization;
  let authenticated = false;
  if (auth && auth.startsWith('Bearer ')) {
    try {
      const { sessions } = await import('./server/routes/auth.js');
      const token = auth.slice(7);
      const session = sessions.get(token);
      authenticated = !!(session && session.expiresAt > Date.now() && session.isAdministrator);
    } catch { /* fall through — treat as unauthenticated */ }
  }
  if (process.env.NODE_ENV === 'development') authenticated = true;

  if (!authenticated) {
    // Return only the public subset needed for the license banner and first-run detection.
    // Deliberately excluded:
    //   licenseKey       — the key itself is the licence; anyone who reads it can activate
    //                      their own install, and licenseOrg (which the signature binds to)
    //                      would be the other half. hasLicenseKey answers the only question
    //                      the banner actually asks: is a licence present?
    //   hostname/instance — names the internal SQL Server. The status bar gets these from the
    //                      authenticated settings call instead.
    const { licenseOrg, licenseIssued, licenseExpiry, licenseValid,
            licenseTrial, trialDaysLeft, trialStatus, trialStart,
            appBaseUrl, theme } = config;
    return res.json({ hasLicenseKey: !!config.licenseKey,
                      licenseOrg, licenseIssued, licenseExpiry, licenseValid,
                      licenseTrial, trialDaysLeft, trialStatus, trialStart,
                      appBaseUrl, theme });
  }

  res.json(config);
});

// POST /api/settings — write access requires administrator authentication
// Exception: allowed without auth when database is not yet configured (first-run setup wizard)
app.post('/api/settings', async (req, res) => {
  if (process.env.NODE_ENV !== 'development') {
    const config = readConfig();
    const dbConfigured = !!(config.hostname && config.database && config.username);

    // Allow unauthenticated access only when database isn't configured yet (first-run)
    // Once the DB is configured, admin auth is required for all changes.
    let authenticated = !dbConfigured;
    if (!authenticated) {
      const auth = req.headers.authorization;
      if (auth && auth.startsWith('Bearer ')) {
        try {
          const { sessions } = await import('./server/routes/auth.js');
          const token = auth.slice(7);
          const session = sessions.get(token);
          authenticated = !!(session && session.expiresAt > Date.now() && session.isAdministrator);
        } catch { /* fall through */ }
      }
    }
    if (!authenticated) {
      logger.warn('Settings save rejected: unauthenticated request', { path: '/api/settings', category: 'auth' });
      return res.status(401).json({ success: false, message: 'Administrator authentication required.' });
    }
  }

  try {
    const data = { ...req.body };
    if (data.licenseKey === '') {
      data.licenseOrg = '';
      data.licenseIssued = '';
      data.licenseExpiry = '';
      data.licenseValid = false;
      data.licenseTrial = false;
    } else if (data.licenseOrg !== undefined) {
      // Trial status is a property of the license, never client input. A settings form
      // loaded while a trial was running still holds licenseTrial: true, and saving it
      // would label a real license as a trial.
      // Only derived when the caller actually sends the organisation: the setup wizard posts
      // just the database fields, and deriving from an absent value resolved to false and
      // cleared a running trial.
      data.licenseTrial = data.licenseOrg === 'Trial License';
    }
    const saved = writeConfig(data);
    res.json({ success: true, settings: saved });
  } catch (err) {
    logger.error('Settings save failed', { error: err.message, category: 'settings' });
    res.status(500).json({ success: false, message: err.message });
  }
});

// Validate license key (requires admin auth when DB is configured)
app.post('/api/validate-license', async (req, res) => {
  if (process.env.NODE_ENV !== 'development') {
    const cfg = readConfig();
    const dbConfigured = !!(cfg.hostname && cfg.database && cfg.username);
    if (dbConfigured) {
      let authenticated = false;
      const auth = req.headers.authorization;
      if (auth && auth.startsWith('Bearer ')) {
        try {
          const { sessions } = await import('./server/routes/auth.js');
          const session = sessions.get(auth.slice(7));
          authenticated = !!(session && session.expiresAt > Date.now() && session.isAdministrator);
        } catch { /* fall through */ }
      }
      if (!authenticated) {
        logger.warn('License validation rejected: unauthenticated request', { path: '/api/validate-license', category: 'auth' });
        return res.status(401).json({ valid: false, message: 'Administrator authentication required.' });
      }
    }
  }

  const { key, org } = req.body;
  if (!key) return res.json({ valid: false, message: 'License key is required' });
  if (!org) return res.json({ valid: false, message: 'Organization name is required' });

  const info = decodeLicense(key, org);
  if (!info.valid && info.message) {
    return res.json(info);
  }

  // Save to config
  const config = readConfig();
  config.licenseKey = key;
  config.licenseOrg = info.org;
  config.licenseIssued = info.issued;
  config.licenseExpiry = info.expiry;
  config.licenseValid = info.valid;
  config.licenseTrial = info.org === 'Trial License';
  writeConfig(config);

  // Mark trial as upgraded when a paid license is applied
  if (info.valid && info.org !== 'Trial License') {
    try {
      let pool = null;
      try {
        const { getPool } = await import('./server/db.js');
        pool = await getPool();
      } catch { /* ignore */ }
      if (pool) await markUpgraded(pool, info.org);
    } catch { /* non-critical */ }
  }

  res.json({
    ...info,
    trial: info.org === 'Trial License',
    message: info.valid
      ? `License valid — ${info.org} (${info.daysLeft} days remaining)`
      : `License expired on ${info.expiry}`,
  });
});

// Trial status check
app.get('/api/trial-status', async (req, res) => {
  try {
    let pool = null;
    try {
      const { getPool } = await import('./server/db.js');
      pool = await getPool();
    } catch { /* DB not connected — check other layers */ }

    const status = await checkTrialStatus(pool);
    res.json(status);
  } catch (err) {
    logger.error('Trial status check failed', { error: err.message, category: 'trial' });
    res.json({ status: 'error', message: err.message });
  }
});

// Activate trial (manual trigger / backup)
app.post('/api/activate-trial', async (req, res) => {
  try {
    let pool = null;
    try {
      const { getPool } = await import('./server/db.js');
      pool = await getPool();
    } catch { /* DB not connected */ }

    const existing = await checkTrialStatus(pool);
    if (existing.status === 'expired') {
      return res.json({ success: false, reason: 'expired', message: 'Trial period has ended. Please purchase a license.' });
    }
    if (existing.status === 'active') {
      return res.json({ success: true, alreadyActivated: true, ...existing });
    }

    const result = await activateTrial(pool);

    // Update config file
    const config = readConfig();
    config.licenseTrial = true;
    config.licenseOrg = 'Trial License';
    config.licenseIssued = result.trialStart;
    config.licenseValid = true;
    config.trialDaysLeft = 60;
    writeConfig(config);

    res.json({ success: true, alreadyActivated: false, trialStart: result.trialStart, daysLeft: 60 });
  } catch (err) {
    logger.error('Trial activation failed', { error: err.message, category: 'trial' });
    res.json({ success: false, message: err.message });
  }
});

// Build mssql config from settings. buildSqlConfig lives in server/db.js so this route and the
// pool the application runs on cannot drift apart; only the request timeout differs (a test
// should fail fast, a real query may take minutes).
function buildOneOffSqlConfig(settings) {
  return buildSqlConfig(settings, { requestTimeout: 10000 });
}

// Instance + port together is the most common first attempt for a named instance. It used to fail
// with no hint; buildSqlConfig now connects on the port and drops the instance name, so say so —
// otherwise a typo'd port silently looks like "the instance name is wrong".
const INSTANCE_AND_PORT_NOTE = 'Instance and Port were both filled in: the port is used and the instance name is ignored (a port addresses the instance directly).';

// Connecting to a caller-supplied host is a probe primitive: without a limit this endpoint
// can be used to sweep the internal network from the server's own network position.
const testConnectionLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: clientKey,
  message: { success: false, message: 'Too many connection tests. Please wait before trying again.' },
});

// Test database connection
app.post('/api/test-connection', testConnectionLimiter, async (req, res) => {
  // Open before the database is configured (the setup wizard needs it), administrator-only
  // afterwards. forceSetupScreen re-opens it for recovery when the stored connection is
  // broken and nobody can sign in to fix it.
  if (process.env.NODE_ENV !== 'development') {
    const config = readConfig();
    const dbConfigured = !!(config.hostname && config.database && config.username);
    let authenticated = !dbConfigured || !!config.forceSetupScreen;
    if (!authenticated) {
      const auth = req.headers.authorization;
      if (auth && auth.startsWith('Bearer ')) {
        try {
          const { sessions } = await import('./server/routes/auth.js');
          const session = sessions.get(auth.slice(7));
          authenticated = !!(session && session.expiresAt > Date.now() && session.isAdministrator);
        } catch { /* fall through */ }
      }
    }
    if (!authenticated) {
      logger.warn('Test-connection rejected: unauthenticated request', { path: '/api/test-connection', category: 'auth' });
      return res.status(401).json({ success: false, message: 'Administrator authentication required.' });
    }
  }

  // Connection details must be supplied explicitly. The old fallback to the stored config
  // let an anonymous caller learn the server name, version and database of the live install.
  const settings = req.body || {};
  if (!settings.hostname || !settings.database || !settings.username) {
    return res.json({ success: false, message: 'Hostname, database and username are required.' });
  }

  // A dedicated pool, not the global sql.connect(): that returns whatever global pool already
  // exists and ignores this config, so the test reported the existing connection instead of
  // the requested one — and closing it tore down the connection the app itself was using.
  const pool = new sql.ConnectionPool(buildOneOffSqlConfig(settings));
  const note = hasInstanceAndPort(settings) ? ` ${INSTANCE_AND_PORT_NOTE}` : '';
  try {
    await pool.connect();
    const result = await pool.request().query('SELECT @@VERSION AS version, @@SERVERNAME AS serverName, DB_NAME() AS databaseName');
    const row = result.recordset[0];

    res.json({
      success: true,
      message: `Connected to ${row.serverName} — ${row.databaseName}.${note}`,
      serverVersion: row.version.split('\n')[0],
      serverName: row.serverName,
      databaseName: row.databaseName,
    });
  } catch (err) {
    writeCrashLog('TEST-CONNECTION', err);
    logger.error('Test connection failed', { error: err.message, code: err.code, category: 'database' });
    // Driver errors distinguish "refused" from "timeout" from "login failed", which turns this
    // into a port scanner. The detail stays in the log; the caller gets one generic message.
    res.json({ success: false, message: `Could not connect with these settings. See logs/errorlog.txt for details.${note}` });
  } finally {
    try { await pool.close(); } catch { /* ignore */ }
  }
});

// ==========================================
// Auth routes (public — no middleware needed)
// ==========================================
app.use('/api/auth', authRouter);

// Auth middleware — protects all routes below this line
app.use(authMiddleware);

// Slow request detection (writes to error log when threshold exceeded)
app.use(slowRequestMiddleware);

// ==========================================
// Database-backed API routes
// ==========================================
app.use('/api/models', modelsRouter);
app.use('/api/entities', entitiesRouter);
app.use('/api/data', dataRouter);
app.use('/api/roles', rolesRouter);
app.use('/api/audit-log', auditRouter);
app.use('/api/import', importRouter);
app.use('/api/db-settings', settingsRouter);
app.use('/api/integration-views', integrationViewsRouter);
app.use('/api/users', usersRouter);
app.use('/api/favorites', favoritesRouter);
app.use('/api/hidden-entities', hiddenEntitiesRouter);
app.use('/api/error-log', errorlogRouter);
app.use('/api/email', emailRouter);
app.use('/api/approvals', approvalRouter);
app.use('/api/staging', stagingRouter);
app.use('/api/model-export', modelExportRouter);
app.use("/api", apiKeysRouter);
app.use('/api/v1', v1Router);

// Database health check
app.get('/api/health', async (req, res) => {
  try {
    const { getPool } = await import('./server/db.js');
    const pool = await getPool();
    await pool.request().query('SELECT 1');

    // Check if core tables exist
    const tables = await pool.request().query(
      "SELECT COUNT(*) AS cnt FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME IN ('Models','Entities','Attributes','EntityRows','EntityValues','Roles','Permissions','AuditLog','Users')"
    );
    const tablesExist = tables.recordset[0].cnt >= 9;

    // Check schema version
    let schemaVersion = null;
    try {
      const sv = await pool.request().query("SELECT TOP 1 Version FROM SchemaVersion");
      schemaVersion = sv.recordset[0]?.Version || null;
    } catch { /* SchemaVersion table doesn't exist yet */ }

    // Check Full-Text Search status: 1) feature installed, 2) indexes exist, 3) service running (CONTAINS), 4) Windows service
    let ftsInstalled = false;
    let ftsServiceRunning = false;
    let ftsWindowsService = false;
    let fullTextSearch = false;
    let ftsIndexCount = 0;
    if (tablesExist) {
      try {
        // Step 1: Is the FTS feature installed?
        const ftsCheck = await pool.request().query("SELECT FULLTEXTSERVICEPROPERTY('IsFullTextInstalled') AS FtsInstalled");
        ftsInstalled = ftsCheck.recordset[0]?.FtsInstalled === 1;
        if (ftsInstalled) {
          // Step 2: Do the FTS indexes exist?
          const ftsIdx = await pool.request().query("SELECT COUNT(*) AS cnt FROM sys.fulltext_indexes WHERE object_id IN (OBJECT_ID('EntityRows'), OBJECT_ID('EntityValues'))");
          ftsIndexCount = ftsIdx.recordset[0]?.cnt || 0;

          // Step 3: Is the FTS daemon service actually running? (try a real CONTAINS query)
          if (ftsIndexCount >= 2) {
            try {
              await pool.request().query("SELECT TOP 0 Id FROM EntityRows WHERE CONTAINS(Code, '\"_fts_healthcheck_\"')");
              ftsServiceRunning = true;
            } catch {
              // CONTAINS failed — the Filter Daemon Launcher service is not running
              ftsServiceRunning = false;
            }
          }

          fullTextSearch = ftsServiceRunning && ftsIndexCount >= 2;
        }
      } catch { /* FTS check failed — report as unavailable */ }
    }

    // Step 4: Check Windows service status (independent of SQL checks)
    // Service name: MSSQLFDLauncher (default instance) or MSSQLFDLauncher$INSTANCE (named)
    const config = readConfig();
    const instanceName = config.instance;
    const ftsServiceNames = instanceName
      ? [`MSSQLFDLauncher$${instanceName}`, 'MSSQLFDLauncher']
      : ['MSSQLFDLauncher'];
    for (const svcName of ftsServiceNames) {
      try {
        const { stdout } = await execFileAsync('sc', ['query', svcName]);
        ftsWindowsService = /RUNNING/.test(stdout);
        break; // found the service, stop trying
      } catch { /* service not found, try next */ }
    }

    res.json({
      status: 'ok',
      database: 'connected',
      tablesExist,
      schemaVersion,
      ftsInstalled,
      ftsServiceRunning,
      ftsWindowsService,
      fullTextSearch,
      ftsIndexCount,
      appVersion: APP_VERSION,
    });
  } catch (err) {
    logger.warn('Health check: DB connection failed', { error: err.message, category: 'database' });
    res.json({ status: 'error', database: 'disconnected', message: err.message });
  }
});

// Initialize database schema (run setup script)
// Requires either: (a) an authenticated administrator session, or (b) first-run mode
// (no users exist yet — schema must be set up before accounts can be created).
app.post('/api/setup-database', async (req, res) => {
  if (process.env.NODE_ENV !== 'development') {
    const auth = req.headers.authorization;
    let authenticated = false;
    if (auth && auth.startsWith('Bearer ')) {
      try {
        const { sessions } = await import('./server/routes/auth.js');
        const token = auth.slice(7);
        const session = sessions.get(token);
        authenticated = !!(session && session.expiresAt > Date.now() && session.isAdministrator);
      } catch { /* fall through */ }
    }
    // Unauthenticated access is allowed ONLY when we can positively prove this is a
    // first run: the database is reachable and holds no human accounts yet. Anything
    // we cannot prove — including a database error — is denied, because this endpoint
    // deploys DDL (ALTER TABLE, CREATE/DROP PROCEDURE) against the live database.
    if (!authenticated) {
      let isFirstRun = false;
      try {
        const { getPool } = await import('./server/db.js');
        const pool = await getPool();

        // Query INFORMATION_SCHEMA rather than Users directly: on a genuinely fresh
        // database the Users table does not exist, and a missing-table error must not
        // be indistinguishable from a transient failure.
        const tableRes = await pool.request().query("SELECT COUNT(*) AS cnt FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Users'");
        const usersTableExists = (tableRes.recordset[0]?.cnt || 0) > 0;
        if (!usersTableExists) {
          isFirstRun = true; // no schema at all
        } else {
          const countRes = await pool.request().query("SELECT COUNT(*) AS cnt FROM Users WHERE IsDeleted = 0 AND IsSystem = 0 AND UserType = 'standard'");
          const hasUsers = (countRes.recordset[0]?.cnt || 0) > 0;
          if (!hasUsers) {
            isFirstRun = true; // schema exists but no accounts were ever created
          } else {
            let schemaVersion = null;
            try {
              const sv = await pool.request().query("SELECT TOP 1 Version FROM SchemaVersion");
              schemaVersion = sv.recordset[0]?.Version || null;
            } catch { /* SchemaVersion table may not exist */ }
            if (schemaVersion === APP_VERSION) {
              // Schema is current and users exist — DB is already fully set up.
              // This happens when reinstalling on a new server with an existing database.
              // Skip schema setup and go straight to login.
              return res.json({ success: true, alreadySetup: true, hasUsers: true });
            }
            // Version mismatch (upgrade): accounts exist, so an administrator must sign
            // in before the new schema is deployed.
          }
        }
      } catch (err) {
        // Cannot determine the state of the database — deny rather than assume first run.
        logger.warn('Setup-database state check failed — denying unauthenticated request', { error: err.message, category: 'database' });
      }

      if (!isFirstRun) {
        logger.warn('Setup-database rejected: unauthenticated request', { path: '/api/setup-database', category: 'auth' });
        return res.status(401).json({ success: false, message: 'Administrator authentication required.' });
      }
    }
  }

  const settings = readConfig();
  if (!settings.hostname || !settings.database || !settings.username) {
    return res.json({ success: false, message: 'Database not configured.' });
  }

  let pool;
  try {
    pool = await sql.connect(buildOneOffSqlConfig(settings));

    // Check if tables already exist
    const check = await pool.request().query(
      "SELECT COUNT(*) AS cnt FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME IN ('Models','Entities','Attributes','EntityRows','EntityValues','Roles','Permissions','AuditLog')"
    );

    const alreadySetup = check.recordset[0].cnt >= 8;

    // Read and execute setup script
    // Production: setup-database.sql is in scripts/ next to server.js
    // Development: it's at ../scripts/setup-database.sql
    const { resolve: resolvePath } = await import('path');
    const prodPath = resolvePath(__dirname, 'scripts', 'setup-database.sql');
    const devPath = resolvePath(__dirname, '..', 'scripts', 'setup-database.sql');
    const scriptPath = existsSync(prodPath) ? prodPath : devPath;
    const script = readFS(scriptPath, 'utf-8');

    // Split on GO statements and execute each batch
    const batches = splitBatches(script);

    if (alreadySetup) {
      // Tables exist — only run stored procedure + schema + migration batches (safe to re-run)
      const spBatches = selectUpgradeBatches(batches);
      for (let i = 0; i < spBatches.length; i++) {
        const batch = spBatches[i];
        try {
          await pool.request().query(batch);
        } catch (e) {
          // FTS batches may fail due to permissions — don't block the rest
          if (isSkippableFtsFailure(batch, e.message)) {
            console.log('FTS batch skipped (insufficient permissions):', e.message);
          } else {
            const firstLine = describeBatch(batch, i);
            const detail = `Setup SP batch ${i + 1}/${spBatches.length} failed [${firstLine}]: ${e.message}`;
            writeCrashLog('SETUP-DATABASE', new Error(detail));
            throw new Error(`${e.message}\n\n(SP Batch ${i + 1}: ${firstLine})`);
          }
        }
      }

      // Check FTS status after update
      const ftsCheck = await pool.request().query("SELECT FULLTEXTSERVICEPROPERTY('IsFullTextInstalled') AS FtsInstalled");
      const ftsInstalled = ftsCheck.recordset[0]?.FtsInstalled === 1;
      const ftsIndexCheck = await pool.request().query("SELECT COUNT(*) AS cnt FROM sys.fulltext_indexes WHERE object_id IN (OBJECT_ID('EntityRows'), OBJECT_ID('EntityValues'))");
      const ftsIndexCount = ftsIndexCheck.recordset[0]?.cnt || 0;

      let ftsWarning = null;
      if (!ftsInstalled) {
        ftsWarning = 'Full-Text Search is not installed on this SQL Server instance. Search will use LIKE (slower). Install the "Full-Text and Semantic Extractions for Search" feature via the SQL Server installer, set the Filter Daemon Launcher service to Automatic, then run Setup Database again.';
      } else if (ftsIndexCount < 2) {
        ftsWarning = 'Full-Text Search is installed but the indexes could not be created. Run Setup Database again to retry.';
      }

      // Ensure schema version is up to date
      try {
        await pool.request().query(`IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'SchemaVersion') CREATE TABLE SchemaVersion (Version NVARCHAR(20) NOT NULL, UpdatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE())`);
        const svCount = await pool.request().query("SELECT COUNT(*) AS cnt FROM SchemaVersion");
        if (svCount.recordset[0].cnt === 0) {
          await pool.request().input('v', sql.NVarChar(20), APP_VERSION).query("INSERT INTO SchemaVersion (Version) VALUES (@v)");
        } else {
          await pool.request().input('v', sql.NVarChar(20), APP_VERSION).query("UPDATE SchemaVersion SET Version = @v, UpdatedAt = GETUTCDATE()");
        }
      } catch { /* non-critical */ }

      // Sync trial record to newly available DB
      try {
        const trialRecord = await getTrialRecord(null);
        if (trialRecord && trialRecord.trialStart) {
          await writeTrialRecord(pool, new Date(trialRecord.trialStart));
          console.log('[trial] Synced to database after setup');
        }
      } catch (e) {
        console.log('[trial] DB sync after setup failed (non-critical):', e.message);
      }

      // Check if any real human admin users exist (excludes system + API users)
      let hasUsers = false;
      try {
        const userCheck = await pool.request().query("SELECT COUNT(*) AS cnt FROM Users WHERE IsDeleted = 0 AND IsSystem = 0 AND UserType = 'standard'");
        hasUsers = (userCheck.recordset[0]?.cnt || 0) > 0;
      } catch { /* tables may not exist yet */ }

      res.json({ success: true, message: 'Stored procedures updated.', alreadySetup: true, hasUsers, schemaVersion: APP_VERSION, ftsInstalled, ftsIndexCount, ftsWarning });
    } else {
      // Fresh install — split into phases:
      // Phase 1: DDL (tables, indexes, constraints, SPs) in a transaction → rollback on failure
      // Phase 2: FTS (outside transaction — FTS DDL cannot run inside transactions)
      const ftsBatches = [];
      const ddlBatches = [];
      for (const batch of batches) {
        if (!batch.trim()) continue;
        if (/FULLTEXT/i.test(batch) && (/CREATE\s+FULLTEXT/i.test(batch) || /FULLTEXTSERVICEPROPERTY/i.test(batch))) {
          ftsBatches.push(batch);
        } else {
          ddlBatches.push(batch);
        }
      }

      // Phase 1: DDL in transaction
      const transaction = pool.transaction();
      await transaction.begin();
      try {
        for (let i = 0; i < ddlBatches.length; i++) {
          const batch = ddlBatches[i];
          try {
            await transaction.request().query(batch);
          } catch (batchErr) {
            const firstLine = batch.trim().split('\n').find(l => l.trim() && !l.trim().startsWith('--'))?.trim().substring(0, 120) || `batch ${i + 1}`;
            const detail = `Setup batch ${i + 1}/${ddlBatches.length} failed [${firstLine}]: ${batchErr.message}`;
            writeCrashLog('SETUP-DATABASE', new Error(detail));
            throw new Error(`${batchErr.message}\n\n(Batch ${i + 1}: ${firstLine})`);
          }
        }
        await transaction.commit();
      } catch (txErr) {
        try { await transaction.rollback(); } catch { /* rollback may fail if connection dropped */ }
        throw txErr;
      }

      // Phase 2: FTS setup (outside transaction — best effort)
      for (const batch of ftsBatches) {
        try {
          await pool.request().query(batch);
        } catch (e) {
          console.log('FTS batch skipped (non-critical):', e.message);
        }
      }

      // Check FTS status after fresh install
      const ftsCheck = await pool.request().query("SELECT FULLTEXTSERVICEPROPERTY('IsFullTextInstalled') AS FtsInstalled");
      const ftsInstalled = ftsCheck.recordset[0]?.FtsInstalled === 1;
      const ftsIndexCheck = await pool.request().query("SELECT COUNT(*) AS cnt FROM sys.fulltext_indexes WHERE object_id IN (OBJECT_ID('EntityRows'), OBJECT_ID('EntityValues'))");
      const ftsIndexCount = ftsIndexCheck.recordset[0]?.cnt || 0;

      let ftsWarning = null;
      if (!ftsInstalled) {
        ftsWarning = 'Full-Text Search is not installed on this SQL Server instance. Search will use LIKE (slower). Install the "Full-Text and Semantic Extractions for Search" feature via the SQL Server installer, set the Filter Daemon Launcher service to Automatic, then run Setup Database again.';
      } else if (ftsIndexCount < 2) {
        ftsWarning = 'Full-Text Search is installed but the indexes could not be created. Run Setup Database again to retry.';
      }

      // Ensure schema version is written (script should have done this, but be safe)
      try {
        const svCount = await pool.request().query("SELECT COUNT(*) AS cnt FROM SchemaVersion");
        if (svCount.recordset[0].cnt === 0) {
          await pool.request().input('v', sql.NVarChar(20), APP_VERSION).query("INSERT INTO SchemaVersion (Version) VALUES (@v)");
        } else {
          await pool.request().input('v', sql.NVarChar(20), APP_VERSION).query("UPDATE SchemaVersion SET Version = @v, UpdatedAt = GETUTCDATE()");
        }
      } catch { /* non-critical */ }

      // Sync trial record to newly available DB
      try {
        const trialRecord = await getTrialRecord(null);
        if (trialRecord && trialRecord.trialStart) {
          await writeTrialRecord(pool, new Date(trialRecord.trialStart));
          console.log('[trial] Synced to database after setup');
        }
      } catch (e) {
        console.log('[trial] DB sync after setup failed (non-critical):', e.message);
      }

      res.json({ success: true, message: 'Database schema created successfully.', hasUsers: false, schemaVersion: APP_VERSION, ftsInstalled, ftsIndexCount, ftsWarning });
    }
  } catch (err) {
    writeCrashLog('SETUP-DATABASE', err);
    logger.error('Database setup failed', { error: err.message, category: 'database' });
    res.json({ success: false, message: err.message });
  } finally {
    if (pool) {
      try { await pool.close(); } catch { /* ignore */ }
    }
  }
});

// Production: serve built frontend from dist/ (no-op in dev — dist/ doesn't exist)
const distPath = pathJoin(__dirname, 'dist');
if (existsSync(distPath)) {
  app.use(express.static(distPath));
  app.use((req, res, next) => {
    if (req.method === 'GET' && !req.path.startsWith('/api/')) {
      res.sendFile(pathJoin(distPath, 'index.html'));
    } else {
      next();
    }
  });
}

// Error handler (must be last)
app.use(errorHandler);

const PORT = process.env.PORT || 3001;
// Undefined binds to every interface, which is what a real installation needs — customers
// reach Primentra over the network. Test stacks set HOST=127.0.0.1 so they stay local, which
// also keeps Windows from raising a firewall prompt for every new port they open.
const HOST = process.env.HOST || undefined;
const server = app.listen(PORT, HOST, async () => {
  console.log(`Primentra API server running on http://localhost:${PORT}`);

  // Service started successfully — log to Event Viewer and clear crash counter
  writeEventLog('INFORMATION', 101,
    `Primentra v${APP_VERSION} started successfully on port ${PORT} — Node.js ${process.version}, PID ${process.pid}`);
  clearCrashCount();

  // Connect logger to database for error/warn persistence
  setDbWriter(async (entry) => {
    try {
      await dbExecute('usp_ErrorLog_Write', {
        Level: entry.level,
        Method: entry.method || null,
        Path: entry.path || null,
        StatusCode: entry.statusCode ? { type: dbSql.Int, value: entry.statusCode } : null,
        Message: entry.message || null,
        Stack: entry.stack || null,
        UserId: entry.userId ? { type: dbSql.Int, value: entry.userId } : null,
        RequestBody: entry.requestBody || null,
        Duration: entry.duration ? { type: dbSql.Int, value: entry.duration } : null,
      });
    } catch { /* DB write failure should never crash the server */ }
  });
  // Load log category settings from config file (refreshed every 60s)
  setSettingsLoader(async () => {
    try {
      return readConfig();
    } catch { return null; }
  });

  logger.info('Server started', { path: `http://localhost:${PORT}`, category: 'server' });
  console.log(`Config file: ${CONFIG_PATH}`);
  const config = readConfig();

  if (config.licenseKey) {
    const info = decodeLicense(config.licenseKey, config.licenseOrg);
    if (info.valid) {
      console.log(`License: ${info.org} (expires ${info.expiry}, ${info.daysLeft} days left)`);
    } else {
      console.log(`License expired: ${config.licenseOrg} (${config.licenseExpiry})`);
    }
  } else {
    console.log('No license key configured');
  }

  // Check Full-Text Search status at startup: 1) feature, 2) indexes, 3) service
  try {
    const { getPool } = await import('./server/db.js');
    const pool = await getPool();
    const ftsCheck = await pool.request().query("SELECT FULLTEXTSERVICEPROPERTY('IsFullTextInstalled') AS FtsInstalled");
    const ftsInstalled = ftsCheck.recordset[0]?.FtsInstalled === 1;
    if (!ftsInstalled) {
      console.warn('[WARNING] Full-Text Search is NOT installed on this SQL Server instance. Search will fall back to LIKE (significantly slower).');
      logger.warn('Full-Text Search is not installed — search performance will be degraded', { category: 'server' });
    } else {
      const ftsIdx = await pool.request().query("SELECT COUNT(*) AS cnt FROM sys.fulltext_indexes WHERE object_id IN (OBJECT_ID('EntityRows'), OBJECT_ID('EntityValues'))");
      const ftsCount = ftsIdx.recordset[0]?.cnt || 0;
      if (ftsCount < 2) {
        console.warn(`[WARNING] Full-Text Search: only ${ftsCount}/2 indexes exist. Run Setup Database to create missing indexes.`);
        logger.warn(`Full-Text Search indexes incomplete (${ftsCount}/2) — run Setup Database`, { category: 'server' });
      } else {
        // Indexes exist — verify the FTS daemon service is actually running
        let serviceRunning = false;
        try {
          await pool.request().query("SELECT TOP 0 Id FROM EntityRows WHERE CONTAINS(Code, '\"_fts_healthcheck_\"')");
          serviceRunning = true;
        } catch { /* CONTAINS failed — service not running */ }

        // Check Windows service status
        let winServiceRunning = false;
        const startupConfig = readConfig();
        const instName = startupConfig.instance;
        const svcNames = instName ? [`MSSQLFDLauncher$${instName}`, 'MSSQLFDLauncher'] : ['MSSQLFDLauncher'];
        for (const svc of svcNames) {
          try {
            const { stdout } = await execFileAsync('sc', ['query', svc]);
            winServiceRunning = /RUNNING/.test(stdout);
            break;
          } catch { /* try next */ }
        }

        if (serviceRunning) {
          console.log(`Full-Text Search: active (2 indexes, service running${winServiceRunning ? ', Windows service running' : ''})`);
        } else {
          console.warn('[WARNING] Full-Text Search indexes exist but the Filter Daemon Launcher service is not running. Start it via services.msc.');
          logger.warn('Full-Text Search daemon service is not running — start SQL Full-text Filter Daemon Launcher via services.msc', { category: 'server' });
        }

        if (!winServiceRunning) {
          console.warn('[WARNING] MSSQLFDLauncher Windows service is not running. Set it to Automatic and start it in services.msc.');
          logger.warn('MSSQLFDLauncher Windows service is not running — set to Automatic and start in services.msc', { category: 'server' });
        }
      }
    }
  } catch { /* DB not connected at startup — FTS check skipped */ }

  // Trial protection: auto-start or validate trial on every boot
  try {
    let pool = null;
    try {
      const { getPool } = await import('./server/db.js');
      pool = await getPool();
    } catch { /* DB not connected at startup */ }

    if (!config.licenseKey) {
      // No license key — check/activate trial
      const status = await checkTrialStatus(pool);

      if (status.status === 'not_activated') {
        // First ever boot — auto-activate trial
        const result = await activateTrial(pool);
        config.licenseTrial = true;
        config.licenseOrg = 'Trial License';
        config.licenseIssued = result.trialStart;
        config.licenseValid = true;
        config.trialDaysLeft = 60;
        writeConfig(config);
        console.log(`[trial] Auto-activated — 60 days trial started`);
      } else if (status.status === 'active') {
        // Trial still running — update config with live data
        config.licenseTrial = true;
        config.licenseOrg = 'Trial License';
        config.licenseValid = true;
        config.trialDaysLeft = status.daysLeft;
        config.trialStart = status.trialStart;
        writeConfig(config);
        // Heal: re-sync any missing layers
        await writeTrialRecord(pool, new Date(status.trialStart));
        console.log(`[trial] Active — ${status.daysLeft} days remaining`);
      } else if (status.status === 'expired') {
        config.licenseTrial = true;
        config.licenseOrg = 'Trial License';
        config.licenseValid = false;
        config.trialDaysLeft = 0;
        writeConfig(config);
        console.log(`[trial] Expired — application is read-only`);
      }
    }
  } catch (err) {
    console.error('[trial] Startup check failed:', err.message);
    logger.error('Startup trial check failed', { error: err.message, category: 'trial' });
  }

  // License expiry notification scheduler
  async function checkLicenseExpiry() {
    try {
      const cfg = readConfig();
      const notif = cfg.licenseNotification || {};
      if (!notif.enabled || !notif.recipients) return;

      // Determine days left (license or trial)
      let daysLeft = null;
      let expiryDate = null;
      let orgName = null;

      if (cfg.licenseKey) {
        const info = decodeLicense(cfg.licenseKey, cfg.licenseOrg);
        if (info.valid) {
          daysLeft = info.daysLeft;
          expiryDate = info.expiry;
          orgName = info.org;
        }
      } else if (cfg.licenseTrial && cfg.trialDaysLeft != null) {
        daysLeft = cfg.trialDaysLeft;
        orgName = 'Trial License';
        // Calculate expiry from trialStart + 60 days
        if (cfg.trialStart) {
          const d = new Date(cfg.trialStart);
          d.setDate(d.getDate() + 60);
          expiryDate = d.toISOString().slice(0, 10);
        }
      }

      if (daysLeft == null || daysLeft < 0) return;

      // Check if daysLeft matches any threshold
      const thresholds = notif.daysBeforeExpiry || [30, 14, 7, 3, 1];
      if (!thresholds.includes(daysLeft)) return;

      // Frequency check: once / daily / weekly
      const freq = notif.frequency || 'daily';
      const now = Date.now();
      const lastSent = cfg.licenseNotificationLastSent || 0;
      const hoursSinceLast = (now - lastSent) / (1000 * 60 * 60);

      if (freq === 'once' && lastSent > 0) return;
      if (freq === 'daily' && hoursSinceLast < 20) return;
      if (freq === 'weekly' && hoursSinceLast < 160) return;

      // Send notification
      await sendLicenseExpiryWarning({
        recipients: notif.recipients,
        daysLeft,
        expiryDate: expiryDate || 'unknown',
        orgName: orgName || cfg.licenseOrg || 'Unknown',
      });

      // Record last sent time
      cfg.licenseNotificationLastSent = now;
      writeConfig(cfg);
      console.log(`[license] Expiry notification sent (${daysLeft} days left)`);
    } catch (err) {
      console.error('[license] Notification check failed:', err.message);
      logger.error('License expiry notification check failed', { error: err.message, category: 'license' });
    }
  }

  // Run 10 seconds after startup, then every 6 hours
  setTimeout(checkLicenseExpiry, 10000);
  setInterval(checkLicenseExpiry, 6 * 60 * 60 * 1000);

  // Read a retention setting from AppSettings (table-driven, single source of truth)
  async function getRetentionDays(key, fallback) {
    try {
      const result = await dbExecute('usp_Settings_GetApp');
      const row = result.recordset.find(r => r.SettingKey === key);
      if (row) {
        const val = parseInt(row.SettingValue, 10);
        if (!isNaN(val)) return val;
      }
    } catch { /* fall through to default */ }
    return fallback;
  }

  // Audit log cleanup scheduler — runs daily
  async function runAuditCleanup() {
    try {
      const retentionDays = await getRetentionDays('auditRetentionDays', 90);
      const cutoff = new Date();
      cutoff.setDate(cutoff.getDate() - retentionDays);
      const result = await dbExecute('usp_AuditLog_Cleanup', { RetentionDays: retentionDays });
      const deleted = result.recordset[0]?.DeletedCount || 0;
      if (deleted > 0) {
        console.log(`[audit-cleanup] Removed ${deleted} entries older than ${retentionDays} days (before ${cutoff.toISOString().slice(0, 10)})`);
      }
    } catch (err) {
      console.error('[audit-cleanup] Failed:', err.message);
      logger.error('Audit log cleanup failed', { error: err.message, category: 'audit' });
    }
  }

  // Run once at startup (after 30s to let DB settle), then every 24 hours
  setTimeout(runAuditCleanup, 30000);
  setInterval(runAuditCleanup, 24 * 60 * 60 * 1000);

  // Approval data cleanup scheduler — runs daily
  async function runApprovalCleanup() {
    try {
      const retentionDays = await getRetentionDays('approvalRetentionDays', 365);
      if (retentionDays <= 0) return; // disabled — keep forever
      const result = await dbExecute('usp_Approval_Cleanup', { RetentionDays: retentionDays });
      const deleted = result.recordset[0]?.DeletedCount || 0;
      if (deleted > 0) {
        console.log(`[approval-cleanup] Removed ${deleted} resolved approval request(s) older than ${retentionDays} days`);
      }
    } catch (err) {
      console.error('[approval-cleanup] Failed:', err.message);
      logger.error('Approval cleanup failed', { error: err.message, category: 'approvals' });
    }
  }

  // Run 35s after startup (after audit cleanup at 30s), then every 24 hours
  setTimeout(runApprovalCleanup, 35000);
  setInterval(runApprovalCleanup, 24 * 60 * 60 * 1000);
});

server.on('error', (err) => {
  writeCrashLog('SERVER LISTEN ERROR', err);
  const detail = err.code === 'EADDRINUSE'
    ? `Port ${PORT} is already in use by another application. Change the port with: scripts\\change-port.bat <new-port>`
    : `Server failed to start: ${err?.message || err}`;
  writeEventLog('ERROR', 203, `[v${APP_VERSION}] ${detail}. Check logs\\errorlog.txt for the full stack trace.`);
  process.exit(1);
});
