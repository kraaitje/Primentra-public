// Batch handling for setup-database.sql.
//
// Shared by the live upgrade endpoint (POST /api/setup-database) and the
// pre-release upgrade matrix (scripts/verify-upgrade-matrix.js). Both must run
// the exact same selection, otherwise the release gate verifies a code path
// customers never take.

/** Split a T-SQL script into batches on GO separators. */
export function splitBatches(script) {
  return script.split(/^\s*GO\s*$/gim).filter(b => b.trim());
}

// Batches that are safe to re-run against a database that already holds the
// schema. Anything outside this list is skipped on upgrade — which is why every
// new table and index needs an IF NOT EXISTS guard and every new column needs an
// ALTER TABLE block in the MIGRATIONS section.
const UPGRADE_BATCH_PATTERNS = [
  /CREATE\s+(OR\s+ALTER\s+)?PROCEDURE/i,
  /DROP\s+PROCEDURE/i,
  // Views are as re-runnable as procedures. Without this a CREATE OR ALTER VIEW batch is
  // silently skipped on upgrade, so an existing database would run new procedures against
  // a view that was never created there.
  /CREATE\s+(OR\s+ALTER\s+)?VIEW/i,
  /DROP\s+VIEW/i,
  /CREATE\s+SCHEMA/i,
  /ALTER\s+TABLE/i,
  /sp_rename/i,
  /-- MIGRATION/i,
  /FULLTEXT/i,
  // IF NOT EXISTS CREATE TABLE — safe to re-run, needed for tables added after initial release
  /IF\s+NOT\s+EXISTS\s*\(SELECT\s+.+FROM\s+(INFORMATION_SCHEMA\.TABLES|sys\.tables)/i,
  /IF\s+OBJECT_ID\s*\(/i,
];

/** Select the batches an upgrade re-runs against an existing database. */
export function selectUpgradeBatches(batches) {
  return batches.filter(b => UPGRADE_BATCH_PATTERNS.some(re => re.test(b)));
}

/** Full-text batches fail on instances without FTS permissions; that is not fatal. */
export function isSkippableFtsFailure(batch, message) {
  return /FULLTEXT/i.test(batch) && /permission/i.test(message);
}

/** First non-comment line of a batch, for error messages. */
export function describeBatch(batch, index) {
  return batch.trim().split('\n').find(l => l.trim() && !l.trim().startsWith('--'))?.trim().substring(0, 120)
    || `batch ${index + 1}`;
}
