-- ============================================
-- Primentra Database Setup Script
-- SQL Server 2016+ required
-- ============================================
-- Prerequisites: Run setup-db-and-user.sql first to create the database,
-- service account, and permissions. This script creates all tables,
-- stored procedures, indexes, and migrations.
-- ============================================

-- No USE statement: this script deploys into whichever database the connection is already
-- pointed at. Hardcoding a name made every deployment land in a database literally called
-- "Primentra", regardless of the name the customer chose during setup.
--
-- Guard for the manual route: `sqlcmd -i setup-database.sql` without -d would otherwise
-- deploy the entire schema into master without complaining.
IF DB_NAME() IN ('master', 'tempdb', 'model', 'msdb')
    THROW 50000, 'Refusing to deploy into a system database. Connect to the target database first (sqlcmd -d <database>).', 1;
GO

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

-- ============================================
-- SCHEMAS
-- ============================================
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'mdm')
    EXEC('CREATE SCHEMA [mdm]');
GO

-- ============================================
-- MODELS
-- ============================================
CREATE TABLE Models (
    Id          INT IDENTITY(1,1) CONSTRAINT PK_Models PRIMARY KEY,
    Name        NVARCHAR(200) NOT NULL,
    Description NVARCHAR(500) NULL,
    IsActive    BIT NOT NULL DEFAULT 1,
    SortOrder   INT NOT NULL DEFAULT 0,
    CreatedAt   DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    ModifiedAt  DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO

-- ============================================
-- ENTITIES
-- ============================================
CREATE TABLE Entities (
    Id                  INT IDENTITY(1,1) CONSTRAINT PK_Entities PRIMARY KEY,
    ModelId             INT NOT NULL REFERENCES Models(Id),
    Name                NVARCHAR(200) NOT NULL,
    Description         NVARCHAR(500) NULL,
    TableName           NVARCHAR(128) NOT NULL,
    SortOrder           INT NOT NULL DEFAULT 0,
    IsActive            BIT NOT NULL DEFAULT 1,
    RequiresApproval    BIT NOT NULL DEFAULT 0,
    SharedAcrossModels  BIT NOT NULL DEFAULT 0,
    AutoGenerateCode      BIT NOT NULL DEFAULT 0,
    ApproverCanApproveOwn BIT NOT NULL DEFAULT 0,
    ApprovalStrategy      NVARCHAR(20) NOT NULL DEFAULT 'any',
    CreatedAt             DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    ModifiedAt            DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO

-- EntityApprovers is created after Users (see below)


-- ============================================
-- ATTRIBUTES
-- ============================================
CREATE TABLE Attributes (
    Id              INT IDENTITY(1,1) CONSTRAINT PK_Attributes PRIMARY KEY,
    EntityId        INT NOT NULL REFERENCES Entities(Id) ON DELETE CASCADE,
    DisplayName     NVARCHAR(200) NOT NULL,
    Name            NVARCHAR(128) NOT NULL,
    DataType        NVARCHAR(20) NOT NULL CHECK (DataType IN ('Text','Int','Decimal','DateTime','Domain','Boolean')),
    MaxLength       INT NULL,
    IsRequired      BIT NOT NULL DEFAULT 0,
    IsCode          BIT NOT NULL DEFAULT 0,
    IsName          BIT NOT NULL DEFAULT 0,
    IsHidden        BIT NOT NULL DEFAULT 0,
    IsSystemDate    BIT NOT NULL DEFAULT 0,
    SortOrder       INT NOT NULL DEFAULT 0,
    DomainEntityId  INT NULL REFERENCES Entities(Id),
    Description     NVARCHAR(500) NULL,
    DateFormat      NVARCHAR(20) NULL,
    BooleanDisplayFormat NVARCHAR(20) NULL CONSTRAINT CHK_Attributes_BooleanDisplayFormat CHECK (BooleanDisplayFormat IN ('1/0', 'Yes/No', 'Custom')),
    DecimalPlaces   INT NULL,
    AllowNegative   BIT NULL,
    DomainParentAttributeId INT NULL,
    CreatedAt       DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    ModifiedAt      DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO


-- Backfill system date attributes for existing entities that don't have them yet
INSERT INTO Attributes (EntityId, DisplayName, Name, DataType, IsRequired, IsCode, IsName, IsHidden, IsSystemDate, SortOrder, Description)
SELECT e.Id, 'Created', 'createdAt', 'DateTime', 0, 0, 0, 1, 1, 9998, 'Date this record was created'
FROM Entities e
WHERE NOT EXISTS (SELECT 1 FROM Attributes a WHERE a.EntityId = e.Id AND a.IsSystemDate = 1 AND a.Name = 'createdAt');

INSERT INTO Attributes (EntityId, DisplayName, Name, DataType, IsRequired, IsCode, IsName, IsHidden, IsSystemDate, SortOrder, Description)
SELECT e.Id, 'Last Modified', 'modifiedAt', 'DateTime', 0, 0, 0, 1, 1, 9999, 'Date this record was last modified'
FROM Entities e
WHERE NOT EXISTS (SELECT 1 FROM Attributes a WHERE a.EntityId = e.Id AND a.IsSystemDate = 1 AND a.Name = 'modifiedAt');
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Attributes_EntityId')
    CREATE INDEX IX_Attributes_EntityId ON Attributes(EntityId);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Attributes_DomainEntityId')
    CREATE INDEX IX_Attributes_DomainEntityId ON Attributes(DomainEntityId) WHERE DomainEntityId IS NOT NULL;
GO

-- ============================================
-- ENTITY ROWS (one row per master data record)
-- ============================================
CREATE TABLE EntityRows (
    Id          BIGINT IDENTITY(1,1) CONSTRAINT PK_EntityRows PRIMARY KEY,
    EntityId    INT NOT NULL REFERENCES Entities(Id),
    Code        NVARCHAR(200) NOT NULL,
    Name        NVARCHAR(500) NOT NULL,
    CreatedAt   DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    ModifiedAt  DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    CreatedBy   INT NULL,
    ModifiedBy  INT NULL,

    CONSTRAINT UQ_EntityRows_Code UNIQUE (EntityId, Code)
);
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_EntityRows_EntityId')
    CREATE INDEX IX_EntityRows_EntityId ON EntityRows(EntityId);
GO

-- ============================================
-- ENTITY VALUES (EAV: one value per attribute per row)
-- ============================================
CREATE TABLE EntityValues (
    Id              BIGINT IDENTITY(1,1) CONSTRAINT PK_EntityValues PRIMARY KEY,
    EntityRowId     BIGINT NOT NULL REFERENCES EntityRows(Id) ON DELETE CASCADE,
    AttributeId     INT NOT NULL REFERENCES Attributes(Id) ON DELETE CASCADE,
    TextValue       NVARCHAR(MAX) NULL,
    IntValue        INT NULL,
    DecimalValue    DECIMAL(18,6) NULL,
    DateTimeValue   DATETIME2 NULL,
    DomainValue     BIGINT NULL REFERENCES EntityRows(Id),

    CONSTRAINT UQ_EntityValues UNIQUE (EntityRowId, AttributeId)
);
GO

-- Covering index: eliminates key lookups on EAV fetch (EntityRowId + all value columns)
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_EntityValues_EntityRowId' AND object_id = OBJECT_ID('EntityValues'))
    DROP INDEX IX_EntityValues_EntityRowId ON EntityValues;
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_EntityValues_EntityRowId_Cover')
    CREATE INDEX IX_EntityValues_EntityRowId_Cover ON EntityValues(EntityRowId)
    INCLUDE (AttributeId, TextValue, IntValue, DecimalValue, DateTimeValue, DomainValue);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_EntityValues_AttributeId')
    CREATE INDEX IX_EntityValues_AttributeId ON EntityValues(AttributeId);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_EntityValues_DomainValue')
    CREATE INDEX IX_EntityValues_DomainValue ON EntityValues(DomainValue) WHERE DomainValue IS NOT NULL;
GO

-- ============================================
-- ROLES
-- ============================================
CREATE TABLE Roles (
    Id          INT IDENTITY(1,1) CONSTRAINT PK_Roles PRIMARY KEY,
    Name        NVARCHAR(200) NOT NULL UNIQUE,
    Description NVARCHAR(500) NULL,
    IsAdmin     BIT NOT NULL DEFAULT 0,
    CanApprove  BIT NOT NULL DEFAULT 0,
    CreatedAt   DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    ModifiedAt  DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO

-- Seed default Administrators role
IF NOT EXISTS (SELECT 1 FROM Roles WHERE IsAdmin = 1)
    INSERT INTO Roles (Name, Description, IsAdmin, CanApprove)
    VALUES ('Administrators', 'Full system access', 1, 0);
GO

-- ============================================
-- USERS
-- ============================================
CREATE TABLE Users (
    Id                  INT IDENTITY(1,1) CONSTRAINT PK_Users PRIMARY KEY,
    Email               NVARCHAR(320) NOT NULL,
    DisplayName         NVARCHAR(200) NOT NULL,
    PasswordHash        NVARCHAR(500) NULL,
    MustChangePassword  BIT NOT NULL DEFAULT 1,
    FailedLoginAttempts INT NOT NULL DEFAULT 0,
    IsActive              BIT NOT NULL DEFAULT 1,
    IsDeleted             BIT NOT NULL DEFAULT 0,
    IsSystem              BIT NOT NULL DEFAULT 0,
    PasswordLastChangedAt DATETIME2 NULL,
    LastLoginAt           DATETIME2 NULL,
    UserType              NVARCHAR(20) NOT NULL CONSTRAINT DF_Users_UserType DEFAULT 'standard',
    CreatedAt             DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    ModifiedAt            DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    DashboardPreferences  NVARCHAR(MAX) NULL,

    CONSTRAINT CK_Users_UserType CHECK (UserType IN ('standard', 'api'))
);
GO

-- EntityApprovers: depends on both Entities and Users, so lives here
CREATE TABLE EntityApprovers (
    EntityId      INT NOT NULL REFERENCES Entities(Id) ON DELETE CASCADE,
    UserId        INT NOT NULL REFERENCES Users(Id) ON DELETE CASCADE,
    ReceivesEmail BIT NOT NULL DEFAULT 1,
    CreatedAt     DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    CONSTRAINT PK_EntityApprovers PRIMARY KEY (EntityId, UserId)
);
GO

-- Filtered unique index: email must be unique among non-deleted users
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'UQ_Users_Email_Active')
    CREATE UNIQUE INDEX UQ_Users_Email_Active ON Users(Email) WHERE IsDeleted = 0;
GO

-- ============================================
-- API KEYS
-- ============================================
CREATE TABLE ApiKeys (
    Id          INT IDENTITY(1,1) CONSTRAINT PK_ApiKeys PRIMARY KEY,
    UserId      INT NOT NULL REFERENCES Users(Id),
    Name        NVARCHAR(200) NOT NULL,
    KeyHash     NVARCHAR(500) NOT NULL,
    KeyPrefix   NVARCHAR(12) NOT NULL,
    IsActive    BIT NOT NULL DEFAULT 1,
    IsDeleted   BIT NOT NULL DEFAULT 0,
    ExpiresAt   DATETIME2 NULL,
    LastUsedAt  DATETIME2 NULL,
    CallCount   BIGINT NOT NULL DEFAULT 0,
    ReadCount   BIGINT NOT NULL DEFAULT 0,
    CreateCount BIGINT NOT NULL DEFAULT 0,
    UpdateCount BIGINT NOT NULL DEFAULT 0,
    DeleteCount BIGINT NOT NULL DEFAULT 0,
    CreatedAt   DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    ModifiedAt  DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    CONSTRAINT UQ_ApiKeys_KeyHash UNIQUE (KeyHash)
    -- One active key per API user enforced in SP logic (soft-deleted rows must not block new keys)
);
GO

-- ============================================
-- GROUP MEMBERS
-- ============================================
CREATE TABLE RoleMembers (
    Id          INT IDENTITY(1,1) CONSTRAINT PK_RoleMembers PRIMARY KEY,
    RoleId      INT NOT NULL REFERENCES Roles(Id) ON DELETE CASCADE,
    UserId      INT NOT NULL REFERENCES Users(Id) ON DELETE CASCADE,
    CreatedAt   DATETIME2 NOT NULL DEFAULT GETUTCDATE(),

    CONSTRAINT UQ_RoleMembers UNIQUE (RoleId, UserId)
);
GO

-- ============================================
-- PERMISSIONS
-- ============================================
CREATE TABLE Permissions (
    Id          INT IDENTITY(1,1) CONSTRAINT PK_Permissions PRIMARY KEY,
    RoleId      INT NOT NULL REFERENCES Roles(Id) ON DELETE CASCADE,
    Scope       NVARCHAR(20) NOT NULL CHECK (Scope IN ('model','entity','attribute')),
    TargetId    INT NOT NULL,
    Level       NVARCHAR(20) NOT NULL CHECK (Level IN ('moderator','write','read','none')),
    CanCreate   BIT NOT NULL DEFAULT 0,
    CanRead     BIT NOT NULL DEFAULT 0,
    CanUpdate   BIT NOT NULL DEFAULT 0,
    CanDelete   BIT NOT NULL DEFAULT 0,
    IsModerator BIT NOT NULL DEFAULT 0,
    IsExplicit  BIT NOT NULL DEFAULT 0,
    CreatedAt   DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    ModifiedAt  DATETIME2 NOT NULL DEFAULT GETUTCDATE(),

    CONSTRAINT UQ_Permissions UNIQUE (RoleId, Scope, TargetId)
);
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Permissions_RoleId')
    CREATE INDEX IX_Permissions_RoleId ON Permissions(RoleId);
GO

-- ============================================
-- INTEGRATION VIEWS
-- ============================================
CREATE TABLE IntegrationViews (
    Id                INT IDENTITY(1,1) CONSTRAINT PK_IntegrationViews PRIMARY KEY,
    Name              NVARCHAR(200) NOT NULL,
    EntityId          INT NOT NULL REFERENCES Entities(Id) ON DELETE CASCADE,
    ViewType          NVARCHAR(20) NOT NULL CHECK (ViewType IN ('hierarchy','flat')),
    ExcludedColumns   NVARCHAR(MAX) NULL,
    ColumnSnapshot    NVARCHAR(MAX) NULL,
    TypeSnapshot      NVARCHAR(MAX) NULL,
    CreatedAt         DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    ModifiedAt        DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO

-- ============================================
-- AUDIT LOG
-- ============================================
CREATE TABLE AuditLog (
    Id          BIGINT IDENTITY(1,1) CONSTRAINT PK_AuditLog PRIMARY KEY,
    EntityId    INT NULL,  -- No FK: audit log is a historical record; EntityId preserved after entity deletion
    EntityName  NVARCHAR(200) NOT NULL,
    ModelName   NVARCHAR(200) NOT NULL,
    Action      NVARCHAR(50) NOT NULL CHECK (Action IN (
                    'create','edit','delete','import','create/edit','purge',
                    'login_success','login_failed','account_locked','logout',
                    'first_user_setup','user_created','user_updated','user_deleted',
                    'admin_password_reset','welcome_email_sent',
                    'password_changed','password_forced_change',
                    'permission_change','DataTypeChange',
                    'approved','force_approved',
                    'approval_submitted','approval_rejected','approval_sent_back',
                    'api_user_created','api_user_updated','api_user_deleted',
                    'api_key_regenerated','api_access_enabled','api_access_disabled'
                )),
    RecordCount INT NOT NULL DEFAULT 1,
    UserId      INT NULL,
    Comment     NVARCHAR(1000) NULL,
    Details     NVARCHAR(MAX) NULL,
    CreatedAt   DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_AuditLog_EntityId')
    CREATE INDEX IX_AuditLog_EntityId ON AuditLog(EntityId);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_AuditLog_CreatedAt')
    CREATE INDEX IX_AuditLog_CreatedAt ON AuditLog(CreatedAt DESC);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_AuditLog_UserId')
    CREATE INDEX IX_AuditLog_UserId ON AuditLog(UserId) WHERE UserId IS NOT NULL;
GO

-- Extend AuditLog.Action constraint to include approval action types.
-- QUOTED_IDENTIFIER ON is required because AuditLog has a filtered index (IX_AuditLog_UserId).
-- Without it, ALTER TABLE DDL on this table is rejected by SQL Server.
SET QUOTED_IDENTIFIER ON;
GO

-- Drop any auto-named inline constraint created by the CREATE TABLE block.
DECLARE @CkName2 NVARCHAR(200);
SELECT @CkName2 = cc.name
FROM sys.check_constraints cc
JOIN sys.columns c ON c.object_id = cc.parent_object_id AND c.column_id = cc.parent_column_id
WHERE cc.parent_object_id = OBJECT_ID('AuditLog') AND c.name = 'Action'
  AND cc.name <> 'CK_AuditLog_Action';

IF @CkName2 IS NOT NULL
    EXEC ('ALTER TABLE AuditLog DROP CONSTRAINT [' + @CkName2 + ']');
GO

-- Drop and recreate the named constraint unconditionally so the value list
-- is always current on both fresh installs and upgrades.
SET QUOTED_IDENTIFIER ON;
GO
IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_AuditLog_Action' AND parent_object_id = OBJECT_ID('AuditLog'))
    ALTER TABLE AuditLog DROP CONSTRAINT CK_AuditLog_Action;

ALTER TABLE AuditLog ADD CONSTRAINT CK_AuditLog_Action CHECK (Action IN (
    'create','edit','delete','import','create/edit','purge',
    'login_success','login_failed','account_locked','logout',
    'first_user_setup','user_created','user_updated','user_deleted',
    'admin_password_reset','welcome_email_sent',
    'password_changed','password_forced_change',
    'permission_change','DataTypeChange',
    'approved','force_approved',
    'approval_submitted','approval_rejected','approval_sent_back',
    'api_user_created','api_user_updated','api_user_deleted',
    'api_key_regenerated','api_access_enabled','api_access_disabled'
));
GO

-- ============================================
-- FK CASCADE MIGRATIONS (existing installations)
-- Fresh installs get the correct ON DELETE actions from the CREATE TABLE
-- statements above. These blocks upgrade existing tables idempotently.
-- ============================================

-- IntegrationViews.EntityId: upgrade NO ACTION → ON DELETE CASCADE
-- Allows deleting an Entity to automatically remove its IntegrationViews.
BEGIN
    DECLARE @fk1 NVARCHAR(200);
    SELECT @fk1 = fk.name
    FROM sys.foreign_keys fk
    JOIN sys.foreign_key_columns fkc ON fk.object_id = fkc.constraint_object_id
    WHERE fk.parent_object_id       = OBJECT_ID('IntegrationViews')
      AND fkc.parent_column_id      = COLUMNPROPERTY(OBJECT_ID('IntegrationViews'), 'EntityId', 'ColumnId')
      AND fk.delete_referential_action <> 1; -- 1 = CASCADE
    IF @fk1 IS NOT NULL
        EXEC('ALTER TABLE IntegrationViews DROP CONSTRAINT [' + @fk1 + ']');
END;
GO
IF NOT EXISTS (
    SELECT 1 FROM sys.foreign_keys fk
    JOIN sys.foreign_key_columns fkc ON fk.object_id = fkc.constraint_object_id
    WHERE fk.parent_object_id  = OBJECT_ID('IntegrationViews')
      AND fkc.parent_column_id = COLUMNPROPERTY(OBJECT_ID('IntegrationViews'), 'EntityId', 'ColumnId')
)
    ALTER TABLE IntegrationViews
        ADD CONSTRAINT FK_IntegrationViews_EntityId
            FOREIGN KEY (EntityId) REFERENCES Entities(Id) ON DELETE CASCADE;
GO

-- AuditLog.Action: add 'approved' to the CHECK constraint
-- Drop the existing (auto-named) constraint and recreate with the extended list.
BEGIN
    DECLARE @ck NVARCHAR(200);
    SELECT @ck = name
    FROM sys.check_constraints
    WHERE parent_object_id = OBJECT_ID('AuditLog')
      AND name LIKE '%Action%';
    IF @ck IS NOT NULL
        EXEC('ALTER TABLE AuditLog DROP CONSTRAINT [' + @ck + ']');
END;
GO
IF NOT EXISTS (
    SELECT 1 FROM sys.check_constraints
    WHERE parent_object_id = OBJECT_ID('AuditLog')
      AND name = 'CK_AuditLog_Action'
)
    ALTER TABLE AuditLog ADD CONSTRAINT CK_AuditLog_Action CHECK (Action IN (
        'create','edit','delete','import','create/edit','purge',
        'login_success','login_failed','account_locked','logout',
        'first_user_setup','user_created','user_updated','user_deleted',
        'admin_password_reset','welcome_email_sent',
        'password_changed','password_forced_change',
        'permission_change','DataTypeChange',
        'approved','force_approved',
        'approval_submitted','approval_rejected','approval_sent_back',
        'api_user_created','api_user_updated','api_user_deleted',
        'api_key_regenerated','api_access_enabled','api_access_disabled'
    ));
GO

-- AuditLog.EntityId: upgrade NO ACTION → ON DELETE SET NULL
-- Drop FK on AuditLog.EntityId if it exists — audit log is a historical record,
-- EntityId must be preserved after entity deletion (not SET NULL).
BEGIN
    DECLARE @fk2 NVARCHAR(200);
    SELECT @fk2 = fk.name
    FROM sys.foreign_keys fk
    JOIN sys.foreign_key_columns fkc ON fk.object_id = fkc.constraint_object_id
    WHERE fk.parent_object_id  = OBJECT_ID('AuditLog')
      AND fkc.parent_column_id = COLUMNPROPERTY(OBJECT_ID('AuditLog'), 'EntityId', 'ColumnId');
    IF @fk2 IS NOT NULL
        EXEC('ALTER TABLE AuditLog DROP CONSTRAINT [' + @fk2 + ']');
END;
GO

-- StagingBatches migration moved below its CREATE TABLE

-- ============================================
-- USER SETTINGS
-- ============================================
CREATE TABLE UserSettings (
    Id           INT IDENTITY(1,1) CONSTRAINT PK_UserSettings PRIMARY KEY,
    UserId       INT NULL REFERENCES Users(Id) ON DELETE CASCADE,
    SettingKey   NVARCHAR(100) NOT NULL,
    SettingValue NVARCHAR(MAX) NULL,
    CreatedAt    DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    ModifiedAt   DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO
-- Filtered unique index: allows NULL (anonymous) but enforces uniqueness per authenticated user
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'UQ_UserSettings_UserId_Key')
    CREATE UNIQUE INDEX UQ_UserSettings_UserId_Key ON UserSettings(UserId, SettingKey) WHERE UserId IS NOT NULL;
GO

-- ============================================
-- USER FAVORITES
-- ============================================
CREATE TABLE UserFavorites (
    Id          INT IDENTITY(1,1) CONSTRAINT PK_UserFavorites PRIMARY KEY,
    UserId      INT NOT NULL REFERENCES Users(Id) ON DELETE CASCADE,
    EntityId    INT NOT NULL REFERENCES Entities(Id) ON DELETE CASCADE,
    CreatedAt   DATETIME2 NOT NULL DEFAULT GETUTCDATE(),

    CONSTRAINT UQ_UserFavorites UNIQUE (UserId, EntityId)
);
GO

-- ============================================
-- APP SETTINGS
-- ============================================
CREATE TABLE AppSettings (
    SettingKey      NVARCHAR(100) CONSTRAINT PK_AppSettings PRIMARY KEY,
    SettingValue    NVARCHAR(MAX) NULL,
    CreatedAt       DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    ModifiedAt      DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO

-- ============================================
-- STAGING IMPORT
-- ============================================
CREATE TABLE StagingImport (
    Id              BIGINT IDENTITY(1,1) CONSTRAINT PK_StagingImport PRIMARY KEY,
    SessionId       UNIQUEIDENTIFIER NOT NULL,
    EntityName      NVARCHAR(200) NOT NULL,
    ModelName       NVARCHAR(200) NULL,
    RowData         NVARCHAR(MAX) NOT NULL,
    ProcessedAt     DATETIME2 NULL,
    Status          NVARCHAR(20) DEFAULT 'pending',
    ErrorMessage    NVARCHAR(1000) NULL,
    CreatedAt       DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_StagingImport_SessionId')
    CREATE INDEX IX_StagingImport_SessionId ON StagingImport(SessionId);
GO

-- ============================================
-- STAGING SCHEMA
-- ============================================
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'stg')
    EXEC('CREATE SCHEMA [stg]');
GO

-- Grant permissions on stg schema to the application service account
IF EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'primentra_svc')
BEGIN
    GRANT SELECT, INSERT, UPDATE, DELETE, ALTER, EXECUTE ON SCHEMA::stg TO primentra_svc;
    GRANT CREATE TABLE TO primentra_svc;
END;
GO

-- ============================================
-- fn_StagingTableName
-- Sanitises an entity name into a valid SQL identifier
-- for use as a staging table name in the stg schema.
-- Spaces -> underscores, non-alphanumeric stripped,
-- consecutive underscores collapsed.
-- ============================================
CREATE OR ALTER FUNCTION dbo.fn_StagingTableName(@EntityName NVARCHAR(200))
RETURNS NVARCHAR(200)
AS
BEGIN
    DECLARE @Result NVARCHAR(200) = @EntityName;

    -- 1. Replace spaces with underscores
    SET @Result = REPLACE(@Result, ' ', '_');

    -- 2. Remove all characters that aren't letters, digits, or underscores
    DECLARE @i INT = 1, @Clean NVARCHAR(200) = N'';
    WHILE @i <= LEN(@Result)
    BEGIN
        DECLARE @ch NCHAR(1) = SUBSTRING(@Result, @i, 1);
        IF @ch LIKE '[A-Za-z0-9_]'
            SET @Clean = @Clean + @ch;
        SET @i = @i + 1;
    END;
    SET @Result = @Clean;

    -- 3. Collapse consecutive underscores
    WHILE CHARINDEX('__', @Result) > 0
        SET @Result = REPLACE(@Result, '__', '_');

    -- 4. Trim leading/trailing underscores
    WHILE LEN(@Result) > 0 AND LEFT(@Result, 1) = '_'
        SET @Result = STUFF(@Result, 1, 1, '');
    WHILE LEN(@Result) > 0 AND RIGHT(@Result, 1) = '_'
        SET @Result = LEFT(@Result, LEN(@Result) - 1);

    RETURN @Result;
END;
GO

-- ============================================
-- fn_ResolveStagingTable
-- Resolves the qualified staging table name (stg.[Name])
-- for a given EntityId. Reads the stored TableName from
-- StagingConfigurations; falls back to Entity_{id} for
-- legacy rows that predate the named-table migration.
-- ============================================
CREATE OR ALTER FUNCTION dbo.fn_ResolveStagingTable(@EntityId INT)
RETURNS NVARCHAR(300)
AS
BEGIN
    DECLARE @SafeName NVARCHAR(200);

    SELECT @SafeName = TableName
    FROM StagingConfigurations
    WHERE EntityId = @EntityId;

    IF @SafeName IS NULL
        SET @SafeName = N'Entity_' + CAST(@EntityId AS NVARCHAR(20));

    RETURN N'stg.' + QUOTENAME(@SafeName);
END;
GO

-- ============================================
-- STAGINGCONFIGURATIONS
-- One row per entity that has staging enabled.
-- ============================================
CREATE TABLE StagingConfigurations (
    Id                  INT IDENTITY(1,1) PRIMARY KEY,
    EntityId            INT NOT NULL UNIQUE REFERENCES Entities(Id) ON DELETE CASCADE,
    IsEnabled           BIT NOT NULL DEFAULT 1,
    TableName           NVARCHAR(200) NULL,
    DefaultImportAction TINYINT NOT NULL DEFAULT 0,
    DefaultMergeMode    NVARCHAR(30) NOT NULL DEFAULT 'overwrite',
    SentinelText        NVARCHAR(20) NOT NULL DEFAULT '~NULL~',
    SentinelNumber      DECIMAL(38,0) NOT NULL DEFAULT -98765432101234567890,
    SentinelDateTime    NVARCHAR(30) NOT NULL DEFAULT '5555-11-22T12:34:56',
    CreatedAt           DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    ModifiedAt          DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO

-- ============================================
-- STAGINGFIELDRULES
-- Per-attribute rules for each staged entity.
-- ============================================
CREATE TABLE StagingFieldRules (
    Id                  INT IDENTITY(1,1) PRIMARY KEY,
    EntityId            INT NOT NULL REFERENCES Entities(Id) ON DELETE CASCADE,
    AttributeId         INT NOT NULL REFERENCES Attributes(Id) ON DELETE NO ACTION,
    MergeMode           NVARCHAR(30) NOT NULL DEFAULT 'auto',
    OnValidationError   NVARCHAR(20) NOT NULL DEFAULT 'error_row',
    SourcePriority      NVARCHAR(MAX) NULL,
    CreatedAt           DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    ModifiedAt          DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    UNIQUE (EntityId, AttributeId)
);
GO

-- ============================================
-- STAGINGBATCHES
-- One row per import batch execution.
-- ============================================
CREATE TABLE StagingBatches (
    Id            INT IDENTITY(1,1) PRIMARY KEY,
    EntityId      INT NOT NULL REFERENCES Entities(Id),
    BatchTag      NVARCHAR(100) NULL,
    Status        TINYINT NOT NULL DEFAULT 1,
    TotalRows     INT NOT NULL DEFAULT 0,
    SuccessRows   INT NOT NULL DEFAULT 0,
    ErrorRows     INT NOT NULL DEFAULT 0,
    SkippedRows   INT NOT NULL DEFAULT 0,
    StartedAt     DATETIME2 NULL,
    CompletedAt   DATETIME2 NULL,
    StartedBy     INT NULL REFERENCES Users(Id),
    TriggerSource NVARCHAR(100) NULL,
    SkippedReason NVARCHAR(200) NULL,
    CreatedAt     DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO

-- ============================================
-- STAGINGERRORDETAILS
-- Row-level error detail for a batch.
-- ============================================
CREATE TABLE StagingErrorDetails (
    Id              BIGINT IDENTITY(1,1) PRIMARY KEY,
    BatchId         INT NOT NULL REFERENCES StagingBatches(Id) ON DELETE CASCADE,
    StagingRowId    BIGINT NOT NULL,
    Code            NVARCHAR(200) NULL,
    AttributeName   NVARCHAR(200) NULL,
    StagingValue    NVARCHAR(500) NULL,
    ErrorCode       INT NOT NULL,
    ErrorMessage    NVARCHAR(500) NOT NULL,
    CreatedAt       DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO

-- ============================================
-- ERRORCODES
-- System-wide reference table for all error codes.
-- DBAs can JOIN this table to look up what any error code means.
-- Two code types: 'Throw' (SP THROW numbers) and 'StagingBitmask' (staging row ErrorCode bitmask).
-- ============================================
CREATE TABLE ErrorCodes (
    ErrorCode    INT PRIMARY KEY,
    CodeType     NVARCHAR(20) NOT NULL,     -- 'Throw' | 'StagingBitmask'
    Name         NVARCHAR(50) NOT NULL,     -- Short identifier: 'DuplicateCode', 'CodeRequired', etc.
    Category     NVARCHAR(20) NOT NULL,     -- 'Validation' | 'NotFound' | 'Protected' | 'RowLevel' | 'Attribute' | 'NewCode' | 'System'
    Description  NVARCHAR(200) NOT NULL,    -- Human-readable description
    UsedIn       NVARCHAR(500) NOT NULL     -- SP or component names where this code is set
);
GO

-- Pre-populate ErrorCodes reference data
IF NOT EXISTS (SELECT 1 FROM ErrorCodes)
BEGIN
    -- System 1: SP THROW error numbers (50xxx)
    INSERT INTO ErrorCodes (ErrorCode, CodeType, Name, Category, Description, UsedIn) VALUES
    (50001, 'Throw', 'ValidationError',       'Validation', 'Validation or business rule violation',              'usp_Data_SaveRow, usp_User_Create, usp_User_Update, usp_IntegrationView_Drop, usp_Staging_CreateTable, usp_Scheduler_SaveConfig'),
    (50002, 'Throw', 'NotFound',              'NotFound',   'Record not found',                                   'usp_Entity_Update, usp_User_Update, usp_User_ResetPassword, usp_User_ChangePassword, usp_Staging_CreateTable'),
    (50003, 'Throw', 'ProtectedResource',     'Protected',  'Protected resource or state conflict',               'usp_Role_Update, usp_User_Update, usp_User_Delete, usp_Staging_DropTable, usp_Staging_RebuildTable, usp_Staging_SaveConfiguration'),
    (50004, 'Throw', 'EntityRefNotFound',     'NotFound',   'Entity reference not found (integration views)',      'usp_IntegrationView_Deploy'),
    (50005, 'Throw', 'InvalidNameFormat',     'Validation', 'Invalid name or input format',                        'usp_IntegrationView_Deploy'),
    (50009, 'Throw', 'StagingSetupFailure',   'System',     'Staging setup failure (table naming)',                'usp_Staging_CreateTable'),
    (50010, 'Throw', 'StagingEntityNotFound', 'NotFound',   'Staging entity lookup failure',                       'usp_Staging_ProcessBatch'),
    (50011, 'Throw', 'StagingTableMissing',   'System',     'Staging table missing at runtime',                    'usp_Staging_ProcessBatch'),
    (50012, 'Throw', 'NoEligibleRows',        'Validation', 'No eligible rows for batch processing',               'usp_Staging_ProcessBatch');

    -- System 2: Staging row-level bitmask error codes
    INSERT INTO ErrorCodes (ErrorCode, CodeType, Name, Category, Description, UsedIn) VALUES
    (1,      'StagingBitmask', 'DuplicateCode',        'RowLevel',  'Duplicate Code in batch',                      'usp_Staging_ProcessBatch (step 2a)'),
    (2,      'StagingBitmask', 'CodeRequired',          'RowLevel',  'Code is required',                             'usp_Staging_ProcessBatch (step 2b)'),
    (4,      'StagingBitmask', 'CodeAlreadyExists',     'RowLevel',  'Code already exists (insert-only)',             'usp_Staging_ProcessBatch (step 2d)'),
    (8,      'StagingBitmask', 'CodeNotFound',          'RowLevel',  'Code does not exist (update/delete)',           'usp_Staging_ProcessBatch (step 2e)'),
    (16,     'StagingBitmask', 'InvalidImportAction',   'RowLevel',  'Invalid ImportAction value',                    'usp_Staging_ProcessBatch (step 2c)'),
    (32,     'StagingBitmask', 'ReservedCode',          'RowLevel',  'Reserved Code (placeholder)',                   'Not implemented'),
    (64,     'StagingBitmask', 'DeleteBlockedByRef',    'RowLevel',  'Delete blocked by references',                  'usp_Staging_ProcessBatch (step 2f)'),
    (128,    'StagingBitmask', 'RequiredFieldEmpty',    'Attribute', 'Required field empty',                          'usp_Staging_ProcessBatch (attribute validation)'),
    (256,    'StagingBitmask', 'TextExceedsMaxLen',     'Attribute', 'Text exceeds max length',                       'usp_Staging_ProcessBatch (attribute validation)'),
    (512,    'StagingBitmask', 'InvalidInteger',        'Attribute', 'Invalid integer value',                         'usp_Staging_ProcessBatch (attribute validation)'),
    (1024,   'StagingBitmask', 'InvalidDecimal',        'Attribute', 'Invalid decimal value',                         'usp_Staging_ProcessBatch (attribute validation)'),
    (2048,   'StagingBitmask', 'InvalidDatetime',       'Attribute', 'Invalid datetime value',                        'usp_Staging_ProcessBatch (attribute validation)'),
    (4096,   'StagingBitmask', 'InvalidBoolean',        'Attribute', 'Invalid boolean value',                         'usp_Staging_ProcessBatch (attribute validation)'),
    (8192,   'StagingBitmask', 'DomainNotFound',        'Attribute', 'Domain value not found',                        'usp_Staging_ProcessBatch (attribute validation)'),
    (16384,  'StagingBitmask', 'DomainInactive',        'Attribute', 'Domain value inactive (placeholder)',            'Not implemented'),
    (32768,  'StagingBitmask', 'NewCodeAlreadyExists',  'NewCode',   'NewCode already exists in production',           'usp_Staging_ProcessBatch (step 2g)'),
    (65536,  'StagingBitmask', 'DuplicateNewCode',      'NewCode',   'Duplicate NewCode in batch',                     'usp_Staging_ProcessBatch (step 2h)'),
    (131072, 'StagingBitmask', 'ProcessingFailed',      'System',    'Processing failed (system error in CATCH block)', 'usp_Staging_ProcessBatch (CATCH handler)');
END
GO

-- ============================================
-- SCHEDULERCONFIGURATIONS
-- One row per entity with scheduler settings.
-- Nullable EntityId reserved for future non-entity tasks.
-- ============================================
CREATE TABLE SchedulerConfigurations (
    Id                      INT IDENTITY(1,1) PRIMARY KEY,
    EntityId                INT NULL REFERENCES Entities(Id),

    -- Mode: 'manual' | 'scheduled' | 'triggered'
    ProcessingMode          NVARCHAR(20) NOT NULL DEFAULT 'manual',

    -- Scheduled mode settings
    ScheduleType            NVARCHAR(20) NULL,      -- 'interval' | 'daily' | 'weekly' | 'monthly'
    IntervalMinutes         INT NULL,               -- For interval schedule type
    RunTimes                NVARCHAR(200) NULL,     -- Comma-separated HH:mm times
    RunDays                 NVARCHAR(100) NULL,     -- Comma-separated day names (Mon,Tue,...)
    RunDaysOfMonth          NVARCHAR(100) NULL,     -- Comma-separated day numbers (1,15,...)

    -- Trigger mode settings
    TriggerOnNewRows        BIT NOT NULL DEFAULT 0,
    TriggerRowThreshold     INT NULL,               -- Fire when N rows queued
    TriggerIdleMinutes      INT NULL,               -- Fire when rows have waited N minutes
    TriggerDebounceSeconds  INT NOT NULL DEFAULT 60,
    ZombieTimeoutMinutes    INT NOT NULL DEFAULT 30,

    -- Overlap guard and run tracking
    IsRunning               BIT NOT NULL DEFAULT 0,
    RunStartedAt            DATETIME2 NULL,
    RunStartedBy            NVARCHAR(50) NULL,      -- 'Manual' | 'Schedule' | 'Trigger: reason'

    -- Schedule tracking
    NextScheduledRun        DATETIME2 NULL,
    LastCompletedAt         DATETIME2 NULL,
    LastTriggerCheck        DATETIME2 NULL,

    -- Status
    IsEnabled               BIT NOT NULL DEFAULT 1,
    CreatedAt               DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    ModifiedAt              DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),

    CONSTRAINT UQ_SchedulerConfig_EntityId UNIQUE (EntityId)
);
GO

-- ============================================
-- SCHEDULERLOG
-- Audit trail of every dispatcher action per entity.
-- ============================================
CREATE TABLE SchedulerLog (
    Id              INT IDENTITY(1,1) PRIMARY KEY,
    EntityId        INT NOT NULL,
    EventTime       DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    EventType       NVARCHAR(30) NOT NULL,   -- 'fired' | 'skipped' | 'error' | 'completed' | 'zombie'
    TriggerSource   NVARCHAR(100) NULL,
    Message         NVARCHAR(500) NULL,
    RowsQueued      INT NULL,
    DurationMs      INT NULL,
    BatchId         INT NULL
);
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_SchedulerLog_EntityId_EventTime' AND object_id = OBJECT_ID('SchedulerLog'))
    CREATE NONCLUSTERED INDEX IX_SchedulerLog_EntityId_EventTime ON SchedulerLog (EntityId, EventTime DESC);
GO

-- ============================================
-- SYSTEM CONFIG
-- ============================================
CREATE TABLE SystemConfig (
    Id          INT IDENTITY(1,1) CONSTRAINT PK_SystemConfig PRIMARY KEY,
    ConfigKey   NVARCHAR(64)  NOT NULL,
    ConfigValue DATETIME2     NOT NULL,
    Metadata    NVARCHAR(200) NULL,
    UpdatedAt   DATETIME2     NULL,
    CreatedAt   DATETIME2     NOT NULL DEFAULT GETUTCDATE()
);
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'UQ_SystemConfig_ConfigKey' AND object_id = OBJECT_ID('SystemConfig'))
    CREATE UNIQUE INDEX UQ_SystemConfig_ConfigKey ON SystemConfig(ConfigKey);
GO

-- ============================================
-- UNIQUE CONSTRAINTS
-- ============================================
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'UQ_Models_Name')
    ALTER TABLE Models ADD CONSTRAINT UQ_Models_Name UNIQUE (Name);

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'UQ_Entities_ModelId_Name')
    ALTER TABLE Entities ADD CONSTRAINT UQ_Entities_ModelId_Name UNIQUE (ModelId, Name);
GO

-- ============================================
-- ERROR LOG
-- ============================================
CREATE TABLE ErrorLog (
    Id          BIGINT IDENTITY(1,1) CONSTRAINT PK_ErrorLog PRIMARY KEY,
    Timestamp   DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    Level       NVARCHAR(10) NOT NULL DEFAULT 'error',
    Method      NVARCHAR(10) NULL,
    Path        NVARCHAR(500) NULL,
    StatusCode  INT NULL,
    Message     NVARCHAR(MAX) NULL,
    Stack       NVARCHAR(MAX) NULL,
    UserId      INT NULL,
    RequestBody NVARCHAR(MAX) NULL,
    Duration    INT NULL
);
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ErrorLog_Timestamp' AND object_id = OBJECT_ID('ErrorLog'))
    CREATE NONCLUSTERED INDEX IX_ErrorLog_Timestamp ON ErrorLog (Timestamp DESC);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_ErrorLog_Level' AND object_id = OBJECT_ID('ErrorLog'))
    CREATE NONCLUSTERED INDEX IX_ErrorLog_Level ON ErrorLog (Level);
GO

-- ============================================
-- MODEL PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_Model_GetAll
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns all models ordered by SortOrder then Name,
--              including all metadata columns.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Id, Name, Description, IsActive, SortOrder, CreatedAt, ModifiedAt
    FROM Models ORDER BY SortOrder, Name;
END;
GO

CREATE OR ALTER PROCEDURE usp_Model_Create
    @Name NVARCHAR(200),
    @Description NVARCHAR(500) = NULL,
    @IsActive BIT = 1,
    @SortOrder INT = 0,
    @CreatedAt DATETIME2 = NULL,
    @ModifiedAt DATETIME2 = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Creates a new model and returns the inserted row
--              including all metadata columns. Optional @CreatedAt
--              and @ModifiedAt allow preserving original timestamps
--              during migration (defaults to GETUTCDATE() when NULL).
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v1.1  2026-02-17  Added optional CreatedAt/ModifiedAt override for migration
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO Models (Name, Description, IsActive, SortOrder, CreatedAt, ModifiedAt)
    OUTPUT INSERTED.Id, INSERTED.Name, INSERTED.Description, INSERTED.IsActive, INSERTED.SortOrder, INSERTED.CreatedAt, INSERTED.ModifiedAt
    VALUES (@Name, @Description, @IsActive, @SortOrder, COALESCE(@CreatedAt, GETUTCDATE()), COALESCE(@ModifiedAt, GETUTCDATE()));
END;
GO

CREATE OR ALTER PROCEDURE usp_Model_Update
    @Id INT,
    @Name NVARCHAR(200) = NULL,
    @Description NVARCHAR(500) = NULL,
    @IsActive BIT = NULL,
    @SortOrder INT = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Updates an existing model's fields. NULL parameters are
--              ignored for most fields (preserving the existing value),
--              except @Description which is intentionally set to NULL
--              when passed as NULL to allow clearing the description.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Models SET
        Name = COALESCE(@Name, Name),
        Description = @Description,
        IsActive = COALESCE(@IsActive, IsActive),
        SortOrder = COALESCE(@SortOrder, SortOrder),
        ModifiedAt = GETUTCDATE()
    OUTPUT INSERTED.Id, INSERTED.Name, INSERTED.Description, INSERTED.IsActive, INSERTED.SortOrder, INSERTED.CreatedAt, INSERTED.ModifiedAt
    WHERE Id = @Id;
END;
GO

CREATE OR ALTER PROCEDURE usp_Model_DeleteDataBatch
    @Id        INT,
    @BatchSize INT = 50000
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-02
-- Description: Deletes one batch of data rows across ALL entities in a model.
--              Called in a loop by the API with per-batch commits to avoid
--              lock exhaustion on large models.
--
--              Order: EntityValues → ApprovalRows → EntityRows.
--              Each call auto-commits its batch. Returns BatchDeleted and Phase.
--
-- Change History:
--   v1.0  2026-03-02  Initial version — mirrors usp_Entity_DeleteDataBatch
--                     but scopes to all entities in the model
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Deleted INT = 0;

    -- Phase 1: EntityValues (heaviest table)
    DELETE TOP (@BatchSize) ev
    FROM EntityValues ev
    INNER JOIN EntityRows er ON er.Id = ev.EntityRowId
    INNER JOIN Entities e ON e.Id = er.EntityId
    WHERE e.ModelId = @Id;
    SET @Deleted = @@ROWCOUNT;

    IF @Deleted > 0
    BEGIN
        SELECT @Deleted AS BatchDeleted, N'values' AS Phase;
        RETURN;
    END

    -- Phase 2: ApprovalRows
    DELETE TOP (@BatchSize) ar
    FROM ApprovalRows ar
    INNER JOIN EntityRows er ON er.Id = ar.EntityRowId
    INNER JOIN Entities e ON e.Id = er.EntityId
    WHERE e.ModelId = @Id;
    SET @Deleted = @@ROWCOUNT;

    IF @Deleted > 0
    BEGIN
        SELECT @Deleted AS BatchDeleted, N'approvals' AS Phase;
        RETURN;
    END

    -- Phase 3: EntityRows (EntityValues already gone — CASCADE is a no-op)
    DELETE TOP (@BatchSize) FROM EntityRows
    WHERE EntityId IN (SELECT Id FROM Entities WHERE ModelId = @Id);
    SET @Deleted = @@ROWCOUNT;

    SELECT @Deleted AS BatchDeleted, N'rows' AS Phase;
END;
GO

CREATE OR ALTER PROCEDURE usp_Model_Delete
    @Id INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Lightweight metadata cleanup + final model deletion.
--              Heavy data (EntityValues, ApprovalRows, EntityRows) must be
--              removed first via usp_Model_DeleteDataBatch.
--
--              Still includes fallback deletes for small models where the
--              API may skip the batch loop.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v1.1  2026-03-02  Batch-delete EntityValues, ApprovalRows, EntityRows
--                     in 50 000-row chunks to prevent timeouts on large models
--   v1.2  2026-03-02  Moved heavy data deletion to usp_Model_DeleteDataBatch;
--                     this SP now handles only metadata + final entity/model removal
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRANSACTION;
    BEGIN TRY
        -- Materialize entity IDs once to avoid repeated subquery evaluation
        SELECT Id INTO #ModelEntityIds FROM Entities WHERE ModelId = @Id;

        -- Clean up integration views for entities in this model
        DELETE FROM IntegrationViews
        WHERE EntityId IN (SELECT Id FROM #ModelEntityIds);

        -- Clean up audit log entries for entities in this model
        DELETE FROM AuditLog WHERE EntityId IN (SELECT Id FROM #ModelEntityIds);

        -- Clean up orphaned permissions for entities in this model
        DELETE FROM Permissions WHERE Scope = 'entity' AND TargetId IN (SELECT Id FROM #ModelEntityIds);

        -- Clean up model-level permissions
        DELETE FROM Permissions WHERE Scope = 'model' AND TargetId = @Id;

        -- Fallback: delete any remaining data rows (small models, or if batch loop was skipped)
        DELETE ev FROM EntityValues ev
        INNER JOIN EntityRows er ON er.Id = ev.EntityRowId
        WHERE er.EntityId IN (SELECT Id FROM #ModelEntityIds);

        DELETE ar FROM ApprovalRows ar
        INNER JOIN EntityRows er ON er.Id = ar.EntityRowId
        WHERE er.EntityId IN (SELECT Id FROM #ModelEntityIds);

        DELETE FROM EntityRows WHERE EntityId IN (SELECT Id FROM #ModelEntityIds);

        -- Approval history for the model's entities. Same reason as in usp_Entity_Delete:
        -- ApprovalRequests.EntityId has no ON DELETE CASCADE, so a model containing an entity
        -- that ever went through an approval could not be deleted. Clear the self-reference
        -- first; ApprovalRows and ApprovalReviews cascade from the request.
        UPDATE ApprovalRequests SET PreviousRequestId = NULL
        WHERE PreviousRequestId IN (SELECT Id FROM ApprovalRequests WHERE EntityId IN (SELECT Id FROM #ModelEntityIds));
        DELETE FROM ApprovalRequests WHERE EntityId IN (SELECT Id FROM #ModelEntityIds);

        DELETE FROM EntityApprovers WHERE EntityId IN (SELECT Id FROM #ModelEntityIds);

        -- Delete entities and model
        DELETE FROM Entities WHERE ModelId = @Id;
        DELETE FROM Models WHERE Id = @Id;
        DECLARE @Deleted INT = @@ROWCOUNT;

        DROP TABLE #ModelEntityIds;
        COMMIT TRANSACTION;
        SELECT @Deleted AS Deleted;
    END TRY
    BEGIN CATCH
        IF OBJECT_ID('tempdb..#ModelEntityIds') IS NOT NULL DROP TABLE #ModelEntityIds;
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Model_Reorder
    @OrderJson NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Bulk-updates SortOrder for a set of models provided as
--              a JSON array of {id, sortOrder} objects. Used by the
--              drag-and-drop reorder UI.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE m SET m.SortOrder = j.sortOrder, m.ModifiedAt = GETUTCDATE()
    FROM Models m
    INNER JOIN OPENJSON(@OrderJson) WITH (id INT '$.id', sortOrder INT '$.sortOrder') j ON m.Id = j.id;
    SELECT @@ROWCOUNT AS Updated;
END;
GO

-- ============================================
-- ENTITY PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_Entity_GetAll
    @ModelId INT = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns all entities and their attributes, optionally
--              filtered by model. Produces two result sets: (1) entities
--              and (2) attributes for those entities. The frontend
--              consumes both in a single call to avoid N+1 lookups.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    -- Result set 1: entities
    SELECT e.Id, e.ModelId, m.Name AS ModelName, e.Name, e.Description, e.TableName, e.SortOrder, e.IsActive, e.RequiresApproval, e.ApproverCanApproveOwn, e.ApprovalStrategy, e.SharedAcrossModels, e.AutoGenerateCode, e.CreatedAt, e.ModifiedAt,
           CAST(CASE WHEN sc.EntityId IS NOT NULL THEN 1 ELSE 0 END AS BIT) AS HasStaging
    FROM Entities e
    LEFT JOIN Models m ON m.Id = e.ModelId
    LEFT JOIN StagingConfigurations sc ON sc.EntityId = e.Id
    WHERE (@ModelId IS NULL OR e.ModelId = @ModelId)
    ORDER BY e.ModelId, e.SortOrder, e.Name;
    -- Result set 2: attributes for those entities
    SELECT a.Id, a.EntityId, a.DisplayName, a.Name, a.DataType, a.MaxLength, a.IsRequired, a.IsCode, a.IsName, a.IsHidden, a.IsSystemDate, a.SortOrder, a.DomainEntityId, a.DomainParentAttributeId, a.DateFormat, a.BooleanDisplayFormat, a.DecimalPlaces, a.AllowNegative, a.Description, a.CreatedAt, a.ModifiedAt FROM Attributes a
    INNER JOIN Entities e ON e.Id = a.EntityId
    WHERE (@ModelId IS NULL OR e.ModelId = @ModelId)
    ORDER BY a.EntityId, a.SortOrder;
END;
GO

CREATE OR ALTER PROCEDURE usp_Entity_GetById
    @Id INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns a single entity by its primary key plus all of
--              its attributes ordered by SortOrder. Produces two result
--              sets: (1) entity metadata, (2) attribute list.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT e.Id, e.ModelId, m.Name AS ModelName, e.Name, e.Description, e.TableName, e.SortOrder, e.IsActive, e.RequiresApproval, e.ApproverCanApproveOwn, e.ApprovalStrategy, e.SharedAcrossModels, e.AutoGenerateCode, e.CreatedAt, e.ModifiedAt FROM Entities e LEFT JOIN Models m ON m.Id = e.ModelId WHERE e.Id = @Id;
    SELECT Id, EntityId, DisplayName, Name, DataType, MaxLength, IsRequired, IsCode, IsName, IsHidden, IsSystemDate, SortOrder, DomainEntityId, DomainParentAttributeId, DateFormat, BooleanDisplayFormat, DecimalPlaces, AllowNegative, Description, CreatedAt, ModifiedAt FROM Attributes WHERE EntityId = @Id ORDER BY SortOrder;
END;
GO

CREATE OR ALTER PROCEDURE usp_Entity_GetByName
    @Name NVARCHAR(200)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Looks up an entity's Id by its exact Name. Used during
--              import to resolve entity references by name.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Id FROM Entities WHERE Name = @Name;
END;
GO

CREATE OR ALTER PROCEDURE usp_Entity_Create
    @ModelId INT,
    @Name NVARCHAR(200),
    @Description NVARCHAR(500) = NULL,
    @TableName NVARCHAR(128) = NULL,
    @SortOrder INT = 0,
    @IsActive BIT = 1,
    @RequiresApproval BIT = 0,
    @SharedAcrossModels BIT = 0,
    @AutoGenerateCode BIT = 0,
    @AttributesJson NVARCHAR(MAX) = NULL,
    @CreatedAt DATETIME2 = NULL,
    @ModifiedAt DATETIME2 = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Creates a new entity within a model, optionally with an
--              initial set of attributes supplied as a JSON array. TableName
--              defaults to the entity name with spaces replaced by underscores
--              if not provided. Optional @CreatedAt/@ModifiedAt allow preserving
--              original timestamps during migration. Attributes in the JSON array
--              may include description and timestamp fields. Returns the created
--              entity and its attributes as two result sets.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v1.1  2026-02-17  Added Description, CreatedAt, ModifiedAt for attributes + entity timestamp override
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        DECLARE @EntityId INT;
        INSERT INTO Entities (ModelId, Name, Description, TableName, SortOrder, IsActive, RequiresApproval, SharedAcrossModels, AutoGenerateCode, CreatedAt, ModifiedAt)
        VALUES (@ModelId, @Name, @Description, COALESCE(@TableName, REPLACE(@Name, ' ', '_')), @SortOrder, @IsActive, @RequiresApproval, @SharedAcrossModels, @AutoGenerateCode, COALESCE(@CreatedAt, GETUTCDATE()), COALESCE(@ModifiedAt, GETUTCDATE()));
        SET @EntityId = SCOPE_IDENTITY();

        -- Bulk-insert initial attributes when provided (e.g. during migration import)
        IF @AttributesJson IS NOT NULL
        BEGIN
            INSERT INTO Attributes (EntityId, DisplayName, Name, DataType, MaxLength, IsRequired, IsCode, IsName, IsHidden, SortOrder, DomainEntityId, DomainParentAttributeId, DateFormat, BooleanDisplayFormat, DecimalPlaces, AllowNegative, Description, CreatedAt, ModifiedAt)
            SELECT @EntityId, j.displayName, COALESCE(j.name, REPLACE(j.displayName, ' ', '')), COALESCE(j.dataType, 'Text'),
                   j.maxLength, ISNULL(j.isRequired, 0), ISNULL(j.isCode, 0), ISNULL(j.isName, 0), ISNULL(j.isHidden, 0),
                   ISNULL(j.sortOrder, 0), j.domainEntityId, j.domainParentAttributeId, j.dateFormat, j.booleanDisplayFormat, j.decimalPlaces, j.allowNegative, j.description,
                   COALESCE(TRY_CAST(j.createdAt AS DATETIME2), GETUTCDATE()),
                   COALESCE(TRY_CAST(j.modifiedAt AS DATETIME2), GETUTCDATE())
            FROM OPENJSON(@AttributesJson) WITH (
                displayName NVARCHAR(200), name NVARCHAR(128), dataType NVARCHAR(20),
                maxLength INT, isRequired BIT, isCode BIT, isName BIT, isHidden BIT,
                sortOrder INT, domainEntityId INT, domainParentAttributeId INT, dateFormat NVARCHAR(20), booleanDisplayFormat NVARCHAR(20),
                decimalPlaces INT, allowNegative BIT, description NVARCHAR(500),
                createdAt NVARCHAR(30), modifiedAt NVARCHAR(30)
            ) j;
        END

        -- Auto-insert system date attributes (always hidden by default, read-only in grid)
        IF NOT EXISTS (SELECT 1 FROM Attributes WHERE EntityId = @EntityId AND IsSystemDate = 1 AND Name = 'createdAt')
            INSERT INTO Attributes (EntityId, DisplayName, Name, DataType, IsRequired, IsCode, IsName, IsHidden, IsSystemDate, SortOrder, Description)
            VALUES (@EntityId, 'Created', 'createdAt', 'DateTime', 0, 0, 0, 1, 1, 9998, 'Date this record was created');
        IF NOT EXISTS (SELECT 1 FROM Attributes WHERE EntityId = @EntityId AND IsSystemDate = 1 AND Name = 'modifiedAt')
            INSERT INTO Attributes (EntityId, DisplayName, Name, DataType, IsRequired, IsCode, IsName, IsHidden, IsSystemDate, SortOrder, Description)
            VALUES (@EntityId, 'Last Modified', 'modifiedAt', 'DateTime', 0, 0, 0, 1, 1, 9999, 'Date this record was last modified');

        COMMIT TRANSACTION;
        -- Return entity + attributes
        SELECT Id, ModelId, Name, Description, TableName, SortOrder, IsActive, RequiresApproval, ApproverCanApproveOwn, ApprovalStrategy, SharedAcrossModels, AutoGenerateCode, CreatedAt, ModifiedAt FROM Entities WHERE Id = @EntityId;
        SELECT Id, EntityId, DisplayName, Name, DataType, MaxLength, IsRequired, IsCode, IsName, IsHidden, IsSystemDate, SortOrder, DomainEntityId, DomainParentAttributeId, DateFormat, BooleanDisplayFormat, DecimalPlaces, AllowNegative, Description, CreatedAt, ModifiedAt FROM Attributes WHERE EntityId = @EntityId ORDER BY SortOrder;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Entity_Update
    @Id INT,
    @Name NVARCHAR(200) = NULL,
    @Description NVARCHAR(500) = NULL,
    @TableName NVARCHAR(128) = NULL,
    @SortOrder INT = NULL,
    @IsActive BIT = NULL,
    @RequiresApproval BIT = NULL,
    @ApproverCanApproveOwn BIT = NULL,
    @ApprovalStrategy NVARCHAR(20) = NULL,
    @SharedAcrossModels BIT = NULL,
    @AutoGenerateCode BIT = NULL,
    @AttributesJson NVARCHAR(MAX) = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Updates an entity's metadata and optionally performs a
--              full attribute sync. When @AttributesJson is supplied, the
--              SP deletes removed attributes, updates existing ones (matched
--              by Id), and inserts new ones (no Id). @Description is a
--              deliberate NULL-override: passing NULL clears the field.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        UPDATE Entities SET
            Name = COALESCE(@Name, Name),
            Description = @Description,
            TableName = COALESCE(@TableName, TableName),
            SortOrder = COALESCE(@SortOrder, SortOrder),
            IsActive = COALESCE(@IsActive, IsActive),
            RequiresApproval = COALESCE(@RequiresApproval, RequiresApproval),
            ApproverCanApproveOwn = COALESCE(@ApproverCanApproveOwn, ApproverCanApproveOwn),
            ApprovalStrategy = COALESCE(@ApprovalStrategy, ApprovalStrategy),
            SharedAcrossModels = COALESCE(@SharedAcrossModels, SharedAcrossModels),
            AutoGenerateCode = COALESCE(@AutoGenerateCode, AutoGenerateCode),
            ModifiedAt = GETUTCDATE()
        WHERE Id = @Id;

        IF @@ROWCOUNT = 0
        BEGIN
            IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
            THROW 50002, 'Entity not found', 1;
        END

        IF @AttributesJson IS NOT NULL
        BEGIN
            -- Parse incoming attributes into temp table
            SELECT id, displayName, name, dataType, maxLength, isRequired, isCode, isName, isHidden, sortOrder, domainEntityId, domainParentAttributeId, dateFormat, booleanDisplayFormat, decimalPlaces, allowNegative, description
            INTO #IncomingAttrs
            FROM OPENJSON(@AttributesJson) WITH (
                id INT, displayName NVARCHAR(200), name NVARCHAR(128), dataType NVARCHAR(20),
                maxLength INT, isRequired BIT, isCode BIT, isName BIT, isHidden BIT,
                sortOrder INT, domainEntityId INT, domainParentAttributeId INT, dateFormat NVARCHAR(20), booleanDisplayFormat NVARCHAR(20),
                decimalPlaces INT, allowNegative BIT, description NVARCHAR(500)
            );

            -- Delete custom attributes not in incoming set (never delete system date attrs)
            DELETE FROM Attributes
            WHERE EntityId = @Id
              AND IsSystemDate = 0
              AND Id NOT IN (SELECT id FROM #IncomingAttrs WHERE id IS NOT NULL);

            -- Update custom attributes (full field update)
            UPDATE a SET
                a.DisplayName = i.displayName, a.Name = COALESCE(i.name, a.Name),
                a.DataType = COALESCE(i.dataType, a.DataType), a.MaxLength = i.maxLength,
                a.IsRequired = ISNULL(i.isRequired, 0), a.IsCode = ISNULL(i.isCode, 0),
                a.IsName = ISNULL(i.isName, 0), a.IsHidden = ISNULL(i.isHidden, 0), a.SortOrder = ISNULL(i.sortOrder, 0),
                a.DomainEntityId = i.domainEntityId,
                a.DomainParentAttributeId = i.domainParentAttributeId,
                a.DateFormat = i.dateFormat,
                a.BooleanDisplayFormat = i.booleanDisplayFormat,
                a.DecimalPlaces = i.decimalPlaces,
                a.AllowNegative = i.allowNegative,
                a.Description = i.description,
                a.ModifiedAt = GETUTCDATE()
            FROM Attributes a INNER JOIN #IncomingAttrs i ON a.Id = i.id
            WHERE a.EntityId = @Id AND a.IsSystemDate = 0;

            -- Update system date attrs: only allow toggling IsHidden
            UPDATE a SET
                a.IsHidden = ISNULL(i.isHidden, a.IsHidden),
                a.ModifiedAt = GETUTCDATE()
            FROM Attributes a INNER JOIN #IncomingAttrs i ON a.Id = i.id
            WHERE a.EntityId = @Id AND a.IsSystemDate = 1;

            -- Insert new custom attributes (no id, never system date)
            INSERT INTO Attributes (EntityId, DisplayName, Name, DataType, MaxLength, IsRequired, IsCode, IsName, IsHidden, SortOrder, DomainEntityId, DomainParentAttributeId, DateFormat, BooleanDisplayFormat, DecimalPlaces, AllowNegative, Description)
            SELECT @Id, displayName, COALESCE(name, REPLACE(displayName, ' ', '')), COALESCE(dataType, 'Text'),
                   maxLength, ISNULL(isRequired, 0), ISNULL(isCode, 0), ISNULL(isName, 0), ISNULL(isHidden, 0),
                   ISNULL(sortOrder, 0), domainEntityId, domainParentAttributeId, dateFormat, booleanDisplayFormat, decimalPlaces, allowNegative, description
            FROM #IncomingAttrs WHERE id IS NULL;

            DROP TABLE #IncomingAttrs;
        END

        COMMIT TRANSACTION;
        SELECT Id, ModelId, Name, Description, TableName, SortOrder, IsActive, RequiresApproval, ApproverCanApproveOwn, ApprovalStrategy, SharedAcrossModels, AutoGenerateCode, CreatedAt, ModifiedAt FROM Entities WHERE Id = @Id;
        SELECT Id, EntityId, DisplayName, Name, DataType, MaxLength, IsRequired, IsCode, IsName, IsHidden, IsSystemDate, SortOrder, DomainEntityId, DomainParentAttributeId, DateFormat, BooleanDisplayFormat, DecimalPlaces, AllowNegative, Description, CreatedAt, ModifiedAt FROM Attributes WHERE EntityId = @Id ORDER BY SortOrder;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- ============================================
-- ENTITY DERIVED COLUMNS
-- ============================================

CREATE TABLE EntityDerivedColumns (
    Id            INT IDENTITY(1,1) CONSTRAINT PK_EntityDerivedColumns PRIMARY KEY,
    EntityId      INT NOT NULL REFERENCES Entities(Id) ON DELETE CASCADE,
    DisplayName   NVARCHAR(200) NOT NULL,
    AttributePath NVARCHAR(MAX) NOT NULL,
    SortOrder     INT NOT NULL DEFAULT 0,
    CreatedAt     DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO

CREATE OR ALTER PROCEDURE usp_EntityDerivedColumns_Get
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-27
-- Description: Returns all derived column definitions for an entity.
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Id, EntityId, DisplayName, AttributePath, SortOrder, CreatedAt
    FROM EntityDerivedColumns
    WHERE EntityId = @EntityId
    ORDER BY SortOrder, Id;
END;
GO

CREATE OR ALTER PROCEDURE usp_EntityDerivedColumns_Save
    @EntityId     INT,
    @Id           INT = NULL,
    @DisplayName  NVARCHAR(200),
    @AttributePath NVARCHAR(MAX),
    @SortOrder    INT = 0
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-27
-- Description: Upserts a derived column definition. Returns the saved row.
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    IF @Id IS NOT NULL AND EXISTS (SELECT 1 FROM EntityDerivedColumns WHERE Id = @Id AND EntityId = @EntityId)
    BEGIN
        UPDATE EntityDerivedColumns
        SET DisplayName = @DisplayName, AttributePath = @AttributePath, SortOrder = @SortOrder
        WHERE Id = @Id AND EntityId = @EntityId;
        SELECT Id, EntityId, DisplayName, AttributePath, SortOrder, CreatedAt FROM EntityDerivedColumns WHERE Id = @Id;
    END
    ELSE
    BEGIN
        INSERT INTO EntityDerivedColumns (EntityId, DisplayName, AttributePath, SortOrder)
        OUTPUT INSERTED.Id, INSERTED.EntityId, INSERTED.DisplayName, INSERTED.AttributePath, INSERTED.SortOrder, INSERTED.CreatedAt
        VALUES (@EntityId, @DisplayName, @AttributePath, @SortOrder);
    END
END;
GO

CREATE OR ALTER PROCEDURE usp_EntityDerivedColumns_Delete
    @Id       INT,
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-27
-- Description: Deletes a single derived column definition.
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM EntityDerivedColumns WHERE Id = @Id AND EntityId = @EntityId;
    SELECT @@ROWCOUNT AS Deleted;
END;
GO

SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE usp_Entity_CheckDomainUsage
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-26
-- Description: Returns all attributes and derived columns in other entities
--              that reference @EntityId. Used to warn before deletion.
--
-- Change History:
--   v1.0  2026-02-26  Initial version — domain attributes only
--   v1.1  2026-02-27  Added derived column path references
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    -- Domain attribute references
    SELECT
        a.Id              AS AttributeId,
        a.DisplayName     AS AttributeName,
        e.Id              AS UsedInEntityId,
        e.Name            AS UsedInEntityName,
        'domain'          AS UsageType,
        NULL              AS DerivedColumnId,
        NULL              AS DerivedColumnName
    FROM Attributes a
    JOIN Entities e ON a.EntityId = e.Id
    WHERE a.DomainEntityId = @EntityId
    UNION ALL
    -- Derived column references (any attribute in the path belongs to @EntityId)
    SELECT
        NULL              AS AttributeId,
        NULL              AS AttributeName,
        e.Id              AS UsedInEntityId,
        e.Name            AS UsedInEntityName,
        'derived'         AS UsageType,
        dc.Id             AS DerivedColumnId,
        dc.DisplayName    AS DerivedColumnName
    FROM EntityDerivedColumns dc
    JOIN Entities e ON dc.EntityId = e.Id
    CROSS APPLY OPENJSON(dc.AttributePath) WITH (AttrId INT '$') ap
    JOIN Attributes a ON a.Id = ap.AttrId
    WHERE a.EntityId = @EntityId;
END;
GO

SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE usp_Entity_DeleteDataBatch
    @Id        INT,
    @BatchSize INT = 50000
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-02
-- Description: Deletes one batch of data rows for an entity. Called in a
--              loop by the API (like CloneDataBatch) with per-batch commits
--              to avoid lock exhaustion on large entities.
--
--              Order: EntityValues → ApprovalRows → EntityRows.
--              Each call auto-commits its batch. Returns only BatchDeleted
--              and Phase — no expensive COUNT(*) per batch.
--
-- Change History:
--   v1.0  2026-03-02  Initial version — split from usp_Entity_Delete to
--                     support multi-million row entities without lock
--                     exhaustion or timeouts
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Deleted INT = 0;

    -- Phase 1: EntityValues (heaviest table — typically 5-20x EntityRows)
    DELETE TOP (@BatchSize) ev
    FROM EntityValues ev
    INNER JOIN EntityRows er ON er.Id = ev.EntityRowId
    WHERE er.EntityId = @Id;
    SET @Deleted = @@ROWCOUNT;

    IF @Deleted > 0
    BEGIN
        SELECT @Deleted AS BatchDeleted, N'values' AS Phase;
        RETURN;
    END

    -- Phase 2: ApprovalRows
    DELETE TOP (@BatchSize) ar
    FROM ApprovalRows ar
    INNER JOIN EntityRows er ON er.Id = ar.EntityRowId
    WHERE er.EntityId = @Id;
    SET @Deleted = @@ROWCOUNT;

    IF @Deleted > 0
    BEGIN
        SELECT @Deleted AS BatchDeleted, N'approvals' AS Phase;
        RETURN;
    END

    -- Phase 3: EntityRows (EntityValues already gone — CASCADE is a no-op)
    DELETE TOP (@BatchSize) FROM EntityRows WHERE EntityId = @Id;
    SET @Deleted = @@ROWCOUNT;

    SELECT @Deleted AS BatchDeleted, N'rows' AS Phase;
END;
GO

CREATE OR ALTER PROCEDURE usp_Entity_Delete
    @Id         INT,
    @ClearDomain BIT = 0,
    @UserId     INT = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Final step of entity deletion: cleans up metadata
--              (domain refs, permissions, integration views) and deletes
--              the entity itself. All heavy data (EntityValues, ApprovalRows,
--              EntityRows) must be removed first via usp_Entity_DeleteDataBatch.
--              When @ClearDomain = 1, clears domain FK references in other
--              entities before deleting.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v1.1  2026-02-26  Added @ClearDomain param to support safe deletion
--                     of entities used as domain sources
--   v1.2  2026-03-01  Added @UserId, audit log entry for delete, stopped
--                     destroying audit history (FK ON DELETE SET NULL
--                     handles it automatically)
--   v1.3  2026-03-02  Moved heavy data deletion to usp_Entity_DeleteDataBatch;
--                     this SP now handles only lightweight metadata cleanup
--   v1.4  2026-03-04  Delete SchedulerConfigurations row before entity deletion
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- Capture entity metadata before deletion for audit trail
    DECLARE @EntityName NVARCHAR(200);
    DECLARE @ModelName  NVARCHAR(200);
    DECLARE @RowCount   INT;

    SELECT @EntityName = e.Name, @ModelName = m.Name
    FROM   Entities e
    INNER JOIN Models m ON m.Id = e.ModelId
    WHERE  e.Id = @Id;

    SELECT @RowCount = COUNT(*) FROM EntityRows WHERE EntityId = @Id;

    -- Precondition: if this entity is used as a domain source, the caller must
    -- set @ClearDomain = 1.  The API enforces this via usp_Entity_CheckDomainUsage.
    BEGIN TRANSACTION;
    BEGIN TRY
        IF @ClearDomain = 1
        BEGIN
            UPDATE ev SET ev.IntValue = NULL
            FROM EntityValues ev
            JOIN Attributes a ON a.Id = ev.AttributeId
            WHERE a.DomainEntityId = @Id;
            UPDATE Attributes SET DomainEntityId = NULL WHERE DomainEntityId = @Id;
            DELETE dc FROM EntityDerivedColumns dc
            WHERE EXISTS (
                SELECT 1 FROM OPENJSON(dc.AttributePath) WITH (AttrId INT '$') ap
                JOIN Attributes a ON a.Id = ap.AttrId
                WHERE a.EntityId = @Id
            );
        END

        UPDATE Attributes SET DomainParentAttributeId = NULL
        WHERE DomainParentAttributeId IN (SELECT Id FROM Attributes WHERE EntityId = @Id);

        DELETE FROM IntegrationViews WHERE EntityId = @Id;
        DELETE FROM Permissions WHERE Scope = 'entity' AND TargetId = @Id;
        DELETE FROM Permissions WHERE Scope = 'attribute' AND TargetId IN (SELECT Id FROM Attributes WHERE EntityId = @Id);

        -- Approval history for this entity. ApprovalRequests.EntityId has no ON DELETE
        -- CASCADE, so without this an entity that ever went through an approval could not
        -- be deleted at all — the delete failed on the foreign key. ApprovalRows and
        -- ApprovalReviews do cascade from the request, so removing the requests is enough;
        -- PreviousRequestId is a self-reference without cascade and has to be cleared first.
        UPDATE ApprovalRequests SET PreviousRequestId = NULL
        WHERE PreviousRequestId IN (SELECT Id FROM ApprovalRequests WHERE EntityId = @Id);
        DELETE FROM ApprovalRequests WHERE EntityId = @Id;

        DELETE FROM EntityApprovers WHERE EntityId = @Id;

        -- Delete any remaining rows (should be 0 if DeleteDataBatch was called,
        -- but handles small entities where the API skips the batch loop)
        DELETE FROM ApprovalRows WHERE EntityRowId IN (SELECT Id FROM EntityRows WHERE EntityId = @Id);
        DELETE FROM EntityRows WHERE EntityId = @Id;
        DELETE FROM SchedulerConfigurations WHERE EntityId = @Id;
        DELETE FROM Entities WHERE Id = @Id;
        DECLARE @Deleted INT = @@ROWCOUNT;
        COMMIT TRANSACTION;

        IF @Deleted > 0 AND @EntityName IS NOT NULL
        BEGIN
            DECLARE @AuditDetails NVARCHAR(MAX);
            SELECT @AuditDetails = (
                SELECT @Id AS entityId, @EntityName AS entityName, @ModelName AS modelName, @ClearDomain AS clearDomain, @RowCount AS rowsDeleted
                FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
            );
            INSERT INTO AuditLog (EntityId, EntityName, ModelName, Action, RecordCount, UserId, Details)
            VALUES (NULL, @EntityName, @ModelName, N'delete', @RowCount, @UserId, @AuditDetails);
        END

        SELECT @Deleted AS Deleted;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Entity_Reorder
    @OrderJson NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Bulk-updates SortOrder for a set of entities provided as
--              a JSON array of {id, sortOrder} objects. Used by the
--              drag-and-drop reorder UI within a model.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE e SET e.SortOrder = j.sortOrder, e.ModifiedAt = GETUTCDATE()
    FROM Entities e
    INNER JOIN OPENJSON(@OrderJson) WITH (id INT '$.id', sortOrder INT '$.sortOrder') j ON e.Id = j.id;
    SELECT @@ROWCOUNT AS Updated;
END;
GO

-- ============================================
-- ATTRIBUTE PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_Attribute_GetByEntity
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns all attributes for a given entity, ordered by
--              SortOrder. Used when the attribute list is needed independently
--              of the full entity load.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Id, EntityId, DisplayName, Name, DataType, MaxLength, IsRequired, IsCode, IsName, IsHidden, IsSystemDate, SortOrder, DomainEntityId, DomainParentAttributeId, DateFormat, BooleanDisplayFormat, DecimalPlaces, AllowNegative, Description, CreatedAt, ModifiedAt FROM Attributes WHERE EntityId = @EntityId ORDER BY SortOrder;
END;
GO

CREATE OR ALTER PROCEDURE usp_Attribute_Create
    @EntityId INT,
    @DisplayName NVARCHAR(200),
    @Name NVARCHAR(128) = NULL,
    @DataType NVARCHAR(20) = 'Text',
    @MaxLength INT = NULL,
    @IsRequired BIT = 0,
    @IsCode BIT = 0,
    @IsName BIT = 0,
    @SortOrder INT = 0,
    @DomainEntityId INT = NULL,
    @DomainParentAttributeId INT = NULL,
    @DateFormat NVARCHAR(20) = NULL,
    @BooleanDisplayFormat NVARCHAR(20) = NULL,
    @DecimalPlaces INT = NULL,
    @AllowNegative BIT = NULL,
    @Description NVARCHAR(500) = NULL,
    @CreatedAt DATETIME2 = NULL,
    @ModifiedAt DATETIME2 = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Creates a single attribute for an entity. If @Name is not
--              provided it is derived from @DisplayName by removing spaces.
--              Code and Name attributes are always forced to IsRequired=1
--              regardless of the input value. Optional @CreatedAt/@ModifiedAt
--              allow preserving original timestamps during migration.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v1.1  2026-02-17  Added Description, CreatedAt, ModifiedAt for migration support
--   v1.2  2026-02-26  Added BooleanDisplayFormat
--   v1.3  2026-02-26  Added DecimalPlaces, AllowNegative
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    -- Force IsRequired for Code/Name
    IF @IsCode = 1 OR @IsName = 1 SET @IsRequired = 1;

    INSERT INTO Attributes (EntityId, DisplayName, Name, DataType, MaxLength, IsRequired, IsCode, IsName, IsHidden, SortOrder, DomainEntityId, DomainParentAttributeId, DateFormat, BooleanDisplayFormat, DecimalPlaces, AllowNegative, Description, CreatedAt, ModifiedAt)
    OUTPUT INSERTED.Id, INSERTED.EntityId, INSERTED.DisplayName, INSERTED.Name,
           INSERTED.DataType, INSERTED.MaxLength, INSERTED.IsRequired,
           INSERTED.IsCode, INSERTED.IsName, INSERTED.IsHidden, INSERTED.IsSystemDate, INSERTED.SortOrder,
           INSERTED.DomainEntityId, INSERTED.DomainParentAttributeId, INSERTED.DateFormat, INSERTED.BooleanDisplayFormat, INSERTED.DecimalPlaces, INSERTED.AllowNegative, INSERTED.Description,
           INSERTED.CreatedAt, INSERTED.ModifiedAt
    VALUES (@EntityId, @DisplayName, COALESCE(@Name, REPLACE(@DisplayName, ' ', '')), @DataType, @MaxLength, @IsRequired, @IsCode, @IsName, 0, @SortOrder, @DomainEntityId, @DomainParentAttributeId, @DateFormat, @BooleanDisplayFormat, @DecimalPlaces, @AllowNegative, @Description, COALESCE(@CreatedAt, GETUTCDATE()), COALESCE(@ModifiedAt, GETUTCDATE()));
END;
GO

CREATE OR ALTER PROCEDURE usp_Attribute_Update
    @Id INT,
    @DisplayName NVARCHAR(200) = NULL,
    @Name NVARCHAR(128) = NULL,
    @DataType NVARCHAR(20) = NULL,
    @MaxLength INT = NULL,
    @IsRequired BIT = NULL,
    @IsCode BIT = NULL,
    @IsName BIT = NULL,
    @SortOrder INT = NULL,
    @DomainEntityId INT = NULL,
    @DomainParentAttributeId INT = NULL,
    @DateFormat NVARCHAR(20) = NULL,
    @BooleanDisplayFormat NVARCHAR(20) = NULL,
    @DecimalPlaces INT = NULL,
    @AllowNegative BIT = NULL,
    @Description NVARCHAR(500) = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Updates a single attribute. @MaxLength, @DomainEntityId,
--              @Description, @DateFormat, @BooleanDisplayFormat, @DecimalPlaces
--              and @AllowNegative are NULL-override fields: passing NULL
--              explicitly clears them. Code and Name attributes are forced
--              to IsRequired=1.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v1.1  2026-02-17  Added Description (NULL-override pattern)
--   v1.2  2026-02-26  Added BooleanDisplayFormat
--   v1.3  2026-02-26  Added DecimalPlaces, AllowNegative
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    -- Force IsRequired for Code/Name
    IF @IsCode = 1 OR @IsName = 1 SET @IsRequired = 1;

    UPDATE Attributes SET
        DisplayName = COALESCE(@DisplayName, DisplayName),
        Name = COALESCE(@Name, Name),
        DataType = COALESCE(@DataType, DataType),
        MaxLength = @MaxLength,
        IsRequired = COALESCE(@IsRequired, IsRequired),
        IsCode = COALESCE(@IsCode, IsCode),
        IsName = COALESCE(@IsName, IsName),
        SortOrder = COALESCE(@SortOrder, SortOrder),
        DomainEntityId = @DomainEntityId,
        DomainParentAttributeId = @DomainParentAttributeId,
        DateFormat = @DateFormat,
        BooleanDisplayFormat = @BooleanDisplayFormat,
        DecimalPlaces = @DecimalPlaces,
        AllowNegative = @AllowNegative,
        Description = @Description,
        ModifiedAt = GETUTCDATE()
    OUTPUT INSERTED.Id, INSERTED.EntityId, INSERTED.DisplayName, INSERTED.Name,
           INSERTED.DataType, INSERTED.MaxLength, INSERTED.IsRequired,
           INSERTED.IsCode, INSERTED.IsName, INSERTED.IsHidden, INSERTED.IsSystemDate, INSERTED.SortOrder,
           INSERTED.DomainEntityId, INSERTED.DomainParentAttributeId, INSERTED.DateFormat, INSERTED.BooleanDisplayFormat, INSERTED.DecimalPlaces, INSERTED.AllowNegative, INSERTED.Description,
           INSERTED.CreatedAt, INSERTED.ModifiedAt
    WHERE Id = @Id;
END;
GO

CREATE OR ALTER PROCEDURE usp_Attribute_DataTypePreview
    @Id INT,
    @NewDataType NVARCHAR(20)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-18
-- Description: Dry-run preview for a datatype change. Returns the number of
--              rows affected, how many can be converted automatically, and
--              how many will be cleared. Does NOT modify any data.
--
-- Change History:
--   v1.0  2026-02-18  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @OldDataType NVARCHAR(20), @EntityId INT, @DisplayName NVARCHAR(200);

    SELECT @OldDataType = DataType, @EntityId = EntityId, @DisplayName = DisplayName
    FROM Attributes WHERE Id = @Id;

    IF @OldDataType IS NULL
    BEGIN
        SELECT 0 AS TotalRows, 0 AS ConvertibleCount, 0 AS WillClearCount,
               'Attribute not found' AS Error, NULL AS AttributeName, NULL AS OldDataType;
        RETURN;
    END

    IF @OldDataType = @NewDataType
    BEGIN
        SELECT 0 AS TotalRows, 0 AS ConvertibleCount, 0 AS WillClearCount,
               NULL AS Error, @DisplayName AS AttributeName, @OldDataType AS OldDataType;
        RETURN;
    END

    DECLARE @TotalRows INT = 0;
    DECLARE @ConvertibleCount INT = 0;

    -- Count rows with data in the source column
    IF @OldDataType = 'Text'
    BEGIN
        SELECT @TotalRows = COUNT(*) FROM EntityValues WHERE AttributeId = @Id AND TextValue IS NOT NULL;

        IF @NewDataType = 'Int'
            SELECT @ConvertibleCount = COUNT(*) FROM EntityValues
            WHERE AttributeId = @Id AND TextValue IS NOT NULL AND TRY_CAST(TextValue AS INT) IS NOT NULL;
        ELSE IF @NewDataType = 'Boolean'
            SELECT @ConvertibleCount = COUNT(*) FROM EntityValues
            WHERE AttributeId = @Id AND TextValue IS NOT NULL
            AND LOWER(LTRIM(RTRIM(TextValue))) IN ('yes','no','true','false','1','0','ja','nee');
        ELSE IF @NewDataType = 'Decimal'
            SELECT @ConvertibleCount = COUNT(*) FROM EntityValues
            WHERE AttributeId = @Id AND TextValue IS NOT NULL AND TRY_CAST(TextValue AS DECIMAL(18,6)) IS NOT NULL;
        ELSE IF @NewDataType = 'DateTime'
            SELECT @ConvertibleCount = COUNT(*) FROM EntityValues
            WHERE AttributeId = @Id AND TextValue IS NOT NULL AND TRY_CAST(TextValue AS DATETIME2) IS NOT NULL;
        ELSE -- Domain
            SET @ConvertibleCount = 0;
    END
    ELSE IF @OldDataType IN ('Int', 'Boolean')
    BEGIN
        SELECT @TotalRows = COUNT(*) FROM EntityValues WHERE AttributeId = @Id AND IntValue IS NOT NULL;

        IF @NewDataType = 'Text' OR (@OldDataType = 'Int' AND @NewDataType = 'Boolean')
            OR (@OldDataType = 'Boolean' AND @NewDataType = 'Int')
            OR @NewDataType = 'Decimal'
            SET @ConvertibleCount = @TotalRows;
        ELSE IF @NewDataType = 'Boolean' AND @OldDataType = 'Int'
            SET @ConvertibleCount = @TotalRows;
        ELSE -- DateTime, Domain
            SET @ConvertibleCount = 0;
    END
    ELSE IF @OldDataType = 'Decimal'
    BEGIN
        SELECT @TotalRows = COUNT(*) FROM EntityValues WHERE AttributeId = @Id AND DecimalValue IS NOT NULL;

        IF @NewDataType = 'Text' OR @NewDataType = 'Boolean'
            SET @ConvertibleCount = @TotalRows;
        ELSE IF @NewDataType = 'Int'
            SELECT @ConvertibleCount = COUNT(*) FROM EntityValues
            WHERE AttributeId = @Id AND DecimalValue IS NOT NULL
            AND DecimalValue = CAST(CAST(DecimalValue AS INT) AS DECIMAL(18,6));
        ELSE -- DateTime, Domain
            SET @ConvertibleCount = 0;
    END
    ELSE IF @OldDataType = 'DateTime'
    BEGIN
        SELECT @TotalRows = COUNT(*) FROM EntityValues WHERE AttributeId = @Id AND DateTimeValue IS NOT NULL;

        IF @NewDataType = 'Text'
            SET @ConvertibleCount = @TotalRows;
        ELSE -- Int, Boolean, Decimal, Domain
            SET @ConvertibleCount = 0;
    END
    ELSE IF @OldDataType = 'Domain'
    BEGIN
        SELECT @TotalRows = COUNT(*) FROM EntityValues WHERE AttributeId = @Id AND DomainValue IS NOT NULL;
        SET @ConvertibleCount = 0;
    END

    SELECT @TotalRows AS TotalRows, @ConvertibleCount AS ConvertibleCount,
           @TotalRows - @ConvertibleCount AS WillClearCount,
           NULL AS Error, @DisplayName AS AttributeName, @OldDataType AS OldDataType;
END;
GO

CREATE OR ALTER PROCEDURE usp_Attribute_ChangeDataType
    @Id INT,
    @NewDataType NVARCHAR(20),
    @Action NVARCHAR(10),       -- 'convert' or 'clear'
    @UserId INT = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-18
-- Description: Safely changes an attribute's datatype. If @Action='convert',
--              attempts to convert existing values to the new type; unconvertible
--              values are set to NULL. If @Action='clear', all values are NULLed.
--              Writes a summary to the audit log (no per-row snapshot).
--              Cleans up orphaned values in non-target columns.
--              Runs in a single transaction for atomicity.
--
-- Conversion matrix:
--   Text    -> Int/Decimal: TRY_CAST
--   Text    -> Boolean:     yes/true/1/ja -> 1, no/false/0/nee -> 0
--   Text    -> DateTime:    TRY_CAST
--   Int     -> Text:        CAST (always)
--   Int     -> Boolean:     non-zero -> 1, zero -> 0 (same column)
--   Int     -> Decimal:     CAST (always)
--   Boolean -> Text:        1 -> 'Yes', 0 -> 'No'
--   Boolean -> Int:         same column, no move
--   Boolean -> Decimal:     CAST (always)
--   Decimal -> Text:        CAST (always)
--   Decimal -> Int:         lossless only (no fractional part)
--   Decimal -> Boolean:     non-zero -> 1, zero -> 0
--   DateTime-> Text:        ISO 8601 format (always)
--   Domain  -> any:         cannot convert (always clear)
--   any     -> Domain:      cannot convert (always clear)
--
-- Change History:
--   v1.0  2026-02-18  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @OldDataType NVARCHAR(20), @EntityId INT, @DisplayName NVARCHAR(200), @AttrName NVARCHAR(128);
    DECLARE @EntityName NVARCHAR(200), @ModelName NVARCHAR(200);
    DECLARE @TotalAffected INT = 0, @Converted INT = 0, @Cleared INT = 0;

    -- Get attribute info
    SELECT @OldDataType = DataType, @EntityId = EntityId, @DisplayName = DisplayName, @AttrName = Name
    FROM Attributes WHERE Id = @Id;

    IF @OldDataType IS NULL
    BEGIN
        SELECT 'Attribute not found' AS Error, 0 AS TotalAffected, 0 AS Converted, 0 AS Cleared;
        RETURN;
    END

    SELECT @EntityName = e.Name, @ModelName = m.Name
    FROM Entities e INNER JOIN Models m ON e.ModelId = m.Id
    WHERE e.Id = @EntityId;

    IF @OldDataType = @NewDataType
    BEGIN
        SELECT NULL AS Error, 0 AS TotalAffected, 0 AS Converted, 0 AS Cleared;
        RETURN;
    END

    BEGIN TRANSACTION;
    BEGIN TRY

        -- ============ COUNT TOTAL AFFECTED ============
        IF @OldDataType = 'Text'
            SELECT @TotalAffected = COUNT(*) FROM EntityValues WHERE AttributeId = @Id AND TextValue IS NOT NULL;
        ELSE IF @OldDataType IN ('Int', 'Boolean')
            SELECT @TotalAffected = COUNT(*) FROM EntityValues WHERE AttributeId = @Id AND IntValue IS NOT NULL;
        ELSE IF @OldDataType = 'Decimal'
            SELECT @TotalAffected = COUNT(*) FROM EntityValues WHERE AttributeId = @Id AND DecimalValue IS NOT NULL;
        ELSE IF @OldDataType = 'DateTime'
            SELECT @TotalAffected = COUNT(*) FROM EntityValues WHERE AttributeId = @Id AND DateTimeValue IS NOT NULL;
        ELSE IF @OldDataType = 'Domain'
            SELECT @TotalAffected = COUNT(*) FROM EntityValues WHERE AttributeId = @Id AND DomainValue IS NOT NULL;

        -- ============ CONVERSION OR CLEAR ============
        IF @TotalAffected > 0
        BEGIN
            IF @Action = 'convert'
            BEGIN
                -- ---- TEXT -> targets ----
                IF @OldDataType = 'Text'
                BEGIN
                    IF @NewDataType = 'Int'
                        UPDATE EntityValues SET IntValue = TRY_CAST(TextValue AS INT), TextValue = NULL
                        WHERE AttributeId = @Id AND TextValue IS NOT NULL;
                    ELSE IF @NewDataType = 'Boolean'
                        UPDATE EntityValues SET
                            IntValue = CASE
                                WHEN LOWER(LTRIM(RTRIM(TextValue))) IN ('yes','true','1','ja') THEN 1
                                WHEN LOWER(LTRIM(RTRIM(TextValue))) IN ('no','false','0','nee') THEN 0
                                ELSE NULL END,
                            TextValue = NULL
                        WHERE AttributeId = @Id AND TextValue IS NOT NULL;
                    ELSE IF @NewDataType = 'Decimal'
                        UPDATE EntityValues SET DecimalValue = TRY_CAST(TextValue AS DECIMAL(18,6)), TextValue = NULL
                        WHERE AttributeId = @Id AND TextValue IS NOT NULL;
                    ELSE IF @NewDataType = 'DateTime'
                        UPDATE EntityValues SET DateTimeValue = TRY_CAST(TextValue AS DATETIME2), TextValue = NULL
                        WHERE AttributeId = @Id AND TextValue IS NOT NULL;
                    ELSE -- Text -> Domain (can't convert)
                        UPDATE EntityValues SET TextValue = NULL
                        WHERE AttributeId = @Id AND TextValue IS NOT NULL;
                END
                -- ---- INT -> targets ----
                ELSE IF @OldDataType = 'Int'
                BEGIN
                    IF @NewDataType = 'Text'
                        UPDATE EntityValues SET TextValue = CAST(IntValue AS NVARCHAR(MAX)), IntValue = NULL
                        WHERE AttributeId = @Id AND IntValue IS NOT NULL;
                    ELSE IF @NewDataType = 'Boolean'
                        -- Same column (IntValue), just normalize: non-zero -> 1
                        UPDATE EntityValues SET IntValue = CASE WHEN IntValue != 0 THEN 1 ELSE 0 END
                        WHERE AttributeId = @Id AND IntValue IS NOT NULL;
                    ELSE IF @NewDataType = 'Decimal'
                        UPDATE EntityValues SET DecimalValue = CAST(IntValue AS DECIMAL(18,6)), IntValue = NULL
                        WHERE AttributeId = @Id AND IntValue IS NOT NULL;
                    ELSE -- DateTime, Domain (can't convert)
                        UPDATE EntityValues SET IntValue = NULL
                        WHERE AttributeId = @Id AND IntValue IS NOT NULL;
                END
                -- ---- BOOLEAN -> targets ----
                ELSE IF @OldDataType = 'Boolean'
                BEGIN
                    IF @NewDataType = 'Text'
                        UPDATE EntityValues SET TextValue = CASE WHEN IntValue = 1 THEN 'Yes' ELSE 'No' END, IntValue = NULL
                        WHERE AttributeId = @Id AND IntValue IS NOT NULL;
                    ELSE IF @NewDataType = 'Int'
                        -- Same column (IntValue), values already 0/1, no change needed
                        SET @Converted = @TotalAffected;
                    ELSE IF @NewDataType = 'Decimal'
                        UPDATE EntityValues SET DecimalValue = CAST(IntValue AS DECIMAL(18,6)), IntValue = NULL
                        WHERE AttributeId = @Id AND IntValue IS NOT NULL;
                    ELSE -- DateTime, Domain (can't convert)
                        UPDATE EntityValues SET IntValue = NULL
                        WHERE AttributeId = @Id AND IntValue IS NOT NULL;
                END
                -- ---- DECIMAL -> targets ----
                ELSE IF @OldDataType = 'Decimal'
                BEGIN
                    IF @NewDataType = 'Text'
                        UPDATE EntityValues SET TextValue = CAST(DecimalValue AS NVARCHAR(MAX)), DecimalValue = NULL
                        WHERE AttributeId = @Id AND DecimalValue IS NOT NULL;
                    ELSE IF @NewDataType = 'Int'
                        UPDATE EntityValues SET
                            IntValue = CASE WHEN DecimalValue = CAST(CAST(DecimalValue AS INT) AS DECIMAL(18,6))
                                       THEN CAST(DecimalValue AS INT) ELSE NULL END,
                            DecimalValue = NULL
                        WHERE AttributeId = @Id AND DecimalValue IS NOT NULL;
                    ELSE IF @NewDataType = 'Boolean'
                        UPDATE EntityValues SET IntValue = CASE WHEN DecimalValue != 0 THEN 1 ELSE 0 END, DecimalValue = NULL
                        WHERE AttributeId = @Id AND DecimalValue IS NOT NULL;
                    ELSE -- DateTime, Domain (can't convert)
                        UPDATE EntityValues SET DecimalValue = NULL
                        WHERE AttributeId = @Id AND DecimalValue IS NOT NULL;
                END
                -- ---- DATETIME -> targets ----
                ELSE IF @OldDataType = 'DateTime'
                BEGIN
                    IF @NewDataType = 'Text'
                        UPDATE EntityValues SET TextValue = CONVERT(NVARCHAR(30), DateTimeValue, 126), DateTimeValue = NULL
                        WHERE AttributeId = @Id AND DateTimeValue IS NOT NULL;
                    ELSE -- Int, Boolean, Decimal, Domain (can't convert)
                        UPDATE EntityValues SET DateTimeValue = NULL
                        WHERE AttributeId = @Id AND DateTimeValue IS NOT NULL;
                END
                -- ---- DOMAIN -> targets ----
                ELSE IF @OldDataType = 'Domain'
                BEGIN
                    -- Domain references can never be meaningfully converted
                    UPDATE EntityValues SET DomainValue = NULL
                    WHERE AttributeId = @Id AND DomainValue IS NOT NULL;
                END

                -- Count successfully converted values in the target column
                IF @NewDataType = 'Text'
                    SELECT @Converted = COUNT(*) FROM EntityValues WHERE AttributeId = @Id AND TextValue IS NOT NULL;
                ELSE IF @NewDataType IN ('Int', 'Boolean')
                    -- Skip recount for same-column cases where we already set @Converted
                    IF @Converted = 0
                        SELECT @Converted = COUNT(*) FROM EntityValues WHERE AttributeId = @Id AND IntValue IS NOT NULL;
                ELSE IF @NewDataType = 'Decimal'
                    SELECT @Converted = COUNT(*) FROM EntityValues WHERE AttributeId = @Id AND DecimalValue IS NOT NULL;
                ELSE IF @NewDataType = 'DateTime'
                    SELECT @Converted = COUNT(*) FROM EntityValues WHERE AttributeId = @Id AND DateTimeValue IS NOT NULL;
                ELSE IF @NewDataType = 'Domain'
                    SET @Converted = 0;

                SET @Cleared = @TotalAffected - @Converted;
            END
            ELSE -- @Action = 'clear'
            BEGIN
                IF @OldDataType = 'Text'
                    UPDATE EntityValues SET TextValue = NULL WHERE AttributeId = @Id AND TextValue IS NOT NULL;
                ELSE IF @OldDataType IN ('Int', 'Boolean')
                    UPDATE EntityValues SET IntValue = NULL WHERE AttributeId = @Id AND IntValue IS NOT NULL;
                ELSE IF @OldDataType = 'Decimal'
                    UPDATE EntityValues SET DecimalValue = NULL WHERE AttributeId = @Id AND DecimalValue IS NOT NULL;
                ELSE IF @OldDataType = 'DateTime'
                    UPDATE EntityValues SET DateTimeValue = NULL WHERE AttributeId = @Id AND DateTimeValue IS NOT NULL;
                ELSE IF @OldDataType = 'Domain'
                    UPDATE EntityValues SET DomainValue = NULL WHERE AttributeId = @Id AND DomainValue IS NOT NULL;

                SET @Cleared = @TotalAffected;
                SET @Converted = 0;
            END

            -- ============ CLEANUP ORPHANED VALUES ============
            -- Ensure only the target column retains values; NULL everything else
            UPDATE EntityValues SET
                TextValue     = CASE WHEN @NewDataType = 'Text'              THEN TextValue     ELSE NULL END,
                IntValue      = CASE WHEN @NewDataType IN ('Int', 'Boolean') THEN IntValue      ELSE NULL END,
                DecimalValue  = CASE WHEN @NewDataType = 'Decimal'           THEN DecimalValue  ELSE NULL END,
                DateTimeValue = CASE WHEN @NewDataType = 'DateTime'          THEN DateTimeValue ELSE NULL END,
                DomainValue   = CASE WHEN @NewDataType = 'Domain'            THEN DomainValue   ELSE NULL END
            WHERE AttributeId = @Id
            AND (
                (@NewDataType <> 'Text'              AND TextValue     IS NOT NULL)
                OR (@NewDataType NOT IN ('Int','Boolean') AND IntValue IS NOT NULL)
                OR (@NewDataType <> 'Decimal'        AND DecimalValue  IS NOT NULL)
                OR (@NewDataType <> 'DateTime'       AND DateTimeValue IS NOT NULL)
                OR (@NewDataType <> 'Domain'         AND DomainValue   IS NOT NULL)
            );
        END

        -- ============ UPDATE ATTRIBUTE METADATA ============
        UPDATE Attributes SET
            DataType = @NewDataType,
            DomainEntityId = CASE WHEN @NewDataType = 'Domain' THEN DomainEntityId ELSE NULL END,
            MaxLength = CASE WHEN @NewDataType = 'Text' THEN MaxLength ELSE NULL END,
            ModifiedAt = GETUTCDATE()
        WHERE Id = @Id;

        -- ============ AUDIT LOG ============
        DECLARE @Details NVARCHAR(MAX);
        SET @Details = (
            SELECT @Id AS attributeId, @DisplayName AS attributeName, @AttrName AS attributeDbName,
                   @OldDataType AS fromType, @NewDataType AS toType, @Action AS [action],
                   @TotalAffected AS totalAffected, @Converted AS converted, @Cleared AS cleared
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        EXEC usp_AuditLog_Write
            @EntityId = @EntityId,
            @EntityName = @EntityName,
            @ModelName = @ModelName,
            @Action = N'DataTypeChange',
            @RecordCount = @TotalAffected,
            @UserId = @UserId,
            @Details = @Details;

        COMMIT;
        SELECT NULL AS Error, @TotalAffected AS TotalAffected, @Converted AS Converted, @Cleared AS Cleared;

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        SELECT ERROR_MESSAGE() AS Error, 0 AS TotalAffected, 0 AS Converted, 0 AS Cleared;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Attribute_Delete
    @Id INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Deletes a single attribute by Id. Associated EntityValues
--              are removed by the ON DELETE CASCADE constraint on the
--              Attributes foreign key.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM Attributes WHERE Id = @Id;
    SELECT @@ROWCOUNT AS Deleted;
END;
GO

-- ============================================
-- ROLE PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_Role_GetAll
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns all roles and their members as two result sets.
--              Roles are ordered alphabetically; members include joined
--              User data (Email, DisplayName) so the caller never needs
--              a separate user lookup.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v2.0  2026-02-17  Members result set now joins Users table; returns
--                     UserId, Email, DisplayName instead of Email column
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    -- Result set 1: all groups ordered alphabetically
    SELECT Id, Name, Description, IsAdmin, CanApprove, CreatedAt, ModifiedAt FROM Roles ORDER BY Name;
    -- Result set 2: members with resolved user info for display in the UI
    SELECT gm.Id, gm.RoleId, gm.UserId, u.Email, u.DisplayName
    FROM RoleMembers gm
    JOIN Users u ON u.Id = gm.UserId
    ORDER BY gm.RoleId;
END;
GO

CREATE OR ALTER PROCEDURE usp_Role_Create
    @Name NVARCHAR(200),
    @Description NVARCHAR(500) = NULL,
    @IsAdmin BIT = 0,
    @CanApprove BIT = 0,
    @MembersJson NVARCHAR(MAX) = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Creates a new permission role, optionally populating its
--              member list from a JSON array of User IDs (integers) in the
--              same atomic transaction. NULL values in the array are skipped.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v2.0  2026-02-17  @MembersJson is now an array of INT user IDs instead
--                     of email strings; member result set joins Users table
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        INSERT INTO Roles (Name, Description, IsAdmin, CanApprove) VALUES (@Name, @Description, @IsAdmin, @CanApprove);
        DECLARE @RoleId INT = SCOPE_IDENTITY();

        -- Insert members from array of user IDs; skip NULLs
        IF @MembersJson IS NOT NULL
            INSERT INTO RoleMembers (RoleId, UserId)
            SELECT @RoleId, CAST(value AS INT) FROM OPENJSON(@MembersJson) WHERE value IS NOT NULL;

        COMMIT TRANSACTION;
        SELECT Id, Name, Description, IsAdmin, CanApprove, CreatedAt, ModifiedAt FROM Roles WHERE Id = @RoleId;
        -- Return members with resolved user info for immediate display
        SELECT gm.Id, gm.RoleId, gm.UserId, u.Email, u.DisplayName
        FROM RoleMembers gm
        JOIN Users u ON u.Id = gm.UserId
        WHERE gm.RoleId = @RoleId;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Role_Update
    @Id INT,
    @Name NVARCHAR(200) = NULL,
    @Description NVARCHAR(500) = NULL,
    @IsAdmin BIT = NULL,
    @CanApprove BIT = NULL,
    @MembersJson NVARCHAR(MAX) = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Updates a role's name and description. When @MembersJson is
--              supplied the entire member list is replaced (delete-then-insert).
--              @Description is a NULL-override: passing NULL clears the field.
--              Throws error 50003 if the group does not exist.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v2.0  2026-02-17  @MembersJson is now an array of INT user IDs instead
--                     of email strings; member result set joins Users table
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        UPDATE Roles SET
            Name = COALESCE(@Name, Name),
            Description = @Description,
            IsAdmin = COALESCE(@IsAdmin, IsAdmin),
            CanApprove = COALESCE(@CanApprove, CanApprove),
            ModifiedAt = GETUTCDATE()
        OUTPUT INSERTED.Id, INSERTED.Name, INSERTED.Description,
               INSERTED.IsAdmin, INSERTED.CanApprove,
               INSERTED.CreatedAt, INSERTED.ModifiedAt
        WHERE Id = @Id;

        IF @@ROWCOUNT = 0
        BEGIN
            IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
            THROW 50003, 'Role not found', 1;
        END

        -- Replace member list atomically when provided; delete-then-insert is safe
        -- because the whole operation is wrapped in a transaction
        IF @MembersJson IS NOT NULL
        BEGIN
            DELETE FROM RoleMembers WHERE RoleId = @Id;
            INSERT INTO RoleMembers (RoleId, UserId)
            SELECT @Id, CAST(value AS INT) FROM OPENJSON(@MembersJson) WHERE value IS NOT NULL;
        END

        -- Safety net: the system must keep at least one usable administrator.
        -- Because the member list is REPLACED, a caller that passes an incomplete list
        -- silently removes everyone it left out — this is how every real administrator was
        -- once wiped from the Administrators role, with no way back through the UI.
        -- Only evaluated when this call can actually take administrator access away, so an
        -- unrelated rename still works on an installation that is already in that state.
        IF @MembersJson IS NOT NULL OR @IsAdmin = 0
        BEGIN
            IF NOT EXISTS (
                SELECT 1
                FROM RoleMembers rm
                JOIN Roles r ON r.Id = rm.RoleId
                JOIN Users u ON u.Id = rm.UserId
                WHERE r.IsAdmin = 1 AND u.IsDeleted = 0 AND u.IsActive = 1
            )
            BEGIN
                IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
                THROW 50003, 'This change would leave the system without an active administrator.', 1;
            END
        END

        COMMIT TRANSACTION;
        SELECT Id, Name, Description, IsAdmin, CanApprove, CreatedAt, ModifiedAt FROM Roles WHERE Id = @Id;
        -- Return members with resolved user info for immediate display
        SELECT gm.Id, gm.RoleId, gm.UserId, u.Email, u.DisplayName
        FROM RoleMembers gm
        JOIN Users u ON u.Id = gm.UserId
        WHERE gm.RoleId = @Id;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Role_Delete
    @Id INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Deletes a role and all of its permissions in a single
--              atomic transaction. RoleMembers are removed by the ON DELETE
--              CASCADE constraint on the Roles foreign key.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v1.1  2026-07-31  Refuses to remove the last active administrator
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        DELETE FROM Permissions WHERE RoleId = @Id;
        DELETE FROM Roles WHERE Id = @Id;
        DECLARE @Deleted INT = @@ROWCOUNT;

        -- Administrator rights come from role membership, so deleting an IsAdmin role takes them
        -- away from everyone in it. Several admin roles may exist and any of them may be deleted;
        -- what may not happen is ending up with none, because there is then no way back in
        -- through the UI. Same check, number and wording as usp_Role_Update.
        IF NOT EXISTS (
            SELECT 1
            FROM RoleMembers rm
            JOIN Roles r ON r.Id = rm.RoleId
            JOIN Users u ON u.Id = rm.UserId
            WHERE r.IsAdmin = 1 AND u.IsDeleted = 0 AND u.IsActive = 1
        )
        BEGIN
            IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
            THROW 50003, 'This change would leave the system without an active administrator.', 1;
        END

        COMMIT TRANSACTION;
        SELECT @Deleted AS Deleted;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- ============================================
-- PERMISSION PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_Permission_GetByScope
    @RoleId INT = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns permissions, optionally filtered by group. When
--              @RoleId is NULL all permissions are returned (used for
--              full permission load on startup).
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v2.0  2026-02-20  Added CRUD columns (CanCreate, CanRead, CanUpdate,
--                      CanDelete, IsModerator)
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Id, RoleId, Scope, TargetId, Level,
           CanCreate, CanRead, CanUpdate, CanDelete, IsModerator, IsExplicit
    FROM Permissions
    WHERE (@RoleId IS NULL OR RoleId = @RoleId)
    ORDER BY RoleId, Scope, TargetId;
END;
GO

CREATE OR ALTER PROCEDURE usp_Permission_Upsert
    @RoleId     INT,
    @Scope       NVARCHAR(20),
    @TargetId    INT,
    @Level       NVARCHAR(20)  = NULL,
    @CanCreate   BIT           = 0,
    @CanRead     BIT           = 0,
    @CanUpdate   BIT           = 0,
    @CanDelete   BIT           = 0,
    @IsModerator BIT           = 0,
    @IsExplicit  BIT           = 0,
    @UserId      INT           = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Sets a single permission for a group/scope/target combination.
--              Implements upsert as delete-then-insert: the existing row is
--              always removed first. For attribute scope, @Level controls
--              insertion. For model/entity scope, CRUD bits control insertion.
--              @IsExplicit=1 forces insertion even when all CRUD bits are zero
--              (explicit-none override that blocks parent inheritance).
--              Writes a granular audit entry capturing old and new state.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v2.0  2026-02-20  Added CRUD columns + audit logging
--   v3.0  2026-02-23  Granular per-permission audit entry with Details JSON
--   v4.0  2026-02-24  Added IsExplicit support for permission override
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- Capture old state before any changes
    DECLARE @OldLevel  NVARCHAR(20) = 'none';
    DECLARE @OldCreate BIT = 0, @OldRead BIT = 0, @OldUpdate BIT = 0;
    DECLARE @OldDelete BIT = 0, @OldMod  BIT = 0;
    DECLARE @OldExists BIT = 0;

    SELECT @OldExists = 1,
           @OldLevel  = Level,
           @OldCreate = CanCreate, @OldRead   = CanRead,
           @OldUpdate = CanUpdate, @OldDelete = CanDelete,
           @OldMod    = IsModerator
    FROM Permissions
    WHERE RoleId = @RoleId AND Scope = @Scope AND TargetId = @TargetId;

    -- Normalize new values
    DECLARE @NewLevel  NVARCHAR(20) = ISNULL(@Level, 'none');
    DECLARE @NewCreate BIT = ISNULL(@CanCreate,   0);
    DECLARE @NewRead   BIT = ISNULL(@CanRead,     0);
    DECLARE @NewUpdate BIT = ISNULL(@CanUpdate,   0);
    DECLARE @NewDelete BIT = ISNULL(@CanDelete,   0);
    DECLARE @NewMod    BIT = ISNULL(@IsModerator, 0);

    -- Determine if a row should be inserted
    DECLARE @ShouldInsert BIT = 0;
    IF @Scope = 'attribute' AND @NewLevel IS NOT NULL AND @NewLevel <> 'none'
        SET @ShouldInsert = 1;
    ELSE IF @Scope IN ('model','entity') AND (@NewCreate = 1 OR @NewRead = 1 OR @NewUpdate = 1 OR @NewDelete = 1 OR @NewMod = 1)
        SET @ShouldInsert = 1;
    ELSE IF @Scope IN ('model','entity') AND @IsExplicit = 1
        SET @ShouldInsert = 1;  -- explicit-none override: store even with all-zero CRUD

    -- Effective new state when not inserting is all-zero/none
    IF @ShouldInsert = 0
    BEGIN
        SET @NewLevel  = 'none'; SET @NewCreate = 0; SET @NewRead   = 0;
        SET @NewUpdate = 0;      SET @NewDelete = 0; SET @NewMod    = 0;
    END;

    -- Execute the upsert
    DELETE FROM Permissions WHERE RoleId = @RoleId AND Scope = @Scope AND TargetId = @TargetId;

    IF @ShouldInsert = 1
    BEGIN
        INSERT INTO Permissions (RoleId, Scope, TargetId, Level, CanCreate, CanRead, CanUpdate, CanDelete, IsModerator, IsExplicit)
        OUTPUT INSERTED.Id, INSERTED.RoleId, INSERTED.Scope, INSERTED.TargetId,
               INSERTED.Level, INSERTED.CanCreate, INSERTED.CanRead, INSERTED.CanUpdate,
               INSERTED.CanDelete, INSERTED.IsModerator, INSERTED.IsExplicit,
               INSERTED.CreatedAt, INSERTED.ModifiedAt
        VALUES (@RoleId, @Scope, @TargetId, ISNULL(@Level,'none'), @CanCreate, @CanRead, @CanUpdate, @CanDelete, @IsModerator, @IsExplicit);
    END
    ELSE
        SELECT 1 AS Removed;

    -- Determine if anything actually changed
    DECLARE @Changed BIT = 0;
    IF @Scope = 'attribute'
    BEGIN
        IF @OldLevel <> @NewLevel SET @Changed = 1;
    END
    ELSE
    BEGIN
        IF @OldCreate <> @NewCreate OR @OldRead <> @NewRead OR
           @OldUpdate <> @NewUpdate OR @OldDelete <> @NewDelete OR @OldMod <> @NewMod
            SET @Changed = 1;
    END;

    IF @Changed = 1
    BEGIN
        DECLARE @ModId   INT = NULL, @ModName   NVARCHAR(200) = NULL;
        DECLARE @EntId   INT = NULL, @EntName   NVARCHAR(200) = NULL;
        DECLARE @AttId   INT = NULL, @AttName   NVARCHAR(200) = NULL;
        DECLARE @RoleName NVARCHAR(200);
        DECLARE @AuditEntityId   INT          = NULL;
        DECLARE @AuditEntityName NVARCHAR(200) = N'Unknown';
        DECLARE @AuditModelName  NVARCHAR(200) = N'Unknown';

        SELECT @RoleName = Name FROM Roles WHERE Id = @RoleId;

        IF @Scope = 'model'
        BEGIN
            SELECT @ModId = Id, @ModName = Name FROM Models WHERE Id = @TargetId;
            SET @AuditEntityName = ISNULL(@ModName, N'Unknown');
            SET @AuditModelName  = ISNULL(@ModName, N'Unknown');
        END
        ELSE IF @Scope = 'entity'
        BEGIN
            SELECT @EntId = e.Id, @EntName = e.Name, @ModId = m.Id, @ModName = m.Name
            FROM Entities e JOIN Models m ON e.ModelId = m.Id
            WHERE e.Id = @TargetId;
            SET @AuditEntityId   = @EntId;
            SET @AuditEntityName = ISNULL(@EntName, N'Unknown');
            SET @AuditModelName  = ISNULL(@ModName, N'Unknown');
        END
        ELSE IF @Scope = 'attribute'
        BEGIN
            SELECT @AttId = a.Id, @AttName = a.Name,
                   @EntId = e.Id, @EntName = e.Name,
                   @ModId = m.Id, @ModName = m.Name
            FROM Attributes a
            JOIN Entities e ON a.EntityId = e.Id
            JOIN Models m ON e.ModelId = m.Id
            WHERE a.Id = @TargetId;
            SET @AuditEntityId   = @EntId;
            SET @AuditEntityName = ISNULL(@EntName, N'Unknown');
            SET @AuditModelName  = ISNULL(@ModName, N'Unknown');
        END;

        -- Compute effective levels for attribute permissions (resolve 'none' = inherited)
        DECLARE @EffOldLevel NVARCHAR(20) = @OldLevel;
        DECLARE @EffNewLevel NVARCHAR(20) = @NewLevel;
        IF @Scope = 'attribute'
        BEGIN
            DECLARE @LkpCreate BIT, @LkpRead BIT, @LkpUpdate BIT, @LkpMod BIT;
            IF @OldLevel = 'none' AND @EntId IS NOT NULL
            BEGIN
                SELECT @LkpCreate = CanCreate, @LkpRead = CanRead, @LkpUpdate = CanUpdate, @LkpMod = IsModerator
                FROM Permissions WHERE RoleId = @RoleId AND Scope = 'entity' AND TargetId = @EntId;
                IF @LkpRead IS NOT NULL OR @LkpCreate IS NOT NULL OR @LkpUpdate IS NOT NULL
                    SET @EffOldLevel = CASE WHEN ISNULL(@LkpMod,0)=1 OR ISNULL(@LkpUpdate,0)=1 OR ISNULL(@LkpCreate,0)=1 THEN 'write' WHEN ISNULL(@LkpRead,0)=1 THEN 'read' ELSE 'none' END;
                ELSE IF @ModId IS NOT NULL
                BEGIN
                    SET @LkpCreate = NULL; SET @LkpRead = NULL; SET @LkpUpdate = NULL; SET @LkpMod = NULL;
                    SELECT @LkpCreate = CanCreate, @LkpRead = CanRead, @LkpUpdate = CanUpdate, @LkpMod = IsModerator
                    FROM Permissions WHERE RoleId = @RoleId AND Scope = 'model' AND TargetId = @ModId;
                    SET @EffOldLevel = CASE WHEN ISNULL(@LkpMod,0)=1 OR ISNULL(@LkpUpdate,0)=1 OR ISNULL(@LkpCreate,0)=1 THEN 'write' WHEN ISNULL(@LkpRead,0)=1 THEN 'read' ELSE 'none' END;
                END;
            END;
            IF @NewLevel = 'none' AND @EntId IS NOT NULL
            BEGIN
                SET @LkpCreate = NULL; SET @LkpRead = NULL; SET @LkpUpdate = NULL; SET @LkpMod = NULL;
                SELECT @LkpCreate = CanCreate, @LkpRead = CanRead, @LkpUpdate = CanUpdate, @LkpMod = IsModerator
                FROM Permissions WHERE RoleId = @RoleId AND Scope = 'entity' AND TargetId = @EntId;
                IF @LkpRead IS NOT NULL OR @LkpCreate IS NOT NULL OR @LkpUpdate IS NOT NULL
                    SET @EffNewLevel = CASE WHEN ISNULL(@LkpMod,0)=1 OR ISNULL(@LkpUpdate,0)=1 OR ISNULL(@LkpCreate,0)=1 THEN 'write' WHEN ISNULL(@LkpRead,0)=1 THEN 'read' ELSE 'none' END;
                ELSE IF @ModId IS NOT NULL
                BEGIN
                    SET @LkpCreate = NULL; SET @LkpRead = NULL; SET @LkpUpdate = NULL; SET @LkpMod = NULL;
                    SELECT @LkpCreate = CanCreate, @LkpRead = CanRead, @LkpUpdate = CanUpdate, @LkpMod = IsModerator
                    FROM Permissions WHERE RoleId = @RoleId AND Scope = 'model' AND TargetId = @ModId;
                    SET @EffNewLevel = CASE WHEN ISNULL(@LkpMod,0)=1 OR ISNULL(@LkpUpdate,0)=1 OR ISNULL(@LkpCreate,0)=1 THEN 'write' WHEN ISNULL(@LkpRead,0)=1 THEN 'read' ELSE 'none' END;
                END;
            END;
        END;

        -- Build changes JSON
        DECLARE @ChangesJson NVARCHAR(MAX) = N'';
        IF @Scope = 'attribute'
        BEGIN
            SET @ChangesJson = N'"level":{"from":"' + @EffOldLevel + N'","to":"' + @EffNewLevel + N'"}';
        END
        ELSE
        BEGIN
            DECLARE @Parts NVARCHAR(MAX) = N'';
            IF @OldCreate <> @NewCreate
                SET @Parts += N',"canCreate":{"from":' + CASE @OldCreate WHEN 1 THEN N'true' ELSE N'false' END + N',"to":' + CASE @NewCreate WHEN 1 THEN N'true' ELSE N'false' END + N'}';
            IF @OldRead <> @NewRead
                SET @Parts += N',"canRead":{"from":' + CASE @OldRead WHEN 1 THEN N'true' ELSE N'false' END + N',"to":' + CASE @NewRead WHEN 1 THEN N'true' ELSE N'false' END + N'}';
            IF @OldUpdate <> @NewUpdate
                SET @Parts += N',"canUpdate":{"from":' + CASE @OldUpdate WHEN 1 THEN N'true' ELSE N'false' END + N',"to":' + CASE @NewUpdate WHEN 1 THEN N'true' ELSE N'false' END + N'}';
            IF @OldDelete <> @NewDelete
                SET @Parts += N',"canDelete":{"from":' + CASE @OldDelete WHEN 1 THEN N'true' ELSE N'false' END + N',"to":' + CASE @NewDelete WHEN 1 THEN N'true' ELSE N'false' END + N'}';
            IF @OldMod <> @NewMod
                SET @Parts += N',"isModerator":{"from":' + CASE @OldMod WHEN 1 THEN N'true' ELSE N'false' END + N',"to":' + CASE @NewMod WHEN 1 THEN N'true' ELSE N'false' END + N'}';
            IF LEN(@Parts) > 0
                SET @ChangesJson = SUBSTRING(@Parts, 2, LEN(@Parts));
        END;

        -- Build full Details JSON
        DECLARE @Details NVARCHAR(MAX);
        SET @Details  = N'{"scope":"'    + @Scope + N'"';
        SET @Details += N',"modelId":'   + CAST(ISNULL(@ModId, 0) AS NVARCHAR(20));
        SET @Details += N',"modelName":"' + ISNULL(REPLACE(@ModName, '"', '\"'), N'') + N'"';
        IF @Scope IN ('entity','attribute')
        BEGIN
            SET @Details += N',"entityId":'    + CAST(ISNULL(@EntId, 0) AS NVARCHAR(20));
            SET @Details += N',"entityName":"' + ISNULL(REPLACE(@EntName, '"', '\"'), N'') + N'"';
        END;
        IF @Scope = 'attribute'
        BEGIN
            SET @Details += N',"attributeId":'    + CAST(ISNULL(@AttId, 0) AS NVARCHAR(20));
            SET @Details += N',"attributeName":"' + ISNULL(REPLACE(@AttName, '"', '\"'), N'') + N'"';
        END;
        SET @Details += N',"roleId":'    + CAST(@RoleId AS NVARCHAR(20));
        SET @Details += N',"roleName":"' + ISNULL(REPLACE(@RoleName, '"', '\"'), N'') + N'"';
        SET @Details += N',"changes":{'  + @ChangesJson + N'}}';

        INSERT INTO AuditLog (EntityId, EntityName, ModelName, Action, RecordCount, UserId, Comment, Details)
        VALUES (@AuditEntityId, @AuditEntityName, @AuditModelName,
                N'permission_change', 1, @UserId, NULL, @Details);
    END;
END;
GO

CREATE OR ALTER PROCEDURE usp_Permission_BulkSave
    @RoleId          INT,
    @PermissionsJson  NVARCHAR(MAX),
    @UserId           INT = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Replaces all permissions for a role in one atomic operation.
--              Deletes all existing permissions for the role, then inserts
--              the full set from the JSON array. Writes a granular audit entry
--              per individual permission change with full Details JSON.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v2.0  2026-02-20  Added CRUD columns + audit logging
--   v3.0  2026-02-23  Granular per-permission audit entries with Details JSON
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        -- Safety: drop temp tables if they exist from a prior aborted call
        IF OBJECT_ID('tempdb..#OldPerms') IS NOT NULL DROP TABLE #OldPerms;
        IF OBJECT_ID('tempdb..#NewPerms') IS NOT NULL DROP TABLE #NewPerms;
        IF OBJECT_ID('tempdb..#Changes')  IS NOT NULL DROP TABLE #Changes;

        -- Capture current permissions before changes
        SELECT Scope, TargetId, Level, CanCreate, CanRead, CanUpdate, CanDelete, IsModerator, IsExplicit
        INTO #OldPerms
        FROM Permissions
        WHERE RoleId = @RoleId;

        -- Parse incoming permissions
        SELECT j.scope   AS Scope,
               j.targetId AS TargetId,
               ISNULL(j.level,       'none') AS Level,
               ISNULL(j.canCreate,   0)      AS CanCreate,
               ISNULL(j.canRead,     0)      AS CanRead,
               ISNULL(j.canUpdate,   0)      AS CanUpdate,
               ISNULL(j.canDelete,   0)      AS CanDelete,
               ISNULL(j.isModerator, 0)      AS IsModerator,
               ISNULL(j.isExplicit,  0)      AS IsExplicit
        INTO #NewPerms
        FROM OPENJSON(@PermissionsJson) WITH (
            scope       NVARCHAR(20),
            targetId    INT,
            level       NVARCHAR(20),
            canCreate   BIT,
            canRead     BIT,
            canUpdate   BIT,
            canDelete   BIT,
            isModerator BIT,
            isExplicit  BIT
        ) j
        WHERE j.scope IS NOT NULL;

        -- Remove "all-zero/none" entries so #NewPerms reflects only active permissions
        -- Explicit-none overrides (IsExplicit=1) are preserved — they block parent inheritance
        DELETE FROM #NewPerms
        WHERE (Scope = 'attribute' AND (Level IS NULL OR Level = 'none'))
           OR (Scope IN ('model','entity') AND CanCreate = 0 AND CanRead = 0
               AND CanUpdate = 0 AND CanDelete = 0 AND IsModerator = 0 AND IsExplicit = 0);

        -- Replace all permissions atomically
        DELETE FROM Permissions WHERE RoleId = @RoleId;

        INSERT INTO Permissions (RoleId, Scope, TargetId, Level, CanCreate, CanRead, CanUpdate, CanDelete, IsModerator, IsExplicit)
        SELECT @RoleId, n.Scope, n.TargetId, n.Level,
               n.CanCreate, n.CanRead, n.CanUpdate, n.CanDelete, n.IsModerator, n.IsExplicit
        FROM #NewPerms n;

        DECLARE @SavedCount INT = @@ROWCOUNT;

        -- Get role name once (shared across all audit entries)
        DECLARE @RoleName NVARCHAR(200);
        SELECT @RoleName = Name FROM Roles WHERE Id = @RoleId;

        -- Build change set: full outer join between old and new effective states
        SELECT
            COALESCE(o.Scope,    n.Scope)    AS Scope,
            COALESCE(o.TargetId, n.TargetId) AS TargetId,
            ISNULL(o.Level,       'none')    AS OldLevel,
            ISNULL(n.Level,       'none')    AS NewLevel,
            ISNULL(o.CanCreate,   0)         AS OldCreate,
            ISNULL(n.CanCreate,   0)         AS NewCreate,
            ISNULL(o.CanRead,     0)         AS OldRead,
            ISNULL(n.CanRead,     0)         AS NewRead,
            ISNULL(o.CanUpdate,   0)         AS OldUpdate,
            ISNULL(n.CanUpdate,   0)         AS NewUpdate,
            ISNULL(o.CanDelete,   0)         AS OldDelete,
            ISNULL(n.CanDelete,   0)         AS NewDelete,
            ISNULL(o.IsModerator, 0)         AS OldMod,
            ISNULL(n.IsModerator, 0)         AS NewMod
        INTO #Changes
        FROM #OldPerms o
        FULL OUTER JOIN #NewPerms n ON o.Scope = n.Scope AND o.TargetId = n.TargetId
        WHERE
            (COALESCE(o.Scope, n.Scope) = 'attribute'
                AND ISNULL(o.Level,'none') <> ISNULL(n.Level,'none'))
            OR
            (COALESCE(o.Scope, n.Scope) IN ('model','entity') AND (
                ISNULL(o.CanCreate,  0) <> ISNULL(n.CanCreate,  0) OR
                ISNULL(o.CanRead,    0) <> ISNULL(n.CanRead,    0) OR
                ISNULL(o.CanUpdate,  0) <> ISNULL(n.CanUpdate,  0) OR
                ISNULL(o.CanDelete,  0) <> ISNULL(n.CanDelete,  0) OR
                ISNULL(o.IsModerator,0) <> ISNULL(n.IsModerator,0)
            ));

        -- Write one audit entry per changed permission
        DECLARE @CScope    NVARCHAR(20), @CTargetId  INT;
        DECLARE @COldLevel NVARCHAR(20), @CNewLevel  NVARCHAR(20);
        DECLARE @COldCreate BIT, @CNewCreate BIT;
        DECLARE @COldRead   BIT, @CNewRead   BIT;
        DECLARE @COldUpdate BIT, @CNewUpdate BIT;
        DECLARE @COldDelete BIT, @CNewDelete BIT;
        DECLARE @COldMod    BIT, @CNewMod    BIT;
        DECLARE @CModId INT, @CModName NVARCHAR(200);
        DECLARE @CEntId INT, @CEntName NVARCHAR(200);
        DECLARE @CAttId INT, @CAttName NVARCHAR(200);
        DECLARE @CAuditEntityId   INT;
        DECLARE @CAuditEntityName NVARCHAR(200);
        DECLARE @CAuditModelName  NVARCHAR(200);
        DECLARE @CChangesJson NVARCHAR(MAX);
        DECLARE @CParts       NVARCHAR(MAX);
        DECLARE @CDetails     NVARCHAR(MAX);
        DECLARE @CEffOldLevel NVARCHAR(20);
        DECLARE @CEffNewLevel NVARCHAR(20);
        DECLARE @LkpCreate    BIT, @LkpRead BIT, @LkpUpdate BIT, @LkpMod BIT;

        DECLARE change_cur CURSOR LOCAL FAST_FORWARD FOR
            SELECT Scope, TargetId,
                   OldLevel, NewLevel,
                   OldCreate, NewCreate,
                   OldRead,   NewRead,
                   OldUpdate, NewUpdate,
                   OldDelete, NewDelete,
                   OldMod,    NewMod
            FROM #Changes;

        OPEN change_cur;
        FETCH NEXT FROM change_cur INTO
            @CScope, @CTargetId,
            @COldLevel, @CNewLevel,
            @COldCreate, @CNewCreate,
            @COldRead,   @CNewRead,
            @COldUpdate, @CNewUpdate,
            @COldDelete, @CNewDelete,
            @COldMod,    @CNewMod;

        WHILE @@FETCH_STATUS = 0
        BEGIN
            -- Reset per-iteration variables
            SET @CModId = NULL; SET @CModName = NULL;
            SET @CEntId = NULL; SET @CEntName = NULL;
            SET @CAttId = NULL; SET @CAttName = NULL;
            SET @CAuditEntityId   = NULL;
            SET @CAuditEntityName = N'Unknown';
            SET @CAuditModelName  = N'Unknown';
            SET @CEffOldLevel = NULL; SET @CEffNewLevel = NULL;
            SET @LkpCreate = NULL; SET @LkpRead = NULL; SET @LkpUpdate = NULL; SET @LkpMod = NULL;

            IF @CScope = 'model'
            BEGIN
                SELECT @CModId = Id, @CModName = Name FROM Models WHERE Id = @CTargetId;
                SET @CAuditEntityName = ISNULL(@CModName, N'Unknown');
                SET @CAuditModelName  = ISNULL(@CModName, N'Unknown');
            END
            ELSE IF @CScope = 'entity'
            BEGIN
                SELECT @CEntId = e.Id, @CEntName = e.Name, @CModId = m.Id, @CModName = m.Name
                FROM Entities e JOIN Models m ON e.ModelId = m.Id
                WHERE e.Id = @CTargetId;
                SET @CAuditEntityId   = @CEntId;
                SET @CAuditEntityName = ISNULL(@CEntName, N'Unknown');
                SET @CAuditModelName  = ISNULL(@CModName, N'Unknown');
            END
            ELSE IF @CScope = 'attribute'
            BEGIN
                SELECT @CAttId = a.Id, @CAttName = a.Name,
                       @CEntId = e.Id, @CEntName = e.Name,
                       @CModId = m.Id, @CModName = m.Name
                FROM Attributes a
                JOIN Entities e ON a.EntityId = e.Id
                JOIN Models m ON e.ModelId = m.Id
                WHERE a.Id = @CTargetId;
                SET @CAuditEntityId   = @CEntId;
                SET @CAuditEntityName = ISNULL(@CEntName, N'Unknown');
                SET @CAuditModelName  = ISNULL(@CModName, N'Unknown');
            END;

            -- Compute effective levels for attribute permissions (resolve 'none' = inherited)
            SET @CEffOldLevel = @COldLevel;
            SET @CEffNewLevel = @CNewLevel;
            IF @CScope = 'attribute'
            BEGIN
                IF @COldLevel = 'none' AND @CEntId IS NOT NULL
                BEGIN
                    SELECT @LkpCreate = CanCreate, @LkpRead = CanRead, @LkpUpdate = CanUpdate, @LkpMod = IsModerator
                    FROM #OldPerms WHERE Scope = 'entity' AND TargetId = @CEntId;
                    IF @LkpRead IS NOT NULL OR @LkpCreate IS NOT NULL OR @LkpUpdate IS NOT NULL
                        SET @CEffOldLevel = CASE WHEN ISNULL(@LkpMod,0)=1 OR ISNULL(@LkpUpdate,0)=1 OR ISNULL(@LkpCreate,0)=1 THEN 'write' WHEN ISNULL(@LkpRead,0)=1 THEN 'read' ELSE 'none' END;
                    ELSE IF @CModId IS NOT NULL
                    BEGIN
                        SET @LkpCreate = NULL; SET @LkpRead = NULL; SET @LkpUpdate = NULL; SET @LkpMod = NULL;
                        SELECT @LkpCreate = CanCreate, @LkpRead = CanRead, @LkpUpdate = CanUpdate, @LkpMod = IsModerator
                        FROM #OldPerms WHERE Scope = 'model' AND TargetId = @CModId;
                        SET @CEffOldLevel = CASE WHEN ISNULL(@LkpMod,0)=1 OR ISNULL(@LkpUpdate,0)=1 OR ISNULL(@LkpCreate,0)=1 THEN 'write' WHEN ISNULL(@LkpRead,0)=1 THEN 'read' ELSE 'none' END;
                    END;
                END;
                IF @CNewLevel = 'none' AND @CEntId IS NOT NULL
                BEGIN
                    SET @LkpCreate = NULL; SET @LkpRead = NULL; SET @LkpUpdate = NULL; SET @LkpMod = NULL;
                    SELECT @LkpCreate = CanCreate, @LkpRead = CanRead, @LkpUpdate = CanUpdate, @LkpMod = IsModerator
                    FROM #NewPerms WHERE Scope = 'entity' AND TargetId = @CEntId;
                    IF @LkpRead IS NOT NULL OR @LkpCreate IS NOT NULL OR @LkpUpdate IS NOT NULL
                        SET @CEffNewLevel = CASE WHEN ISNULL(@LkpMod,0)=1 OR ISNULL(@LkpUpdate,0)=1 OR ISNULL(@LkpCreate,0)=1 THEN 'write' WHEN ISNULL(@LkpRead,0)=1 THEN 'read' ELSE 'none' END;
                    ELSE IF @CModId IS NOT NULL
                    BEGIN
                        SET @LkpCreate = NULL; SET @LkpRead = NULL; SET @LkpUpdate = NULL; SET @LkpMod = NULL;
                        SELECT @LkpCreate = CanCreate, @LkpRead = CanRead, @LkpUpdate = CanUpdate, @LkpMod = IsModerator
                        FROM #NewPerms WHERE Scope = 'model' AND TargetId = @CModId;
                        SET @CEffNewLevel = CASE WHEN ISNULL(@LkpMod,0)=1 OR ISNULL(@LkpUpdate,0)=1 OR ISNULL(@LkpCreate,0)=1 THEN 'write' WHEN ISNULL(@LkpRead,0)=1 THEN 'read' ELSE 'none' END;
                    END;
                END;
            END;

            -- Build changes JSON
            IF @CScope = 'attribute'
            BEGIN
                SET @CChangesJson = N'"level":{"from":"' + @CEffOldLevel + N'","to":"' + @CEffNewLevel + N'"}';
            END
            ELSE
            BEGIN
                SET @CParts = N'';
                IF @COldCreate <> @CNewCreate
                    SET @CParts += N',"canCreate":{"from":' + CASE @COldCreate WHEN 1 THEN N'true' ELSE N'false' END + N',"to":' + CASE @CNewCreate WHEN 1 THEN N'true' ELSE N'false' END + N'}';
                IF @COldRead <> @CNewRead
                    SET @CParts += N',"canRead":{"from":' + CASE @COldRead WHEN 1 THEN N'true' ELSE N'false' END + N',"to":' + CASE @CNewRead WHEN 1 THEN N'true' ELSE N'false' END + N'}';
                IF @COldUpdate <> @CNewUpdate
                    SET @CParts += N',"canUpdate":{"from":' + CASE @COldUpdate WHEN 1 THEN N'true' ELSE N'false' END + N',"to":' + CASE @CNewUpdate WHEN 1 THEN N'true' ELSE N'false' END + N'}';
                IF @COldDelete <> @CNewDelete
                    SET @CParts += N',"canDelete":{"from":' + CASE @COldDelete WHEN 1 THEN N'true' ELSE N'false' END + N',"to":' + CASE @CNewDelete WHEN 1 THEN N'true' ELSE N'false' END + N'}';
                IF @COldMod <> @CNewMod
                    SET @CParts += N',"isModerator":{"from":' + CASE @COldMod WHEN 1 THEN N'true' ELSE N'false' END + N',"to":' + CASE @CNewMod WHEN 1 THEN N'true' ELSE N'false' END + N'}';
                SET @CChangesJson = CASE WHEN LEN(@CParts) > 0 THEN SUBSTRING(@CParts, 2, LEN(@CParts)) ELSE N'' END;
            END;

            -- Build full Details JSON
            SET @CDetails  = N'{"scope":"'    + @CScope + N'"';
            SET @CDetails += N',"modelId":'   + CAST(ISNULL(@CModId, 0) AS NVARCHAR(20));
            SET @CDetails += N',"modelName":"' + ISNULL(REPLACE(@CModName, '"', '\"'), N'') + N'"';
            IF @CScope IN ('entity','attribute')
            BEGIN
                SET @CDetails += N',"entityId":'    + CAST(ISNULL(@CEntId, 0) AS NVARCHAR(20));
                SET @CDetails += N',"entityName":"' + ISNULL(REPLACE(@CEntName, '"', '\"'), N'') + N'"';
            END;
            IF @CScope = 'attribute'
            BEGIN
                SET @CDetails += N',"attributeId":'    + CAST(ISNULL(@CAttId, 0) AS NVARCHAR(20));
                SET @CDetails += N',"attributeName":"' + ISNULL(REPLACE(@CAttName, '"', '\"'), N'') + N'"';
            END;
            SET @CDetails += N',"roleId":'    + CAST(@RoleId AS NVARCHAR(20));
            SET @CDetails += N',"roleName":"' + ISNULL(REPLACE(@RoleName, '"', '\"'), N'') + N'"';
            SET @CDetails += N',"changes":{'  + @CChangesJson + N'}}';

            INSERT INTO AuditLog (EntityId, EntityName, ModelName, Action, RecordCount, UserId, Comment, Details)
            VALUES (@CAuditEntityId, @CAuditEntityName, @CAuditModelName,
                    N'permission_change', 1, @UserId, NULL, @CDetails);

            FETCH NEXT FROM change_cur INTO
                @CScope, @CTargetId,
                @COldLevel, @CNewLevel,
                @COldCreate, @CNewCreate,
                @COldRead,   @CNewRead,
                @COldUpdate, @CNewUpdate,
                @COldDelete, @CNewDelete,
                @COldMod,    @CNewMod;
        END;

        CLOSE change_cur;
        DEALLOCATE change_cur;

        COMMIT TRANSACTION;
        SELECT @SavedCount AS Saved;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Permission_Delete
    @Id INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Deletes a single permission record by its primary key.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM Permissions WHERE Id = @Id;
    SELECT @@ROWCOUNT AS Deleted;
END;
GO

CREATE OR ALTER PROCEDURE usp_Permission_GetEffective
    @UserId   INT,
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-20
-- Description: Returns the effective CRUD permission bits for a user on a
--              specific entity. Resolves by OR-aggregating all group permissions
--              at entity scope first, falling back to model scope if no
--              entity-level rows exist. IsModerator implies full CRUD.
--              C/U/D imply Read.
--
-- Change History:
--   v1.0  2026-02-20  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @ModelId INT;
    SELECT @ModelId = ModelId FROM Entities WHERE Id = @EntityId;

    DECLARE
        @CanCreate   BIT = 0,
        @CanRead     BIT = 0,
        @CanUpdate   BIT = 0,
        @CanDelete   BIT = 0,
        @IsModerator BIT = 0,
        @HasEntityScope BIT = 0;

    -- Entity scope: OR-aggregate across all groups the user belongs to
    SELECT
        @CanCreate   = ISNULL(MAX(CAST(p.CanCreate AS INT)), 0),
        @CanRead     = ISNULL(MAX(CAST(p.CanRead AS INT)), 0),
        @CanUpdate   = ISNULL(MAX(CAST(p.CanUpdate AS INT)), 0),
        @CanDelete   = ISNULL(MAX(CAST(p.CanDelete AS INT)), 0),
        @IsModerator = ISNULL(MAX(CAST(p.IsModerator AS INT)), 0),
        @HasEntityScope = CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END
    FROM Permissions p
    INNER JOIN RoleMembers gm ON gm.RoleId = p.RoleId AND gm.UserId = @UserId
    WHERE p.Scope = 'entity' AND p.TargetId = @EntityId;

    -- Fall back to model scope only if no entity-scope rows found
    IF @HasEntityScope = 0 AND @ModelId IS NOT NULL
    BEGIN
        SELECT
            @CanCreate   = ISNULL(MAX(CAST(p.CanCreate AS INT)), 0),
            @CanRead     = ISNULL(MAX(CAST(p.CanRead AS INT)), 0),
            @CanUpdate   = ISNULL(MAX(CAST(p.CanUpdate AS INT)), 0),
            @CanDelete   = ISNULL(MAX(CAST(p.CanDelete AS INT)), 0),
            @IsModerator = ISNULL(MAX(CAST(p.IsModerator AS INT)), 0)
        FROM Permissions p
        INNER JOIN RoleMembers gm ON gm.RoleId = p.RoleId AND gm.UserId = @UserId
        WHERE p.Scope = 'model' AND p.TargetId = @ModelId;
    END

    -- IsModerator implies full CRUD
    IF @IsModerator = 1
    BEGIN
        SET @CanCreate = 1;
        SET @CanRead   = 1;
        SET @CanUpdate = 1;
        SET @CanDelete = 1;
    END

    -- C/U/D imply Read
    IF @CanCreate = 1 OR @CanUpdate = 1 OR @CanDelete = 1
        SET @CanRead = 1;

    SELECT @CanCreate AS CanCreate, @CanRead AS CanRead,
           @CanUpdate AS CanUpdate, @CanDelete AS CanDelete,
           @IsModerator AS IsModerator;
END;
GO

-- ============================================
-- SETTINGS PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_Settings_GetUser
    @UserId INT NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns all settings key-value pairs for the specified user.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT SettingKey, SettingValue FROM UserSettings WHERE UserId = @UserId;
END;
GO

CREATE OR ALTER PROCEDURE usp_Settings_SaveUser
    @UserId INT NULL,
    @SettingsJson NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Upserts user settings from a JSON key-value object using MERGE.
--              Existing keys are updated; missing keys are inserted. The
--              COLLATE DATABASE_DEFAULT handles collation differences between
--              OPENJSON output and the table column.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    MERGE UserSettings AS target
    USING (
        SELECT @UserId AS UserId, [key] COLLATE DATABASE_DEFAULT AS SettingKey, [value] AS SettingValue
        FROM OPENJSON(@SettingsJson)
    ) AS source
    ON (target.UserId = source.UserId OR (target.UserId IS NULL AND source.UserId IS NULL))
       AND target.SettingKey = source.SettingKey
    WHEN MATCHED THEN UPDATE SET SettingValue = source.SettingValue, ModifiedAt = GETUTCDATE()
    WHEN NOT MATCHED THEN INSERT (UserId, SettingKey, SettingValue) VALUES (source.UserId, source.SettingKey, source.SettingValue);
    SELECT @@ROWCOUNT AS Saved;
END;
GO

CREATE OR ALTER PROCEDURE usp_Settings_GetApp
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns all application-wide settings key-value pairs.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT SettingKey, SettingValue FROM AppSettings;
END;
GO

CREATE OR ALTER PROCEDURE usp_Settings_SaveApp
    @SettingsJson NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Upserts application-wide settings from a JSON key-value object
--              using MERGE. Updates ModifiedAt on existing rows; inserts new
--              keys as needed.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    MERGE AppSettings AS target
    USING (
        SELECT [key] COLLATE DATABASE_DEFAULT AS SettingKey, [value] AS SettingValue
        FROM OPENJSON(@SettingsJson)
    ) AS source
    ON target.SettingKey = source.SettingKey
    WHEN MATCHED THEN UPDATE SET SettingValue = source.SettingValue, ModifiedAt = GETUTCDATE()
    WHEN NOT MATCHED THEN INSERT (SettingKey, SettingValue) VALUES (source.SettingKey, source.SettingValue);
    SELECT @@ROWCOUNT AS Saved;
END;
GO

-- ============================================
-- AUDIT LOG PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_AuditLog_Write
    @EntityId INT = NULL,
    @EntityName NVARCHAR(200),
    @ModelName NVARCHAR(200),
    @Action NVARCHAR(50),
    @RecordCount INT = 1,
    @UserId INT = NULL,
    @Comment NVARCHAR(1000) = NULL,
    @Details NVARCHAR(MAX) = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Inserts a single audit log entry and returns the generated Id.
--              Called after every create, edit, delete, or import operation
--              to maintain a change history.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO AuditLog (EntityId, EntityName, ModelName, Action, RecordCount, UserId, Comment, Details)
    VALUES (@EntityId, @EntityName, @ModelName, @Action, @RecordCount, @UserId, @Comment, @Details);
    SELECT SCOPE_IDENTITY() AS Id;
END;
GO

CREATE OR ALTER PROCEDURE usp_AuditLog_Cleanup
    @RetentionDays INT = 90
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Removes audit log entries older than @RetentionDays (default
--              90 days). Intended to be run periodically as a maintenance job
--              to prevent unbounded table growth.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM AuditLog WHERE CreatedAt < DATEADD(DAY, -@RetentionDays, GETUTCDATE());
    SELECT @@ROWCOUNT AS DeletedCount;
END;
GO

CREATE OR ALTER PROCEDURE usp_Approval_Cleanup
    @RetentionDays INT = 365
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-26
-- Description: Removes resolved approval requests (approved, rejected,
--              sent_back, cancelled) older than @RetentionDays. Pending
--              requests are never deleted. Child rows and reviews are removed
--              via ON DELETE CASCADE. The self-referential PreviousRequestId
--              FK is NULLed before deletion to avoid FK violations.
--              @RetentionDays = 0 disables cleanup entirely.
--
-- Change History:
--   v1.0  2026-02-26  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- 0 = keep forever, skip cleanup
    IF @RetentionDays <= 0
    BEGIN
        SELECT 0 AS DeletedCount;
        RETURN;
    END

    -- NULL out self-referential links pointing to records about to be deleted
    -- (PreviousRequestId is nullable; no cascade is defined on this FK)
    UPDATE ApprovalRequests
    SET PreviousRequestId = NULL
    WHERE PreviousRequestId IN (
        SELECT Id FROM ApprovalRequests
        WHERE Status IN ('approved', 'rejected', 'sent_back', 'cancelled')
          AND SubmittedAt < DATEADD(DAY, -@RetentionDays, SYSDATETIME())
    );

    -- Delete old terminal-state requests; ApprovalRows and ApprovalReviews cascade
    DELETE FROM ApprovalRequests
    WHERE Status IN ('approved', 'rejected', 'sent_back', 'cancelled')
      AND SubmittedAt < DATEADD(DAY, -@RetentionDays, SYSDATETIME());

    SELECT @@ROWCOUNT AS DeletedCount;
END;
GO

CREATE OR ALTER PROCEDURE usp_AuditLog_GetDashboard
    @Days INT = 365
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-09
-- Description: Returns the last 200 data-action audit entries within @Days
--              for the dashboard widgets. Includes direct data changes and
--              approval workflow actions. Lightweight: no Details column.
--
-- Change History:
--   v1.0  2026-03-09  Initial version
--   v1.1  2026-03-09  Added approval_submitted, approved, force_approved,
--                      and create/edit to action filter
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SET @Days = CASE WHEN @Days < 1 THEN 365 WHEN @Days > 3650 THEN 3650 ELSE @Days END;

    SELECT TOP 200
           a.Id, a.EntityId, a.EntityName, a.ModelName, a.Action,
           a.RecordCount, a.UserId,
           u.DisplayName AS UserDisplayName,
           a.Comment, a.CreatedAt
    FROM AuditLog a
    LEFT JOIN Users u ON u.Id = a.UserId
    WHERE a.Action IN ('edit', 'create', 'delete', 'import', 'purge',
                       'create/edit', 'approval_submitted', 'approved', 'force_approved')
      AND a.CreatedAt >= DATEADD(DAY, -@Days, GETUTCDATE())
      AND a.EntityName NOT LIKE 'TEST[_]%'
    ORDER BY a.CreatedAt DESC;
END;
GO

CREATE OR ALTER PROCEDURE usp_AuditLog_GetPaginated
    @Page INT = 1,
    @PageSize INT = 50,
    @EntityId INT = NULL,
    @Action NVARCHAR(50) = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns a paginated page of audit log entries, optionally
--              filtered by entity and/or action type. Produces two result
--              sets: (1) total count for pagination UI, (2) the requested page
--              ordered newest-first.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Offset INT = (@Page - 1) * @PageSize;

    -- Result set 1: total matching rows (for pagination metadata)
    SELECT COUNT(*) AS Total FROM AuditLog
    WHERE (@EntityId IS NULL OR EntityId = @EntityId)
      AND (@Action IS NULL OR Action = @Action);

    -- Result set 2: the current page of results
    SELECT a.Id, a.EntityId, a.EntityName, a.ModelName, a.Action, a.RecordCount,
           a.UserId, u.Email AS UserEmail, u.DisplayName AS UserDisplayName,
           a.Comment, a.Details, a.CreatedAt
    FROM AuditLog a
    LEFT JOIN Users u ON u.Id = a.UserId
    WHERE (@EntityId IS NULL OR a.EntityId = @EntityId)
      AND (@Action IS NULL OR a.Action = @Action)
    ORDER BY a.CreatedAt DESC
    OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE usp_AuditLog_ResolveAttributes
    @EntityIdsJson NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Resolves attribute names for a set of entity IDs supplied
--              as a JSON array. Used by the audit log viewer to display
--              human-readable attribute names instead of raw attribute IDs
--              stored in the Details JSON.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT EntityId, Name, DisplayName
    FROM Attributes
    WHERE EntityId IN (SELECT CAST(value AS INT) FROM OPENJSON(@EntityIdsJson));
END;
GO

CREATE OR ALTER PROCEDURE usp_AuditLog_GetByRow
    @EntityId INT,
    @RowCode NVARCHAR(200),
    @RowId BIGINT = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns the audit history for a specific data row, matched
--              by Code or by the saved database Id stored in the Details JSON.
--              The @RowId fallback handles cases where a row was created and
--              its temporary frontend Id was replaced by the real DB Id on save.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- When a DB row ID is available, match exclusively by _savedId to prevent
    -- old deleted rows with the same code from polluting the audit history.
    -- Fall back to code-matching only when no DB ID is provided (demo mode).
    SELECT TOP 50
        al.Id, al.Action, al.UserId,
        u.Email AS UserEmail, u.DisplayName AS UserDisplayName,
        al.Comment, al.Details, al.CreatedAt
    FROM AuditLog al
    LEFT JOIN Users u ON u.Id = al.UserId
    WHERE al.EntityId = @EntityId
      AND al.Details IS NOT NULL
      AND EXISTS (
          SELECT 1 FROM OPENJSON(al.Details) WITH (
              code NVARCHAR(200) '$.code',
              _savedId BIGINT '$._savedId'
          ) j
          WHERE (@RowId IS NOT NULL AND j._savedId = @RowId)
             OR (@RowId IS NULL     AND j.code = @RowCode)
      )
    ORDER BY al.CreatedAt DESC;
END;
GO

-- ============================================
-- DATA PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_Data_GetByEntity
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns all rows and their EAV attribute values for an entity.
--              Domain values are resolved to their Code and Name via a join.
--              This is the full-export query — use usp_Data_GetByEntityPaginated
--              for grid display to avoid loading all rows at once.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        er.Id, er.Code, er.Name,
        er.CreatedAt, er.ModifiedAt, er.CreatedBy, er.ModifiedBy,
        uc.DisplayName AS CreatedByName, uc.Email AS CreatedByEmail,
        um.DisplayName AS ModifiedByName, um.Email AS ModifiedByEmail,
        a.Id AS AttributeId, a.Name AS AttributeName, a.DataType,
        ev.TextValue, ev.IntValue, ev.DecimalValue, ev.DateTimeValue, ev.DomainValue,
        dr.Code AS DomainCode, dr.Name AS DomainName
    FROM EntityRows er
    LEFT JOIN EntityValues ev ON ev.EntityRowId = er.Id
    LEFT JOIN Attributes a ON a.Id = ev.AttributeId AND a.IsSystemDate = 0
    LEFT JOIN EntityRows dr ON dr.Id = ev.DomainValue
    LEFT JOIN Users uc ON uc.Id = er.CreatedBy
    LEFT JOIN Users um ON um.Id = er.ModifiedBy
    WHERE er.EntityId = @EntityId
    ORDER BY er.Id, a.SortOrder;
END;
GO

CREATE OR ALTER PROCEDURE usp_Data_GetRowCounts
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns the row count per entity across all entities.
--              Used by the dashboard and entity list to display record
--              counts without loading the actual data.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT EntityId, COUNT(*) AS Cnt FROM EntityRows GROUP BY EntityId;
END;
GO

CREATE OR ALTER PROCEDURE usp_Data_GetSingleRow
    @EntityId INT,
    @RowId BIGINT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns a single entity row and all of its EAV attribute
--              values identified by EntityId and RowId. Domain values are
--              resolved to Code and Name. Used for row-level detail views.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT er.Id, er.Code, er.Name, er.CreatedAt, er.ModifiedAt, er.CreatedBy, er.ModifiedBy,
           uc.DisplayName AS CreatedByName, uc.Email AS CreatedByEmail,
           um.DisplayName AS ModifiedByName, um.Email AS ModifiedByEmail,
           a.Id AS AttributeId, a.Name AS AttributeName, a.DataType,
           ev.TextValue, ev.IntValue, ev.DecimalValue, ev.DateTimeValue, ev.DomainValue,
           dr.Code AS DomainCode, dr.Name AS DomainName
    FROM EntityRows er
    LEFT JOIN EntityValues ev ON ev.EntityRowId = er.Id
    LEFT JOIN Attributes a ON a.Id = ev.AttributeId AND a.IsSystemDate = 0
    LEFT JOIN EntityRows dr ON dr.Id = ev.DomainValue
    LEFT JOIN Users uc ON uc.Id = er.CreatedBy
    LEFT JOIN Users um ON um.Id = er.ModifiedBy
    WHERE er.EntityId = @EntityId AND er.Id = @RowId
    ORDER BY a.SortOrder;
END;
GO

CREATE OR ALTER PROCEDURE usp_Data_SaveRow
    @EntityId INT,
    @RowId BIGINT = NULL,
    @Code NVARCHAR(200),
    @Name NVARCHAR(500),
    @Values NVARCHAR(MAX),
    @UserId INT = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Creates or updates a single entity row and its EAV attribute
--              values. When @RowId is NULL a new row is inserted; otherwise
--              the existing row is updated. Validates required fields (Code,
--              Name, and required custom attributes) before writing. EAV values
--              are merged using MERGE to handle inserts and updates in one pass.
--              Supports the OwnTransaction pattern to work standalone or nested
--              inside a caller's transaction.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @OwnTransaction BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRANSACTION; SET @OwnTransaction = 1; END

    BEGIN TRY
        -- Parse @Values once to avoid repeated OPENJSON calls.
        -- domainValue is parsed as NVARCHAR(50) to prevent implicit BIGINT conversion
        -- errors from dooming the transaction before we can return a meaningful message.
        SELECT
            CAST(attributeId AS INT) AS AttributeId,
            textValue, intValue, decimalValue, dateTimeValue, domainValue
        INTO #ParsedValues
        FROM OPENJSON(@Values) WITH (
            attributeId INT, textValue NVARCHAR(MAX), intValue INT,
            decimalValue DECIMAL(18,6), dateTimeValue DATETIME2, domainValue NVARCHAR(50)
        );

        -- Validate that all provided domainValues are valid integers (EntityRow Ids).
        -- A non-integer value means the attribute is configured as Domain but has no
        -- domain entity linked, or the frontend sent a wrong value type.
        IF EXISTS (
            SELECT 1 FROM #ParsedValues WHERE domainValue IS NOT NULL AND TRY_CAST(domainValue AS BIGINT) IS NULL
        )
        BEGIN
            DECLARE @BadDomainField NVARCHAR(200) = NULL;
            DECLARE @BadDomainValue NVARCHAR(50) = NULL;
            SELECT TOP 1 @BadDomainField = a.DisplayName, @BadDomainValue = pv.domainValue
            FROM #ParsedValues pv
            JOIN Attributes a ON a.Id = pv.AttributeId
            WHERE pv.domainValue IS NOT NULL AND TRY_CAST(pv.domainValue AS BIGINT) IS NULL;
            DECLARE @DomainErrMsg NVARCHAR(500) = 'Field "' + ISNULL(@BadDomainField, '?') + '" is configured as a Domain type but received an invalid value ("' + ISNULL(@BadDomainValue, '?') + '"). Either link a domain entity to this field in Administration, or change its type.';
            THROW 50001, @DomainErrMsg, 1;
        END
        -- Required field validation
        DECLARE @MissingFields NVARCHAR(MAX) = '';
        DECLARE @AutoGenCode BIT;
        SELECT @AutoGenCode = ISNULL(AutoGenerateCode, 0) FROM Entities WHERE Id = @EntityId;

        -- Check Code (required unless auto-generated)
        IF @AutoGenCode = 0 AND LTRIM(RTRIM(ISNULL(@Code, ''))) = ''
            SET @MissingFields = @MissingFields + 'Code, ';

        -- Check Name (always required)
        IF LTRIM(RTRIM(ISNULL(@Name, ''))) = ''
            SET @MissingFields = @MissingFields + 'Name, ';

        -- Check required custom attributes
        DECLARE @TempMissing NVARCHAR(MAX);
        SELECT @TempMissing = STUFF((
            SELECT ', ' + a.DisplayName
            FROM Attributes a
            WHERE a.EntityId = @EntityId
                AND a.IsRequired = 1
                AND a.IsCode = 0
                AND a.IsName = 0
                AND NOT EXISTS (
                    SELECT 1 FROM #ParsedValues v
                    WHERE v.attributeId = a.Id
                    AND (
                        (a.DataType = 'Text' AND LTRIM(RTRIM(ISNULL(v.textValue, ''))) <> '')
                        OR (a.DataType = 'Int' AND v.intValue IS NOT NULL)
                        OR (a.DataType = 'Decimal' AND v.decimalValue IS NOT NULL)
                        OR (a.DataType = 'DateTime' AND v.dateTimeValue IS NOT NULL)
                        OR (a.DataType = 'Boolean' AND v.intValue IS NOT NULL)
                        OR (a.DataType = 'Domain' AND v.domainValue IS NOT NULL)
                    )
                )
            FOR XML PATH(''), TYPE
        ).value('.', 'NVARCHAR(MAX)'), 1, 2, '');

        IF @TempMissing IS NOT NULL
            SET @MissingFields = @MissingFields + @TempMissing;

        -- Remove trailing comma if exists
        SET @MissingFields = RTRIM(@MissingFields);
        IF RIGHT(@MissingFields, 1) = ',' SET @MissingFields = LEFT(@MissingFields, LEN(@MissingFields) - 1);

        IF LEN(@MissingFields) > 0
        BEGIN
            DECLARE @ErrorMsg NVARCHAR(500) = 'Required fields missing: ' + @MissingFields;
            THROW 50001, @ErrorMsg, 1;
        END

        -- Validate domain values exist before writing (prevents FK violation 500 errors)
        IF EXISTS (
            SELECT 1 FROM #ParsedValues j
            WHERE j.domainValue IS NOT NULL
              AND NOT EXISTS (SELECT 1 FROM EntityRows WHERE Id = TRY_CAST(j.domainValue AS BIGINT))
        )
            THROW 50001, 'One or more domain field values reference rows that no longer exist in the database. Please refresh the page and try again.', 1;

        IF @RowId IS NULL
        BEGIN
            INSERT INTO EntityRows (EntityId, Code, Name, CreatedBy, ModifiedBy)
            VALUES (@EntityId, @Code, @Name, @UserId, @UserId);
            SET @RowId = SCOPE_IDENTITY();
        END
        ELSE
        BEGIN
            UPDATE EntityRows SET Code = @Code, Name = @Name,
                ModifiedAt = GETUTCDATE(), ModifiedBy = @UserId
            WHERE Id = @RowId AND EntityId = @EntityId;
        END

        MERGE EntityValues AS target
        USING (
            SELECT @RowId AS EntityRowId, pv.AttributeId,
                   pv.textValue, pv.intValue, pv.decimalValue, pv.dateTimeValue, pv.domainValue
            FROM #ParsedValues pv
            -- Never write EntityValues for system date attributes — their values
            -- come from EntityRows.CreatedAt / ModifiedAt, not from EntityValues
            JOIN Attributes sa ON sa.Id = pv.AttributeId AND sa.IsSystemDate = 0
        ) AS source
        ON target.EntityRowId = source.EntityRowId AND target.AttributeId = source.AttributeId
        WHEN MATCHED THEN UPDATE SET
            TextValue = source.textValue, IntValue = source.intValue,
            DecimalValue = source.decimalValue, DateTimeValue = source.dateTimeValue,
            DomainValue = TRY_CAST(source.domainValue AS BIGINT)
        WHEN NOT MATCHED THEN
            INSERT (EntityRowId, AttributeId, TextValue, IntValue, DecimalValue, DateTimeValue, DomainValue)
            VALUES (source.EntityRowId, source.AttributeId, source.textValue, source.intValue,
                    source.decimalValue, source.dateTimeValue, TRY_CAST(source.domainValue AS BIGINT));

        IF OBJECT_ID('tempdb..#ParsedValues') IS NOT NULL DROP TABLE #ParsedValues;
        IF @OwnTransaction = 1 COMMIT TRANSACTION;
        SELECT @RowId AS Id, ModifiedAt, CreatedAt FROM EntityRows WHERE Id = @RowId;
    END TRY
    BEGIN CATCH
        IF @OwnTransaction = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        IF OBJECT_ID('tempdb..#ParsedValues') IS NOT NULL DROP TABLE #ParsedValues;
        THROW;
    END CATCH
END;
GO

SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE OR ALTER PROCEDURE usp_Data_BulkImportRows
    @EntityId      INT,
    @ConflictAction NVARCHAR(20),   -- 'import' | 'overwrite' | 'delete_import'
    @RowsJson      NVARCHAR(MAX),   -- [{code, name, values:[{attributeId,textValue,...}]}]
    @UserId        INT = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-26
-- Description: High-performance bulk import for a single entity.
--              Parses all rows from JSON once, resolves conflicts, and
--              writes EntityRows + EntityValues in set-based operations.
--              Avoids the per-row overhead of usp_Data_SaveRow (no per-row
--              temp tables, no per-row validation, no per-row audit trail).
--              Used exclusively by the migration wizard import path.
--
-- Change History:
--   v1.0  2026-02-26  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @OwnTransaction BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRANSACTION; SET @OwnTransaction = 1; END

    BEGIN TRY
        -- 1. If delete_import, purge all existing rows first
        IF @ConflictAction = 'delete_import'
        BEGIN
            UPDATE EntityValues SET DomainValue = NULL
            WHERE DomainValue IN (SELECT Id FROM EntityRows WHERE EntityId = @EntityId);
            DELETE ApprovalRows WHERE EntityRowId IN (SELECT Id FROM EntityRows WHERE EntityId = @EntityId);
            DELETE EntityRows WHERE EntityId = @EntityId;
        END

        -- 2. Parse incoming rows into temp table
        SELECT
            CAST(j.code AS NVARCHAR(200))        AS Code,
            LOWER(CAST(j.code AS NVARCHAR(200))) AS CodeLower,
            CAST(j.name AS NVARCHAR(500))         AS Name,
            CAST(j.vals AS NVARCHAR(MAX))         AS ValuesJson
        INTO #InRows
        FROM OPENJSON(@RowsJson) WITH (
            code  NVARCHAR(200)  '$.code',
            name  NVARCHAR(500)  '$.name',
            vals  NVARCHAR(MAX)  '$.values' AS JSON
        ) j;

        -- 3. Pre-compute system-date attribute IDs to exclude from values insert
        SELECT Id INTO #SysDateAttrs
        FROM Attributes
        WHERE EntityId = @EntityId AND IsSystemDate = 1;

        -- 4. Snapshot existing codes (after purge, so empty for delete_import)
        SELECT Id, LOWER(Code) AS CodeLower
        INTO #Existing
        FROM EntityRows
        WHERE EntityId = @EntityId;

        -- 5. Insert rows whose code does not yet exist (all three modes)
        INSERT INTO EntityRows (EntityId, Code, Name, CreatedBy, ModifiedBy)
        SELECT @EntityId, ir.Code, ir.Name, @UserId, @UserId
        FROM #InRows ir
        WHERE NOT EXISTS (SELECT 1 FROM #Existing ex WHERE ex.CodeLower = ir.CodeLower);
        DECLARE @inserted INT = @@ROWCOUNT;

        -- 6. Update existing rows for overwrite mode
        DECLARE @updated INT = 0;
        IF @ConflictAction = 'overwrite'
        BEGIN
            UPDATE er
            SET er.Code = ir.Code, er.Name = ir.Name,
                er.ModifiedAt = GETUTCDATE(), er.ModifiedBy = @UserId
            FROM EntityRows er
            JOIN #Existing ex ON ex.Id = er.Id
            JOIN #InRows ir   ON ir.CodeLower = ex.CodeLower;
            SET @updated = @@ROWCOUNT;
        END

        DECLARE @skipped INT = 0;
        IF @ConflictAction = 'import'
            SET @skipped = (SELECT COUNT(*) FROM #InRows) - @inserted;

        -- 7. Build row-ID map: CodeLower -> EntityRow.Id, flag whether pre-existing
        --    For import:        only new rows (pre-existing rows were skipped)
        --    For overwrite:     all rows (new + updated)
        --    For delete_import: all rows (all are new after the purge)
        SELECT
            er.Id                                                     AS RowId,
            ir.ValuesJson,
            CASE WHEN ex.Id IS NOT NULL THEN 1 ELSE 0 END             AS WasExisting
        INTO #RowMap
        FROM EntityRows er
        JOIN #InRows ir ON LOWER(er.Code) = ir.CodeLower
        LEFT JOIN #Existing ex ON ex.CodeLower = ir.CodeLower
        WHERE er.EntityId = @EntityId
          AND (@ConflictAction = 'overwrite' OR ex.Id IS NULL);

        -- 8. INSERT EntityValues for newly inserted rows (all modes)
        INSERT INTO EntityValues
            (EntityRowId, AttributeId, TextValue, IntValue, DecimalValue, DateTimeValue, DomainValue)
        SELECT
            rm.RowId,
            CAST(v.attributeId AS INT),
            v.textValue, v.intValue, v.decimalValue, v.dateTimeValue, v.domainValue
        FROM #RowMap rm
        CROSS APPLY OPENJSON(rm.ValuesJson) WITH (
            attributeId   INT,
            textValue     NVARCHAR(MAX),
            intValue      INT,
            decimalValue  DECIMAL(18,6),
            dateTimeValue DATETIME2,
            domainValue   BIGINT
        ) v
        WHERE rm.WasExisting = 0
          AND v.attributeId IS NOT NULL
          AND v.attributeId NOT IN (SELECT Id FROM #SysDateAttrs);

        -- 9. MERGE EntityValues for pre-existing rows (overwrite only)
        IF @ConflictAction = 'overwrite'
        BEGIN
            MERGE EntityValues AS target
            USING (
                SELECT
                    rm.RowId,
                    CAST(v.attributeId AS INT) AS AttributeId,
                    v.textValue, v.intValue, v.decimalValue, v.dateTimeValue, v.domainValue
                FROM #RowMap rm
                CROSS APPLY OPENJSON(rm.ValuesJson) WITH (
                    attributeId   INT,
                    textValue     NVARCHAR(MAX),
                    intValue      INT,
                    decimalValue  DECIMAL(18,6),
                    dateTimeValue DATETIME2,
                    domainValue   BIGINT
                ) v
                WHERE rm.WasExisting = 1
                  AND v.attributeId IS NOT NULL
                  AND v.attributeId NOT IN (SELECT Id FROM #SysDateAttrs)
            ) AS source
            ON target.EntityRowId = source.RowId AND target.AttributeId = source.AttributeId
            WHEN MATCHED THEN UPDATE SET
                TextValue     = source.textValue,
                IntValue      = source.intValue,
                DecimalValue  = source.decimalValue,
                DateTimeValue = source.dateTimeValue,
                DomainValue   = source.domainValue
            WHEN NOT MATCHED THEN
                INSERT (EntityRowId, AttributeId, TextValue, IntValue, DecimalValue, DateTimeValue, DomainValue)
                VALUES (source.RowId, source.AttributeId, source.textValue, source.intValue,
                        source.decimalValue, source.dateTimeValue, source.domainValue);
        END

        IF @OwnTransaction = 1 COMMIT TRANSACTION;
        SELECT @inserted AS inserted, @updated AS updated, @skipped AS skipped;
    END TRY
    BEGIN CATCH
        IF @OwnTransaction = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Data_DeleteRows
    @EntityId INT,
    @RowIds NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Deletes a specific set of entity rows by their Ids (supplied
--              as a JSON array). Before deleting, nulls out any DomainValue
--              references pointing to these rows in EntityValues to prevent
--              FK constraint violations from cross-entity domain relationships.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v1.1  2026-02-23  Use temp table for IDs to give optimizer accurate
--                     cardinality estimates; INNER JOIN delete for clarity.
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @OwnTransaction BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRANSACTION; SET @OwnTransaction = 1; END

    BEGIN TRY
        -- Materialize IDs into a temp table so the optimizer has accurate statistics
        CREATE TABLE #DelIds (Id BIGINT NOT NULL PRIMARY KEY);
        INSERT INTO #DelIds (Id)
            SELECT CAST(value AS BIGINT) FROM OPENJSON(@RowIds);

        -- Null out domain references pointing to these rows (prevent FK violations)
        UPDATE EntityValues SET DomainValue = NULL
        WHERE DomainValue IN (SELECT Id FROM #DelIds);

        -- Remove approval rows referencing these entity rows
        DELETE FROM ApprovalRows WHERE EntityRowId IN (SELECT Id FROM #DelIds);

        -- Delete rows (set-based join is cleaner and index-friendly)
        DELETE er FROM EntityRows er
        INNER JOIN #DelIds d ON er.Id = d.Id
        WHERE er.EntityId = @EntityId;

        DECLARE @Deleted INT = @@ROWCOUNT;
        DROP TABLE #DelIds;
        IF @OwnTransaction = 1 COMMIT TRANSACTION;
        SELECT @Deleted AS DeletedCount;
    END TRY
    BEGIN CATCH
        IF OBJECT_ID('tempdb..#DelIds') IS NOT NULL DROP TABLE #DelIds;
        IF @OwnTransaction = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Data_DeleteAllRows
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Deletes every row for an entity. Before deleting, nulls out
--              any DomainValue references in EntityValues that point to these
--              rows to prevent FK constraint violations. Used for the
--              "Delete + import" action during bulk data operations.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @OwnTransaction BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRANSACTION; SET @OwnTransaction = 1; END

    BEGIN TRY
        -- Clear domain references pointing to this entity's rows before deleting
        UPDATE EntityValues SET DomainValue = NULL
        WHERE DomainValue IN (SELECT Id FROM EntityRows WHERE EntityId = @EntityId);

        -- Remove approval rows referencing this entity's rows
        DELETE FROM ApprovalRows WHERE EntityRowId IN (SELECT Id FROM EntityRows WHERE EntityId = @EntityId);

        DELETE FROM EntityRows WHERE EntityId = @EntityId;
        DECLARE @Deleted INT = @@ROWCOUNT;
        IF @OwnTransaction = 1 COMMIT TRANSACTION;
        SELECT @Deleted AS DeletedCount;
    END TRY
    BEGIN CATCH
        IF @OwnTransaction = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Data_GetExistingCodes
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns the Id and Code of every row for an entity. Used
--              during import to detect conflicts before upserting data
--              (Code is the business key / unique identifier for a row).
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Id, Code FROM EntityRows WHERE EntityId = @EntityId;
END;
GO

CREATE OR ALTER PROCEDURE usp_Data_GetEntityMeta
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns the entity name and its parent model name for a given
--              entity Id. Used to populate audit log entries with human-readable
--              context without requiring the caller to look up the model separately.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT e.Name AS EntityName, m.Name AS ModelName
    FROM Entities e JOIN Models m ON m.Id = e.ModelId
    WHERE e.Id = @EntityId;
END;
GO

CREATE OR ALTER PROCEDURE usp_Data_GetDeleteSnapshot
    @EntityId INT,
    @RowIds NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Captures a snapshot of rows (with all attribute values) before
--              they are deleted. The snapshot is written to the audit log Details
--              field so that deleted records can be inspected historically.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT er.Id, er.Code, er.Name,
           a.DisplayName AS AttributeName, a.DataType,
           ev.TextValue, ev.IntValue, ev.DecimalValue, ev.DateTimeValue, ev.DomainValue,
           dr.Code AS DomainCode, dr.Name AS DomainName
    FROM EntityRows er
    LEFT JOIN EntityValues ev ON ev.EntityRowId = er.Id
    LEFT JOIN Attributes a ON a.Id = ev.AttributeId
    LEFT JOIN EntityRows dr ON dr.Id = ev.DomainValue
    WHERE er.EntityId = @EntityId
      AND er.Id IN (SELECT CAST(value AS BIGINT) FROM OPENJSON(@RowIds))
    ORDER BY er.Id, a.SortOrder;
END;
GO

CREATE OR ALTER PROCEDURE usp_Data_GetAllRowsSnapshot
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-18
-- Description: Captures a snapshot of ALL rows for an entity (with all
--              attribute values) before a purge operation. The snapshot is
--              written to the audit log Details field so that purged records
--              can be inspected and re-imported if needed.
--
-- Change History:
--   v1.0  2026-02-18  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT er.Id, er.Code, er.Name,
           a.DisplayName AS AttributeName, a.DataType,
           ev.TextValue, ev.IntValue, ev.DecimalValue, ev.DateTimeValue, ev.DomainValue,
           dr.Code AS DomainCode, dr.Name AS DomainName
    FROM EntityRows er
    LEFT JOIN EntityValues ev ON ev.EntityRowId = er.Id
    LEFT JOIN Attributes a ON a.Id = ev.AttributeId
    LEFT JOIN EntityRows dr ON dr.Id = ev.DomainValue
    WHERE er.EntityId = @EntityId
    ORDER BY er.Id, a.SortOrder;
END;
GO

CREATE OR ALTER PROCEDURE usp_Data_GetRowsSnapshot
    @EntityId INT,
    @RowIdsJson NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-09
-- Description: Captures a snapshot of specific rows (by ID) for an entity,
--              including all attribute values. Used by the delete-rows route
--              to store a full server-side snapshot in the audit log before
--              deleting the rows.
--
-- Change History:
--   v1.0  2026-03-09  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- Parse row IDs from JSON array
    SELECT er.Id, er.Code, er.Name,
           a.DisplayName AS AttributeName, a.DataType,
           ev.TextValue, ev.IntValue, ev.DecimalValue, ev.DateTimeValue, ev.DomainValue,
           dr.Code AS DomainCode, dr.Name AS DomainName
    FROM EntityRows er
    INNER JOIN OPENJSON(@RowIdsJson) j ON er.Id = CAST(j.value AS BIGINT)
    LEFT JOIN EntityValues ev ON ev.EntityRowId = er.Id
    LEFT JOIN Attributes a ON a.Id = ev.AttributeId
    LEFT JOIN EntityRows dr ON dr.Id = ev.DomainValue
    WHERE er.EntityId = @EntityId
    ORDER BY er.Id, a.SortOrder;
END;
GO

CREATE OR ALTER PROCEDURE usp_Data_GetAttributeNames
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns attribute Id, internal Name, display label, and data
--              type for all attributes of an entity. Used by the import
--              pipeline to map incoming column names to attribute definitions.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Id, Name, DisplayName, DataType FROM Attributes WHERE EntityId = @EntityId;
END;
GO

CREATE OR ALTER PROCEDURE usp_Data_ResolveDomainValue
    @DomainEntityId INT,
    @TextValue NVARCHAR(500)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Resolves a text value to a domain EntityRow Id using a
--              three-pass strategy: (1) exact Code match, (2) exact Name
--              match, (3) extract Code from "{Code} Name" display format.
--              Returns NULL when no match is found. Used for single-value
--              domain resolution during import; see usp_Data_ResolveDomainValuesBatch
--              for bulk resolution.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @RowId BIGINT = NULL;
    DECLARE @Trimmed NVARCHAR(500) = LTRIM(RTRIM(@TextValue));

    -- Pass 1: match on Code (preferred — stable business key)
    SELECT TOP 1 @RowId = Id FROM EntityRows WHERE EntityId = @DomainEntityId AND Code = @Trimmed;

    -- Pass 2: fall back to Name match
    IF @RowId IS NULL
        SELECT TOP 1 @RowId = Id FROM EntityRows WHERE EntityId = @DomainEntityId AND Name = @Trimmed;

    -- Pass 3: extract Code from "{Code} Name" display format (produced by some export formats)
    IF @RowId IS NULL AND @Trimmed LIKE '{%} %'
    BEGIN
        DECLARE @ExtCode NVARCHAR(200) = SUBSTRING(@Trimmed, 2, CHARINDEX('}', @Trimmed) - 2);
        SELECT TOP 1 @RowId = Id FROM EntityRows WHERE EntityId = @DomainEntityId AND Code = @ExtCode;
    END

    SELECT @RowId AS ResolvedRowId;
END;
GO

-- ============================================
-- IMPORT / EXPORT PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_Import_UploadStaging
    @SessionId UNIQUEIDENTIFIER,
    @DataJson NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Bulk-inserts rows into the staging table for a given import
--              session. The caller supplies a session GUID that groups all
--              rows belonging to the same import operation. Each row's raw
--              JSON payload is stored as-is for later processing.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO StagingImport (SessionId, EntityName, ModelName, RowData)
    SELECT @SessionId, j.entityName, j.modelName, j.rowData
    FROM OPENJSON(@DataJson) WITH (
        entityName NVARCHAR(200), modelName NVARCHAR(200), rowData NVARCHAR(MAX) AS JSON
    ) j;
    SELECT @@ROWCOUNT AS Inserted;
END;
GO

CREATE OR ALTER PROCEDURE usp_Import_GetPreview
    @SessionId UNIQUEIDENTIFIER
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns a preview summary for an import session. Produces two
--              result sets: (1) count of staged rows per entity/model, and
--              (2) existing row counts for those entities so the UI can warn
--              about overwrites or conflicts before the user commits the import.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    -- Result set 1: staged counts per entity being imported
    SELECT EntityName, ModelName, COUNT(*) AS [RowCount]
    FROM StagingImport WHERE SessionId = @SessionId AND Status = 'pending'
    GROUP BY EntityName, ModelName;

    -- Result set 2: entity info with existing counts to detect potential conflicts
    SELECT e.Id AS EntityId, e.Name AS EntityName, COUNT(er.Id) AS ExistingCount
    FROM Entities e LEFT JOIN EntityRows er ON er.EntityId = e.Id
    WHERE e.Name IN (SELECT DISTINCT EntityName FROM StagingImport WHERE SessionId = @SessionId)
    GROUP BY e.Id, e.Name;
END;
GO

CREATE OR ALTER PROCEDURE usp_Import_GetStagedRows
    @SessionId UNIQUEIDENTIFIER,
    @EntityName NVARCHAR(200)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns all pending staged rows for a specific entity within
--              an import session. Called by the import executor to process
--              each entity's rows one at a time.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Id, RowData FROM StagingImport
    WHERE SessionId = @SessionId AND EntityName = @EntityName AND Status = 'pending';
END;
GO

CREATE OR ALTER PROCEDURE usp_Import_MarkProcessed
    @Id BIGINT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Marks a staging row as processed after it has been successfully
--              imported. This prevents re-processing and provides an audit trail
--              of which rows were handled within the session.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE StagingImport SET Status = 'processed', ProcessedAt = GETUTCDATE() WHERE Id = @Id;
END;
GO

CREATE OR ALTER PROCEDURE usp_Export_GetEntityData
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns everything needed for a full entity JSON export:
--              (1) entity name and model name, (2) all attribute definitions,
--              and (3) all row data with EAV values and resolved domain labels.
--              The three result sets allow the caller to reconstruct the entity
--              structure and data in a single round-trip.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    -- Result set 1: entity info
    SELECT e.Name AS EntityName, m.Name AS ModelName
    FROM Entities e JOIN Models m ON m.Id = e.ModelId WHERE e.Id = @EntityId;
    -- Result set 2: attributes
    SELECT Id, EntityId, DisplayName, Name, DataType, MaxLength, IsRequired, IsCode, IsName, SortOrder, DomainEntityId, Description, CreatedAt, ModifiedAt FROM Attributes WHERE EntityId = @EntityId ORDER BY SortOrder;
    -- Result set 3: row data
    SELECT er.Id, er.Code, er.Name,
           a.Name AS AttributeName, a.DataType,
           ev.TextValue, ev.IntValue, ev.DecimalValue, ev.DateTimeValue, ev.DomainValue,
           dr.Code AS DomainCode, dr.Name AS DomainName
    FROM EntityRows er
    LEFT JOIN EntityValues ev ON ev.EntityRowId = er.Id
    LEFT JOIN Attributes a ON a.Id = ev.AttributeId
    LEFT JOIN EntityRows dr ON dr.Id = ev.DomainValue
    WHERE er.EntityId = @EntityId
    ORDER BY er.Id, a.SortOrder;
END;
GO

-- ============================================
-- INTEGRATION VIEW PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_IntegrationView_GetAll
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns all integration view definitions ordered by name.
--              Includes column and type snapshots so the UI can detect when
--              the underlying entity structure has changed since the view was
--              last deployed.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Id, Name, EntityId, ViewType, ExcludedColumns, ColumnSnapshot, TypeSnapshot, CreatedAt, ModifiedAt FROM IntegrationViews ORDER BY Name;
END;
GO

CREATE OR ALTER PROCEDURE usp_IntegrationView_Create
    @Name NVARCHAR(200),
    @EntityId INT,
    @ViewType NVARCHAR(20) = 'flat',
    @ExcludedColumns NVARCHAR(MAX) = NULL,
    @ColumnSnapshot NVARCHAR(MAX) = NULL,
    @TypeSnapshot NVARCHAR(MAX) = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Creates a new integration view definition. The view is not
--              deployed to the mdm schema here — use usp_IntegrationView_Deploy
--              separately. Snapshots capture the column/type state at creation
--              time for drift detection.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO IntegrationViews (Name, EntityId, ViewType, ExcludedColumns, ColumnSnapshot, TypeSnapshot)
    OUTPUT INSERTED.Id, INSERTED.Name, INSERTED.EntityId, INSERTED.ViewType,
           INSERTED.ExcludedColumns, INSERTED.ColumnSnapshot, INSERTED.TypeSnapshot,
           INSERTED.CreatedAt, INSERTED.ModifiedAt
    VALUES (@Name, @EntityId, @ViewType, @ExcludedColumns, @ColumnSnapshot, @TypeSnapshot);
END;
GO

CREATE OR ALTER PROCEDURE usp_IntegrationView_Update
    @Id INT,
    @Name NVARCHAR(200) = NULL,
    @EntityId INT = NULL,
    @ViewType NVARCHAR(20) = NULL,
    @ExcludedColumns NVARCHAR(MAX) = NULL,
    @ColumnSnapshot NVARCHAR(MAX) = NULL,
    @TypeSnapshot NVARCHAR(MAX) = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Updates an integration view definition. Returns the old name
--              before updating so the caller can rename the deployed SQL view
--              if the name changed. @ExcludedColumns, @ColumnSnapshot, and
--              @TypeSnapshot are NULL-override fields: passing NULL clears them.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    -- Return old name first so the caller can detect a rename and drop/recreate the SQL view
    SELECT Name AS OldName FROM IntegrationViews WHERE Id = @Id;
    -- Update the record
    UPDATE IntegrationViews SET
        Name = COALESCE(@Name, Name),
        EntityId = COALESCE(@EntityId, EntityId),
        ViewType = COALESCE(@ViewType, ViewType),
        ExcludedColumns = @ExcludedColumns,
        ColumnSnapshot = @ColumnSnapshot,
        TypeSnapshot = @TypeSnapshot,
        ModifiedAt = GETUTCDATE()
    OUTPUT INSERTED.Id, INSERTED.Name, INSERTED.EntityId, INSERTED.ViewType,
           INSERTED.ExcludedColumns, INSERTED.ColumnSnapshot, INSERTED.TypeSnapshot,
           INSERTED.CreatedAt, INSERTED.ModifiedAt
    WHERE Id = @Id;
END;
GO

CREATE OR ALTER PROCEDURE usp_IntegrationView_Delete
    @Id INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Deletes an integration view definition. Returns the view name
--              before deleting so the caller can drop the corresponding SQL
--              view from the mdm schema via usp_IntegrationView_Drop.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    -- Return name for SQL view cleanup before removing the definition record
    SELECT Name FROM IntegrationViews WHERE Id = @Id;
    DELETE FROM IntegrationViews WHERE Id = @Id;
END;
GO

CREATE OR ALTER PROCEDURE usp_IntegrationView_GetSyncData
    @Id INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns all data needed to deploy or redeploy an integration
--              view. Produces four result sets: (1) the view definition,
--              (2) the primary entity's attributes, (3) all entities for
--              hierarchy resolution, and (4) all attributes with entity names
--              for building parent-entity column lists in hierarchy views.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    -- Result set 1: view metadata and configuration
    SELECT Id, Name, EntityId, ViewType, ExcludedColumns, ColumnSnapshot, TypeSnapshot, CreatedAt, ModifiedAt FROM IntegrationViews WHERE Id = @Id;
    -- Result set 2: primary entity attributes
    SELECT a.Id, a.EntityId, a.DisplayName, a.Name, a.DataType, a.MaxLength, a.IsRequired, a.IsCode, a.IsName, a.SortOrder, a.DomainEntityId, a.CreatedAt, a.ModifiedAt FROM Attributes a
    INNER JOIN IntegrationViews v ON v.EntityId = a.EntityId
    WHERE v.Id = @Id ORDER BY a.SortOrder;
    -- Result set 3: all entities (needed to resolve parent TableNames in hierarchy views)
    SELECT Id, ModelId, Name, Description, TableName, SortOrder, IsActive, RequiresApproval, ApproverCanApproveOwn, ApprovalStrategy, SharedAcrossModels, AutoGenerateCode, CreatedAt, ModifiedAt FROM Entities;
    -- Result set 4: all attributes with entity names (for building parent-entity column joins)
    SELECT a.Id, a.EntityId, a.DisplayName, a.Name, a.DataType, a.MaxLength, a.IsRequired, a.IsCode, a.IsName, a.SortOrder, a.DomainEntityId, a.CreatedAt, a.ModifiedAt, e.Name AS EntityName FROM Attributes a
    JOIN Entities e ON e.Id = a.EntityId ORDER BY a.EntityId, a.SortOrder;
END;
GO

CREATE OR ALTER PROCEDURE usp_IntegrationView_Deploy
    @ViewName NVARCHAR(200),
    @EntityId INT,
    @ExcludedColumns NVARCHAR(MAX) = NULL,
    @ViewType NVARCHAR(20) = 'flat'
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Dynamically generates and deploys a SQL view to the [mdm]
--              schema using sp_executesql. For 'flat' views the main entity's
--              columns are pivoted from EAV. For 'hierarchy' views, domain
--              attribute columns are expanded to include the parent entity's
--              system fields (ID, Code, Name) and custom attributes.
--
--              Dynamic SQL is required here because SQL cannot parameterize
--              object names (view name, column aliases). All inputs are
--              bracket-escaped or integer-cast to prevent SQL injection.
--
--              Two cursor passes are used:
--                Pass 1: main entity custom attributes (non-domain or flat domain)
--                Pass 2: parent entity columns appended after (hierarchy only)
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- Validate view name characters
    IF @ViewName LIKE '%[^a-zA-Z0-9_ -]%'
    BEGIN
        THROW 50005, 'View name contains invalid characters. Only letters, numbers, spaces, hyphens and underscores are allowed.', 1;
    END

    -- Get entity TableName for column prefixing
    DECLARE @TableName NVARCHAR(200);
    SELECT @TableName = TableName FROM Entities WHERE Id = @EntityId;
    IF @TableName IS NULL
    BEGIN
        DECLARE @ErrMsg NVARCHAR(200) = 'Entity with Id ' + CAST(@EntityId AS NVARCHAR(10)) + ' not found.';
        THROW 50004, @ErrMsg, 1;
    END

    DECLARE @Excluded TABLE (ColName NVARCHAR(300));
    IF @ExcludedColumns IS NOT NULL
        INSERT INTO @Excluded (ColName) SELECT value COLLATE DATABASE_DEFAULT FROM OPENJSON(@ExcludedColumns);

    DECLARE @Cols NVARCHAR(MAX) = '';
    DECLARE @ParentCols NVARCHAR(MAX) = '';
    DECLARE @HasHierarchy BIT = 0;
    DECLARE @ColName NVARCHAR(128), @AttrName NVARCHAR(200), @DataType NVARCHAR(20), @DomainEntityId INT, @ValueCol NVARCHAR(50);
    DECLARE @PrefixedName NVARCHAR(300);
    DECLARE @ParentTableName NVARCHAR(200);
    DECLARE @ParentIdCol NVARCHAR(300), @ParentCodeCol NVARCHAR(300), @ParentNameCol NVARCHAR(300);
    DECLARE @PColName NVARCHAR(128), @PAttrName NVARCHAR(200), @PDataType NVARCHAR(20), @PValueCol NVARCHAR(50), @FullColName NVARCHAR(300);
    -- Store domain attr Name for parent column joins (needed in second pass)
    DECLARE @DomainAttrNames TABLE (AttrName NVARCHAR(128), DomainEntityId INT);

    -- First pass: main entity custom attributes only
    DECLARE attr_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT Name, DisplayName, DataType, DomainEntityId FROM Attributes
        WHERE EntityId = @EntityId ORDER BY SortOrder;
    OPEN attr_cursor;
    FETCH NEXT FROM attr_cursor INTO @ColName, @AttrName, @DataType, @DomainEntityId;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @AttrName NOT IN ('Id', 'Code', 'Name', 'CreatedAt', 'ModifiedAt')
        BEGIN
            IF @ViewType = 'hierarchy' AND @DataType = 'Domain' AND @DomainEntityId IS NOT NULL
            BEGIN
                -- Remember domain attrs for second pass
                INSERT INTO @DomainAttrNames (AttrName, DomainEntityId) VALUES (@ColName, @DomainEntityId);
            END
            ELSE
            BEGIN
                SET @PrefixedName = @TableName + '_' + @AttrName;
                IF NOT EXISTS (SELECT 1 FROM @Excluded WHERE ColName = @PrefixedName)
                BEGIN
                    SET @ValueCol = CASE @DataType
                        WHEN 'Text' THEN 'ev.TextValue' WHEN 'Int' THEN 'ev.IntValue'
                        WHEN 'Boolean' THEN 'ev.IntValue'
                        WHEN 'Decimal' THEN 'ev.DecimalValue' WHEN 'DateTime' THEN 'ev.DateTimeValue'
                        WHEN 'Domain' THEN 'ev.DomainValue' ELSE 'ev.TextValue' END;

                    SET @Cols = @Cols + ',
    MAX(CASE WHEN a.Name = ''' + REPLACE(@ColName, '''', '''''') + ''' THEN ' + @ValueCol + ' END) AS [' + REPLACE(@PrefixedName, ']', ']]') + ']';
                END
            END
        END
        FETCH NEXT FROM attr_cursor INTO @ColName, @AttrName, @DataType, @DomainEntityId;
    END
    CLOSE attr_cursor; DEALLOCATE attr_cursor;

    -- Second pass: parent entity columns (appended after all main entity columns)
    IF @ViewType = 'hierarchy'
    BEGIN
        DECLARE @DomainAttrName NVARCHAR(128), @DomainEntId INT;
        DECLARE domain_cursor CURSOR LOCAL FAST_FORWARD FOR
            SELECT AttrName, DomainEntityId FROM @DomainAttrNames;
        OPEN domain_cursor;
        FETCH NEXT FROM domain_cursor INTO @DomainAttrName, @DomainEntId;

        WHILE @@FETCH_STATUS = 0
        BEGIN
            SET @HasHierarchy = 1;
            SELECT @ParentTableName = TableName FROM Entities WHERE Id = @DomainEntId;
            IF @ParentTableName IS NOT NULL
            BEGIN
                -- Parent system fields: ID, Code, Name
                SET @ParentIdCol = @ParentTableName + '_ID';
                SET @ParentCodeCol = @ParentTableName + '_Code';
                SET @ParentNameCol = @ParentTableName + '_Name';

                IF NOT EXISTS (SELECT 1 FROM @Excluded WHERE ColName = @ParentIdCol)
                    SET @ParentCols = @ParentCols + ',
    MAX(CASE WHEN a.Name = ''' + REPLACE(@DomainAttrName, '''', '''''') + ''' AND a.DataType = ''Domain'' THEN dr.Id END) AS [' + REPLACE(@ParentIdCol, ']', ']]') + ']';

                IF NOT EXISTS (SELECT 1 FROM @Excluded WHERE ColName = @ParentCodeCol)
                    SET @ParentCols = @ParentCols + ',
    MAX(CASE WHEN a.Name = ''' + REPLACE(@DomainAttrName, '''', '''''') + ''' AND a.DataType = ''Domain'' THEN dr.Code END) AS [' + REPLACE(@ParentCodeCol, ']', ']]') + ']';

                IF NOT EXISTS (SELECT 1 FROM @Excluded WHERE ColName = @ParentNameCol)
                    SET @ParentCols = @ParentCols + ',
    MAX(CASE WHEN a.Name = ''' + REPLACE(@DomainAttrName, '''', '''''') + ''' AND a.DataType = ''Domain'' THEN dr.Name END) AS [' + REPLACE(@ParentNameCol, ']', ']]') + ']';

                -- Parent custom attributes
                DECLARE parent_cursor CURSOR LOCAL FAST_FORWARD FOR
                    SELECT Name, DisplayName, DataType FROM Attributes WHERE EntityId = @DomainEntId ORDER BY SortOrder;
                OPEN parent_cursor;
                FETCH NEXT FROM parent_cursor INTO @PColName, @PAttrName, @PDataType;
                WHILE @@FETCH_STATUS = 0
                BEGIN
                    IF @PAttrName NOT IN ('Id', 'Code', 'Name', 'CreatedAt', 'ModifiedAt')
                    BEGIN
                        SET @FullColName = @ParentTableName + '_' + @PAttrName;
                        IF NOT EXISTS (SELECT 1 FROM @Excluded WHERE ColName = @FullColName)
                        BEGIN
                            SET @PValueCol = CASE @PDataType
                                WHEN 'Text' THEN 'pev.TextValue' WHEN 'Int' THEN 'pev.IntValue'
                                WHEN 'Boolean' THEN 'pev.IntValue'
                                WHEN 'Decimal' THEN 'pev.DecimalValue' WHEN 'DateTime' THEN 'pev.DateTimeValue'
                                WHEN 'Domain' THEN 'pev.DomainValue' ELSE 'pev.TextValue' END;
                            SET @ParentCols = @ParentCols + ',
    MAX(CASE WHEN a.Name = ''' + REPLACE(@DomainAttrName, '''', '''''') + ''' AND a.DataType = ''Domain'' AND pa.Name = ''' + REPLACE(@PColName, '''', '''''') + ''' THEN ' + @PValueCol + ' END) AS [' + REPLACE(@FullColName, ']', ']]') + ']';
                        END
                    END
                    FETCH NEXT FROM parent_cursor INTO @PColName, @PAttrName, @PDataType;
                END
                CLOSE parent_cursor; DEALLOCATE parent_cursor;
            END
            FETCH NEXT FROM domain_cursor INTO @DomainAttrName, @DomainEntId;
        END
        CLOSE domain_cursor; DEALLOCATE domain_cursor;
    END

    DECLARE @From NVARCHAR(MAX) = '
FROM EntityRows er
LEFT JOIN EntityValues ev ON ev.EntityRowId = er.Id
LEFT JOIN Attributes a ON a.Id = ev.AttributeId
LEFT JOIN EntityRows dr ON dr.Id = ev.DomainValue AND a.DataType = ''Domain''';

    IF @HasHierarchy = 1
        SET @From = @From + '
LEFT JOIN EntityValues pev ON pev.EntityRowId = dr.Id
LEFT JOIN Attributes pa ON pa.Id = pev.AttributeId';

    DECLARE @Sql NVARCHAR(MAX) = '
CREATE OR ALTER VIEW [mdm].[' + REPLACE(@ViewName, ']', ']]') + '] AS
SELECT
    er.Id AS [' + REPLACE(@TableName, ']', ']]') + '_ID],
    er.Code AS [' + REPLACE(@TableName, ']', ']]') + '_Code],
    er.Name AS [' + REPLACE(@TableName, ']', ']]') + '_Name]' + @Cols + ',
    er.CreatedAt AS [' + REPLACE(@TableName, ']', ']]') + '_CreatedAt],
    er.ModifiedAt AS [' + REPLACE(@TableName, ']', ']]') + '_ModifiedAt]' + @ParentCols + @From + '
WHERE er.EntityId = ' + CAST(@EntityId AS NVARCHAR(10)) + '
GROUP BY er.Id, er.Code, er.Name, er.CreatedAt, er.ModifiedAt;';

    EXEC sp_executesql @Sql;
END;
GO

CREATE OR ALTER PROCEDURE usp_IntegrationView_Drop
    @ViewName NVARCHAR(200)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Drops a deployed SQL view from the [mdm] schema if it exists.
--              Uses dynamic SQL via sp_executesql because object names cannot
--              be parameterized. The view name is bracket-escaped to prevent
--              SQL injection.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- Validate view name to prevent dynamic SQL injection
    IF @ViewName LIKE '%[^a-zA-Z0-9_ ]%'
        THROW 50001, 'View name contains invalid characters.', 1;

    DECLARE @Sql NVARCHAR(500) = 'IF OBJECT_ID(''[mdm].[' + REPLACE(@ViewName, '''', '''''') + ']'', ''V'') IS NOT NULL DROP VIEW [mdm].[' + REPLACE(@ViewName, ']', ']]') + ']';
    EXEC sp_executesql @Sql;
END;
GO

-- ============================================
-- PERFORMANCE INDEXES FOR PAGINATION
-- ============================================
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_EntityRows_EntityId_Name')
    CREATE INDEX IX_EntityRows_EntityId_Name ON EntityRows(EntityId, Name);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_EntityRows_EntityId_Code')
    CREATE INDEX IX_EntityRows_EntityId_Code ON EntityRows(EntityId, Code);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_EntityRows_EntityId_CreatedAt')
    CREATE INDEX IX_EntityRows_EntityId_CreatedAt ON EntityRows(EntityId, CreatedAt);
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_EntityRows_EntityId_ModifiedAt')
    CREATE INDEX IX_EntityRows_EntityId_ModifiedAt ON EntityRows(EntityId, ModifiedAt);

-- Covering index on Attributes: eliminates lookups for filter + sort operations
IF EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Attributes_EntityId_Name' AND object_id = OBJECT_ID('Attributes'))
    DROP INDEX IX_Attributes_EntityId_Name ON Attributes;
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Attributes_EntityId_Name_Cover')
    CREATE INDEX IX_Attributes_EntityId_Name_Cover ON Attributes(EntityId, Name)
    INCLUDE (DataType, SortOrder, DisplayName, IsRequired, IsCode, IsName, DomainEntityId);

-- Missing index for model-to-entity lookups
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Entities_ModelId')
    CREATE INDEX IX_Entities_ModelId ON Entities(ModelId);
GO

-- ============================================
-- PAGINATED DATA RETRIEVAL
-- ============================================
CREATE OR ALTER PROCEDURE usp_Data_GetByEntityPaginated
    @EntityId       INT,
    @PageNumber     INT = 1,
    @PageSize       INT = 100,
    @SearchText     NVARCHAR(200) = NULL,
    @SortField      NVARCHAR(200) = NULL,
    @SortDirection  NVARCHAR(4) = 'ASC',
    @ColumnFilters  NVARCHAR(MAX) = NULL,  -- JSON: {"attrName":[domainId1,domainId2,...]}
    @TextFilters    NVARCHAR(MAX) = NULL   -- JSON: {"code":"abc","name":"branch 100360","customAttr":"val"}
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Paginates entity rows with full EAV attribute values, optional
--              full-text search, multi-field sorting, domain column filters,
--              and per-column text filters. Uses a 3-phase strategy:
--
--              Phase 1: Collect all matching row IDs into #MatchedRows
--                       (search + column filters + text filters applied here).
--              Phase 2: Sort matched rows and paginate into #PagedRowIds using
--                       ROW_NUMBER() with a consolidated CASE-based ORDER BY
--                       that handles system fields and custom attribute sorts.
--              Phase 3: Return full EAV data for paginated rows only, plus
--                       a metadata result set with total count and page info.
--
--              OPTION (RECOMPILE) on the final select prevents cached plans
--              from ignoring runtime filter values (sort field varies per call).
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY

    -- Sanitize inputs
    IF @PageNumber < 1 SET @PageNumber = 1;
    IF @PageSize < 1 SET @PageSize = 100;
    IF @PageSize > 1000 SET @PageSize = 1000;
    IF @SortDirection NOT IN ('ASC', 'DESC') SET @SortDirection = 'ASC';
    SET @SearchText = LTRIM(RTRIM(ISNULL(@SearchText, '')));
    IF @SearchText = '' SET @SearchText = NULL;
    IF @ColumnFilters = '' OR @ColumnFilters = '{}' SET @ColumnFilters = NULL;
    IF @TextFilters = '' OR @TextFilters = '{}' SET @TextFilters = NULL;

    -- Count active column filters
    DECLARE @FilterCount INT = 0;
    IF @ColumnFilters IS NOT NULL
        SELECT @FilterCount = COUNT(DISTINCT [key]) FROM OPENJSON(@ColumnFilters);

    -- ────────────────────────────────────────────
    -- Full-Text Search: detect indexes (used by global search + text filters)
    -- ────────────────────────────────────────────
    DECLARE @HasFtsRows BIT = 0;
    DECLARE @HasFtsValues BIT = 0;
    IF EXISTS (SELECT 1 FROM sys.fulltext_indexes WHERE object_id = OBJECT_ID('EntityRows'))
        SET @HasFtsRows = 1;
    IF EXISTS (SELECT 1 FROM sys.fulltext_indexes WHERE object_id = OBJECT_ID('EntityValues'))
        SET @HasFtsValues = 1;

    -- Build FTS query for global search text
    -- Converts "amsterdam" → '"amsterdam*"', "amster dam" → '"amster*" AND "dam*"'
    DECLARE @FtsQuery NVARCHAR(1000) = NULL;
    IF @SearchText IS NOT NULL AND @HasFtsRows = 1
    BEGIN
        DECLARE @CleanSearch NVARCHAR(500) = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(@SearchText, '"', ''), '*', ''), '''', '')));
        IF LEN(@CleanSearch) > 0
            SELECT @FtsQuery = STUFF((
                SELECT ' AND "' + LTRIM(RTRIM(value)) + '*"'
                FROM STRING_SPLIT(@CleanSearch, ' ')
                WHERE LEN(LTRIM(RTRIM(value))) > 0
                FOR XML PATH(''), TYPE
            ).value('.', 'NVARCHAR(1000)'), 1, 5, '');
    END

    -- ────────────────────────────────────────────
    -- Pre-parse text filters (needed before Phase 1 to optimize initial row loading)
    -- ────────────────────────────────────────────
    DECLARE @TFCount INT = 0;
    DECLARE @codeFilter NVARCHAR(500) = NULL, @nameFilter NVARCHAR(500) = NULL;
    DECLARE @codeFts NVARCHAR(1000) = NULL, @nameFts NVARCHAR(1000) = NULL;
    DECLARE @HasCustomAttrFilters BIT = 0;

    IF @TextFilters IS NOT NULL
    BEGIN
        SELECT
            [key] COLLATE SQL_Latin1_General_CP1_CI_AS AS FilterKey,
            LTRIM(RTRIM(CAST(value AS NVARCHAR(500)))) AS FilterVal,
            CAST(NULL AS NVARCHAR(1000)) AS FtsQuery
        INTO #TextFilterList
        FROM OPENJSON(@TextFilters)
        WHERE LTRIM(RTRIM(CAST(value AS NVARCHAR(500)))) <> '';

        SELECT @TFCount = COUNT(*) FROM #TextFilterList;

        IF @TFCount > 0
        BEGIN
            -- Build FTS queries for all filter values at once (set-based, using STRING_SPLIT + FOR XML)
            IF @HasFtsRows = 1 OR @HasFtsValues = 1
            BEGIN
                UPDATE tf SET tf.FtsQuery = sub.FtsQ
                FROM #TextFilterList tf
                CROSS APPLY (
                    SELECT STUFF((
                        SELECT ' AND "' + LTRIM(RTRIM(value)) + '*"'
                        FROM STRING_SPLIT(
                            LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(tf.FilterVal, '"', ''), '*', ''), '''', ''))),
                            ' '
                        )
                        WHERE LEN(LTRIM(RTRIM(value))) > 0
                        FOR XML PATH(''), TYPE
                    ).value('.', 'NVARCHAR(1000)'), 1, 5, '') AS FtsQ
                ) sub
                WHERE LEN(LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(tf.FilterVal, '"', ''), '*', ''), '''', '')))) > 0;
            END

            SELECT @codeFilter = FilterVal, @codeFts = FtsQuery FROM #TextFilterList WHERE FilterKey = 'code';
            SELECT @nameFilter = FilterVal, @nameFts = FtsQuery FROM #TextFilterList WHERE FilterKey = 'name';
            IF EXISTS (SELECT 1 FROM #TextFilterList WHERE FilterKey NOT IN ('code', 'name'))
                SET @HasCustomAttrFilters = 1;
        END
    END

    -- ────────────────────────────────────────────
    -- Phase 1: Collect matching row IDs into temp table
    -- When text filters exist on code/name, populate directly from filter
    -- instead of loading all rows then deleting (avoids 525K INSERT + DELETE).
    -- ────────────────────────────────────────────
    CREATE TABLE #MatchedRows (Id BIGINT PRIMARY KEY);
    DECLARE @NameApplied BIT = 0, @CodeApplied BIT = 0;

    IF @SearchText IS NOT NULL
    BEGIN
        -- Global search: FTS or LIKE on EntityRows (Code, Name)
        -- CONTAINS is wrapped in sp_executesql so CREATE PROCEDURE doesn't validate FTS indexes at parse time
        IF @HasFtsRows = 1 AND @FtsQuery IS NOT NULL
            EXEC sp_executesql N'INSERT INTO #MatchedRows (Id) SELECT er.Id FROM EntityRows er WHERE er.EntityId = @EntityId AND CONTAINS((er.Code, er.Name), @FtsQuery)',
                N'@EntityId INT, @FtsQuery NVARCHAR(1000)', @EntityId, @FtsQuery;
        ELSE
            INSERT INTO #MatchedRows (Id)
            SELECT er.Id FROM EntityRows er
            WHERE er.EntityId = @EntityId
              AND (er.Code LIKE '%' + @SearchText + '%' OR er.Name LIKE '%' + @SearchText + '%');

        -- Global search: FTS or LIKE on EntityValues (TextValue)
        IF @HasFtsValues = 1 AND @FtsQuery IS NOT NULL
            EXEC sp_executesql N'INSERT INTO #MatchedRows (Id) SELECT DISTINCT ev.EntityRowId FROM EntityValues ev INNER JOIN EntityRows er ON er.Id = ev.EntityRowId WHERE er.EntityId = @EntityId AND CONTAINS(ev.TextValue, @FtsQuery) AND ev.EntityRowId NOT IN (SELECT Id FROM #MatchedRows)',
                N'@EntityId INT, @FtsQuery NVARCHAR(1000)', @EntityId, @FtsQuery;
        ELSE
            INSERT INTO #MatchedRows (Id)
            SELECT DISTINCT ev.EntityRowId FROM EntityValues ev
            INNER JOIN EntityRows er ON er.Id = ev.EntityRowId
            WHERE er.EntityId = @EntityId AND ev.TextValue LIKE '%' + @SearchText + '%'
              AND ev.EntityRowId NOT IN (SELECT Id FROM #MatchedRows);
    END
    ELSE IF @nameFilter IS NOT NULL
    BEGIN
        -- Populate directly from name filter (avoids loading all rows)
        IF @HasFtsRows = 1 AND @nameFts IS NOT NULL
            EXEC sp_executesql N'INSERT INTO #MatchedRows (Id) SELECT er.Id FROM EntityRows er WHERE er.EntityId = @EntityId AND CONTAINS(er.Name, @nameFts)',
                N'@EntityId INT, @nameFts NVARCHAR(1000)', @EntityId, @nameFts;
        ELSE
            INSERT INTO #MatchedRows (Id)
            SELECT er.Id FROM EntityRows er
            WHERE er.EntityId = @EntityId AND er.Name LIKE '%' + @nameFilter + '%';
        SET @NameApplied = 1;
    END
    ELSE IF @codeFilter IS NOT NULL
    BEGIN
        -- Populate directly from code filter
        IF @HasFtsRows = 1 AND @codeFts IS NOT NULL
            EXEC sp_executesql N'INSERT INTO #MatchedRows (Id) SELECT er.Id FROM EntityRows er WHERE er.EntityId = @EntityId AND CONTAINS(er.Code, @codeFts)',
                N'@EntityId INT, @codeFts NVARCHAR(1000)', @EntityId, @codeFts;
        ELSE
            INSERT INTO #MatchedRows (Id)
            SELECT er.Id FROM EntityRows er
            WHERE er.EntityId = @EntityId AND er.Code LIKE '%' + @codeFilter + '%';
        SET @CodeApplied = 1;
    END
    ELSE
    BEGIN
        INSERT INTO #MatchedRows (Id)
        SELECT Id FROM EntityRows WHERE EntityId = @EntityId;
    END

    -- Apply column filters (domain attributes) — materialized to avoid per-row OPENJSON
    IF @FilterCount > 0
    BEGIN
        SELECT
            df.[key] COLLATE SQL_Latin1_General_CP1_CI_AS AS AttrName,
            CAST(v.value AS BIGINT) AS DomainVal
        INTO #ColFilterList
        FROM OPENJSON(@ColumnFilters) df
        CROSS APPLY OPENJSON(df.value) v;

        DELETE FROM #MatchedRows
        WHERE Id NOT IN (
            SELECT mr.Id FROM #MatchedRows mr
            WHERE (
                SELECT COUNT(DISTINCT cfl.AttrName)
                FROM #ColFilterList cfl
                WHERE EXISTS (
                    SELECT 1 FROM EntityValues ev
                    JOIN Attributes a ON a.Id = ev.AttributeId
                    WHERE ev.EntityRowId = mr.Id
                      AND a.Name = cfl.AttrName
                      AND ev.DomainValue = cfl.DomainVal
                )
            ) = @FilterCount
        );

        DROP TABLE #ColFilterList;
    END

    -- Apply remaining text filters not used in Phase 1 (successive narrowing).
    -- Always use LIKE here (not CONTAINS) because:
    --   1. #MatchedRows is already small after Phase 1, so LIKE is fast
    --   2. LIKE gives accurate substring matching (CONTAINS only does prefix matching,
    --      which misses cases like code "P-200007" not matching CONTAINS '"6*"')
    IF @TFCount > 0
    BEGIN
        IF @codeFilter IS NOT NULL AND @CodeApplied = 0
            DELETE FROM #MatchedRows WHERE Id NOT IN (
                SELECT er.Id FROM EntityRows er
                WHERE er.Id IN (SELECT Id FROM #MatchedRows)
                  AND er.Code LIKE '%' + @codeFilter + '%');

        IF @nameFilter IS NOT NULL AND @NameApplied = 0
            DELETE FROM #MatchedRows WHERE Id NOT IN (
                SELECT er.Id FROM EntityRows er
                WHERE er.Id IN (SELECT Id FROM #MatchedRows)
                  AND er.Name LIKE '%' + @nameFilter + '%');

        -- Custom attribute text filters (cursor for dynamic attribute names)
        -- Always LIKE here too — #MatchedRows is already small
        IF @HasCustomAttrFilters = 1
        BEGIN
            DECLARE @attrKey NVARCHAR(200), @attrVal NVARCHAR(500), @attrFts NVARCHAR(1000);
            DECLARE attr_cursor CURSOR LOCAL FAST_FORWARD FOR
                SELECT FilterKey, FilterVal, FtsQuery FROM #TextFilterList WHERE FilterKey NOT IN ('code', 'name');
            OPEN attr_cursor;
            FETCH NEXT FROM attr_cursor INTO @attrKey, @attrVal, @attrFts;

            WHILE @@FETCH_STATUS = 0
            BEGIN
                DELETE FROM #MatchedRows WHERE Id NOT IN (
                    SELECT ev.EntityRowId FROM EntityValues ev
                    JOIN Attributes a ON a.Id = ev.AttributeId
                    WHERE ev.EntityRowId IN (SELECT Id FROM #MatchedRows)
                      AND a.Name = @attrKey AND ev.TextValue LIKE '%' + @attrVal + '%');

                FETCH NEXT FROM attr_cursor INTO @attrKey, @attrVal, @attrFts;
            END

            CLOSE attr_cursor;
            DEALLOCATE attr_cursor;
        END
    END

    IF OBJECT_ID('tempdb..#TextFilterList') IS NOT NULL
        DROP TABLE #TextFilterList;

    -- ────────────────────────────────────────────
    -- Phase 2: Count + sort + paginate
    -- ────────────────────────────────────────────
    DECLARE @TotalCount INT;
    SELECT @TotalCount = COUNT(*) FROM #MatchedRows;

    DECLARE @Offset INT = (@PageNumber - 1) * @PageSize;
    CREATE TABLE #PagedRowIds (Id BIGINT PRIMARY KEY, RowNum INT);

    -- Consolidated sort: single query handles all sort fields
    -- Also fixes ROW_NUMBER bug (was always ORDER BY er.Id regardless of sort field)
    ;WITH SortedRows AS (
        SELECT
            er.Id,
            ROW_NUMBER() OVER (
                ORDER BY
                    -- System fields: id
                    CASE WHEN (@SortField IS NULL OR @SortField = 'id') AND @SortDirection = 'ASC' THEN er.Id END ASC,
                    CASE WHEN (@SortField IS NULL OR @SortField = 'id') AND @SortDirection = 'DESC' THEN er.Id END DESC,
                    -- System fields: code
                    CASE WHEN @SortField = 'code' AND @SortDirection = 'ASC' THEN er.Code END ASC,
                    CASE WHEN @SortField = 'code' AND @SortDirection = 'DESC' THEN er.Code END DESC,
                    -- System fields: name
                    CASE WHEN @SortField = 'name' AND @SortDirection = 'ASC' THEN er.Name END ASC,
                    CASE WHEN @SortField = 'name' AND @SortDirection = 'DESC' THEN er.Name END DESC,
                    -- System fields: createdAt
                    CASE WHEN @SortField = 'createdAt' AND @SortDirection = 'ASC' THEN er.CreatedAt END ASC,
                    CASE WHEN @SortField = 'createdAt' AND @SortDirection = 'DESC' THEN er.CreatedAt END DESC,
                    -- System fields: modifiedAt
                    CASE WHEN @SortField = 'modifiedAt' AND @SortDirection = 'ASC' THEN er.ModifiedAt END ASC,
                    CASE WHEN @SortField = 'modifiedAt' AND @SortDirection = 'DESC' THEN er.ModifiedAt END DESC,
                    -- Custom attribute sort
                    CASE WHEN @SortField NOT IN ('id','code','name','createdAt','modifiedAt') AND @SortField IS NOT NULL
                         AND @SortDirection = 'ASC' THEN sortSub.SortVal END ASC,
                    CASE WHEN @SortField NOT IN ('id','code','name','createdAt','modifiedAt') AND @SortField IS NOT NULL
                         AND @SortDirection = 'DESC' THEN sortSub.SortVal END DESC,
                    er.Id ASC  -- stable tiebreaker
            ) AS RowNum
        FROM EntityRows er
        INNER JOIN #MatchedRows mr ON mr.Id = er.Id
        OUTER APPLY (
            SELECT TOP 1
                CASE a2.DataType
                    WHEN 'Text'     THEN ev2.TextValue
                    WHEN 'Int'      THEN RIGHT('00000000000000000000' + CAST(ev2.IntValue AS NVARCHAR(20)), 20)
                    WHEN 'Decimal'  THEN RIGHT('00000000000000000000' + CAST(ev2.DecimalValue AS NVARCHAR(30)), 30)
                    WHEN 'DateTime' THEN CONVERT(NVARCHAR(30), ev2.DateTimeValue, 126)
                    WHEN 'Boolean'  THEN CAST(ev2.IntValue AS NVARCHAR(1))
                    WHEN 'Domain'   THEN dr2.Name
                    ELSE ev2.TextValue
                END AS SortVal
            FROM EntityValues ev2
            JOIN Attributes a2 ON a2.Id = ev2.AttributeId
            LEFT JOIN EntityRows dr2 ON dr2.Id = ev2.DomainValue
            WHERE ev2.EntityRowId = er.Id AND a2.Name = @SortField
              AND @SortField NOT IN ('id','code','name','createdAt','modifiedAt')
              AND @SortField IS NOT NULL
        ) sortSub
    )
    INSERT INTO #PagedRowIds (Id, RowNum)
    SELECT Id, RowNum
    FROM SortedRows
    WHERE RowNum BETWEEN @Offset + 1 AND @Offset + @PageSize
    OPTION (RECOMPILE);

    -- ────────────────────────────────────────────
    -- Phase 3: Return EAV data for paginated rows
    -- ────────────────────────────────────────────
    SELECT
        er.Id, er.Code, er.Name,
        er.CreatedAt, er.ModifiedAt, er.CreatedBy, er.ModifiedBy,
        uc.DisplayName AS CreatedByName, uc.Email AS CreatedByEmail,
        um.DisplayName AS ModifiedByName, um.Email AS ModifiedByEmail,
        a.Id AS AttributeId, a.Name AS AttributeName, a.DataType,
        ev.TextValue, ev.IntValue, ev.DecimalValue, ev.DateTimeValue, ev.DomainValue,
        dr.Code AS DomainCode, dr.Name AS DomainName,
        CASE WHEN EXISTS (
            SELECT 1 FROM ApprovalRows ar_row
            JOIN ApprovalRequests ar_req ON ar_req.Id = ar_row.ApprovalRequestId
            WHERE ar_row.EntityRowId = er.Id AND ar_req.Status = 'pending'
        ) THEN 1 ELSE 0 END AS HasPendingApproval
    FROM #PagedRowIds p
    JOIN EntityRows er ON er.Id = p.Id
    LEFT JOIN EntityValues ev ON ev.EntityRowId = er.Id
    LEFT JOIN Attributes a ON a.Id = ev.AttributeId AND a.IsSystemDate = 0
    LEFT JOIN EntityRows dr ON dr.Id = ev.DomainValue
    LEFT JOIN Users uc ON uc.Id = er.CreatedBy
    LEFT JOIN Users um ON um.Id = er.ModifiedBy
    ORDER BY p.RowNum, a.SortOrder
    OPTION (RECOMPILE);

    -- Phase 4: Return pagination metadata
    SELECT
        @TotalCount AS TotalCount,
        @PageNumber AS PageNumber,
        @PageSize AS PageSize,
        CEILING(CAST(@TotalCount AS FLOAT) / @PageSize) AS TotalPages;

    DROP TABLE #PagedRowIds;
    DROP TABLE #MatchedRows;
    END TRY
    BEGIN CATCH
        -- Cleanup temp tables if they exist (prevents connection pool reuse errors)
        IF OBJECT_ID('tempdb..#MatchedRows')    IS NOT NULL DROP TABLE #MatchedRows;
        IF OBJECT_ID('tempdb..#PagedRowIds')    IS NOT NULL DROP TABLE #PagedRowIds;
        IF OBJECT_ID('tempdb..#TextFilterList') IS NOT NULL DROP TABLE #TextFilterList;
        IF OBJECT_ID('tempdb..#ColFilterList')  IS NOT NULL DROP TABLE #ColFilterList;
        THROW;
    END CATCH
END;
GO

-- ============================================
-- UTILITY PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_Data_ResolveDomainIds
    @RowIdsJson NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Resolves a JSON array of EntityRow Ids to their Code and Name
--              values. Used by the frontend to display domain labels for
--              a set of known row Ids without loading the entire entity.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT er.Id, er.Code, er.Name
    FROM EntityRows er
    WHERE er.Id IN (SELECT CAST(value AS BIGINT) FROM OPENJSON(@RowIdsJson));
END;
GO

CREATE OR ALTER PROCEDURE usp_Import_CleanupStaging
    @RetentionDays INT = 7
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Removes processed staging import records older than
--              @RetentionDays (default 7 days). Intended to be run
--              periodically to keep the StagingImport table from growing
--              indefinitely.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM StagingImport
    WHERE CreatedAt < DATEADD(DAY, -@RetentionDays, GETUTCDATE())
      AND Status = 'processed';
    SELECT @@ROWCOUNT AS DeletedCount;
END;
GO

CREATE OR ALTER PROCEDURE usp_Data_ResolveDomainValuesBatch
    @ItemsJson NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Batch-resolves multiple domain text values to their EntityRow
--              Ids in a single query, avoiding the N+1 round-trips that
--              usp_Data_ResolveDomainValue would require when processing many
--              rows. Each item carries an idx for the caller to correlate
--              results back to the original request. Resolution uses the same
--              three-pass strategy: Code match, then Name match, then
--              "{Code} Name" format extraction.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    -- Items format: [{"domainEntityId":123,"textValue":"Some Value","idx":0}, ...]
    SELECT
        j.idx,
        j.domainEntityId,
        j.textValue,
        (
            -- Resolve using the same three-pass strategy as usp_Data_ResolveDomainValue
            SELECT TOP 1 er.Id
            FROM EntityRows er
            WHERE er.EntityId = j.domainEntityId
            AND (
                er.Code = LTRIM(RTRIM(j.textValue))
                OR er.Name = LTRIM(RTRIM(j.textValue))
                OR (j.textValue LIKE '{%} %' AND er.Code = SUBSTRING(j.textValue, 2, CHARINDEX('}', j.textValue) - 2))
            )
        ) AS ResolvedRowId
    FROM OPENJSON(@ItemsJson) WITH (
        idx INT,
        domainEntityId INT,
        textValue NVARCHAR(500)
    ) j;
END;
GO

-- ============================================
-- USER PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_User_GetAll
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns all non-deleted users and their group memberships as two
--              result sets. Result set 1: Users ordered by DisplayName.
--              Result set 2: RoleMembers with RoleId and group Name for each
--              user, allowing the caller to reconstruct per-user group lists.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v2.0  2026-02-17  Filter out soft-deleted users; add IsSystem column
--   v3.0  2026-02-23  Include PasswordLastChangedAt in result
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    -- Result set 1: non-deleted users; IsAdministrator/CanApprove computed from role membership
    -- UserType is returned so the UI can tell an API account apart from the internal
    -- system account: both carry IsSystem = 1 and would otherwise be indistinguishable.
    SELECT u.Id, u.Email, u.DisplayName, u.MustChangePassword, u.IsActive, u.IsSystem, u.UserType,
           CASE WHEN EXISTS (
               SELECT 1 FROM RoleMembers rm2 JOIN Roles r2 ON r2.Id = rm2.RoleId
               WHERE rm2.UserId = u.Id AND r2.IsAdmin = 1
           ) THEN 1 ELSE 0 END AS IsAdministrator,
           CASE WHEN EXISTS (
               SELECT 1 FROM RoleMembers rm3 JOIN Roles r3 ON r3.Id = rm3.RoleId
               WHERE rm3.UserId = u.Id AND r3.CanApprove = 1
           ) THEN 1 ELSE 0 END AS CanApprove,
           u.CreatedAt, u.ModifiedAt, u.PasswordLastChangedAt
    FROM Users u
    WHERE u.IsDeleted = 0
    ORDER BY u.DisplayName;
    -- Result set 2: memberships with role name (only for non-deleted users)
    SELECT gm.UserId, gm.RoleId, r.Name AS RoleName
    FROM RoleMembers gm
    JOIN Roles r ON r.Id = gm.RoleId
    JOIN Users u ON u.Id = gm.UserId AND u.IsDeleted = 0
    ORDER BY gm.UserId;
END;
GO

CREATE OR ALTER PROCEDURE usp_User_GetById
    @Id INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns a single user by primary key plus their group memberships
--              as two result sets. Returns even soft-deleted users (needed for
--              audit log display). Mirrors the shape returned by usp_User_GetAll.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v2.0  2026-02-17  Add IsSystem column to output
--   v3.0  2026-02-23  Include PasswordLastChangedAt in result
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    -- Result set 1: single user (including deleted for audit); IsAdministrator/CanApprove computed from roles
    SELECT u.Id, u.Email, u.DisplayName, u.MustChangePassword, u.IsActive, u.IsSystem,
           CASE WHEN EXISTS (
               SELECT 1 FROM RoleMembers rm2 JOIN Roles r2 ON r2.Id = rm2.RoleId
               WHERE rm2.UserId = u.Id AND r2.IsAdmin = 1
           ) THEN 1 ELSE 0 END AS IsAdministrator,
           CASE WHEN EXISTS (
               SELECT 1 FROM RoleMembers rm3 JOIN Roles r3 ON r3.Id = rm3.RoleId
               WHERE rm3.UserId = u.Id AND r3.CanApprove = 1
           ) THEN 1 ELSE 0 END AS CanApprove,
           u.CreatedAt, u.ModifiedAt, u.PasswordLastChangedAt
    FROM Users u WHERE u.Id = @Id;
    -- Result set 2: role memberships for this user
    SELECT gm.UserId, gm.RoleId, r.Name AS RoleName
    FROM RoleMembers gm
    JOIN Roles r ON r.Id = gm.RoleId
    WHERE gm.UserId = @Id
    ORDER BY r.Name;
END;
GO

CREATE OR ALTER PROCEDURE usp_User_Create
    @Email NVARCHAR(320),
    @DisplayName NVARCHAR(200),
    @PasswordHash NVARCHAR(500) = NULL,
    @MustChangePassword BIT = 1,
    @IsActive BIT = 1,
    @IsSystem BIT = 0,
    @RoleIdsJson NVARCHAR(MAX) = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Creates a new user and, when @RoleIdsJson is supplied,
--              inserts RoleMembers rows for each group ID in the JSON array.
--              Returns the created user and their memberships as two result sets.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v2.0  2026-02-17  Added @PasswordHash and @MustChangePassword parameters
--   v3.0  2026-02-17  Added @IsSystem parameter; email uniqueness check now
--                      excludes soft-deleted users
--   v4.0  2026-02-17  Added @IsAdministrator parameter
--   v5.0  2026-02-23  Track PasswordLastChangedAt on create
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- Check for duplicate email (only among non-deleted users)
    IF EXISTS (SELECT 1 FROM Users WHERE Email = @Email AND IsDeleted = 0)
    BEGIN
        THROW 50001, 'A user with this email address already exists.', 1;
    END

    BEGIN TRANSACTION;
    BEGIN TRY
        INSERT INTO Users (Email, DisplayName, PasswordHash, MustChangePassword, IsActive, IsSystem, PasswordLastChangedAt)
        VALUES (@Email, @DisplayName, @PasswordHash, @MustChangePassword, @IsActive, @IsSystem,
                CASE WHEN @PasswordHash IS NOT NULL THEN GETUTCDATE() ELSE NULL END);
        DECLARE @UserId INT = SCOPE_IDENTITY();

        -- Assign initial group memberships when provided
        IF @RoleIdsJson IS NOT NULL
            INSERT INTO RoleMembers (RoleId, UserId)
            SELECT CAST(value AS INT), @UserId FROM OPENJSON(@RoleIdsJson) WHERE value IS NOT NULL;

        COMMIT TRANSACTION;
        -- Return created user; IsAdministrator computed from role membership
        SELECT u.Id, u.Email, u.DisplayName, u.MustChangePassword, u.IsActive, u.IsSystem,
               CASE WHEN EXISTS (
                   SELECT 1 FROM RoleMembers rm2 JOIN Roles r2 ON r2.Id = rm2.RoleId
                   WHERE rm2.UserId = u.Id AND r2.IsAdmin = 1
               ) THEN 1 ELSE 0 END AS IsAdministrator,
               u.CreatedAt, u.ModifiedAt, u.PasswordLastChangedAt
        FROM Users u WHERE u.Id = @UserId;
        -- Return role memberships for display
        SELECT gm.UserId, gm.RoleId, r.Name AS RoleName
        FROM RoleMembers gm
        JOIN Roles r ON r.Id = gm.RoleId
        WHERE gm.UserId = @UserId
        ORDER BY r.Name;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_User_Update
    @Id INT,
    @Email NVARCHAR(320) = NULL,
    @DisplayName NVARCHAR(200) = NULL,
    @PasswordHash NVARCHAR(500) = NULL,
    @MustChangePassword BIT = NULL,
    @IsActive BIT = NULL,
    @RoleIdsJson NVARCHAR(MAX) = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Updates a user's fields. NULL parameters use COALESCE to
--              preserve existing values. When @RoleIdsJson is supplied the
--              group memberships are fully replaced (delete-then-insert) in the
--              same transaction. Always updates ModifiedAt. Returns the updated
--              user and current memberships as two result sets.
--              System users (IsSystem = 1) cannot be modified.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v2.0  2026-02-17  Added @PasswordHash and @MustChangePassword parameters
--   v3.0  2026-02-17  System user protection; email check excludes soft-deleted;
--                      add IsSystem to output
--   v4.0  2026-02-17  Added @IsAdministrator parameter
--   v5.0  2026-02-23  Track PasswordLastChangedAt on password change
--   v5.1  2026-07-31  Refuses to remove the last active administrator
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- Block modifications to system users
    IF EXISTS (SELECT 1 FROM Users WHERE Id = @Id AND IsSystem = 1)
    BEGIN
        THROW 50003, 'System users cannot be modified.', 1;
    END

    -- Check for duplicate email (only when changing email, exclude soft-deleted)
    IF @Email IS NOT NULL AND EXISTS (SELECT 1 FROM Users WHERE Email = @Email AND Id <> @Id AND IsDeleted = 0)
    BEGIN
        THROW 50001, 'A user with this email address already exists.', 1;
    END

    BEGIN TRANSACTION;
    BEGIN TRY
        UPDATE Users SET
            Email                  = COALESCE(@Email, Email),
            DisplayName            = COALESCE(@DisplayName, DisplayName),
            PasswordHash           = COALESCE(@PasswordHash, PasswordHash),
            MustChangePassword     = COALESCE(@MustChangePassword, MustChangePassword),
            IsActive               = COALESCE(@IsActive, IsActive),
            PasswordLastChangedAt  = CASE WHEN @PasswordHash IS NOT NULL THEN GETUTCDATE() ELSE PasswordLastChangedAt END,
            ModifiedAt             = GETUTCDATE()
        WHERE Id = @Id AND IsDeleted = 0;

        IF @@ROWCOUNT = 0
        BEGIN
            IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
            THROW 50002, 'User not found', 1;
        END

        -- Replace group memberships atomically when provided
        IF @RoleIdsJson IS NOT NULL
        BEGIN
            DELETE FROM RoleMembers WHERE UserId = @Id;
            INSERT INTO RoleMembers (RoleId, UserId)
            SELECT CAST(value AS INT), @Id FROM OPENJSON(@RoleIdsJson) WHERE value IS NOT NULL;
        END

        -- Two edits here can take the last administrator away: deactivating them, and replacing
        -- their role list with one that no longer includes an admin role. Only checked when the
        -- call could actually do that, so renaming a user or changing an email still works on an
        -- installation that is already in that state. Same check, number and wording as
        -- usp_Role_Update.
        IF @IsActive = 0 OR @RoleIdsJson IS NOT NULL
        BEGIN
            IF NOT EXISTS (
                SELECT 1
                FROM RoleMembers rm
                JOIN Roles r ON r.Id = rm.RoleId
                JOIN Users u ON u.Id = rm.UserId
                WHERE r.IsAdmin = 1 AND u.IsDeleted = 0 AND u.IsActive = 1
            )
            BEGIN
                IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
                THROW 50003, 'This change would leave the system without an active administrator.', 1;
            END
        END

        COMMIT TRANSACTION;
        -- Return updated user; IsAdministrator computed from role membership
        SELECT u.Id, u.Email, u.DisplayName, u.MustChangePassword, u.IsActive, u.IsSystem,
               CASE WHEN EXISTS (
                   SELECT 1 FROM RoleMembers rm2 JOIN Roles r2 ON r2.Id = rm2.RoleId
                   WHERE rm2.UserId = u.Id AND r2.IsAdmin = 1
               ) THEN 1 ELSE 0 END AS IsAdministrator,
               u.CreatedAt, u.ModifiedAt, u.PasswordLastChangedAt
        FROM Users u WHERE u.Id = @Id;
        -- Return current role memberships
        SELECT gm.UserId, gm.RoleId, r.Name AS RoleName
        FROM RoleMembers gm
        JOIN Roles r ON r.Id = gm.RoleId
        WHERE gm.UserId = @Id
        ORDER BY r.Name;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_User_Delete
    @Id INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Soft-deletes a user by setting IsDeleted = 1 and IsActive = 0.
--              Explicitly removes child rows (RoleMembers, UserFavorites,
--              UserSettings) since ON DELETE CASCADE only fires on physical DELETE.
--              System users cannot be deleted. Audit log entries are preserved.
--
-- Change History:
--   v1.0  2026-02-17  Initial version (hard delete)
--   v2.0  2026-02-17  Converted to soft-delete with system user protection
--   v2.1  2026-07-31  Refuses to remove the last active administrator
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- Block deletion of system users
    IF EXISTS (SELECT 1 FROM Users WHERE Id = @Id AND IsSystem = 1)
    BEGIN
        THROW 50003, 'System users cannot be deleted.', 1;
    END

    DECLARE @Affected INT = 0;

    BEGIN TRANSACTION;
    BEGIN TRY
        -- Soft-delete: mark as deleted and deactivate
        UPDATE Users
        SET IsDeleted = 1, IsActive = 0, ModifiedAt = GETUTCDATE()
        WHERE Id = @Id AND IsDeleted = 0;
        SET @Affected = @@ROWCOUNT;

        -- Explicitly clean up child rows (CASCADE only fires on physical DELETE)
        IF @Affected > 0
        BEGIN
            DELETE FROM RoleMembers WHERE UserId = @Id;
            DELETE FROM UserFavorites WHERE UserId = @Id;
            DELETE FROM UserHiddenEntities WHERE UserId = @Id;
            DELETE FROM UserSettings WHERE UserId = @Id;

            -- Deleting the last administrator locks the installation out just as completely as
            -- deleting the administrator role: both IsActive and the RoleMembers rows are gone
            -- by this point. Same check, number and wording as usp_Role_Update.
            IF NOT EXISTS (
                SELECT 1
                FROM RoleMembers rm
                JOIN Roles r ON r.Id = rm.RoleId
                JOIN Users u ON u.Id = rm.UserId
                WHERE r.IsAdmin = 1 AND u.IsDeleted = 0 AND u.IsActive = 1
            )
            BEGIN
                IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
                THROW 50003, 'This change would leave the system without an active administrator.', 1;
            END
        END

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH

    SELECT @Affected AS Deleted;
END;
GO

CREATE OR ALTER PROCEDURE usp_User_CreateSystem
    @Email NVARCHAR(320),
    @DisplayName NVARCHAR(200)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Creates or returns an existing system user. System users have
--              IsSystem = 1, no password, and cannot be edited or deleted.
--              If a non-deleted system user with the given email already exists,
--              returns the existing user ID without creating a duplicate.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @UserId INT;

    -- Check if system user already exists (non-deleted)
    SELECT @UserId = Id FROM Users WHERE Email = @Email AND IsDeleted = 0 AND IsSystem = 1;

    IF @UserId IS NULL
    BEGIN
        INSERT INTO Users (Email, DisplayName, PasswordHash, MustChangePassword, IsActive, IsSystem)
        VALUES (@Email, @DisplayName, NULL, 0, 1, 1);
        SET @UserId = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        -- Update display name if it changed (self-heal on re-deploy)
        UPDATE Users SET DisplayName = @DisplayName WHERE Id = @UserId AND DisplayName <> @DisplayName;
    END

    SELECT @UserId AS Id, @DisplayName AS DisplayName;
END;
GO

-- ============================================
-- USER FAVORITES PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_UserFavorites_GetByUser
    @UserId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns the list of EntityIds bookmarked by the given user,
--              ordered by when the favorite was created (oldest first so the
--              display order is stable across sessions).
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT EntityId FROM UserFavorites
    WHERE UserId = @UserId
    ORDER BY CreatedAt;
END;
GO

CREATE OR ALTER PROCEDURE usp_UserFavorites_Toggle
    @UserId INT,
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Toggles a user's favorite for an entity: removes it if it
--              already exists, adds it if it does not. Returns a Status column
--              ('added' or 'removed') so the caller can update its UI state
--              without a follow-up query. Uses OwnTransaction pattern so this
--              SP is safe to call both standalone and from within a caller
--              transaction.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @OwnTransaction BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRANSACTION; SET @OwnTransaction = 1; END

    BEGIN TRY
        IF EXISTS (SELECT 1 FROM UserFavorites WHERE UserId = @UserId AND EntityId = @EntityId)
        BEGIN
            DELETE FROM UserFavorites WHERE UserId = @UserId AND EntityId = @EntityId;
            IF @OwnTransaction = 1 COMMIT TRANSACTION;
            SELECT 'removed' AS Status;
        END
        ELSE
        BEGIN
            INSERT INTO UserFavorites (UserId, EntityId) VALUES (@UserId, @EntityId);
            IF @OwnTransaction = 1 COMMIT TRANSACTION;
            SELECT 'added' AS Status;
        END
    END TRY
    BEGIN CATCH
        IF @OwnTransaction = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- ============================================================================
-- FULL-TEXT SEARCH (FTS)
-- ============================================================================
-- Full-Text Search is required for efficient search in Primentra.
-- The stored procedure usp_Data_GetByEntityPaginated automatically uses
-- CONTAINS() when FTS indexes exist, falling back to LIKE if not.
--
-- PREREQUISITES:
--   1. SQL Server Full-Text Search feature must be installed
--      (SQL Server Setup → Feature Selection → Full-Text and Semantic Extractions for Search)
--   2. The SQL Server Full-Text Filter Daemon Launcher service must be running
--      and set to Automatic startup type
-- ============================================================================

-- CREATE PROCEDURE placeholder so this batch is picked up on re-runs
-- (the setup endpoint filters batches by keywords like CREATE PROCEDURE)

-- Only create FTS objects if the Full-Text Search feature is installed
IF FULLTEXTSERVICEPROPERTY('IsFullTextInstalled') = 1
BEGIN
    -- Step 1: Create Full-Text Catalog
    IF NOT EXISTS (SELECT 1 FROM sys.fulltext_catalogs WHERE name = 'PrimentraCatalog')
    BEGIN
        CREATE FULLTEXT CATALOG PrimentraCatalog AS DEFAULT;
        PRINT 'Full-Text Catalog [PrimentraCatalog] created.';
    END

    -- Step 2: Create Full-Text Index on EntityRows (Code, Name)
    -- Dynamically resolve PK index name since inline PRIMARY KEY generates a system name
    IF NOT EXISTS (SELECT 1 FROM sys.fulltext_indexes WHERE object_id = OBJECT_ID('EntityRows'))
    BEGIN
        DECLARE @PKRows NVARCHAR(128);
        SELECT @PKRows = i.name FROM sys.indexes i
        WHERE i.object_id = OBJECT_ID('EntityRows') AND i.is_primary_key = 1;

        IF @PKRows IS NOT NULL
        BEGIN
            DECLARE @SqlRows NVARCHAR(500) = N'CREATE FULLTEXT INDEX ON EntityRows (Code, Name) KEY INDEX '
                + QUOTENAME(@PKRows) + N' ON PrimentraCatalog WITH (CHANGE_TRACKING = AUTO)';
            EXEC sp_executesql @SqlRows;
            PRINT 'Full-Text Index on [EntityRows] created.';
        END
        ELSE
            PRINT 'WARNING: Could not find primary key index on EntityRows.';
    END

    -- Step 3: Create Full-Text Index on EntityValues (TextValue)
    IF NOT EXISTS (SELECT 1 FROM sys.fulltext_indexes WHERE object_id = OBJECT_ID('EntityValues'))
    BEGIN
        DECLARE @PKValues NVARCHAR(128);
        SELECT @PKValues = i.name FROM sys.indexes i
        WHERE i.object_id = OBJECT_ID('EntityValues') AND i.is_primary_key = 1;

        IF @PKValues IS NOT NULL
        BEGIN
            DECLARE @SqlValues NVARCHAR(500) = N'CREATE FULLTEXT INDEX ON EntityValues (TextValue) KEY INDEX '
                + QUOTENAME(@PKValues) + N' ON PrimentraCatalog WITH (CHANGE_TRACKING = AUTO)';
            EXEC sp_executesql @SqlValues;
            PRINT 'Full-Text Index on [EntityValues] created.';
        END
        ELSE
            PRINT 'WARNING: Could not find primary key index on EntityValues.';
    END

    PRINT 'Full-Text Search indexes configured successfully.';
END
ELSE
BEGIN
    PRINT '';
    PRINT '========================================================================';
    PRINT 'WARNING: Full-Text Search is NOT installed on this SQL Server instance.';
    PRINT '========================================================================';
    PRINT '';
    PRINT 'Primentra requires Full-Text Search for fast search performance.';
    PRINT 'Without it, search will fall back to LIKE scans (significantly slower).';
    PRINT '';
    PRINT 'To install Full-Text Search:';
    PRINT '  1. Run the SQL Server Installation Center';
    PRINT '  2. Click "New installation or add features to an existing installation"';
    PRINT '  3. Select "Add features to an existing instance"';
    PRINT '  4. Check "Full-Text and Semantic Extractions for Search"';
    PRINT '  5. Complete the wizard';
    PRINT '  6. Open Services (services.msc) and set "SQL Full-text Filter Daemon';
    PRINT '     Launcher" startup type to Automatic';
    PRINT '';
    PRINT 'After installing Full-Text Search, run this setup again to create the';
    PRINT 'Full-Text indexes.';
    PRINT '========================================================================';
END
GO

CREATE OR ALTER PROCEDURE usp_User_GetDashboardPreferences
    @UserId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-08
-- Description: Returns dashboard preferences JSON for the given user.
--
-- Change History:
--   v1.0  2026-03-08  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ISNULL(DashboardPreferences, '{}') AS DashboardPreferences
    FROM Users WHERE Id = @UserId;
END;
GO

CREATE OR ALTER PROCEDURE usp_User_SaveDashboardPreferences
    @UserId      INT,
    @Preferences NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-08
-- Description: Saves dashboard preferences JSON for the given user.
--
-- Change History:
--   v1.0  2026-03-08  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Users SET DashboardPreferences = @Preferences WHERE Id = @UserId;
END;
GO

-- ============================================
-- AUTH STORED PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_User_GetCount
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns the count of non-deleted users in the system.
--              Used by the auth system to detect first-run state
--              (zero non-deleted users means the setup screen should be shown).
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v2.0  2026-02-17  Exclude soft-deleted users from count
--   v3.0  2026-03-08  Exclude system and API users — only count real human accounts
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT COUNT(*) AS UserCount FROM Users WHERE IsDeleted = 0 AND IsSystem = 0 AND UserType = 'standard';
END;
GO

CREATE OR ALTER PROCEDURE usp_User_GetByEmail
    @Email NVARCHAR(320)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Retrieves a non-deleted user by email address for login
--              authentication. Returns user details including PasswordHash and
--              FailedLoginAttempts, plus group memberships as a second result set.
--              Soft-deleted users are excluded (they cannot log in).
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v2.0  2026-02-17  Exclude soft-deleted users; add IsSystem column
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    -- Result set 1: user with auth-relevant fields; IsAdministrator/CanApprove computed from roles
    SELECT u.Id, u.Email, u.DisplayName, u.PasswordHash, u.MustChangePassword,
           u.FailedLoginAttempts, u.IsActive, u.IsSystem,
           CASE WHEN EXISTS (
               SELECT 1 FROM RoleMembers rm2 JOIN Roles r2 ON r2.Id = rm2.RoleId
               WHERE rm2.UserId = u.Id AND r2.IsAdmin = 1
           ) THEN 1 ELSE 0 END AS IsAdministrator,
           CASE WHEN EXISTS (
               SELECT 1 FROM RoleMembers rm3 JOIN Roles r3 ON r3.Id = rm3.RoleId
               WHERE rm3.UserId = u.Id AND r3.CanApprove = 1
           ) THEN 1 ELSE 0 END AS CanApprove,
           u.CreatedAt, u.ModifiedAt
    FROM Users u
    WHERE u.Email = @Email AND u.IsDeleted = 0;

    -- Result set 2: role memberships for permission resolution
    SELECT gm.UserId, gm.RoleId, r.Name AS RoleName
    FROM RoleMembers gm
    JOIN Roles r ON r.Id = gm.RoleId
    WHERE gm.UserId = (SELECT Id FROM Users WHERE Email = @Email AND IsDeleted = 0)
    ORDER BY r.Name;
END;
GO

CREATE OR ALTER PROCEDURE usp_User_RecordLogin
    @UserId INT,
    @Success BIT,
    @IpAddress NVARCHAR(50) = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Records a login attempt result. On success: resets
--              FailedLoginAttempts to 0 and logs 'login_success'.
--              On failure: increments FailedLoginAttempts; if it reaches
--              5, sets IsActive=0 (lockout) and logs 'account_locked'.
--              Otherwise logs 'login_failed'. All audit entries written
--              to AuditLog for security monitoring.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Email NVARCHAR(320);
    DECLARE @FailedAttempts INT;
    DECLARE @IsActive BIT;
    DECLARE @AuditJson NVARCHAR(MAX);

    SELECT @Email = Email, @FailedAttempts = FailedLoginAttempts, @IsActive = IsActive
    FROM Users WHERE Id = @UserId;

    IF @Success = 1
    BEGIN
        -- Successful login: reset failed attempts counter and record login time
        UPDATE Users SET FailedLoginAttempts = 0, LastLoginAt = GETUTCDATE(), ModifiedAt = GETUTCDATE()
        WHERE Id = @UserId;

        -- Build audit JSON safely using FOR JSON PATH (avoids injection via special chars)
        SELECT @AuditJson = (SELECT @Email AS email, ISNULL(@IpAddress, '') AS ip FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        INSERT INTO AuditLog (EntityId, EntityName, ModelName, Action, Details, UserId, CreatedAt)
        VALUES (NULL, 'Authentication', 'System', 'login_success',
                @AuditJson,
                @UserId, GETUTCDATE());
    END
    ELSE
    BEGIN
        -- Failed login: increment counter
        SET @FailedAttempts = @FailedAttempts + 1;
        UPDATE Users SET FailedLoginAttempts = @FailedAttempts, ModifiedAt = GETUTCDATE()
        WHERE Id = @UserId;

        IF @FailedAttempts >= 5
        BEGIN
            -- Lock the account after 5 failed attempts
            UPDATE Users SET IsActive = 0, ModifiedAt = GETUTCDATE()
            WHERE Id = @UserId;

            -- Build audit JSON safely using FOR JSON PATH
            SELECT @AuditJson = (SELECT @Email AS email, ISNULL(@IpAddress, '') AS ip, @FailedAttempts AS failedAttempts FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

            INSERT INTO AuditLog (EntityId, EntityName, ModelName, Action, Details, UserId, CreatedAt)
            VALUES (NULL, 'Authentication', 'System', 'account_locked',
                    @AuditJson,
                    @UserId, GETUTCDATE());
        END
        ELSE
        BEGIN
            -- Build audit JSON safely using FOR JSON PATH
            SELECT @AuditJson = (SELECT @Email AS email, ISNULL(@IpAddress, '') AS ip, @FailedAttempts AS failedAttempts FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

            INSERT INTO AuditLog (EntityId, EntityName, ModelName, Action, Details, UserId, CreatedAt)
            VALUES (NULL, 'Authentication', 'System', 'login_failed',
                    @AuditJson,
                    @UserId, GETUTCDATE());
        END
    END

    -- Return current state so the caller knows the result
    SELECT FailedLoginAttempts, IsActive FROM Users WHERE Id = @UserId;
END;
GO

-- ============================================
-- SYSTEM CONFIG PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_SystemConfig_Get
    @ConfigKey NVARCHAR(64)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-18
-- Description: Retrieves a system config entry by its key.
--
-- Change History:
--   v1.0  2026-02-18  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Id, ConfigKey, ConfigValue, Metadata, UpdatedAt, CreatedAt
    FROM SystemConfig
    WHERE ConfigKey = @ConfigKey;
END;
GO

CREATE OR ALTER PROCEDURE usp_SystemConfig_Set
    @ConfigKey   NVARCHAR(64),
    @ConfigValue DATETIME2
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-18
-- Description: Inserts a system config entry if not already present.
--              Idempotent — does nothing if the key already exists.
--              Returns the current record regardless.
--
-- Change History:
--   v1.0  2026-02-18  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- Only insert if no record with this key exists
    IF NOT EXISTS (SELECT 1 FROM SystemConfig WHERE ConfigKey = @ConfigKey)
    BEGIN
        INSERT INTO SystemConfig (ConfigKey, ConfigValue)
        VALUES (@ConfigKey, @ConfigValue);
    END

    SELECT Id, ConfigKey, ConfigValue, Metadata, UpdatedAt, CreatedAt
    FROM SystemConfig
    WHERE ConfigKey = @ConfigKey;
END;
GO

CREATE OR ALTER PROCEDURE usp_SystemConfig_Update
    @ConfigKey NVARCHAR(64),
    @Metadata  NVARCHAR(200)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-18
-- Description: Updates the Metadata field for an existing config entry.
--              Used to mark a trial as upgraded to a paid license.
--
-- Change History:
--   v1.0  2026-02-18  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE SystemConfig
    SET Metadata = @Metadata, UpdatedAt = GETUTCDATE()
    WHERE ConfigKey = @ConfigKey;
END;
GO

-- ============================================
-- ADMIN RECOVERY PROCEDURE
-- ============================================

CREATE OR ALTER PROCEDURE usp_User_ResetPassword
    @Email NVARCHAR(320),
    @NewPasswordHash NVARCHAR(500)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Emergency password reset for admin account recovery.
--              Resets the password hash, clears lockout state, and
--              sets MustChangePassword=0. Writes an audit log entry.
--              Intended to be called from the CLI recovery script —
--              not exposed via the web API.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
--   v2.0  2026-02-23  Track PasswordLastChangedAt
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @UserId INT;
    DECLARE @DisplayName NVARCHAR(200);

    -- Resolve the user — soft-deleted accounts cannot be recovered
    SELECT @UserId = Id, @DisplayName = DisplayName
    FROM Users
    WHERE Email = @Email AND IsDeleted = 0;

    IF @UserId IS NULL
        THROW 50002, 'User not found or has been deleted. Check the email address and try again.', 1;

    DECLARE @OwnTransaction BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRANSACTION; SET @OwnTransaction = 1; END

    BEGIN TRY
        UPDATE Users SET
            PasswordHash             = @NewPasswordHash,
            FailedLoginAttempts      = 0,
            IsActive                 = 1,
            MustChangePassword       = 0,
            PasswordLastChangedAt    = GETUTCDATE(),
            ModifiedAt               = GETUTCDATE()
        WHERE Id = @UserId;

        -- Build audit JSON safely using FOR JSON PATH
        DECLARE @ResetJson NVARCHAR(MAX);
        SELECT @ResetJson = (SELECT @Email AS email, 'cli_recovery' AS method, CONVERT(NVARCHAR(30), GETUTCDATE(), 126) AS resetAt FOR JSON PATH, WITHOUT_ARRAY_WRAPPER);

        INSERT INTO AuditLog (EntityId, EntityName, ModelName, Action, Details, UserId, CreatedAt)
        VALUES (
            NULL, 'Authentication', 'System', 'admin_password_reset',
            @ResetJson,
            @UserId, GETUTCDATE()
        );

        IF @OwnTransaction = 1 COMMIT TRANSACTION;

        SELECT @UserId AS Id, @Email AS Email, @DisplayName AS DisplayName;
    END TRY
    BEGIN CATCH
        IF @OwnTransaction = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- ============================================
-- ERROR LOG PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_ErrorLog_Write
    @Level       NVARCHAR(10),
    @Method      NVARCHAR(10) = NULL,
    @Path        NVARCHAR(500) = NULL,
    @StatusCode  INT = NULL,
    @Message     NVARCHAR(MAX) = NULL,
    @Stack       NVARCHAR(MAX) = NULL,
    @UserId      INT = NULL,
    @RequestBody NVARCHAR(MAX) = NULL,
    @Duration    INT = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Inserts a new error log entry.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO ErrorLog (Level, Method, Path, StatusCode, Message, Stack, UserId, RequestBody, Duration)
    VALUES (@Level, @Method, @Path, @StatusCode, @Message, @Stack, @UserId, @RequestBody, @Duration);
END;
GO

CREATE OR ALTER PROCEDURE usp_ErrorLog_Get
    @PageNumber    INT = 1,
    @PageSize      INT = 50,
    @Level         NVARCHAR(10) = NULL,
    @SearchText    NVARCHAR(200) = NULL,
    @DateFrom      DATETIME2 = NULL,
    @DateTo        DATETIME2 = NULL,
    @SortColumn    NVARCHAR(20) = 'Timestamp',
    @SortDirection NVARCHAR(4) = 'DESC'
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns a paginated page of error log entries, optionally
--              filtered by level, search text, and date range. Supports
--              dynamic sorting on Timestamp, Level, StatusCode, Path, and
--              Message columns.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        Id, Timestamp, Level, Method, Path, StatusCode,
        Message, Stack, UserId, RequestBody, Duration,
        COUNT(*) OVER() AS TotalCount
    FROM ErrorLog
    WHERE (@Level      IS NULL OR Level   = @Level)
      AND (@SearchText IS NULL OR Message LIKE '%' + @SearchText + '%'
                               OR Path    LIKE '%' + @SearchText + '%')
      AND (@DateFrom   IS NULL OR Timestamp >= @DateFrom)
      AND (@DateTo     IS NULL OR Timestamp <= @DateTo)
    ORDER BY
        CASE WHEN @SortColumn = 'Timestamp'  AND @SortDirection = 'ASC'  THEN Timestamp  END ASC,
        CASE WHEN @SortColumn = 'Timestamp'  AND @SortDirection = 'DESC' THEN Timestamp  END DESC,
        CASE WHEN @SortColumn = 'Level'      AND @SortDirection = 'ASC'  THEN Level      END ASC,
        CASE WHEN @SortColumn = 'Level'      AND @SortDirection = 'DESC' THEN Level      END DESC,
        CASE WHEN @SortColumn = 'StatusCode' AND @SortDirection = 'ASC'  THEN StatusCode END ASC,
        CASE WHEN @SortColumn = 'StatusCode' AND @SortDirection = 'DESC' THEN StatusCode END DESC,
        CASE WHEN @SortColumn = 'Path'       AND @SortDirection = 'ASC'  THEN Path       END ASC,
        CASE WHEN @SortColumn = 'Path'       AND @SortDirection = 'DESC' THEN Path       END DESC,
        CASE WHEN @SortColumn = 'Message'    AND @SortDirection = 'ASC'  THEN Message    END ASC,
        CASE WHEN @SortColumn = 'Message'    AND @SortDirection = 'DESC' THEN Message    END DESC,
        Timestamp DESC
    OFFSET (@PageNumber - 1) * @PageSize ROWS
    FETCH NEXT @PageSize ROWS ONLY;
END;
GO

CREATE OR ALTER PROCEDURE usp_ErrorLog_Cleanup
    @RetentionDays INT = 30
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Removes error log entries older than @RetentionDays (default
--              30 days). Intended to be run periodically as a maintenance
--              job to prevent unbounded table growth.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM ErrorLog WHERE Timestamp < DATEADD(DAY, -@RetentionDays, GETUTCDATE());
    SELECT @@ROWCOUNT AS DeletedCount;
END;
GO

CREATE OR ALTER PROCEDURE usp_ErrorLog_Truncate
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Deletes all error log entries. Used for manual clearing
--              via the admin error log viewer.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM ErrorLog;
    SELECT @@ROWCOUNT AS DeletedCount;
END;
GO

CREATE OR ALTER PROCEDURE usp_ErrorLog_GetStats
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-17
-- Description: Returns summary statistics for the error log viewer header:
--              total entry count, counts per level, and the oldest/newest
--              entry timestamps.
--
-- Change History:
--   v1.0  2026-02-17  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        COUNT(*) AS TotalEntries,
        SUM(CASE WHEN Level = 'error' THEN 1 ELSE 0 END) AS ErrorCount,
        SUM(CASE WHEN Level = 'warn' THEN 1 ELSE 0 END) AS WarnCount,
        SUM(CASE WHEN Level = 'info' THEN 1 ELSE 0 END) AS InfoCount,
        MIN(Timestamp) AS OldestEntry,
        MAX(Timestamp) AS NewestEntry
    FROM ErrorLog;
END;
GO

-- ============================================
-- USER SELF-SERVICE PROCEDURES
-- ============================================

SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE usp_User_ChangePassword
    @UserId INT,
    @NewPasswordHash NVARCHAR(500)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-20
-- Description: Authenticated user changes their own password.
--              Clears MustChangePassword flag and updates ModifiedAt.
--
-- Change History:
--   v1.0  2026-02-20  Initial version
--   v2.0  2026-02-23  Track PasswordLastChangedAt; write audit log in transaction with ROWCOUNT guard
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @OwnTransaction BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRANSACTION; SET @OwnTransaction = 1; END

    BEGIN TRY
        UPDATE Users
        SET
            PasswordHash            = @NewPasswordHash,
            MustChangePassword      = 0,
            PasswordLastChangedAt   = GETUTCDATE(),
            ModifiedAt              = GETUTCDATE()
        WHERE Id = @UserId
          AND IsDeleted = 0;

        IF @@ROWCOUNT = 0
            THROW 50002, 'User not found', 1;

        -- Audit log: self-service password change
        DECLARE @AuditJson NVARCHAR(MAX);
        SELECT @AuditJson = (
            SELECT @UserId AS targetUserId, CONVERT(NVARCHAR(30), GETUTCDATE(), 126) AS changedAt
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );
        INSERT INTO AuditLog (EntityId, EntityName, ModelName, Action, Details, UserId, CreatedAt)
        VALUES (NULL, 'Authentication', 'System', 'password_changed', @AuditJson, @UserId, GETUTCDATE());

        IF @OwnTransaction = 1 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @OwnTransaction = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO

-- ============================================
-- ENTITY APPROVER PROCEDURES
-- ============================================

SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE usp_EntityApprover_GetByEntity
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-24
-- Description: Returns all approvers assigned to the given entity,
--              joined with Users to provide display name and email.
--              Ordered alphabetically by DisplayName.
--
-- Change History:
--   v1.0  2026-02-24  Initial version
--   v1.1  2026-02-25  Added ReceivesEmail column
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ea.UserId, u.DisplayName, u.Email, ea.ReceivesEmail
    FROM EntityApprovers ea
    INNER JOIN Users u ON u.Id = ea.UserId
    WHERE ea.EntityId = @EntityId
    ORDER BY u.DisplayName;
END;
GO

CREATE OR ALTER PROCEDURE usp_EntityApprover_Set
    @EntityId    INT,
    @ApproversJson NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-24
-- Description: Bulk-replaces all approvers for an entity. Accepts a JSON
--              array of {userId, receivesEmail} objects. Deletes existing
--              approvers for the entity and inserts the new set in a single
--              transaction. Passing an empty array clears all approvers.
--
-- Change History:
--   v1.0  2026-02-24  Initial version
--   v1.1  2026-02-25  Parameter renamed to @ApproversJson; now accepts
--                     [{userId, receivesEmail}] and persists ReceivesEmail
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        DELETE FROM EntityApprovers WHERE EntityId = @EntityId;
        INSERT INTO EntityApprovers (EntityId, UserId, ReceivesEmail)
        SELECT
            @EntityId,
            CAST(j.userId AS INT),
            ISNULL(TRY_CAST(j.receivesEmail AS BIT), 1)
        FROM OPENJSON(@ApproversJson) WITH (
            userId        INT  '$.userId',
            receivesEmail BIT  '$.receivesEmail'
        ) j
        WHERE j.userId IS NOT NULL;
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- ============================================
-- APPROVAL FLOW TABLES
-- ============================================

CREATE TABLE ApprovalRequests (
    Id                INT IDENTITY(1,1) CONSTRAINT PK_ApprovalRequests PRIMARY KEY,
    EntityId          INT NOT NULL REFERENCES Entities(Id),
    SubmittedByUserId INT NOT NULL REFERENCES Users(Id),
    SubmittedAt       DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    Status            NVARCHAR(20) NOT NULL DEFAULT 'pending'
        CONSTRAINT CK_ApprovalRequests_Status
        CHECK (Status IN ('pending','approved','rejected','sent_back','cancelled')),
    SubmitterNote     NVARCHAR(1000) NULL,
    Version           INT NOT NULL DEFAULT 1,
    PreviousRequestId INT NULL REFERENCES ApprovalRequests(Id),
    CreatedAt         DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    ModifiedAt        DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO

CREATE INDEX IX_ApprovalRequests_EntityId    ON ApprovalRequests(EntityId);
CREATE INDEX IX_ApprovalRequests_SubmittedBy ON ApprovalRequests(SubmittedByUserId);
CREATE INDEX IX_ApprovalRequests_Status      ON ApprovalRequests(Status);
GO

CREATE TABLE ApprovalRows (
    Id                    INT IDENTITY(1,1) CONSTRAINT PK_ApprovalRows PRIMARY KEY,
    ApprovalRequestId     INT NOT NULL REFERENCES ApprovalRequests(Id) ON DELETE CASCADE,
    EntityRowId           BIGINT NULL REFERENCES EntityRows(Id),
    Operation             NVARCHAR(10) NOT NULL
        CONSTRAINT CK_ApprovalRows_Operation
        CHECK (Operation IN ('insert','update','delete')),
    RowStatus             NVARCHAR(20) NOT NULL DEFAULT 'pending'
        CONSTRAINT CK_ApprovalRows_RowStatus
        CHECK (RowStatus IN ('pending','approved','rejected')),
    RowCode               NVARCHAR(100) NULL,
    SnapshotData          NVARCHAR(MAX) NULL,
    RowModifiedAtSnapshot DATETIME2 NULL,
    CreatedAt             DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO

CREATE INDEX IX_ApprovalRows_RequestId   ON ApprovalRows(ApprovalRequestId);
CREATE INDEX IX_ApprovalRows_EntityRowId ON ApprovalRows(EntityRowId) WHERE EntityRowId IS NOT NULL;
GO

CREATE TABLE ApprovalReviews (
    Id                INT IDENTITY(1,1) CONSTRAINT PK_ApprovalReviews PRIMARY KEY,
    ApprovalRequestId INT NOT NULL REFERENCES ApprovalRequests(Id) ON DELETE CASCADE,
    ReviewedByUserId  INT NOT NULL REFERENCES Users(Id),
    ReviewedAt        DATETIME2 NOT NULL DEFAULT GETUTCDATE(),
    Decision          NVARCHAR(20) NOT NULL
        CONSTRAINT CK_ApprovalReviews_Decision
        CHECK (Decision IN ('approved','rejected','sent_back')),
    Comment           NVARCHAR(1000) NULL,
    FlaggedRowIds     NVARCHAR(MAX) NULL
);
GO

CREATE INDEX IX_ApprovalReviews_RequestId ON ApprovalReviews(ApprovalRequestId);
GO

-- ============================================
-- APPROVAL FLOW PROCEDURES
-- ============================================

SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE usp_Approval_CloseRequest
    @RequestId        INT,
    @ApprovedByUserId INT = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-25
-- Description: Internal helper. Called after a row decision is recorded.
--              Evaluates all ApprovalRows for the request and closes the
--              parent ApprovalRequest if no rows remain pending.
--              Mixed outcome (some approved, some rejected) resolves as approved.
--              When the request closes as 'approved', writes an AuditLog entry
--              with the submitter's note as the comment.
--
-- Change History:
--   v1.0  2026-02-25  Initial version
--   v1.1  2026-02-25  Write AuditLog entry on approval close
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @PendingCount  INT;
    DECLARE @ApprovedCount INT;
    DECLARE @RejectedCount INT;
    DECLARE @NewStatus     NVARCHAR(20);

    SELECT
        @PendingCount  = SUM(CASE WHEN RowStatus = 'pending'  THEN 1 ELSE 0 END),
        @ApprovedCount = SUM(CASE WHEN RowStatus = 'approved' THEN 1 ELSE 0 END),
        @RejectedCount = SUM(CASE WHEN RowStatus = 'rejected' THEN 1 ELSE 0 END)
    FROM ApprovalRows
    WHERE ApprovalRequestId = @RequestId;

    IF @PendingCount = 0
    BEGIN
        IF @RejectedCount = 0
            SET @NewStatus = 'approved';
        ELSE IF @ApprovedCount = 0
            SET @NewStatus = 'rejected';
        ELSE
            SET @NewStatus = 'approved'; -- mixed: approved with some rejections

        UPDATE ApprovalRequests
        SET Status = @NewStatus, ModifiedAt = GETUTCDATE()
        WHERE Id = @RequestId;

        -- Write audit log entry when request closes as approved
        IF @NewStatus = 'approved'
        BEGIN
            DECLARE @EntityId2      INT;
            DECLARE @EntityName2    NVARCHAR(200);
            DECLARE @ModelName2     NVARCHAR(200);
            DECLARE @SubmitterNote  NVARCHAR(1000);
            DECLARE @SubmittedBy    INT;
            DECLARE @LastReviewerId INT;

            SELECT
                @EntityId2     = ar.EntityId,
                @SubmitterNote = ar.SubmitterNote,
                @SubmittedBy   = ar.SubmittedByUserId
            FROM ApprovalRequests ar
            WHERE ar.Id = @RequestId;

            SELECT TOP 1 @LastReviewerId = ReviewedByUserId
            FROM ApprovalReviews
            WHERE ApprovalRequestId = @RequestId
              AND Decision IN ('approved')
            ORDER BY ReviewedAt DESC;

            SELECT
                @EntityName2 = e.Name,
                @ModelName2  = m.Name
            FROM Entities e
            JOIN Models m ON m.Id = e.ModelId
            WHERE e.Id = @EntityId2;

            -- Build Details JSON: array of approved rows with field-level old→new changes
            -- SnapshotData format: { "fieldName": { "label": "Display", "old": v, "new": v } }
            DECLARE @Details       NVARCHAR(MAX) = N'[';
            DECLARE @FirstRow      BIT = 1;
            DECLARE @DetRowCode    NVARCHAR(100);
            DECLARE @DetRowId      BIGINT;
            DECLARE @DetOperation  NVARCHAR(10);
            DECLARE @DetSnapshot   NVARCHAR(MAX);

            DECLARE det_cur CURSOR LOCAL FAST_FORWARD FOR
                SELECT RowCode, EntityRowId, Operation, SnapshotData
                FROM ApprovalRows
                WHERE ApprovalRequestId = @RequestId
                  AND RowStatus = 'approved';

            OPEN det_cur;
            FETCH NEXT FROM det_cur INTO @DetRowCode, @DetRowId, @DetOperation, @DetSnapshot;

            WHILE @@FETCH_STATUS = 0
            BEGIN
                IF @FirstRow = 0 SET @Details += N',';
                SET @FirstRow = 0;

                DECLARE @ChangesJson NVARCHAR(MAX) = N'[]';
                IF @DetSnapshot IS NOT NULL
                BEGIN
                    SELECT @ChangesJson = ISNULL((
                        SELECT
                            JSON_VALUE(s.value, '$.label') AS field,
                            JSON_VALUE(s.value, '$.old')   AS oldValue,
                            JSON_VALUE(s.value, '$.new')   AS newValue
                        FROM OPENJSON(@DetSnapshot) s
                        FOR JSON PATH, INCLUDE_NULL_VALUES
                    ), N'[]');
                END

                DECLARE @RowObj NVARCHAR(MAX);
                SELECT @RowObj = (
                    SELECT
                        @DetRowCode AS code,
                        @DetRowId   AS _savedId,
                        @DetOperation AS operation,
                        JSON_QUERY(@ChangesJson) AS changes
                    FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
                );
                SET @Details += @RowObj;

                FETCH NEXT FROM det_cur INTO @DetRowCode, @DetRowId, @DetOperation, @DetSnapshot;
            END;

            CLOSE det_cur;
            DEALLOCATE det_cur;
            SET @Details += N']';

            DECLARE @AuditUserId INT = ISNULL(@LastReviewerId, @SubmittedBy);
            EXEC usp_AuditLog_Write
                @EntityId    = @EntityId2,
                @EntityName  = @EntityName2,
                @ModelName   = @ModelName2,
                @Action      = 'approved',
                @RecordCount = @ApprovedCount,
                @UserId      = @AuditUserId,
                @Comment     = @SubmitterNote,
                @Details     = @Details;
        END
    END
END;
GO

CREATE OR ALTER PROCEDURE usp_Approval_Submit
    @EntityId          INT,
    @SubmittedByUserId INT,
    @SubmitterNote     NVARCHAR(1000),
    @RowsJson          NVARCHAR(MAX),
    @PreviousRequestId INT = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-25
-- Description: Creates a new ApprovalRequest for the given entity and
--              populates its ApprovalRows from a JSON array of row changes.
--              If @PreviousRequestId is supplied the prior request is cancelled
--              and the new request inherits an incremented Version.
--              Returns the Id of the newly created request.
--
-- Change History:
--   v1.0  2026-02-25  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        DECLARE @NewVersion    INT = 1;
        DECLARE @NewRequestId  INT;

        IF @PreviousRequestId IS NOT NULL
        BEGIN
            SELECT @NewVersion = Version + 1 FROM ApprovalRequests WHERE Id = @PreviousRequestId;
            UPDATE ApprovalRequests
            SET Status = 'cancelled', ModifiedAt = GETUTCDATE()
            WHERE Id = @PreviousRequestId;
        END

        INSERT INTO ApprovalRequests (EntityId, SubmittedByUserId, SubmitterNote, Version, PreviousRequestId)
        VALUES (@EntityId, @SubmittedByUserId, @SubmitterNote, @NewVersion, @PreviousRequestId);

        SET @NewRequestId = SCOPE_IDENTITY();

        INSERT INTO ApprovalRows (ApprovalRequestId, EntityRowId, Operation, RowCode, SnapshotData, RowModifiedAtSnapshot)
        SELECT
            @NewRequestId,
            NULLIF(r.entityRowId, 0),
            r.operation,
            r.rowCode,
            r.snapshotData,
            TRY_CAST(r.rowModifiedAtSnapshot AS DATETIME2)
        FROM OPENJSON(@RowsJson) WITH (
            entityRowId           BIGINT         '$.entityRowId',
            operation             NVARCHAR(10)   '$.operation',
            rowCode               NVARCHAR(100)  '$.rowCode',
            snapshotData          NVARCHAR(MAX)  '$.snapshotData' AS JSON,
            rowModifiedAtSnapshot NVARCHAR(50)   '$.rowModifiedAtSnapshot'
        ) r;

        -- Audit: log approval submission
        DECLARE @EntityName_Sub NVARCHAR(200);
        DECLARE @ModelName_Sub  NVARCHAR(200);
        DECLARE @RowCount_Sub   INT;
        SELECT @EntityName_Sub = e.Name, @ModelName_Sub = m.Name
        FROM Entities e JOIN Models m ON m.Id = e.ModelId WHERE e.Id = @EntityId;
        SELECT @RowCount_Sub = COUNT(*) FROM ApprovalRows WHERE ApprovalRequestId = @NewRequestId;
        INSERT INTO AuditLog (EntityId, EntityName, ModelName, Action, RecordCount, UserId, Comment, Details)
        VALUES (@EntityId, @EntityName_Sub, @ModelName_Sub, 'approval_submitted', @RowCount_Sub, @SubmittedByUserId, @SubmitterNote, NULL);

        COMMIT TRANSACTION;
        SELECT @NewRequestId AS Id;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Approval_GetPendingForApprover
    @UserId          INT,
    @IsAdministrator BIT = 0
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-25
-- Description: Returns all pending ApprovalRequests for entities where
--              @UserId is an assigned approver, with row-operation counts.
--              When @IsAdministrator = 1, returns ALL pending requests
--              regardless of entity assignment.
--              Ordered oldest-first so approvers work the queue in order.
--
-- Change History:
--   v1.0  2026-02-25  Initial version
--   v1.1  2026-02-26  Admin bypass: @IsAdministrator skips EntityApprovers filter
--   v1.2  2026-03-03  Add HasCurrentUserVoted for dashboard 'already voted' indicator
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        ar.Id,
        ar.EntityId,
        e.Name  AS EntityName,
        ar.SubmittedByUserId,
        u.DisplayName AS SubmitterName,
        ar.SubmittedAt,
        ar.Status,
        ar.Version,
        SUM(CASE WHEN row.Operation = 'insert' THEN 1 ELSE 0 END) AS CountNew,
        SUM(CASE WHEN row.Operation = 'update' THEN 1 ELSE 0 END) AS CountEdit,
        SUM(CASE WHEN row.Operation = 'delete' THEN 1 ELSE 0 END) AS CountDelete,
        -- HasCurrentUserVoted: 1 when current user has already cast an 'approved' vote
        -- (only relevant for strategy='all'; strategy='any' requests close immediately on first approval)
        MAX(CASE WHEN rev.ReviewedByUserId = @UserId AND rev.Decision = 'approved' THEN 1 ELSE 0 END) AS HasCurrentUserVoted
    FROM ApprovalRequests ar
    JOIN Entities e       ON e.Id  = ar.EntityId
    JOIN Users u          ON u.Id  = ar.SubmittedByUserId
    LEFT JOIN EntityApprovers ea ON ea.EntityId = ar.EntityId AND ea.UserId = @UserId
    LEFT JOIN ApprovalRows row ON row.ApprovalRequestId = ar.Id
    LEFT JOIN ApprovalReviews rev ON rev.ApprovalRequestId = ar.Id AND rev.Decision = 'approved'
    WHERE ar.Status = 'pending'
      AND (@IsAdministrator = 1 OR ea.UserId IS NOT NULL)
    GROUP BY ar.Id, ar.EntityId, e.Name, ar.SubmittedByUserId, u.DisplayName,
             ar.SubmittedAt, ar.Status, ar.Version
    ORDER BY ar.SubmittedAt ASC;
END;
GO

CREATE OR ALTER PROCEDURE usp_Approval_GetRecentForApprover
    @UserId          INT,
    @IsAdministrator BIT = 0
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-08
-- Description: Returns the 20 most recent ApprovalRequests (all statuses)
--              for entities where @UserId is an assigned approver.
--              When @IsAdministrator = 1, returns ALL requests regardless
--              of entity assignment. Ordered newest-first.
--
-- Change History:
--   v1.0  2026-03-08  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT TOP 20
        ar.Id,
        ar.EntityId,
        e.Name  AS EntityName,
        ar.SubmittedByUserId,
        u.DisplayName AS SubmitterName,
        ar.SubmittedAt,
        ar.Status,
        ar.Version,
        SUM(CASE WHEN row.Operation = 'insert' THEN 1 ELSE 0 END) AS CountNew,
        SUM(CASE WHEN row.Operation = 'update' THEN 1 ELSE 0 END) AS CountEdit,
        SUM(CASE WHEN row.Operation = 'delete' THEN 1 ELSE 0 END) AS CountDelete,
        MAX(CASE WHEN rev.ReviewedByUserId = @UserId AND rev.Decision = 'approved' THEN 1 ELSE 0 END) AS HasCurrentUserVoted
    FROM ApprovalRequests ar
    JOIN Entities e       ON e.Id  = ar.EntityId
    JOIN Users u          ON u.Id  = ar.SubmittedByUserId
    LEFT JOIN EntityApprovers ea ON ea.EntityId = ar.EntityId AND ea.UserId = @UserId
    LEFT JOIN ApprovalRows row ON row.ApprovalRequestId = ar.Id
    LEFT JOIN ApprovalReviews rev ON rev.ApprovalRequestId = ar.Id AND rev.Decision = 'approved'
    WHERE (@IsAdministrator = 1 OR ea.UserId IS NOT NULL)
    GROUP BY ar.Id, ar.EntityId, e.Name, ar.SubmittedByUserId, u.DisplayName,
             ar.SubmittedAt, ar.Status, ar.Version
    ORDER BY ar.SubmittedAt DESC;
END;
GO

CREATE OR ALTER PROCEDURE usp_Approval_GetMine
    @UserId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-25
-- Description: Returns all ApprovalRequests submitted by @UserId, with
--              row-operation counts and the most-recent reviewer decision.
--              Ordered newest-first so submitters see their latest work first.
--
-- Change History:
--   v1.0  2026-02-25  Initial version
--   v1.1  2026-03-03  Add LatestReviewedAt for "Approved on" column in UI
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        ar.Id,
        ar.EntityId,
        e.Name  AS EntityName,
        ar.SubmittedByUserId,
        u.DisplayName AS SubmitterName,
        ar.SubmittedAt,
        ar.Status,
        ar.Version,
        ar.SubmitterNote,
        SUM(CASE WHEN row.Operation = 'insert' THEN 1 ELSE 0 END) AS CountNew,
        SUM(CASE WHEN row.Operation = 'update' THEN 1 ELSE 0 END) AS CountEdit,
        SUM(CASE WHEN row.Operation = 'delete' THEN 1 ELSE 0 END) AS CountDelete,
        (SELECT TOP 1 rev.Decision
         FROM ApprovalReviews rev
         WHERE rev.ApprovalRequestId = ar.Id
         ORDER BY rev.ReviewedAt DESC) AS LatestDecision,
        (SELECT TOP 1 ru.DisplayName
         FROM ApprovalReviews rev
         JOIN Users ru ON ru.Id = rev.ReviewedByUserId
         WHERE rev.ApprovalRequestId = ar.Id
         ORDER BY rev.ReviewedAt DESC) AS LatestReviewerName,
        -- Date of the most recent review action (used as "Approved on" in the UI)
        (SELECT TOP 1 rev.ReviewedAt
         FROM ApprovalReviews rev
         WHERE rev.ApprovalRequestId = ar.Id
         ORDER BY rev.ReviewedAt DESC) AS LatestReviewedAt
    FROM ApprovalRequests ar
    JOIN Entities e ON e.Id = ar.EntityId
    JOIN Users u    ON u.Id = ar.SubmittedByUserId
    LEFT JOIN ApprovalRows row ON row.ApprovalRequestId = ar.Id
    WHERE ar.SubmittedByUserId = @UserId
    GROUP BY ar.Id, ar.EntityId, e.Name, ar.SubmittedByUserId, u.DisplayName,
             ar.SubmittedAt, ar.Status, ar.Version, ar.SubmitterNote
    ORDER BY ar.SubmittedAt DESC;
END;
GO

CREATE OR ALTER PROCEDURE usp_Approval_GetDetail
    @RequestId        INT,
    @RequestingUserId INT,
    @IsAdministrator  BIT = 0
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-25
-- Description: Returns full detail for a single ApprovalRequest: request
--              metadata (result set 1), all ApprovalRows with conflict
--              detection (result set 2), all ApprovalReviews (result set 3),
--              and approver vote status for strategy='all' UI (result set 4).
--              Access is restricted to the submitter or any assigned approver.
--              Administrators bypass the access check and can view all requests.
--
-- Change History:
--   v1.0  2026-02-25  Initial version
--   v1.1  2026-02-26  Admin bypass: @IsAdministrator skips the access check
--   v1.2  2026-03-03  Add ApprovalStrategy to RS1; add RS4 for vote status
--   v1.3  2026-03-03  RS4: count all approved reviews (not only EntityApprovers) to
--                     match gate logic in usp_Approval_ApproveAll
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- Authorization: must be submitter, assigned approver, or administrator
    IF @IsAdministrator = 0 AND NOT EXISTS (
        SELECT 1
        FROM ApprovalRequests ar
        LEFT JOIN EntityApprovers ea ON ea.EntityId = ar.EntityId AND ea.UserId = @RequestingUserId
        WHERE ar.Id = @RequestId
          AND (ar.SubmittedByUserId = @RequestingUserId OR ea.UserId IS NOT NULL)
    )
    BEGIN
        RAISERROR('Access denied: you are not the submitter or an approver for this request.', 16, 1);
        RETURN;
    END

    -- Result set 1: request header (includes ApprovalStrategy for multi-approver gate UI)
    SELECT
        ar.Id, ar.EntityId, e.Name AS EntityName,
        e.ApprovalStrategy,
        ar.SubmittedByUserId, u.DisplayName AS SubmitterName,
        ar.SubmittedAt, ar.Status, ar.Version,
        ar.SubmitterNote, ar.PreviousRequestId
    FROM ApprovalRequests ar
    JOIN Entities e ON e.Id = ar.EntityId
    JOIN Users u    ON u.Id = ar.SubmittedByUserId
    WHERE ar.Id = @RequestId;

    -- Result set 2: rows with conflict detection
    SELECT
        row.Id, row.ApprovalRequestId, row.EntityRowId,
        row.Operation, row.RowStatus, row.RowCode,
        row.SnapshotData, row.RowModifiedAtSnapshot,
        CASE
            WHEN row.EntityRowId IS NOT NULL
             AND row.RowModifiedAtSnapshot IS NOT NULL
             AND er.ModifiedAt > row.RowModifiedAtSnapshot
            THEN 1 ELSE 0
        END AS IsConflict
    FROM ApprovalRows row
    LEFT JOIN EntityRows er ON er.Id = row.EntityRowId
    WHERE row.ApprovalRequestId = @RequestId;

    -- Result set 3: reviews in chronological order
    SELECT
        rev.Id, rev.ReviewedByUserId, u.DisplayName AS ReviewerName,
        rev.ReviewedAt, rev.Decision, rev.Comment, rev.FlaggedRowIds
    FROM ApprovalReviews rev
    JOIN Users u ON u.Id = rev.ReviewedByUserId
    WHERE rev.ApprovalRequestId = @RequestId
    ORDER BY rev.ReviewedAt ASC;

    -- Result set 4: vote status for strategy='all' — how many approvers have voted
    -- TotalApprovers = assigned EntityApprovers count (the gate ceiling)
    -- VotedApproved  = all distinct users who cast 'approved' on this request,
    --                  including admins/non-EntityApprovers (matches gate check in
    --                  usp_Approval_ApproveAll which counts all approved reviews)
    -- HasCurrentUserVoted = 1 if @RequestingUserId has already cast an 'approved' vote
    DECLARE @EntityId2 INT;
    SELECT @EntityId2 = EntityId FROM ApprovalRequests WHERE Id = @RequestId;

    SELECT
        (SELECT COUNT(*) FROM EntityApprovers WHERE EntityId = @EntityId2)    AS TotalApprovers,
        (SELECT COUNT(DISTINCT ReviewedByUserId) FROM ApprovalReviews
         WHERE ApprovalRequestId = @RequestId AND Decision = 'approved')      AS VotedApproved,
        CAST(ISNULL((SELECT TOP 1 1 FROM ApprovalReviews
                     WHERE ApprovalRequestId = @RequestId
                       AND ReviewedByUserId   = @RequestingUserId
                       AND Decision           = 'approved'), 0) AS BIT)       AS HasCurrentUserVoted;
END;
GO

SET QUOTED_IDENTIFIER ON;
GO

CREATE OR ALTER PROCEDURE usp_Approval_AssertCanReview
    @RequestId       INT,
    @UserId          INT,
    @IsAdministrator BIT = 0
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-07-28
-- Description: Gate for every approval decision. Throws 'Access denied: ...' when the
--              user may not review this request; returns silently when they may.
--
--              Three rules, all of which the product documents but none of which was
--              enforced anywhere before: an approval could be granted by any signed-in
--              caller, for any entity, including on their own submission.
--
--                1. Administrators may always review.
--                2. Otherwise the user must be an assigned approver of the entity the
--                   request belongs to (EntityApprovers).
--                3. A user may not approve their own submission unless the entity sets
--                   ApproverCanApproveOwn.
--
--              Lives in the database rather than in the API so the rule holds for every
--              caller — routes, the external REST API, or a future integration.
--
-- Change History:
--   v1.0  2026-07-28  Initial version — closes the unauthorised-approval gap
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    IF @IsAdministrator = 1 RETURN;

    DECLARE @EntityId INT, @SubmittedBy INT, @CanApproveOwn BIT;

    SELECT @EntityId    = ar.EntityId,
           @SubmittedBy = ar.SubmittedByUserId
    FROM ApprovalRequests ar
    WHERE ar.Id = @RequestId;

    IF @EntityId IS NULL
        THROW 50003, 'Access denied: approval request not found.', 1;

    IF NOT EXISTS (SELECT 1 FROM EntityApprovers WHERE EntityId = @EntityId AND UserId = @UserId)
        THROW 50003, 'Access denied: you are not an approver for this entity.', 1;

    SELECT @CanApproveOwn = ApproverCanApproveOwn FROM Entities WHERE Id = @EntityId;

    IF @SubmittedBy = @UserId AND ISNULL(@CanApproveOwn, 0) = 0
        THROW 50003, 'Access denied: you cannot approve your own submission for this entity.', 1;
END;
GO

CREATE OR ALTER PROCEDURE usp_Approval_ApproveRow
    @ApprovalRowId    INT,
    @ApprovedByUserId INT,
    @IsAdministrator  BIT = 0
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-25
-- Description: Applies the change captured in a single ApprovalRow to the
--              live data and marks the row as approved. For insert operations,
--              auto-rejects if the code already exists. Calls
--              usp_Approval_CloseRequest after each decision to close the
--              parent request when all rows are resolved.
--
-- Change History:
--   v1.0  2026-02-25  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        DECLARE @Operation        NVARCHAR(10);
        DECLARE @EntityRowId      BIGINT;
        DECLARE @SnapshotData     NVARCHAR(MAX);
        DECLARE @RowCode          NVARCHAR(100);
        DECLARE @ApprovalRequestId INT;
        DECLARE @EntityId         INT;

        -- Authorize before touching anything. Reachable directly via the API, so the check
        -- cannot live only in the caller.
        DECLARE @ReqId INT = (SELECT ApprovalRequestId FROM ApprovalRows WHERE Id = @ApprovalRowId);
        EXEC usp_Approval_AssertCanReview @ReqId, @ApprovedByUserId, @IsAdministrator;

        SELECT
            @Operation         = row.Operation,
            @EntityRowId       = row.EntityRowId,
            @SnapshotData      = row.SnapshotData,
            @RowCode           = row.RowCode,
            @ApprovalRequestId = row.ApprovalRequestId,
            @EntityId          = ar.EntityId
        FROM ApprovalRows row
        JOIN ApprovalRequests ar ON ar.Id = row.ApprovalRequestId
        WHERE row.Id = @ApprovalRowId;

        IF @Operation = 'insert'
        BEGIN
            -- Auto-reject if code already exists for this entity
            IF EXISTS (SELECT 1 FROM EntityRows WHERE EntityId = @EntityId AND Code = @RowCode)
            BEGIN
                UPDATE ApprovalRows SET RowStatus = 'rejected' WHERE Id = @ApprovalRowId;
                EXEC usp_Approval_CloseRequest @ApprovalRequestId;
                COMMIT TRANSACTION;
                RETURN;
            END

            -- Insert new EntityRow using snapshot Name (falls back to RowCode if absent)
            DECLARE @NewRowId BIGINT;
            DECLARE @InsertName NVARCHAR(200) = ISNULL(
                JSON_VALUE(@SnapshotData, '$."name".new'), @RowCode);

            INSERT INTO EntityRows (EntityId, Code, Name, CreatedBy, ModifiedBy)
            VALUES (@EntityId, @RowCode, @InsertName, @ApprovedByUserId, @ApprovedByUserId);
            SET @NewRowId = SCOPE_IDENTITY();

            -- Insert EntityValues from SnapshotData
            -- SnapshotData is keyed by attribute Name; each entry has a "new" property
            INSERT INTO EntityValues (EntityRowId, AttributeId, TextValue, IntValue, DecimalValue, DateTimeValue)
            SELECT
                @NewRowId,
                a.Id,
                CASE WHEN a.DataType = 'Text'
                     THEN JSON_VALUE(@SnapshotData, CONCAT('$."', a.Name, '".new'))
                END,
                CASE WHEN a.DataType IN ('Int','Boolean','Domain')
                     THEN TRY_CAST(JSON_VALUE(@SnapshotData, CONCAT('$."', a.Name, '".new')) AS INT)
                END,
                CASE WHEN a.DataType = 'Decimal'
                     THEN TRY_CAST(JSON_VALUE(@SnapshotData, CONCAT('$."', a.Name, '".new')) AS DECIMAL(18,6))
                END,
                CASE WHEN a.DataType = 'DateTime'
                     THEN TRY_CAST(JSON_VALUE(@SnapshotData, CONCAT('$."', a.Name, '".new')) AS DATETIME2)
                END
            FROM Attributes a
            WHERE a.EntityId = @EntityId
              AND a.IsSystemDate = 0
              AND JSON_VALUE(@SnapshotData, CONCAT('$."', a.Name, '".new')) IS NOT NULL;
        END
        ELSE IF @Operation = 'update'
        BEGIN
            -- Update EntityValues for each attribute present in SnapshotData
            UPDATE ev
            SET
                ev.TextValue     = CASE WHEN a.DataType = 'Text'
                                        THEN JSON_VALUE(@SnapshotData, CONCAT('$."', a.Name, '".new'))
                                        ELSE ev.TextValue END,
                ev.IntValue      = CASE WHEN a.DataType IN ('Int','Boolean','Domain')
                                        THEN TRY_CAST(JSON_VALUE(@SnapshotData, CONCAT('$."', a.Name, '".new')) AS INT)
                                        ELSE ev.IntValue END,
                ev.DecimalValue  = CASE WHEN a.DataType = 'Decimal'
                                        THEN TRY_CAST(JSON_VALUE(@SnapshotData, CONCAT('$."', a.Name, '".new')) AS DECIMAL(18,6))
                                        ELSE ev.DecimalValue END,
                ev.DateTimeValue = CASE WHEN a.DataType = 'DateTime'
                                        THEN TRY_CAST(JSON_VALUE(@SnapshotData, CONCAT('$."', a.Name, '".new')) AS DATETIME2)
                                        ELSE ev.DateTimeValue END
            FROM EntityValues ev
            JOIN Attributes a ON a.Id = ev.AttributeId
            WHERE ev.EntityRowId = @EntityRowId
              AND a.IsSystemDate = 0
              AND JSON_VALUE(@SnapshotData, CONCAT('$."', a.Name, '".new')) IS NOT NULL;

            -- Promote EntityRows system fields (Name, Code) and audit columns
            UPDATE EntityRows
            SET
                Name       = CASE WHEN JSON_VALUE(@SnapshotData, '$."name".new') IS NOT NULL
                                  THEN JSON_VALUE(@SnapshotData, '$."name".new')
                                  ELSE Name END,
                Code       = CASE WHEN JSON_VALUE(@SnapshotData, '$."code".new') IS NOT NULL
                                  THEN JSON_VALUE(@SnapshotData, '$."code".new')
                                  ELSE Code END,
                ModifiedBy = @ApprovedByUserId,
                ModifiedAt = GETUTCDATE()
            WHERE Id = @EntityRowId;
        END
        ELSE IF @Operation = 'delete'
        BEGIN
            -- Clear FK references in other approval rows before deleting the live row
            UPDATE ApprovalRows SET EntityRowId = NULL WHERE EntityRowId = @EntityRowId AND Id <> @ApprovalRowId;
            DELETE FROM EntityValues WHERE EntityRowId = @EntityRowId;
            DELETE FROM EntityRows  WHERE Id = @EntityRowId;
        END

        UPDATE ApprovalRows SET RowStatus = 'approved' WHERE Id = @ApprovalRowId;
        EXEC usp_Approval_CloseRequest @ApprovalRequestId, @ApprovedByUserId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Approval_RejectRow
    @ApprovalRowId    INT,
    @ReviewedByUserId INT = NULL,
    @IsAdministrator  BIT = 0
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-25
-- Description: Marks a single ApprovalRow as rejected without touching live
--              data, then calls usp_Approval_CloseRequest to resolve the
--              parent request if all rows are now decided.
--
-- Change History:
--   v1.0  2026-02-25  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        -- Authorize before doing anything (see usp_Approval_AssertCanReview).
        DECLARE @ReqIdRR INT = (SELECT ApprovalRequestId FROM ApprovalRows WHERE Id = @ApprovalRowId);
        EXEC usp_Approval_AssertCanReview @ReqIdRR, @ReviewedByUserId, @IsAdministrator;

        DECLARE @ApprovalRequestId INT;
        SELECT @ApprovalRequestId = ApprovalRequestId FROM ApprovalRows WHERE Id = @ApprovalRowId;

        UPDATE ApprovalRows SET RowStatus = 'rejected' WHERE Id = @ApprovalRowId;
        EXEC usp_Approval_CloseRequest @ApprovalRequestId;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Approval_ApproveAll
    @RequestId        INT,
    @ApprovedByUserId INT,
    @Comment          NVARCHAR(1000) = NULL,
    @IsAdministrator  BIT = 0
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-25
-- Description: Approves all pending rows in a request by iterating a cursor
--              and calling usp_Approval_ApproveRow for each. Records a
--              top-level 'approved' review entry with an optional comment.
--
--              When ApprovalStrategy = 'all', each approver's click records a
--              vote in ApprovalReviews but does NOT apply changes until ALL
--              assigned approvers have voted 'approved'. Any single rejection
--              immediately closes the request as rejected.
--
-- Change History:
--   v1.0  2026-02-25  Initial version
--   v1.1  2026-03-03  Multi-approver gate: vote-first, apply-last for strategy='all'
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        -- Authorize before doing anything (see usp_Approval_AssertCanReview).
        EXEC usp_Approval_AssertCanReview @RequestId, @ApprovedByUserId, @IsAdministrator;

        -- Determine entity strategy and approver counts
        DECLARE @Strategy       NVARCHAR(20);
        DECLARE @EntityId       INT;
        DECLARE @TotalApprovers INT;
        DECLARE @VotedApproved  INT;

        SELECT @EntityId = ar.EntityId, @Strategy = e.ApprovalStrategy
        FROM ApprovalRequests ar
        JOIN Entities e ON e.Id = ar.EntityId
        WHERE ar.Id = @RequestId;

        SELECT @TotalApprovers = COUNT(*) FROM EntityApprovers WHERE EntityId = @EntityId;

        -- Guard: reject the call if no approvers are assigned (misconfigured entity)
        IF @TotalApprovers = 0
        BEGIN
            ROLLBACK TRANSACTION;
            THROW 50001, 'No approvers are assigned to this entity.', 1;
        END

        -- Guard: idempotent — do nothing if this user has already voted 'approved'
        IF EXISTS (
            SELECT 1 FROM ApprovalReviews
            WHERE ApprovalRequestId = @RequestId
              AND ReviewedByUserId  = @ApprovedByUserId
              AND Decision          = 'approved'
        )
        BEGIN
            COMMIT TRANSACTION;
            SELECT 'already_voted' AS Outcome;
            RETURN;
        END

        -- Count approvers who have already cast an 'approved' vote on this request
        SELECT @VotedApproved = COUNT(DISTINCT rev.ReviewedByUserId)
        FROM ApprovalReviews rev
        WHERE rev.ApprovalRequestId = @RequestId AND rev.Decision = 'approved';

        -- strategy='all': gate — only apply if this is the final required vote
        IF @Strategy = 'all' AND (@VotedApproved + 1) < @TotalApprovers
        BEGIN
            -- Record this vote without applying changes; request stays pending
            INSERT INTO ApprovalReviews (ApprovalRequestId, ReviewedByUserId, Decision, Comment)
            VALUES (@RequestId, @ApprovedByUserId, 'approved', @Comment);

            COMMIT TRANSACTION;
            SELECT 'voted' AS Outcome;
            RETURN;
        END

        -- Either strategy='any', or this is the last required vote for strategy='all':
        -- apply all pending rows and close the request
        DECLARE @RowId INT;
        DECLARE cur CURSOR FOR
            SELECT Id FROM ApprovalRows
            WHERE ApprovalRequestId = @RequestId AND RowStatus = 'pending';

        OPEN cur;
        FETCH NEXT FROM cur INTO @RowId;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            EXEC usp_Approval_ApproveRow @RowId, @ApprovedByUserId, @IsAdministrator;
            FETCH NEXT FROM cur INTO @RowId;
        END
        CLOSE cur;
        DEALLOCATE cur;

        INSERT INTO ApprovalReviews (ApprovalRequestId, ReviewedByUserId, Decision, Comment)
        VALUES (@RequestId, @ApprovedByUserId, 'approved', @Comment);

        COMMIT TRANSACTION;
        SELECT 'applied' AS Outcome;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- Migration: extend CK_AuditLog_Action to include approval action types + API action types.
-- Drop and recreate unconditionally so the value list is always current.
IF EXISTS (
    SELECT 1 FROM sys.check_constraints
    WHERE parent_object_id = OBJECT_ID('AuditLog')
      AND name = 'CK_AuditLog_Action'
)
BEGIN
    ALTER TABLE AuditLog DROP CONSTRAINT CK_AuditLog_Action;
    ALTER TABLE AuditLog ADD CONSTRAINT CK_AuditLog_Action CHECK (Action IN (
        'create','edit','delete','import','create/edit','purge',
        'login_success','login_failed','account_locked','logout',
        'first_user_setup','user_created','user_updated','user_deleted',
        'admin_password_reset','welcome_email_sent',
        'password_changed','password_forced_change',
        'permission_change','DataTypeChange',
        'approved','force_approved',
        'approval_submitted','approval_rejected','approval_sent_back',
        'api_user_created','api_user_updated','api_user_deleted',
        'api_key_regenerated','api_access_enabled','api_access_disabled'
    ));
END
GO

CREATE OR ALTER PROCEDURE usp_Approval_ForceApprove
    @RequestId        INT,
    @ApprovedByUserId INT,
    @Comment          NVARCHAR(1000) = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-03
-- Description: Administrator override that approves an approval request
--              immediately, regardless of ApprovalStrategy or how many
--              approvers have already voted. Applies all pending rows,
--              sets status to 'approved', records a review entry, and
--              writes a 'force_approved' entry to AuditLog so the override
--              is always visible in the audit trail.
--
-- Change History:
--   v1.0  2026-03-03  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @OwnTransaction BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRANSACTION; SET @OwnTransaction = 1; END

    BEGIN TRY
        -- Validate the request exists and is still pending
        DECLARE @EntityId INT;
        SELECT @EntityId = EntityId
        FROM ApprovalRequests
        WHERE Id = @RequestId AND Status = 'pending';

        IF @EntityId IS NULL
        BEGIN
            IF @OwnTransaction = 1 ROLLBACK TRANSACTION;
            THROW 50002, 'Approval request not found or is not pending.', 1;
        END

        -- Apply all pending rows (same pattern as usp_Approval_ApproveAll)
        DECLARE @RowId INT;
        DECLARE cur CURSOR LOCAL FAST_FORWARD FOR
            SELECT Id FROM ApprovalRows
            WHERE ApprovalRequestId = @RequestId AND RowStatus = 'pending';

        OPEN cur;
        FETCH NEXT FROM cur INTO @RowId;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            EXEC usp_Approval_ApproveRow @RowId, @ApprovedByUserId, 1;
            FETCH NEXT FROM cur INTO @RowId;
        END
        CLOSE cur;
        DEALLOCATE cur;

        -- Build the full comment so the force approval is always visible in review history
        DECLARE @FullComment NVARCHAR(1000) =
            CASE WHEN @Comment IS NOT NULL AND LEN(LTRIM(@Comment)) > 0
                 THEN N'[Force approved by administrator] ' + @Comment
                 ELSE N'[Force approved by administrator]'
            END;

        -- Record the review decision
        INSERT INTO ApprovalReviews (ApprovalRequestId, ReviewedByUserId, Decision, Comment)
        VALUES (@RequestId, @ApprovedByUserId, 'approved', @FullComment);

        -- Write an additional AuditLog entry with action='force_approved' so the override
        -- is clearly visible separately from the standard 'approved' entry written by CloseRequest
        DECLARE @EntityName NVARCHAR(200);
        DECLARE @ModelName  NVARCHAR(200);
        SELECT @EntityName = e.Name, @ModelName = m.Name
        FROM Entities e
        JOIN Models m ON m.Id = e.ModelId
        WHERE e.Id = @EntityId;

        DECLARE @AuditDetails NVARCHAR(MAX);
        SELECT @AuditDetails = (
            SELECT @RequestId AS requestId, @FullComment AS comment
            FOR JSON PATH, WITHOUT_ARRAY_WRAPPER
        );

        INSERT INTO AuditLog (EntityId, EntityName, ModelName, Action, RecordCount, UserId, Comment, Details)
        VALUES (@EntityId, @EntityName, @ModelName, N'force_approved', 1, @ApprovedByUserId, @FullComment, @AuditDetails);

        IF @OwnTransaction = 1 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @OwnTransaction = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Approval_SendBack
    @RequestId        INT,
    @ReviewedByUserId INT,
    @Comment          NVARCHAR(1000),
    @IsAdministrator  BIT = 0
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-25
-- Description: Returns a request to the submitter for revision. Sets the
--              request status to 'sent_back' and all pending rows to
--              'rejected', and records a 'sent_back' review entry.
--              No live data is modified.
--
-- Change History:
--   v1.0  2026-02-25  Initial version
--   v1.1  2026-02-26  Status now correctly set to 'sent_back' (was 'rejected')
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        -- Authorize before doing anything (see usp_Approval_AssertCanReview).
        EXEC usp_Approval_AssertCanReview @RequestId, @ReviewedByUserId, @IsAdministrator;

        UPDATE ApprovalRequests
        SET Status = 'sent_back', ModifiedAt = GETUTCDATE()
        WHERE Id = @RequestId;

        UPDATE ApprovalRows
        SET RowStatus = 'rejected'
        WHERE ApprovalRequestId = @RequestId AND RowStatus = 'pending';

        INSERT INTO ApprovalReviews (ApprovalRequestId, ReviewedByUserId, Decision, Comment)
        VALUES (@RequestId, @ReviewedByUserId, 'sent_back', @Comment);

        -- Audit: log approval sent back
        DECLARE @EntityId_SB   INT;
        DECLARE @EntityName_SB NVARCHAR(200);
        DECLARE @ModelName_SB  NVARCHAR(200);
        DECLARE @RowCount_SB   INT;
        SELECT @EntityId_SB = EntityId FROM ApprovalRequests WHERE Id = @RequestId;
        SELECT @EntityName_SB = e.Name, @ModelName_SB = m.Name
        FROM Entities e JOIN Models m ON m.Id = e.ModelId WHERE e.Id = @EntityId_SB;
        SELECT @RowCount_SB = COUNT(*) FROM ApprovalRows WHERE ApprovalRequestId = @RequestId;
        INSERT INTO AuditLog (EntityId, EntityName, ModelName, Action, RecordCount, UserId, Comment, Details)
        VALUES (@EntityId_SB, @EntityName_SB, @ModelName_SB, 'approval_sent_back', @RowCount_SB, @ReviewedByUserId, @Comment, NULL);

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Approval_Reject
    @RequestId        INT,
    @ReviewedByUserId INT,
    @Comment          NVARCHAR(1000),
    @IsAdministrator  BIT = 0
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-25
-- Description: Outright rejects a request. Sets the request and all pending
--              rows to 'rejected', and records a 'rejected' review entry.
--              No live data is modified.
--
-- Change History:
--   v1.0  2026-02-25  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRANSACTION;
    BEGIN TRY
        -- Authorize before doing anything (see usp_Approval_AssertCanReview).
        EXEC usp_Approval_AssertCanReview @RequestId, @ReviewedByUserId, @IsAdministrator;

        UPDATE ApprovalRequests
        SET Status = 'rejected', ModifiedAt = GETUTCDATE()
        WHERE Id = @RequestId;

        UPDATE ApprovalRows
        SET RowStatus = 'rejected'
        WHERE ApprovalRequestId = @RequestId AND RowStatus = 'pending';

        INSERT INTO ApprovalReviews (ApprovalRequestId, ReviewedByUserId, Decision, Comment)
        VALUES (@RequestId, @ReviewedByUserId, 'rejected', @Comment);

        -- Audit: log approval rejection
        DECLARE @EntityId_Rjct   INT;
        DECLARE @EntityName_Rjct NVARCHAR(200);
        DECLARE @ModelName_Rjct  NVARCHAR(200);
        DECLARE @RowCount_Rjct   INT;
        SELECT @EntityId_Rjct = EntityId FROM ApprovalRequests WHERE Id = @RequestId;
        SELECT @EntityName_Rjct = e.Name, @ModelName_Rjct = m.Name
        FROM Entities e JOIN Models m ON m.Id = e.ModelId WHERE e.Id = @EntityId_Rjct;
        SELECT @RowCount_Rjct = COUNT(*) FROM ApprovalRows WHERE ApprovalRequestId = @RequestId;
        INSERT INTO AuditLog (EntityId, EntityName, ModelName, Action, RecordCount, UserId, Comment, Details)
        VALUES (@EntityId_Rjct, @EntityName_Rjct, @ModelName_Rjct, 'approval_rejected', @RowCount_Rjct, @ReviewedByUserId, @Comment, NULL);

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Approval_GetPendingCount
    @UserId          INT,
    @IsAdministrator BIT = 0
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-25
-- Description: Returns counts for the nav-bar badge:
--              PendingForMe - requests waiting for @UserId to review.
--              MyApproved   - submissions by @UserId that were approved.
--              MyRejected   - submissions by @UserId that were rejected or sent back.
--              Separated so the frontend can show distinct bell colors per outcome.
--              When @IsAdministrator = 1, PendingForMe counts ALL pending requests
--              (matches the admin bypass in usp_Approval_GetPendingForApprover).
--
-- Change History:
--   v1.0  2026-02-25  Initial version
--   v1.1  2026-02-27  Include 'sent_back' in MyDecisions status filter
--   v1.2  2026-03-03  Split MyDecisions into MyApproved + MyRejected for color-coded bell
--   v1.3  2026-03-03  Add @IsAdministrator bypass so admins get correct PendingForMe count
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        -- Pending approvals needing this user's action.
        -- Admins see all pending requests; approvers see only their assigned entities.
        (SELECT COUNT(*)
         FROM ApprovalRequests ar
         LEFT JOIN EntityApprovers ea ON ea.EntityId = ar.EntityId AND ea.UserId = @UserId
         WHERE ar.Status = 'pending'
           AND (@IsAdministrator = 1 OR ea.UserId IS NOT NULL)) AS PendingForMe,

        -- Submissions this user made that were approved
        (SELECT COUNT(DISTINCT ar.Id)
         FROM ApprovalRequests ar
         JOIN ApprovalReviews rev ON rev.ApprovalRequestId = ar.Id
         WHERE ar.SubmittedByUserId = @UserId
           AND ar.Status = 'approved'
           AND rev.ReviewedAt > ar.SubmittedAt) AS MyApproved,

        -- Submissions this user made that were rejected or sent back
        (SELECT COUNT(DISTINCT ar.Id)
         FROM ApprovalRequests ar
         JOIN ApprovalReviews rev ON rev.ApprovalRequestId = ar.Id
         WHERE ar.SubmittedByUserId = @UserId
           AND ar.Status IN ('rejected','sent_back')
           AND rev.ReviewedAt > ar.SubmittedAt) AS MyRejected;
END;
GO

CREATE OR ALTER PROCEDURE usp_Entity_CheckSchemaLock
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-02-25
-- Description: Raises an error if the entity has any pending approval
--              requests. Called before schema-mutating operations (adding/
--              removing/reordering attributes) to prevent structural changes
--              while in-flight data changes are awaiting review.
--
-- Change History:
--   v1.0  2026-02-25  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Count INT;
    SELECT @Count = COUNT(*) FROM ApprovalRequests WHERE EntityId = @EntityId AND Status = 'pending';
    IF @Count > 0
        RAISERROR('Cannot modify schema while pending approvals exist for entity %d. Approve or reject them first.', 16, 1, @EntityId);
END;
GO

CREATE OR ALTER PROCEDURE usp_Entity_Clone
    @SourceEntityId  INT,
    @NewName         NVARCHAR(200),
    @CloneData       BIT = 1,
    @ClonePermissions BIT = 0,
    @UserId          INT = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-01
-- Description: Clones an entity (structure + optionally data + optionally
--              permissions). Clones Attributes (with DomainParentAttributeId
--              remapping for intra-entity references), EntityDerivedColumns,
--              EntityApprovers, optionally EntityRows + EntityValues (with
--              self-referencing DomainValue remapping), and optionally
--              entity-level Permissions.
--              Returns three result sets:
--                RS1 - New Entities row
--                RS2 - New entity's Attributes
--                RS3 - Stats (RowsCopied, PermissionsCopied)
--
-- Change History:
--   v1.0  2026-03-01  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRANSACTION;
    BEGIN TRY

        -- ----------------------------------------
        -- 1. Validate source entity
        -- ----------------------------------------
        IF NOT EXISTS (SELECT 1 FROM Entities WHERE Id = @SourceEntityId)
        BEGIN
            RAISERROR('Source entity %d does not exist.', 16, 1, @SourceEntityId);
            RETURN;
        END

        -- ----------------------------------------
        -- 2. Create new Entities row
        -- ----------------------------------------
        DECLARE @NewEntityId INT;
        DECLARE @NewSortOrder INT;

        SELECT @NewSortOrder = COALESCE(MAX(SortOrder), 0) + 1
        FROM   Entities
        WHERE  ModelId = (SELECT ModelId FROM Entities WHERE Id = @SourceEntityId);

        INSERT INTO Entities
            (ModelId, Name, Description, TableName, SortOrder, IsActive,
             RequiresApproval, SharedAcrossModels, AutoGenerateCode,
             ApproverCanApproveOwn, ApprovalStrategy, CreatedAt, ModifiedAt)
        SELECT
            ModelId,
            @NewName,
            Description,
            REPLACE(@NewName, ' ', '_'),
            @NewSortOrder,
            IsActive,
            RequiresApproval,
            SharedAcrossModels,
            AutoGenerateCode,
            ApproverCanApproveOwn,
            ApprovalStrategy,
            GETUTCDATE(),
            GETUTCDATE()
        FROM Entities
        WHERE Id = @SourceEntityId;

        SET @NewEntityId = SCOPE_IDENTITY();

        -- ----------------------------------------
        -- 3. Clone Attributes (cursor to capture each new Id)
        -- ----------------------------------------
        CREATE TABLE #AttrMap (OldId INT, NewId INT);

        DECLARE @OldAttrId        INT;
        DECLARE @DisplayName      NVARCHAR(200);
        DECLARE @AttrName         NVARCHAR(128);
        DECLARE @DataType         NVARCHAR(20);
        DECLARE @MaxLength        INT;
        DECLARE @IsRequired       BIT;
        DECLARE @IsCode           BIT;
        DECLARE @IsName           BIT;
        DECLARE @IsHidden         BIT;
        DECLARE @IsSystemDate     BIT;
        DECLARE @SortOrder        INT;
        DECLARE @DomainEntityId   INT;
        DECLARE @DomainParentAttrId INT;
        DECLARE @AttrDescription  NVARCHAR(500);
        DECLARE @DateFormat       NVARCHAR(20);
        DECLARE @BoolDisplayFmt   NVARCHAR(20);
        DECLARE @DecimalPlaces    INT;
        DECLARE @AllowNegative    BIT;
        DECLARE @NewAttrId        INT;

        DECLARE attr_cursor CURSOR LOCAL FAST_FORWARD FOR
            SELECT Id, DisplayName, Name, DataType, MaxLength,
                   IsRequired, IsCode, IsName, IsHidden, IsSystemDate,
                   SortOrder, DomainEntityId, DomainParentAttributeId,
                   Description, DateFormat, BooleanDisplayFormat,
                   DecimalPlaces, AllowNegative
            FROM   Attributes
            WHERE  EntityId = @SourceEntityId
            ORDER BY SortOrder;

        OPEN attr_cursor;
        FETCH NEXT FROM attr_cursor INTO
            @OldAttrId, @DisplayName, @AttrName, @DataType, @MaxLength,
            @IsRequired, @IsCode, @IsName, @IsHidden, @IsSystemDate,
            @SortOrder, @DomainEntityId, @DomainParentAttrId,
            @AttrDescription, @DateFormat, @BoolDisplayFmt,
            @DecimalPlaces, @AllowNegative;

        WHILE @@FETCH_STATUS = 0
        BEGIN
            INSERT INTO Attributes
                (EntityId, DisplayName, Name, DataType, MaxLength,
                 IsRequired, IsCode, IsName, IsHidden, IsSystemDate,
                 SortOrder, DomainEntityId, DomainParentAttributeId,
                 Description, DateFormat, BooleanDisplayFormat,
                 DecimalPlaces, AllowNegative, CreatedAt, ModifiedAt)
            VALUES
                (@NewEntityId, @DisplayName, @AttrName, @DataType, @MaxLength,
                 @IsRequired, @IsCode, @IsName, @IsHidden, @IsSystemDate,
                 @SortOrder, @DomainEntityId, @DomainParentAttrId,
                 @AttrDescription, @DateFormat, @BoolDisplayFmt,
                 @DecimalPlaces, @AllowNegative, GETUTCDATE(), GETUTCDATE());

            SET @NewAttrId = SCOPE_IDENTITY();
            INSERT INTO #AttrMap (OldId, NewId) VALUES (@OldAttrId, @NewAttrId);

            FETCH NEXT FROM attr_cursor INTO
                @OldAttrId, @DisplayName, @AttrName, @DataType, @MaxLength,
                @IsRequired, @IsCode, @IsName, @IsHidden, @IsSystemDate,
                @SortOrder, @DomainEntityId, @DomainParentAttrId,
                @AttrDescription, @DateFormat, @BoolDisplayFmt,
                @DecimalPlaces, @AllowNegative;
        END

        CLOSE attr_cursor;
        DEALLOCATE attr_cursor;

        -- ----------------------------------------
        -- 4. Remap DomainParentAttributeId for intra-entity references
        -- ----------------------------------------
        UPDATE a
        SET    a.DomainParentAttributeId = am.NewId,
               a.ModifiedAt = GETUTCDATE()
        FROM   Attributes a
        INNER JOIN #AttrMap am ON am.OldId = a.DomainParentAttributeId
        WHERE  a.EntityId = @NewEntityId;

        -- ----------------------------------------
        -- 5. Clone EntityDerivedColumns
        -- ----------------------------------------
        INSERT INTO EntityDerivedColumns (EntityId, DisplayName, AttributePath, SortOrder, CreatedAt)
        SELECT @NewEntityId, DisplayName, AttributePath, SortOrder, GETUTCDATE()
        FROM   EntityDerivedColumns
        WHERE  EntityId = @SourceEntityId;

        -- ----------------------------------------
        -- 6. Clone EntityApprovers
        -- ----------------------------------------
        INSERT INTO EntityApprovers (EntityId, UserId, CreatedAt)
        SELECT @NewEntityId, UserId, GETUTCDATE()
        FROM   EntityApprovers
        WHERE  EntityId = @SourceEntityId;

        -- ----------------------------------------
        -- 7. Clone rows + values (optional)
        -- ----------------------------------------
        DECLARE @RowsCopied INT = 0;

        IF @CloneData = 1
        BEGIN
            CREATE TABLE #RowMap (OldRowId BIGINT, NewRowId BIGINT);

            MERGE INTO EntityRows AS target
            USING (
                SELECT Id, Code, Name
                FROM   EntityRows
                WHERE  EntityId = @SourceEntityId
            ) AS source
            ON 1 = 0   -- never match; always insert
            WHEN NOT MATCHED THEN
                INSERT (EntityId, Code, Name, CreatedAt, ModifiedAt, CreatedBy, ModifiedBy)
                VALUES (@NewEntityId, source.Code, source.Name,
                        GETUTCDATE(), GETUTCDATE(), @UserId, @UserId)
            OUTPUT source.Id, inserted.Id INTO #RowMap (OldRowId, NewRowId);

            SET @RowsCopied = @@ROWCOUNT;

            -- Clone EntityValues, remapping row IDs, attribute IDs, and
            -- self-referencing DomainValues
            INSERT INTO EntityValues
                (EntityRowId, AttributeId, TextValue, IntValue,
                 DecimalValue, DateTimeValue, DomainValue)
            SELECT
                rm.NewRowId,
                am.NewId,
                ev.TextValue,
                ev.IntValue,
                ev.DecimalValue,
                ev.DateTimeValue,
                CASE
                    WHEN ev.DomainValue IS NOT NULL AND rm2.NewRowId IS NOT NULL
                        THEN rm2.NewRowId   -- self-referencing row: remap
                    ELSE ev.DomainValue     -- external ref or NULL: keep as-is
                END
            FROM   EntityValues ev
            INNER JOIN #RowMap  rm  ON rm.OldRowId  = ev.EntityRowId
            INNER JOIN #AttrMap am  ON am.OldId     = ev.AttributeId
            LEFT  JOIN #RowMap  rm2 ON rm2.OldRowId = ev.DomainValue;
        END

        -- ----------------------------------------
        -- 8. Clone entity-level permissions (optional)
        -- ----------------------------------------
        DECLARE @PermsCopied INT = 0;

        IF @ClonePermissions = 1
        BEGIN
            INSERT INTO Permissions
                (RoleId, Scope, TargetId, Level,
                 CanCreate, CanRead, CanUpdate, CanDelete,
                 IsModerator, IsExplicit, CreatedAt, ModifiedAt)
            SELECT
                RoleId, Scope, @NewEntityId, Level,
                CanCreate, CanRead, CanUpdate, CanDelete,
                IsModerator, IsExplicit, GETUTCDATE(), GETUTCDATE()
            FROM   Permissions
            WHERE  Scope    = 'entity'
              AND  TargetId = @SourceEntityId;

            SET @PermsCopied = @@ROWCOUNT;
        END

        COMMIT TRANSACTION;

        -- ----------------------------------------
        -- RS1: New entity row
        -- ----------------------------------------
        SELECT Id, ModelId, Name, Description, TableName, SortOrder, IsActive,
               RequiresApproval, ApproverCanApproveOwn, ApprovalStrategy,
               SharedAcrossModels, AutoGenerateCode, CreatedAt, ModifiedAt
        FROM   Entities
        WHERE  Id = @NewEntityId;

        -- ----------------------------------------
        -- RS2: New entity's attributes
        -- ----------------------------------------
        SELECT Id, EntityId, DisplayName, Name, DataType, MaxLength,
               IsRequired, IsCode, IsName, IsHidden, IsSystemDate, SortOrder,
               DomainEntityId, DomainParentAttributeId, DateFormat,
               BooleanDisplayFormat, DecimalPlaces, AllowNegative,
               Description, CreatedAt, ModifiedAt
        FROM   Attributes
        WHERE  EntityId = @NewEntityId
        ORDER BY SortOrder;

        -- ----------------------------------------
        -- RS3: Stats
        -- ----------------------------------------
        SELECT @RowsCopied AS RowsCopied, @PermsCopied AS PermissionsCopied;

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Entity_CloneDataBatch
    @SourceEntityId  INT,
    @NewEntityId     INT,
    @LastSourceRowId BIGINT = 0,
    @BatchSize       INT = 5000,
    @UserId          INT = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-01
-- Description: Clones a batch of EntityRows + EntityValues from source
--              to target entity. Called in a loop by the API for progress
--              tracking. Builds attribute mapping internally by joining
--              on Name (attributes must already be cloned). DomainValue
--              is copied as-is; self-references are fixed afterwards by
--              usp_Entity_CloneFixDomainRefs.
--
-- Change History:
--   v1.0  2026-03-01  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- Build attribute mapping by matching on Name
    CREATE TABLE #AttrMap (OldId INT, NewId INT);
    INSERT INTO #AttrMap (OldId, NewId)
    SELECT src.Id, tgt.Id
    FROM   Attributes src
    INNER JOIN Attributes tgt ON tgt.EntityId = @NewEntityId AND tgt.Name = src.Name
    WHERE  src.EntityId = @SourceEntityId;

    -- Clone batch of rows using MERGE/OUTPUT to capture ID mapping
    CREATE TABLE #RowMap (OldRowId BIGINT, NewRowId BIGINT);

    MERGE INTO EntityRows AS target
    USING (
        SELECT TOP (@BatchSize) Id, Code, Name
        FROM   EntityRows
        WHERE  EntityId = @SourceEntityId AND Id > @LastSourceRowId
        ORDER BY Id
    ) AS source
    ON 1 = 0
    WHEN NOT MATCHED THEN
        INSERT (EntityId, Code, Name, CreatedAt, ModifiedAt, CreatedBy, ModifiedBy)
        VALUES (@NewEntityId, source.Code, source.Name,
                GETUTCDATE(), GETUTCDATE(), @UserId, @UserId)
    OUTPUT source.Id, inserted.Id INTO #RowMap (OldRowId, NewRowId);

    DECLARE @BatchCopied INT = @@ROWCOUNT;

    -- Clone EntityValues for this batch (DomainValue copied as-is for now)
    IF @BatchCopied > 0
    BEGIN
        INSERT INTO EntityValues (EntityRowId, AttributeId, TextValue, IntValue,
                                  DecimalValue, DateTimeValue, DomainValue)
        SELECT rm.NewRowId, am.NewId,
               ev.TextValue, ev.IntValue, ev.DecimalValue, ev.DateTimeValue,
               ev.DomainValue
        FROM   EntityValues ev
        INNER JOIN #RowMap  rm ON rm.OldRowId = ev.EntityRowId
        INNER JOIN #AttrMap am ON am.OldId    = ev.AttributeId;
    END

    -- Return stats
    SELECT @BatchCopied AS RowsCopied,
           COALESCE((SELECT MAX(OldRowId) FROM #RowMap), @LastSourceRowId) AS LastSourceRowId;
END;
GO

CREATE OR ALTER PROCEDURE usp_Entity_CloneFixDomainRefs
    @SourceEntityId INT,
    @NewEntityId    INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-01
-- Description: After batch-cloning data, fixes self-referencing DomainValue
--              foreign keys. A DomainValue is self-referencing when it points
--              to a row in the source entity. These need to be remapped to
--              the corresponding row in the new entity (matched by Code).
--
-- Change History:
--   v1.0  2026-03-01  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE ev
    SET    ev.DomainValue = clone_row.Id
    FROM   EntityValues ev
    INNER JOIN EntityRows er_clone  ON er_clone.Id  = ev.EntityRowId
                                   AND er_clone.EntityId = @NewEntityId
    INNER JOIN EntityRows er_source ON er_source.Id = ev.DomainValue
                                   AND er_source.EntityId = @SourceEntityId
    INNER JOIN EntityRows clone_row ON clone_row.EntityId = @NewEntityId
                                   AND clone_row.Code     = er_source.Code
    WHERE  ev.DomainValue IS NOT NULL;

    SELECT @@ROWCOUNT AS RefsFixed;
END;
GO

-- ============================================
-- STAGING TABLE MANAGEMENT
-- ============================================

-- ============================================
-- usp_Staging_CreateTable
-- Enables staging for an entity: creates a named table
-- in the stg schema, its indexes, and the
-- configuration/field-rule rows.
-- ============================================
CREATE OR ALTER PROCEDURE usp_Staging_CreateTable
    @EntityId INT
AS
BEGIN
    SET NOCOUNT ON;

    -- 1. Verify entity exists
    IF NOT EXISTS (SELECT 1 FROM Entities WHERE Id = @EntityId)
        THROW 50001, 'Entity not found.', 1;

    -- 2. Check staging not already enabled
    IF EXISTS (SELECT 1 FROM StagingConfigurations WHERE EntityId = @EntityId)
        THROW 50002, 'Staging is already enabled for this entity.', 1;

    -- 3. Derive safe table name from entity name
    DECLARE @EntityName NVARCHAR(200);
    SELECT @EntityName = Name FROM Entities WHERE Id = @EntityId;

    DECLARE @SafeName NVARCHAR(200) = dbo.fn_StagingTableName(@EntityName);
    IF @SafeName IS NULL OR LEN(@SafeName) = 0
        THROW 50009, 'Entity name produces an empty staging table name after sanitisation.', 1;

    -- 4. If stg table exists but no config row (orphaned state) — drop and rebuild clean.
    --    Step 2 already confirmed there is no StagingConfigurations row for this entity,
    --    so any existing stg table is definitively orphaned and safe to remove.
    IF EXISTS (
        SELECT 1 FROM sys.tables t
        JOIN sys.schemas s ON s.schema_id = t.schema_id
        WHERE s.name = 'stg' AND t.name = @SafeName
    )
    BEGIN
        DECLARE @DropSQL NVARCHAR(MAX) = N'DROP TABLE stg.' + QUOTENAME(@SafeName) + N';';
        EXEC sp_executesql @DropSQL;
    END

    -- 5. Read attributes (exclude system dates — they are not import fields)
    DECLARE @Attributes TABLE (
        Id              INT,
        Name            NVARCHAR(128),
        DataType        NVARCHAR(20),
        DomainEntityId  INT,
        IsRequired      BIT,
        MaxLength       INT
    );

    INSERT INTO @Attributes (Id, Name, DataType, DomainEntityId, IsRequired, MaxLength)
    SELECT Id, Name, DataType, DomainEntityId, IsRequired, MaxLength
    FROM Attributes
    WHERE EntityId = @EntityId
      AND IsSystemDate = 0
      AND IsHidden = 0
      AND IsCode = 0
      AND IsName = 0;

    -- 6. Build dynamic CREATE TABLE DDL
    DECLARE @TableName NVARCHAR(200) = N'stg.' + QUOTENAME(@SafeName);
    DECLARE @SQL NVARCHAR(MAX);

    SET @SQL = N'CREATE TABLE ' + @TableName + N' (
    Id              BIGINT IDENTITY(1,1) PRIMARY KEY,
    ImportAction    TINYINT NOT NULL DEFAULT 0,
    ImportStatus    TINYINT NOT NULL DEFAULT 0,
    BatchId         INT NULL,
    BatchTag        NVARCHAR(100) NULL,
    ErrorCode       INT NOT NULL DEFAULT 0,
    Code            NVARCHAR(200) NOT NULL,
    Name            NVARCHAR(500) NULL,
    NewCode         NVARCHAR(200) NULL,
    SourceSystem    NVARCHAR(100) NULL,
    SourceTimestamp DATETIME2 NULL,';

    -- Append one NVARCHAR(MAX) column per attribute
    DECLARE @AttrName NVARCHAR(128);
    DECLARE attr_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT Name FROM @Attributes ORDER BY Name;

    OPEN attr_cursor;
    FETCH NEXT FROM attr_cursor INTO @AttrName;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @SQL = @SQL + N'
    ' + QUOTENAME(@AttrName) + N' NVARCHAR(MAX) NULL,';
        FETCH NEXT FROM attr_cursor INTO @AttrName;
    END;
    CLOSE attr_cursor;
    DEALLOCATE attr_cursor;

    SET @SQL = @SQL + N'
    CreatedAt       DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);';

    -- 7. Execute DDL
    EXEC sp_executesql @SQL;

    -- 8. Create indexes
    SET @SQL = N'CREATE INDEX ' + QUOTENAME(N'IX_stg_' + @SafeName + N'_BatchId_Status')
             + N' ON ' + @TableName + N'(BatchId, ImportStatus);';
    EXEC sp_executesql @SQL;

    SET @SQL = N'CREATE INDEX ' + QUOTENAME(N'IX_stg_' + @SafeName + N'_Code')
             + N' ON ' + @TableName + N'(Code);';
    EXEC sp_executesql @SQL;

    -- 9. Insert StagingConfigurations row (store the safe table name)
    INSERT INTO StagingConfigurations (EntityId, TableName)
    VALUES (@EntityId, @SafeName);

    -- 10. Insert StagingFieldRules — one row per attribute with defaults
    INSERT INTO StagingFieldRules (EntityId, AttributeId, MergeMode, OnValidationError)
    SELECT @EntityId, Id, 'auto', 'error_row'
    FROM @Attributes;

    -- 11. Return the new configuration
    SELECT sc.*, e.Name AS EntityName
    FROM StagingConfigurations sc
    JOIN Entities e ON e.Id = sc.EntityId
    WHERE sc.EntityId = @EntityId;

    SELECT sfr.*, a.Name AS AttributeName, a.DisplayName, a.DataType
    FROM StagingFieldRules sfr
    JOIN Attributes a ON a.Id = sfr.AttributeId
    WHERE sfr.EntityId = @EntityId
    ORDER BY a.SortOrder, a.Name;
END;
GO

-- ============================================
-- usp_Staging_DropTable
-- Disables staging for an entity: drops the stg table
-- and removes all configuration rows.
-- ============================================
CREATE OR ALTER PROCEDURE usp_Staging_DropTable
    @EntityId INT
AS
BEGIN
    SET NOCOUNT ON;

    -- 1. Check staging exists for this entity
    IF NOT EXISTS (SELECT 1 FROM StagingConfigurations WHERE EntityId = @EntityId)
        THROW 50003, 'Staging is not enabled for this entity.', 1;

    -- 2. Delete StagingFieldRules (CASCADE on StagingConfigurations handles this,
    --    but we do it explicitly before dropping the table)
    DELETE FROM StagingFieldRules WHERE EntityId = @EntityId;

    -- 3. Delete StagingBatches (CASCADE deletes StagingErrorDetails)
    DELETE FROM StagingBatches WHERE EntityId = @EntityId;

    -- 4. Drop the staging table (resolve name from config)
    DECLARE @TableName NVARCHAR(300) = dbo.fn_ResolveStagingTable(@EntityId);
    DECLARE @SQL NVARCHAR(MAX) = N'DROP TABLE IF EXISTS ' + @TableName + N';';
    EXEC sp_executesql @SQL;

    -- 5. Delete StagingConfigurations row
    DELETE FROM StagingConfigurations WHERE EntityId = @EntityId;

    SELECT 'Staging disabled successfully.' AS Message, @EntityId AS EntityId;
END;
GO

-- ============================================
-- usp_Staging_RebuildTable
-- Syncs the stg table columns with the current
-- Attributes definition (add/drop/rename columns).
-- ============================================
CREATE OR ALTER PROCEDURE usp_Staging_RebuildTable
    @EntityId INT
AS
BEGIN
    SET NOCOUNT ON;

    -- 1. Check staging is enabled
    IF NOT EXISTS (SELECT 1 FROM StagingConfigurations WHERE EntityId = @EntityId)
        THROW 50003, 'Staging is not enabled for this entity.', 1;

    -- 2. Resolve staging table name (need raw name for INFORMATION_SCHEMA lookups)
    DECLARE @SafeName NVARCHAR(200);
    SELECT @SafeName = TableName FROM StagingConfigurations WHERE EntityId = @EntityId;
    IF @SafeName IS NULL
        SET @SafeName = N'Entity_' + CAST(@EntityId AS NVARCHAR(20));

    DECLARE @TableName   NVARCHAR(300) = N'stg.' + QUOTENAME(@SafeName);
    DECLARE @SQL         NVARCHAR(MAX);

    -- System columns that must never be touched
    DECLARE @SystemCols TABLE (ColName NVARCHAR(128));
    INSERT INTO @SystemCols VALUES
        ('Id'), ('ImportAction'), ('ImportStatus'), ('BatchId'), ('BatchTag'),
        ('ErrorCode'), ('Code'), ('Name'), ('NewCode'), ('SourceSystem'), ('SourceTimestamp'),
        ('CreatedAt');

    -- 3. Current columns in the stg table (excluding system columns)
    DECLARE @CurrentCols TABLE (ColName NVARCHAR(128));
    INSERT INTO @CurrentCols (ColName)
    SELECT c.COLUMN_NAME
    FROM INFORMATION_SCHEMA.COLUMNS c
    WHERE c.TABLE_SCHEMA = 'stg'
      AND c.TABLE_NAME   = @SafeName
      AND c.COLUMN_NAME NOT IN (SELECT ColName FROM @SystemCols);

    -- 4. Current attributes from Attributes table (non-system, non-hidden)
    DECLARE @CurrentAttrs TABLE (AttrName NVARCHAR(128));
    INSERT INTO @CurrentAttrs (AttrName)
    SELECT Name
    FROM Attributes
    WHERE EntityId   = @EntityId
      AND IsSystemDate = 0
      AND IsHidden     = 0
      AND IsCode       = 0
      AND IsName       = 0;

    -- 5. Columns to ADD (in Attributes but not in stg table)
    DECLARE @ToAdd TABLE (ColName NVARCHAR(128));
    INSERT INTO @ToAdd (ColName)
    SELECT a.AttrName
    FROM @CurrentAttrs a
    WHERE NOT EXISTS (SELECT 1 FROM @CurrentCols c WHERE c.ColName = a.AttrName);

    -- 6. Columns to DROP (in stg table but not in Attributes)
    DECLARE @ToDrop TABLE (ColName NVARCHAR(128));
    INSERT INTO @ToDrop (ColName)
    SELECT c.ColName
    FROM @CurrentCols c
    WHERE NOT EXISTS (SELECT 1 FROM @CurrentAttrs a WHERE a.AttrName = c.ColName);

    DECLARE @AddCount  INT = (SELECT COUNT(*) FROM @ToAdd);
    DECLARE @DropCount INT = (SELECT COUNT(*) FROM @ToDrop);

    -- 7. ADD new columns
    DECLARE @ColName NVARCHAR(128);

    DECLARE add_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT ColName FROM @ToAdd;
    OPEN add_cursor;
    FETCH NEXT FROM add_cursor INTO @ColName;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @SQL = N'ALTER TABLE ' + @TableName + N' ADD ' + QUOTENAME(@ColName) + N' NVARCHAR(MAX) NULL;';
        EXEC sp_executesql @SQL;
        FETCH NEXT FROM add_cursor INTO @ColName;
    END;
    CLOSE add_cursor;
    DEALLOCATE add_cursor;

    -- 8. DROP removed columns
    DECLARE drop_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT ColName FROM @ToDrop;
    OPEN drop_cursor;
    FETCH NEXT FROM drop_cursor INTO @ColName;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @SQL = N'ALTER TABLE ' + @TableName + N' DROP COLUMN ' + QUOTENAME(@ColName) + N';';
        EXEC sp_executesql @SQL;
        FETCH NEXT FROM drop_cursor INTO @ColName;
    END;
    CLOSE drop_cursor;
    DEALLOCATE drop_cursor;

    -- 9. Sync StagingFieldRules:
    --    Add rows for new attributes
    INSERT INTO StagingFieldRules (EntityId, AttributeId, MergeMode, OnValidationError)
    SELECT @EntityId, a.Id, 'default', 'error_row'
    FROM Attributes a
    WHERE a.EntityId    = @EntityId
      AND a.IsSystemDate = 0
      AND a.IsHidden     = 0
      AND a.IsCode       = 0
      AND a.IsName       = 0
      AND NOT EXISTS (
          SELECT 1 FROM StagingFieldRules sfr
          WHERE sfr.EntityId = @EntityId AND sfr.AttributeId = a.Id
      );

    --    Remove rows for deleted attributes
    DELETE sfr
    FROM StagingFieldRules sfr
    WHERE sfr.EntityId = @EntityId
      AND NOT EXISTS (
          SELECT 1 FROM Attributes a
          WHERE a.Id = sfr.AttributeId
            AND a.IsSystemDate = 0
            AND a.IsHidden     = 0
            AND a.IsCode       = 0
            AND a.IsName       = 0
      );

    -- 10. Return summary
    SELECT
        @AddCount  AS ColumnsAdded,
        @DropCount AS ColumnsDropped,
        @TableName AS TableName;
END;
GO

-- ============================================
-- usp_Staging_GetConfiguration
-- Returns configuration + field rules for an entity.
-- Result set 1: StagingConfigurations row
-- Result set 2: StagingFieldRules joined with Attributes
-- ============================================
CREATE OR ALTER PROCEDURE usp_Staging_GetConfiguration
    @EntityId INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Result set 1: configuration header
    SELECT
        sc.Id,
        sc.EntityId,
        e.Name              AS EntityName,
        sc.IsEnabled,
        sc.TableName,
        sc.DefaultImportAction,
        sc.DefaultMergeMode,
        sc.SentinelText,
        CONVERT(VARCHAR(40), sc.SentinelNumber) AS SentinelNumber,
        sc.SentinelDateTime,
        sc.CreatedAt,
        sc.ModifiedAt
    FROM StagingConfigurations sc
    JOIN Entities e ON e.Id = sc.EntityId
    WHERE sc.EntityId = @EntityId;

    -- Result set 2: per-attribute field rules
    SELECT
        sfr.Id,
        sfr.EntityId,
        sfr.AttributeId,
        a.Name          AS AttributeName,
        a.DisplayName,
        a.DataType,
        sfr.MergeMode,
        sfr.OnValidationError,
        sfr.SourcePriority,
        sfr.CreatedAt,
        sfr.ModifiedAt
    FROM StagingFieldRules sfr
    JOIN Attributes a ON a.Id = sfr.AttributeId
    WHERE sfr.EntityId = @EntityId
    ORDER BY a.SortOrder, a.Name;
END;
GO

-- ============================================
-- usp_Staging_SaveConfiguration
-- Updates top-level config and/or per-field rules.
-- Accepts NULL params — only non-NULL values are applied.
-- ============================================
CREATE OR ALTER PROCEDURE usp_Staging_SaveConfiguration
    @EntityId           INT,
    @DefaultImportAction TINYINT       = NULL,
    @DefaultMergeMode   NVARCHAR(30)  = NULL,
    @SentinelText       NVARCHAR(20)  = NULL,
    @SentinelNumber     DECIMAL(38,0) = NULL,
    @SentinelDateTime   NVARCHAR(30)  = NULL,
    @FieldRules         NVARCHAR(MAX) = NULL   -- JSON array
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM StagingConfigurations WHERE EntityId = @EntityId)
        THROW 50003, 'Staging is not enabled for this entity.', 1;

    -- 1. Update top-level configuration for non-NULL params
    UPDATE StagingConfigurations
    SET
        DefaultImportAction = COALESCE(@DefaultImportAction, DefaultImportAction),
        DefaultMergeMode    = COALESCE(@DefaultMergeMode,    DefaultMergeMode),
        SentinelText        = COALESCE(@SentinelText,        SentinelText),
        SentinelNumber      = COALESCE(@SentinelNumber,      SentinelNumber),
        SentinelDateTime    = COALESCE(@SentinelDateTime,    SentinelDateTime),
        ModifiedAt          = GETUTCDATE()
    WHERE EntityId = @EntityId;

    -- 2. If field rules JSON provided, merge into StagingFieldRules
    --    Expected JSON: [{"attributeId": 1, "mergeMode": "overwrite", "onValidationError": "error_row"}, ...]
    IF @FieldRules IS NOT NULL
    BEGIN
        MERGE StagingFieldRules AS target
        USING (
            SELECT
                CAST(j.AttributeId AS INT)         AS AttributeId,
                CAST(j.MergeMode AS NVARCHAR(30))  AS MergeMode,
                CAST(j.OnValidationError AS NVARCHAR(20)) AS OnValidationError
            FROM OPENJSON(@FieldRules) WITH (
                AttributeId      INT            '$.attributeId',
                MergeMode        NVARCHAR(30)   '$.mergeMode',
                OnValidationError NVARCHAR(20)  '$.onValidationError'
            ) j
        ) AS source ON target.EntityId = @EntityId AND target.AttributeId = source.AttributeId
        WHEN MATCHED THEN UPDATE SET
            MergeMode           = COALESCE(source.MergeMode,           target.MergeMode),
            OnValidationError   = COALESCE(source.OnValidationError,   target.OnValidationError),
            ModifiedAt          = GETUTCDATE()
        WHEN NOT MATCHED BY TARGET THEN INSERT (EntityId, AttributeId, MergeMode, OnValidationError)
            VALUES (@EntityId, source.AttributeId, COALESCE(source.MergeMode, 'auto'), COALESCE(source.OnValidationError, 'error_row'));
    END;

    -- 3. Return updated configuration (mirrors usp_Staging_GetConfiguration)
    SELECT
        sc.Id,
        sc.EntityId,
        e.Name              AS EntityName,
        sc.IsEnabled,
        sc.TableName,
        sc.DefaultImportAction,
        sc.DefaultMergeMode,
        sc.SentinelText,
        CONVERT(VARCHAR(40), sc.SentinelNumber) AS SentinelNumber,
        sc.SentinelDateTime,
        sc.CreatedAt,
        sc.ModifiedAt
    FROM StagingConfigurations sc
    JOIN Entities e ON e.Id = sc.EntityId
    WHERE sc.EntityId = @EntityId;

    SELECT
        sfr.Id,
        sfr.EntityId,
        sfr.AttributeId,
        a.Name          AS AttributeName,
        a.DisplayName,
        a.DataType,
        sfr.MergeMode,
        sfr.OnValidationError,
        sfr.SourcePriority,
        sfr.CreatedAt,
        sfr.ModifiedAt
    FROM StagingFieldRules sfr
    JOIN Attributes a ON a.Id = sfr.AttributeId
    WHERE sfr.EntityId = @EntityId
    ORDER BY a.SortOrder, a.Name;
END;
GO

-- ============================================
-- STAGING PROCESSING ENGINE
-- ============================================

-- ============================================
-- usp_Staging_ProcessBatch
--
-- Core engine: validates staging data and loads
-- it into production tables (EntityRows + EntityValues).
--
-- Parameters:
--   @EntityId  -- entity to process (required)
--   @BatchTag  -- filter staging rows by BatchTag (optional)
--   @BatchId   -- resume or filter by existing BatchId (optional)
--   @UserId    -- user performing the import (optional, for audit)
--
-- ImportAction values:
--   0 = upsert  (insert if not found, update if found)
--   1 = insert  (fail if Code already exists)
--   2 = update  (fail if Code does not exist)
--   3 = delete
--   4 = purge
--   5 = delete_cascade (null out domain refs first, then delete)
--   6 = purge_cascade
--
-- ImportStatus values:
--   0 = Ready
--   1 = OK
--   2 = Error
--   3 = Processing
--
-- Batch Status values:
--   1 = QueuedToRun
--   2 = Running
--   3 = Completed
--   4 = CompletedWithErrors
--   5 = Failed
--
-- ErrorCode bit values (bitwise OR):
--   1     = 100001 Duplicate Code in batch
--   2     = 100002 Code is required
--   4     = 100003 Code already exists (insert-only)
--   8     = 100004 Code not found (update/delete)
--   16    = 100005 Invalid ImportAction
--   64    = 100007 Delete blocked by references
--   128   = 200001 Required field empty (insert)
--   256   = 200002 Text exceeds max length
--   512   = 200003 Invalid integer
--   1024  = 200004 Invalid decimal
--   2048  = 200005 Invalid datetime
--   4096  = 200006 Invalid boolean
--   8192  = 200007 Domain value not found
--   32768 = 300001 NewCode already exists in production
--   65536  = 300002 Duplicate NewCode in batch
--   131072 = 400001 Processing failed (system error in CATCH block)
-- ============================================
CREATE OR ALTER PROCEDURE usp_Staging_ProcessBatch
    @EntityId   INT,
    @BatchTag   NVARCHAR(100) = NULL,
    @BatchId    INT           = NULL,
    @UserId     INT           = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- ----------------------------------------
    -- Working variables
    -- ----------------------------------------
    DECLARE
        @EntityName     NVARCHAR(200),
        @ModelName      NVARCHAR(200),
        @ModelId        INT,
        @StagingTable   NVARCHAR(200),
        @NewBatchId     INT,
        @TotalRows      INT,
        @SuccessRows    INT,
        @ErrorRows      INT,
        @InsertCount    INT,
        @UpdateCount    INT,
        @DeleteCount    INT,
        @SQL            NVARCHAR(MAX),
        @Params         NVARCHAR(1000),
        @SentinelText       NVARCHAR(20),
        @SentinelNumber     DECIMAL(38,0),
        @SentinelDT         NVARCHAR(30),
        @DefaultMergeMode   NVARCHAR(30);

    -- ==========================================
    -- STEP 1: VALIDATE BATCH
    -- ==========================================

    -- 1a. Verify entity exists and staging is enabled
    DECLARE @SafeName NVARCHAR(200);
    SELECT
        @EntityName   = e.Name,
        @ModelId      = e.ModelId,
        @SafeName     = sc.TableName,
        @SentinelText     = sc.SentinelText,
        @SentinelNumber   = sc.SentinelNumber,
        @SentinelDT       = sc.SentinelDateTime,
        @DefaultMergeMode = ISNULL(sc.DefaultMergeMode, 'overwrite')
    FROM Entities e
    JOIN StagingConfigurations sc ON sc.EntityId = e.Id
    WHERE e.Id = @EntityId
      AND sc.IsEnabled = 1;

    IF @EntityName IS NULL
        THROW 50010, 'Entity not found or staging is not enabled for this entity.', 1;

    -- Fallback for legacy tables that predate the named-table migration
    IF @SafeName IS NULL
        SET @SafeName = N'Entity_' + CAST(@EntityId AS NVARCHAR(20));

    -- 1b. Get model name for audit log
    SELECT @ModelName = Name FROM Models WHERE Id = @ModelId;
    IF @ModelName IS NULL SET @ModelName = N'Unknown';

    -- 1c. Build staging table name from stored config
    SET @StagingTable = N'stg.' + QUOTENAME(@SafeName);

    -- 1d. Verify staging table exists
    IF NOT EXISTS (
        SELECT 1
        FROM sys.tables t
        JOIN sys.schemas s ON s.schema_id = t.schema_id
        WHERE s.name = 'stg'
          AND t.name = @SafeName
    )
        THROW 50011, 'Staging table does not exist. Run usp_Staging_CreateTable first.', 1;

    -- 1e. Build temp table to hold eligible row IDs
    CREATE TABLE #EligibleIds (StagingRowId BIGINT NOT NULL PRIMARY KEY);

    -- 1f. Collect rows to process (ImportStatus = 0 = Ready)
    SET @SQL = N'
    INSERT INTO #EligibleIds (StagingRowId)
    SELECT Id
    FROM ' + @StagingTable + N'
    WHERE ImportStatus = 0
    ' +
    CASE WHEN @BatchTag IS NOT NULL THEN N'  AND BatchTag = @pBatchTag ' ELSE N'' END +
    CASE WHEN @BatchId  IS NOT NULL THEN N'  AND BatchId  = @pBatchId  ' ELSE N'' END +
    N';';

    SET @Params = N'@pBatchTag NVARCHAR(100), @pBatchId INT';
    EXEC sp_executesql @SQL, @Params, @pBatchTag = @BatchTag, @pBatchId = @BatchId;

    SET @TotalRows = (SELECT COUNT(*) FROM #EligibleIds);

    IF @TotalRows = 0
    BEGIN
        DROP TABLE #EligibleIds;
        THROW 50012, 'No rows with ImportStatus=0 (Ready) found matching the filter criteria.', 1;
    END;

    -- 1g. Create batch record
    INSERT INTO StagingBatches (EntityId, BatchTag, Status, TotalRows, StartedAt, StartedBy)
    VALUES (@EntityId, @BatchTag, 2, @TotalRows, GETUTCDATE(), @UserId);

    SET @NewBatchId = SCOPE_IDENTITY();

    -- 1h. Assign batch ID and mark rows as Processing (ImportStatus=3)
    SET @SQL = N'
    UPDATE s
    SET s.BatchId      = @pNewBatchId,
        s.ImportStatus = 3
    FROM ' + @StagingTable + N' s
    JOIN #EligibleIds e ON e.StagingRowId = s.Id;';

    SET @Params = N'@pNewBatchId INT';
    EXEC sp_executesql @SQL, @Params, @pNewBatchId = @NewBatchId;

    -- ==========================================
    -- STEP 2: PRE-VALIDATION (set-based)
    -- ==========================================

    -- ----------------------------------------
    -- 2a. Duplicate Code check (ErrorCode |= 1)
    -- ----------------------------------------
    SET @SQL = N'
    UPDATE s
    SET s.ErrorCode = s.ErrorCode | 1
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND s.Code IN (
          SELECT Code
          FROM ' + @StagingTable + N'
          WHERE BatchId = @pBatchId
            AND ImportStatus = 3
          GROUP BY Code
          HAVING COUNT(*) > 1
      );

    INSERT INTO StagingErrorDetails (BatchId, StagingRowId, Code, AttributeName, StagingValue, ErrorCode, ErrorMessage)
    SELECT @pBatchId, s.Id, s.Code, NULL, s.Code, 1, ''Duplicate Code found in this batch.''
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND (s.ErrorCode & 1) = 1
      AND NOT EXISTS (
          SELECT 1 FROM StagingErrorDetails ed
          WHERE ed.BatchId = @pBatchId AND ed.StagingRowId = s.Id AND ed.ErrorCode = 1
      );';

    SET @Params = N'@pBatchId INT';
    EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId;

    -- ----------------------------------------
    -- 2b. Empty Code check (ErrorCode |= 2)
    -- ----------------------------------------
    SET @SQL = N'
    UPDATE s
    SET s.ErrorCode = s.ErrorCode | 2
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND (s.Code IS NULL OR LTRIM(RTRIM(s.Code)) = '''');

    INSERT INTO StagingErrorDetails (BatchId, StagingRowId, Code, AttributeName, StagingValue, ErrorCode, ErrorMessage)
    SELECT @pBatchId, s.Id, s.Code, NULL, s.Code, 2, ''Code is required and cannot be empty.''
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND (s.ErrorCode & 2) = 2
      AND NOT EXISTS (
          SELECT 1 FROM StagingErrorDetails ed
          WHERE ed.BatchId = @pBatchId AND ed.StagingRowId = s.Id AND ed.ErrorCode = 2
      );';

    EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId;

    -- ----------------------------------------
    -- 2c. Invalid ImportAction check (ErrorCode |= 16)
    -- ----------------------------------------
    SET @SQL = N'
    UPDATE s
    SET s.ErrorCode = s.ErrorCode | 16
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND s.ImportAction NOT IN (0,1,2,3,4,5,6);

    INSERT INTO StagingErrorDetails (BatchId, StagingRowId, Code, AttributeName, StagingValue, ErrorCode, ErrorMessage)
    SELECT @pBatchId, s.Id, s.Code, NULL, CAST(s.ImportAction AS NVARCHAR(10)), 16,
           ''Invalid ImportAction value. Must be 0-6.''
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND (s.ErrorCode & 16) = 16
      AND NOT EXISTS (
          SELECT 1 FROM StagingErrorDetails ed
          WHERE ed.BatchId = @pBatchId AND ed.StagingRowId = s.Id AND ed.ErrorCode = 16
      );';

    EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId;

    -- ----------------------------------------
    -- 2d. Code already exists (insert-only, ErrorCode |= 4)
    -- ----------------------------------------
    SET @SQL = N'
    UPDATE s
    SET s.ErrorCode = s.ErrorCode | 4
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND s.ImportAction = 1
      AND EXISTS (
          SELECT 1 FROM EntityRows er
          WHERE er.EntityId = @pEntityId AND er.Code = s.Code
      );

    INSERT INTO StagingErrorDetails (BatchId, StagingRowId, Code, AttributeName, StagingValue, ErrorCode, ErrorMessage)
    SELECT @pBatchId, s.Id, s.Code, NULL, s.Code, 4,
           ''Code already exists in production. Use ImportAction=0 (upsert) or 2 (update).''
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND (s.ErrorCode & 4) = 4
      AND NOT EXISTS (
          SELECT 1 FROM StagingErrorDetails ed
          WHERE ed.BatchId = @pBatchId AND ed.StagingRowId = s.Id AND ed.ErrorCode = 4
      );';

    SET @Params = N'@pBatchId INT, @pEntityId INT';
    EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId, @pEntityId = @EntityId;

    -- ----------------------------------------
    -- 2e. Code not found (update/delete, ErrorCode |= 8)
    -- ----------------------------------------
    SET @SQL = N'
    UPDATE s
    SET s.ErrorCode = s.ErrorCode | 8
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND s.ImportAction IN (2,3,4,5,6)
      AND NOT EXISTS (
          SELECT 1 FROM EntityRows er
          WHERE er.EntityId = @pEntityId AND er.Code = s.Code
      );

    INSERT INTO StagingErrorDetails (BatchId, StagingRowId, Code, AttributeName, StagingValue, ErrorCode, ErrorMessage)
    SELECT @pBatchId, s.Id, s.Code, NULL, s.Code, 8,
           ''Code does not exist in production. Cannot update or delete a non-existent record.''
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND (s.ErrorCode & 8) = 8
      AND NOT EXISTS (
          SELECT 1 FROM StagingErrorDetails ed
          WHERE ed.BatchId = @pBatchId AND ed.StagingRowId = s.Id AND ed.ErrorCode = 8
      );';

    EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId, @pEntityId = @EntityId;

    -- ----------------------------------------
    -- 2f. Delete blocked by references (non-cascade, ErrorCode |= 64)
    --     ImportAction 3,4: only block if referenced by DomainValue in other entities
    -- ----------------------------------------
    SET @SQL = N'
    UPDATE s
    SET s.ErrorCode = s.ErrorCode | 64
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND s.ImportAction IN (3,4)
      AND EXISTS (
          SELECT 1 FROM EntityRows er
          WHERE er.EntityId = @pEntityId AND er.Code = s.Code
            AND EXISTS (
                SELECT 1 FROM EntityValues ev
                WHERE ev.DomainValue = er.Id
            )
      );

    INSERT INTO StagingErrorDetails (BatchId, StagingRowId, Code, AttributeName, StagingValue, ErrorCode, ErrorMessage)
    SELECT @pBatchId, s.Id, s.Code, NULL, s.Code, 64,
           ''Record is referenced by other entities. Use ImportAction=5 or 6 (cascade) to force delete.''
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND (s.ErrorCode & 64) = 64
      AND NOT EXISTS (
          SELECT 1 FROM StagingErrorDetails ed
          WHERE ed.BatchId = @pBatchId AND ed.StagingRowId = s.Id AND ed.ErrorCode = 64
      );';

    EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId, @pEntityId = @EntityId;

    -- ----------------------------------------
    -- 2g. NewCode already exists in production (ErrorCode |= 32768)
    --     Only applies to update/upsert rows with a non-empty NewCode
    -- ----------------------------------------
    SET @SQL = N'
    UPDATE s
    SET s.ErrorCode = s.ErrorCode | 32768
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND s.ImportAction IN (0,2)
      AND s.NewCode IS NOT NULL
      AND LTRIM(RTRIM(s.NewCode)) <> ''''
      AND s.NewCode <> s.Code
      AND EXISTS (
          SELECT 1 FROM EntityRows er
          WHERE er.EntityId = @pEntityId AND er.Code = s.NewCode
      );

    INSERT INTO StagingErrorDetails (BatchId, StagingRowId, Code, AttributeName, StagingValue, ErrorCode, ErrorMessage)
    SELECT @pBatchId, s.Id, s.Code, ''NewCode'', s.NewCode, 32768,
           ''NewCode '''''' + s.NewCode + '''''' already exists in production.''
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND (s.ErrorCode & 32768) = 32768
      AND NOT EXISTS (
          SELECT 1 FROM StagingErrorDetails ed
          WHERE ed.BatchId = @pBatchId AND ed.StagingRowId = s.Id AND ed.ErrorCode = 32768
      );';

    SET @Params = N'@pBatchId INT, @pEntityId INT';
    EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId, @pEntityId = @EntityId;

    -- ----------------------------------------
    -- 2h. Duplicate NewCode in batch (ErrorCode |= 65536)
    --     Multiple rows renaming to the same NewCode
    -- ----------------------------------------
    SET @SQL = N'
    UPDATE s
    SET s.ErrorCode = s.ErrorCode | 65536
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND s.NewCode IS NOT NULL
      AND LTRIM(RTRIM(s.NewCode)) <> ''''
      AND s.NewCode IN (
          SELECT NewCode
          FROM ' + @StagingTable + N'
          WHERE BatchId = @pBatchId
            AND ImportStatus = 3
            AND NewCode IS NOT NULL
            AND LTRIM(RTRIM(NewCode)) <> ''''
          GROUP BY NewCode
          HAVING COUNT(*) > 1
      );

    INSERT INTO StagingErrorDetails (BatchId, StagingRowId, Code, AttributeName, StagingValue, ErrorCode, ErrorMessage)
    SELECT @pBatchId, s.Id, s.Code, ''NewCode'', s.NewCode, 65536,
           ''Duplicate NewCode in batch — multiple rows renaming to '''''' + s.NewCode + ''''''.''
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND (s.ErrorCode & 65536) = 65536
      AND NOT EXISTS (
          SELECT 1 FROM StagingErrorDetails ed
          WHERE ed.BatchId = @pBatchId AND ed.StagingRowId = s.Id AND ed.ErrorCode = 65536
      );';

    SET @Params = N'@pBatchId INT';
    EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId;

    -- ----------------------------------------
    -- 2i. Per-attribute validations (cursor loop)
    -- ----------------------------------------
    DECLARE
        @AttrId         INT,
        @AttrName       NVARCHAR(128),
        @AttrDataType   NVARCHAR(20),
        @AttrMaxLength  INT,
        @AttrIsRequired BIT,
        @AttrDomainEntityId INT,
        @AttrMergeMode  NVARCHAR(30),
        @AttrOnValidErr NVARCHAR(20);

    DECLARE attr_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT
            a.Id,
            a.Name,
            a.DataType,
            a.MaxLength,
            a.IsRequired,
            a.DomainEntityId,
            CASE WHEN ISNULL(sfr.MergeMode, 'auto') = 'auto' THEN LOWER(@DefaultMergeMode) ELSE sfr.MergeMode END,
            ISNULL(sfr.OnValidationError, 'error_row')
        FROM Attributes a
        LEFT JOIN StagingFieldRules sfr
            ON sfr.EntityId = @EntityId AND sfr.AttributeId = a.Id
        WHERE a.EntityId     = @EntityId
          AND a.IsSystemDate  = 0
          AND a.IsHidden      = 0
          AND a.IsCode        = 0
          AND a.IsName        = 0
        ORDER BY a.SortOrder, a.Name;

    OPEN attr_cursor;
    FETCH NEXT FROM attr_cursor INTO
        @AttrId, @AttrName, @AttrDataType, @AttrMaxLength,
        @AttrIsRequired, @AttrDomainEntityId, @AttrMergeMode, @AttrOnValidErr;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- For skip_field mode, we still detect errors but do NOT set ErrorCode on the row
        -- We always insert into StagingErrorDetails for audit purposes
        DECLARE @SetErrorCode BIT = CASE WHEN @AttrOnValidErr = 'skip_field' THEN 0 ELSE 1 END;

        -- Required field check: insert/upsert rows must have a value if IsRequired=1
        IF @AttrIsRequired = 1
        BEGIN
            SET @SQL = N'
            -- Required field: mark rows missing value for INSERT / UPSERT (ImportAction 0 or 1)
            ' + CASE WHEN @SetErrorCode = 1 THEN
            N'UPDATE s
            SET s.ErrorCode = s.ErrorCode | 128
            FROM ' + @StagingTable + N' s
            WHERE s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.ImportAction IN (0,1)
              AND (s.' + QUOTENAME(@AttrName) + N' IS NULL OR LTRIM(RTRIM(s.' + QUOTENAME(@AttrName) + N')) = '''');
            ' ELSE N'' END + N'

            INSERT INTO StagingErrorDetails (BatchId, StagingRowId, Code, AttributeName, StagingValue, ErrorCode, ErrorMessage)
            SELECT @pBatchId, s.Id, s.Code, @pAttrName, s.' + QUOTENAME(@AttrName) + N', 128,
                   ''Required field is empty.''
            FROM ' + @StagingTable + N' s
            WHERE s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.ImportAction IN (0,1)
              AND (s.' + QUOTENAME(@AttrName) + N' IS NULL OR LTRIM(RTRIM(s.' + QUOTENAME(@AttrName) + N')) = '''')
              AND NOT EXISTS (
                  SELECT 1 FROM StagingErrorDetails ed
                  WHERE ed.BatchId = @pBatchId AND ed.StagingRowId = s.Id
                    AND ed.ErrorCode = 128 AND ed.AttributeName = @pAttrName
              );';

            SET @Params = N'@pBatchId INT, @pAttrName NVARCHAR(128)';
            EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId, @pAttrName = @AttrName;
        END;

        -- Max length check (Text only)
        IF @AttrDataType = 'Text' AND @AttrMaxLength IS NOT NULL
        BEGIN
            SET @SQL = N'
            ' + CASE WHEN @SetErrorCode = 1 THEN
            N'UPDATE s
            SET s.ErrorCode = s.ErrorCode | 256
            FROM ' + @StagingTable + N' s
            WHERE s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL
              AND LEN(s.' + QUOTENAME(@AttrName) + N') > @pMaxLen;
            ' ELSE N'' END + N'

            INSERT INTO StagingErrorDetails (BatchId, StagingRowId, Code, AttributeName, StagingValue, ErrorCode, ErrorMessage)
            SELECT @pBatchId, s.Id, s.Code, @pAttrName,
                   LEFT(s.' + QUOTENAME(@AttrName) + N', 500),
                   256,
                   ''Text value exceeds maximum length of '' + CAST(@pMaxLen AS NVARCHAR(10)) + '' characters.''
            FROM ' + @StagingTable + N' s
            WHERE s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL
              AND LEN(s.' + QUOTENAME(@AttrName) + N') > @pMaxLen
              AND NOT EXISTS (
                  SELECT 1 FROM StagingErrorDetails ed
                  WHERE ed.BatchId = @pBatchId AND ed.StagingRowId = s.Id
                    AND ed.ErrorCode = 256 AND ed.AttributeName = @pAttrName
              );';

            SET @Params = N'@pBatchId INT, @pAttrName NVARCHAR(128), @pMaxLen INT';
            EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId, @pAttrName = @AttrName, @pMaxLen = @AttrMaxLength;
        END;

        -- Int validation (ErrorCode |= 512)
        IF @AttrDataType = 'Int'
        BEGIN
            SET @SQL = N'
            ' + CASE WHEN @SetErrorCode = 1 THEN
            N'UPDATE s
            SET s.ErrorCode = s.ErrorCode | 512
            FROM ' + @StagingTable + N' s
            WHERE s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL
              AND TRY_CAST(s.' + QUOTENAME(@AttrName) + N' AS INT) IS NULL;
            ' ELSE N'' END + N'

            INSERT INTO StagingErrorDetails (BatchId, StagingRowId, Code, AttributeName, StagingValue, ErrorCode, ErrorMessage)
            SELECT @pBatchId, s.Id, s.Code, @pAttrName,
                   LEFT(s.' + QUOTENAME(@AttrName) + N', 500),
                   512, ''Value cannot be converted to integer.''
            FROM ' + @StagingTable + N' s
            WHERE s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL
              AND TRY_CAST(s.' + QUOTENAME(@AttrName) + N' AS INT) IS NULL
              AND NOT EXISTS (
                  SELECT 1 FROM StagingErrorDetails ed
                  WHERE ed.BatchId = @pBatchId AND ed.StagingRowId = s.Id
                    AND ed.ErrorCode = 512 AND ed.AttributeName = @pAttrName
              );';

            SET @Params = N'@pBatchId INT, @pAttrName NVARCHAR(128)';
            EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId, @pAttrName = @AttrName;
        END;

        -- Decimal validation (ErrorCode |= 1024)
        IF @AttrDataType = 'Decimal'
        BEGIN
            SET @SQL = N'
            ' + CASE WHEN @SetErrorCode = 1 THEN
            N'UPDATE s
            SET s.ErrorCode = s.ErrorCode | 1024
            FROM ' + @StagingTable + N' s
            WHERE s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL
              AND TRY_CAST(s.' + QUOTENAME(@AttrName) + N' AS DECIMAL(18,6)) IS NULL;
            ' ELSE N'' END + N'

            INSERT INTO StagingErrorDetails (BatchId, StagingRowId, Code, AttributeName, StagingValue, ErrorCode, ErrorMessage)
            SELECT @pBatchId, s.Id, s.Code, @pAttrName,
                   LEFT(s.' + QUOTENAME(@AttrName) + N', 500),
                   1024, ''Value cannot be converted to decimal.''
            FROM ' + @StagingTable + N' s
            WHERE s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL
              AND TRY_CAST(s.' + QUOTENAME(@AttrName) + N' AS DECIMAL(18,6)) IS NULL
              AND NOT EXISTS (
                  SELECT 1 FROM StagingErrorDetails ed
                  WHERE ed.BatchId = @pBatchId AND ed.StagingRowId = s.Id
                    AND ed.ErrorCode = 1024 AND ed.AttributeName = @pAttrName
              );';

            SET @Params = N'@pBatchId INT, @pAttrName NVARCHAR(128)';
            EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId, @pAttrName = @AttrName;
        END;

        -- DateTime validation (ErrorCode |= 2048)
        IF @AttrDataType = 'DateTime'
        BEGIN
            SET @SQL = N'
            ' + CASE WHEN @SetErrorCode = 1 THEN
            N'UPDATE s
            SET s.ErrorCode = s.ErrorCode | 2048
            FROM ' + @StagingTable + N' s
            WHERE s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL
              AND TRY_CAST(s.' + QUOTENAME(@AttrName) + N' AS DATETIME2) IS NULL;
            ' ELSE N'' END + N'

            INSERT INTO StagingErrorDetails (BatchId, StagingRowId, Code, AttributeName, StagingValue, ErrorCode, ErrorMessage)
            SELECT @pBatchId, s.Id, s.Code, @pAttrName,
                   LEFT(s.' + QUOTENAME(@AttrName) + N', 500),
                   2048, ''Value cannot be converted to datetime.''
            FROM ' + @StagingTable + N' s
            WHERE s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL
              AND TRY_CAST(s.' + QUOTENAME(@AttrName) + N' AS DATETIME2) IS NULL
              AND NOT EXISTS (
                  SELECT 1 FROM StagingErrorDetails ed
                  WHERE ed.BatchId = @pBatchId AND ed.StagingRowId = s.Id
                    AND ed.ErrorCode = 2048 AND ed.AttributeName = @pAttrName
              );';

            SET @Params = N'@pBatchId INT, @pAttrName NVARCHAR(128)';
            EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId, @pAttrName = @AttrName;
        END;

        -- Boolean validation (ErrorCode |= 4096)
        IF @AttrDataType = 'Boolean'
        BEGIN
            SET @SQL = N'
            ' + CASE WHEN @SetErrorCode = 1 THEN
            N'UPDATE s
            SET s.ErrorCode = s.ErrorCode | 4096
            FROM ' + @StagingTable + N' s
            WHERE s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL
              AND s.' + QUOTENAME(@AttrName) + N' NOT IN (''0'',''1'',''true'',''false'',''yes'',''no'',''True'',''False'',''Yes'',''No'');
            ' ELSE N'' END + N'

            INSERT INTO StagingErrorDetails (BatchId, StagingRowId, Code, AttributeName, StagingValue, ErrorCode, ErrorMessage)
            SELECT @pBatchId, s.Id, s.Code, @pAttrName,
                   LEFT(s.' + QUOTENAME(@AttrName) + N', 500),
                   4096, ''Invalid boolean value. Use: 0, 1, true, false, yes, no.''
            FROM ' + @StagingTable + N' s
            WHERE s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL
              AND s.' + QUOTENAME(@AttrName) + N' NOT IN (''0'',''1'',''true'',''false'',''yes'',''no'',''True'',''False'',''Yes'',''No'')
              AND NOT EXISTS (
                  SELECT 1 FROM StagingErrorDetails ed
                  WHERE ed.BatchId = @pBatchId AND ed.StagingRowId = s.Id
                    AND ed.ErrorCode = 4096 AND ed.AttributeName = @pAttrName
              );';

            SET @Params = N'@pBatchId INT, @pAttrName NVARCHAR(128)';
            EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId, @pAttrName = @AttrName;
        END;

        -- Domain validation (ErrorCode |= 8192)
        -- Staging column holds the Code of the referenced entity row
        IF @AttrDataType = 'Domain' AND @AttrDomainEntityId IS NOT NULL
        BEGIN
            SET @SQL = N'
            ' + CASE WHEN @SetErrorCode = 1 THEN
            N'UPDATE s
            SET s.ErrorCode = s.ErrorCode | 8192
            FROM ' + @StagingTable + N' s
            WHERE s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL
              AND NOT EXISTS (
                  SELECT 1 FROM EntityRows dr
                  WHERE dr.EntityId = @pDomainEntityId
                    AND dr.Code = s.' + QUOTENAME(@AttrName) + N'
              );
            ' ELSE N'' END + N'

            INSERT INTO StagingErrorDetails (BatchId, StagingRowId, Code, AttributeName, StagingValue, ErrorCode, ErrorMessage)
            SELECT @pBatchId, s.Id, s.Code, @pAttrName,
                   LEFT(s.' + QUOTENAME(@AttrName) + N', 500),
                   8192, ''Domain value not found in referenced entity (Code: '' + ISNULL(LEFT(s.' + QUOTENAME(@AttrName) + N',100),''NULL'') + '').''
            FROM ' + @StagingTable + N' s
            WHERE s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL
              AND NOT EXISTS (
                  SELECT 1 FROM EntityRows dr
                  WHERE dr.EntityId = @pDomainEntityId
                    AND dr.Code = s.' + QUOTENAME(@AttrName) + N'
              )
              AND NOT EXISTS (
                  SELECT 1 FROM StagingErrorDetails ed
                  WHERE ed.BatchId = @pBatchId AND ed.StagingRowId = s.Id
                    AND ed.ErrorCode = 8192 AND ed.AttributeName = @pAttrName
              );';

            SET @Params = N'@pBatchId INT, @pAttrName NVARCHAR(128), @pDomainEntityId INT';
            EXEC sp_executesql @SQL, @Params,
                @pBatchId = @NewBatchId, @pAttrName = @AttrName,
                @pDomainEntityId = @AttrDomainEntityId;
        END;

        FETCH NEXT FROM attr_cursor INTO
            @AttrId, @AttrName, @AttrDataType, @AttrMaxLength,
            @AttrIsRequired, @AttrDomainEntityId, @AttrMergeMode, @AttrOnValidErr;
    END;

    CLOSE attr_cursor;
    DEALLOCATE attr_cursor;

    -- ==========================================
    -- STEP 3: MARK ERRORS
    -- ==========================================
    SET @SQL = N'
    UPDATE s
    SET s.ImportStatus = 2
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3
      AND s.ErrorCode > 0;';

    SET @Params = N'@pBatchId INT';
    EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId;

    -- ==========================================
    -- STEP 4-6: PROCESS DATA (transactional)
    -- ==========================================

    -- Pre-compute: which staging Codes already exist in production?
    -- This table drives upsert (ImportAction=0) routing.
    CREATE TABLE #ExistingCodes (
        Code        NVARCHAR(200) NOT NULL PRIMARY KEY,
        EntityRowId BIGINT NOT NULL
    );

    SET @SQL = N'
    INSERT INTO #ExistingCodes (Code, EntityRowId)
    SELECT er.Code, er.Id
    FROM EntityRows er
    JOIN ' + @StagingTable + N' s
        ON s.Code = er.Code
       AND er.EntityId = @pEntityId
    WHERE s.BatchId = @pBatchId
      AND s.ImportStatus = 3;';

    SET @Params = N'@pBatchId INT, @pEntityId INT';
    EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId, @pEntityId = @EntityId;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- ==========================================
        -- STEP 4: PROCESS INSERTS
        -- ==========================================
        -- Rows that need inserting:
        --   ImportAction=1  (insert-only, no existing code)
        --   ImportAction=0  (upsert, code NOT in #ExistingCodes)
        --
        -- Build temp table for new row IDs after INSERT
        CREATE TABLE #NewRowIds (
            StagingRowId    BIGINT NULL,       -- filled by backfill step after INSERT
            StagingCode     NVARCHAR(200) NOT NULL,
            EntityRowId     BIGINT NOT NULL
        );

        -- Name column expression: use staging Name column, fall back to Code
        DECLARE @NameColExpr NVARCHAR(500) = N'ISNULL(s.[Name], s.Code)';

        -- INSERT new EntityRows with OUTPUT to capture IDs
        SET @SQL = N'
        INSERT INTO EntityRows (EntityId, Code, Name, CreatedBy, ModifiedBy)
        OUTPUT INSERTED.Id, INSERTED.Code
        INTO #NewRowIds (EntityRowId, StagingCode)
        SELECT @pEntityId, s.Code, ' + @NameColExpr + N', @pUserId, @pUserId
        FROM ' + @StagingTable + N' s
        WHERE s.BatchId = @pBatchId
          AND s.ImportStatus = 3
          AND (
              (s.ImportAction = 1)
              OR (s.ImportAction = 0 AND NOT EXISTS (
                    SELECT 1 FROM #ExistingCodes ec WHERE ec.Code = s.Code
                 ))
          );';

        SET @Params = N'@pBatchId INT, @pEntityId INT, @pUserId INT';
        EXEC sp_executesql @SQL, @Params,
            @pBatchId = @NewBatchId, @pEntityId = @EntityId, @pUserId = @UserId;

        -- Back-fill StagingRowId into #NewRowIds
        SET @SQL = N'
        UPDATE nr
        SET nr.StagingRowId = s.Id
        FROM #NewRowIds nr
        JOIN ' + @StagingTable + N' s
            ON s.Code = nr.StagingCode
           AND s.BatchId = @pBatchId
           AND s.ImportStatus = 3;';

        SET @Params = N'@pBatchId INT';
        EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId;

        SET @InsertCount = (SELECT COUNT(*) FROM #NewRowIds);

        -- For each attribute: INSERT EntityValues for newly inserted rows
        DECLARE insert_attr_cursor CURSOR LOCAL FAST_FORWARD FOR
            SELECT
                a.Id,
                a.Name,
                a.DataType,
                a.DomainEntityId,
                CASE WHEN ISNULL(sfr.MergeMode, 'auto') = 'auto' THEN LOWER(@DefaultMergeMode) ELSE sfr.MergeMode END
            FROM Attributes a
            LEFT JOIN StagingFieldRules sfr
                ON sfr.EntityId = @EntityId AND sfr.AttributeId = a.Id
            WHERE a.EntityId     = @EntityId
              AND a.IsSystemDate  = 0
              AND a.IsHidden      = 0
              AND a.IsCode        = 0
              AND a.IsName        = 0
            ORDER BY a.SortOrder, a.Name;

        OPEN insert_attr_cursor;
        FETCH NEXT FROM insert_attr_cursor INTO
            @AttrId, @AttrName, @AttrDataType, @AttrDomainEntityId, @AttrMergeMode;

        WHILE @@FETCH_STATUS = 0
        BEGIN
            IF @AttrMergeMode = 'ignore'
            BEGIN
                FETCH NEXT FROM insert_attr_cursor INTO
                    @AttrId, @AttrName, @AttrDataType, @AttrDomainEntityId, @AttrMergeMode;
                CONTINUE;
            END;

            DECLARE @InsValCol   NVARCHAR(50),
                    @InsCastExpr NVARCHAR(500);

            SELECT
                @InsValCol = CASE @AttrDataType
                    WHEN 'Text'     THEN 'TextValue'
                    WHEN 'Int'      THEN 'IntValue'
                    WHEN 'Boolean'  THEN 'IntValue'
                    WHEN 'Decimal'  THEN 'DecimalValue'
                    WHEN 'DateTime' THEN 'DateTimeValue'
                    WHEN 'Domain'   THEN 'DomainValue'
                END,
                @InsCastExpr = CASE @AttrDataType
                    WHEN 'Text'     THEN N's.' + QUOTENAME(@AttrName)
                    WHEN 'Int'      THEN N'CAST(s.' + QUOTENAME(@AttrName) + N' AS INT)'
                    WHEN 'Boolean'  THEN N'CASE WHEN s.' + QUOTENAME(@AttrName) + N' IN (''1'',''true'',''yes'',''True'',''Yes'') THEN 1 ELSE 0 END'
                    WHEN 'Decimal'  THEN N'CAST(s.' + QUOTENAME(@AttrName) + N' AS DECIMAL(18,6))'
                    WHEN 'DateTime' THEN N'CAST(s.' + QUOTENAME(@AttrName) + N' AS DATETIME2)'
                    WHEN 'Domain'   THEN N'(SELECT dr.Id FROM EntityRows dr WHERE dr.EntityId = ' + CAST(@AttrDomainEntityId AS NVARCHAR(10)) + N' AND dr.Code = s.' + QUOTENAME(@AttrName) + N')'
                END;

            IF @InsValCol IS NULL OR @InsCastExpr IS NULL
            BEGIN
                FETCH NEXT FROM insert_attr_cursor INTO
                    @AttrId, @AttrName, @AttrDataType, @AttrDomainEntityId, @AttrMergeMode;
                CONTINUE;
            END;

            -- Determine sentinel condition (only for overwrite_with_sentinel mode)
            DECLARE @SentinelCheckExpr NVARCHAR(500) = N'';
            IF @AttrMergeMode = 'overwrite_with_sentinel'
            BEGIN
                SET @SentinelCheckExpr = CASE @AttrDataType
                    WHEN 'Text'     THEN N' AND s.' + QUOTENAME(@AttrName) + N' <> @pSentinelText'
                    WHEN 'Domain'   THEN N' AND s.' + QUOTENAME(@AttrName) + N' <> @pSentinelText'
                    WHEN 'Boolean'  THEN N' AND s.' + QUOTENAME(@AttrName) + N' <> @pSentinelText'
                    WHEN 'Int'      THEN N' AND TRY_CAST(s.' + QUOTENAME(@AttrName) + N' AS DECIMAL(38,0)) <> @pSentinelNum'
                    WHEN 'Decimal'  THEN N' AND TRY_CAST(s.' + QUOTENAME(@AttrName) + N' AS DECIMAL(38,0)) <> @pSentinelNum'
                    WHEN 'DateTime' THEN N' AND s.' + QUOTENAME(@AttrName) + N' <> @pSentinelDT'
                    ELSE N''
                END;
            END;

            SET @SQL = N'
            INSERT INTO EntityValues (EntityRowId, AttributeId, ' + @InsValCol + N')
            SELECT nr.EntityRowId, @pAttrId, ' + @InsCastExpr + N'
            FROM ' + @StagingTable + N' s
            JOIN #NewRowIds nr ON nr.StagingCode = s.Code
            WHERE s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL'
              + @SentinelCheckExpr + N';';

            SET @Params = N'@pBatchId INT, @pAttrId INT, @pSentinelText NVARCHAR(20), @pSentinelNum DECIMAL(38,0), @pSentinelDT NVARCHAR(30)';
            EXEC sp_executesql @SQL, @Params,
                @pBatchId = @NewBatchId, @pAttrId = @AttrId,
                @pSentinelText = @SentinelText, @pSentinelNum = @SentinelNumber, @pSentinelDT = @SentinelDT;

            FETCH NEXT FROM insert_attr_cursor INTO
                @AttrId, @AttrName, @AttrDataType, @AttrDomainEntityId, @AttrMergeMode;
        END;

        CLOSE insert_attr_cursor;
        DEALLOCATE insert_attr_cursor;

        -- ==========================================
        -- STEP 5: PROCESS UPDATES
        -- ==========================================
        -- Rows that need updating:
        --   ImportAction=2 (update-only, code must exist)
        --   ImportAction=0 (upsert, code IS in #ExistingCodes)

        SET @UpdateCount = 0;

        -- Update EntityRows.Name and ModifiedAt/ModifiedBy for updated records
        -- Name is a system column in the staging table (like Code)
        SET @SQL = N'
        UPDATE er
        SET er.Name       = ISNULL(s.[Name], er.Name),
            er.ModifiedAt = GETUTCDATE(),
            er.ModifiedBy = @pUserId
        FROM EntityRows er
        JOIN #ExistingCodes ec ON ec.EntityRowId = er.Id
        JOIN ' + @StagingTable + N' s ON s.Code = ec.Code
        WHERE s.BatchId = @pBatchId
          AND s.ImportStatus = 3
          AND s.ImportAction IN (0,2);

        SELECT @pUpdateCount = COUNT(*)
        FROM ' + @StagingTable + N' s
        WHERE s.BatchId = @pBatchId
          AND s.ImportStatus = 3
          AND s.ImportAction IN (0,2)
          AND EXISTS (SELECT 1 FROM #ExistingCodes ec WHERE ec.Code = s.Code);';

        SET @Params = N'@pBatchId INT, @pUserId INT, @pUpdateCount INT OUTPUT';
        EXEC sp_executesql @SQL, @Params,
            @pBatchId = @NewBatchId, @pUserId = @UserId,
            @pUpdateCount = @UpdateCount OUTPUT;

        -- Per-attribute update with merge mode logic
        DECLARE update_attr_cursor CURSOR LOCAL FAST_FORWARD FOR
            SELECT
                a.Id,
                a.Name,
                a.DataType,
                a.DomainEntityId,
                CASE WHEN ISNULL(sfr.MergeMode, 'auto') = 'auto' THEN LOWER(@DefaultMergeMode) ELSE sfr.MergeMode END
            FROM Attributes a
            LEFT JOIN StagingFieldRules sfr
                ON sfr.EntityId = @EntityId AND sfr.AttributeId = a.Id
            WHERE a.EntityId     = @EntityId
              AND a.IsSystemDate  = 0
              AND a.IsHidden      = 0
              AND a.IsCode        = 0
              AND a.IsName        = 0
            ORDER BY a.SortOrder, a.Name;

        OPEN update_attr_cursor;
        FETCH NEXT FROM update_attr_cursor INTO
            @AttrId, @AttrName, @AttrDataType, @AttrDomainEntityId, @AttrMergeMode;

        WHILE @@FETCH_STATUS = 0
        BEGIN
            IF @AttrMergeMode = 'ignore'
            BEGIN
                FETCH NEXT FROM update_attr_cursor INTO
                    @AttrId, @AttrName, @AttrDataType, @AttrDomainEntityId, @AttrMergeMode;
                CONTINUE;
            END;

            DECLARE @UpdValCol   NVARCHAR(50),
                    @UpdCastExpr NVARCHAR(500);

            SELECT
                @UpdValCol = CASE @AttrDataType
                    WHEN 'Text'     THEN 'TextValue'
                    WHEN 'Int'      THEN 'IntValue'
                    WHEN 'Boolean'  THEN 'IntValue'
                    WHEN 'Decimal'  THEN 'DecimalValue'
                    WHEN 'DateTime' THEN 'DateTimeValue'
                    WHEN 'Domain'   THEN 'DomainValue'
                END,
                @UpdCastExpr = CASE @AttrDataType
                    WHEN 'Text'     THEN N's.' + QUOTENAME(@AttrName)
                    WHEN 'Int'      THEN N'CAST(s.' + QUOTENAME(@AttrName) + N' AS INT)'
                    WHEN 'Boolean'  THEN N'CASE WHEN s.' + QUOTENAME(@AttrName) + N' IN (''1'',''true'',''yes'',''True'',''Yes'') THEN 1 ELSE 0 END'
                    WHEN 'Decimal'  THEN N'CAST(s.' + QUOTENAME(@AttrName) + N' AS DECIMAL(18,6))'
                    WHEN 'DateTime' THEN N'CAST(s.' + QUOTENAME(@AttrName) + N' AS DATETIME2)'
                    WHEN 'Domain'   THEN N'(SELECT dr.Id FROM EntityRows dr WHERE dr.EntityId = ' + CAST(ISNULL(@AttrDomainEntityId, 0) AS NVARCHAR(10)) + N' AND dr.Code = s.' + QUOTENAME(@AttrName) + N')'
                END;

            IF @UpdValCol IS NULL OR @UpdCastExpr IS NULL
            BEGIN
                FETCH NEXT FROM update_attr_cursor INTO
                    @AttrId, @AttrName, @AttrDataType, @AttrDomainEntityId, @AttrMergeMode;
                CONTINUE;
            END;

            -- Build WHERE clause for staging value filter based on MergeMode
            DECLARE @StgNullFilter NVARCHAR(200);
            SET @StgNullFilter = CASE @AttrMergeMode
                WHEN 'overwrite'              THEN N'AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL '
                WHEN 'overwrite_all'          THEN N''  -- include NULLs to clear production
                WHEN 'fill_empty'             THEN N'AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL '
                WHEN 'overwrite_with_sentinel' THEN N'AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL '
                ELSE                               N'AND s.' + QUOTENAME(@AttrName) + N' IS NOT NULL '
            END;

            -- Extra filter for fill_empty: only fill if production column is NULL
            DECLARE @FillEmptyFilter NVARCHAR(200);
            SET @FillEmptyFilter = CASE @AttrMergeMode
                WHEN 'fill_empty' THEN N'AND (ev.' + @UpdValCol + N' IS NULL) '
                ELSE N''
            END;

            -- Sentinel value resolution for overwrite_with_sentinel
            -- If staging value = sentinel → write NULL; otherwise write value
            DECLARE @SentinelUpdateExpr NVARCHAR(500);
            IF @AttrMergeMode = 'overwrite_with_sentinel'
            BEGIN
                SET @SentinelUpdateExpr = CASE @AttrDataType
                    WHEN 'Text'     THEN N'CASE WHEN s.' + QUOTENAME(@AttrName) + N' = @pSentinelText THEN NULL ELSE ' + @UpdCastExpr + N' END'
                    WHEN 'Domain'   THEN N'CASE WHEN s.' + QUOTENAME(@AttrName) + N' = @pSentinelText THEN NULL ELSE ' + @UpdCastExpr + N' END'
                    WHEN 'Boolean'  THEN N'CASE WHEN s.' + QUOTENAME(@AttrName) + N' = @pSentinelText THEN NULL ELSE ' + @UpdCastExpr + N' END'
                    WHEN 'Int'      THEN N'CASE WHEN TRY_CAST(s.' + QUOTENAME(@AttrName) + N' AS DECIMAL(38,0)) = @pSentinelNum THEN NULL ELSE ' + @UpdCastExpr + N' END'
                    WHEN 'Decimal'  THEN N'CASE WHEN TRY_CAST(s.' + QUOTENAME(@AttrName) + N' AS DECIMAL(38,0)) = @pSentinelNum THEN NULL ELSE ' + @UpdCastExpr + N' END'
                    WHEN 'DateTime' THEN N'CASE WHEN s.' + QUOTENAME(@AttrName) + N' = @pSentinelDT THEN NULL ELSE ' + @UpdCastExpr + N' END'
                    ELSE @UpdCastExpr
                END;
            END
            ELSE
            BEGIN
                SET @SentinelUpdateExpr = @UpdCastExpr;
            END;

            -- UPDATE existing EntityValues
            SET @SQL = N'
            UPDATE ev
            SET ev.' + @UpdValCol + N' = ' + @SentinelUpdateExpr + N'
            FROM EntityValues ev
            JOIN EntityRows er ON ev.EntityRowId = er.Id AND er.EntityId = @pEntityId
            JOIN #ExistingCodes ec ON ec.EntityRowId = er.Id
            JOIN ' + @StagingTable + N' s ON s.Code = ec.Code
            WHERE ev.AttributeId = @pAttrId
              AND s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.ImportAction IN (0,2)
              ' + @StgNullFilter +
              @FillEmptyFilter + N';

            -- INSERT EntityValues for rows that had no existing row for this attribute
            INSERT INTO EntityValues (EntityRowId, AttributeId, ' + @UpdValCol + N')
            SELECT ec.EntityRowId, @pAttrId, ' + @SentinelUpdateExpr + N'
            FROM #ExistingCodes ec
            JOIN ' + @StagingTable + N' s ON s.Code = ec.Code
            WHERE s.BatchId = @pBatchId
              AND s.ImportStatus = 3
              AND s.ImportAction IN (0,2)
              ' + @StgNullFilter + N'
              AND NOT EXISTS (
                  SELECT 1 FROM EntityValues ev2
                  WHERE ev2.EntityRowId = ec.EntityRowId
                    AND ev2.AttributeId = @pAttrId
              );';

            SET @Params = N'@pBatchId INT, @pAttrId INT, @pEntityId INT, @pSentinelText NVARCHAR(20), @pSentinelNum DECIMAL(38,0), @pSentinelDT NVARCHAR(30)';
            EXEC sp_executesql @SQL, @Params,
                @pBatchId = @NewBatchId, @pAttrId = @AttrId, @pEntityId = @EntityId,
                @pSentinelText = @SentinelText, @pSentinelNum = @SentinelNumber, @pSentinelDT = @SentinelDT;

            FETCH NEXT FROM update_attr_cursor INTO
                @AttrId, @AttrName, @AttrDataType, @AttrDomainEntityId, @AttrMergeMode;
        END;

        CLOSE update_attr_cursor;
        DEALLOCATE update_attr_cursor;

        -- Rename codes: apply NewCode to EntityRows for update/upsert rows
        -- Runs after attribute updates to avoid mid-update key conflicts
        SET @SQL = N'
        UPDATE er
        SET er.Code = s.NewCode
        FROM EntityRows er
        JOIN #ExistingCodes ec ON ec.EntityRowId = er.Id
        JOIN ' + @StagingTable + N' s ON s.Code = ec.Code
        WHERE s.BatchId = @pBatchId
          AND s.ImportStatus = 3
          AND s.ImportAction IN (0,2)
          AND s.NewCode IS NOT NULL
          AND LTRIM(RTRIM(s.NewCode)) <> ''''
          AND s.NewCode <> s.Code;';

        SET @Params = N'@pBatchId INT';
        EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId;

        -- ==========================================
        -- STEP 6: PROCESS DELETES
        -- ==========================================
        -- ImportAction 5 & 6 (cascade): null out DomainValue references first
        SET @SQL = N'
        UPDATE ev
        SET ev.DomainValue = NULL
        FROM EntityValues ev
        JOIN EntityRows er ON ev.DomainValue = er.Id
        JOIN ' + @StagingTable + N' s ON s.Code = er.Code
        WHERE er.EntityId  = @pEntityId
          AND s.BatchId    = @pBatchId
          AND s.ImportStatus = 3
          AND s.ImportAction IN (5,6);';

        SET @Params = N'@pBatchId INT, @pEntityId INT';
        EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId, @pEntityId = @EntityId;

        -- DELETE EntityRows (ImportAction 3,4,5,6)
        -- EntityValues are CASCADE deleted via FK
        SET @SQL = N'
        DELETE er
        FROM EntityRows er
        JOIN ' + @StagingTable + N' s ON s.Code = er.Code
        WHERE er.EntityId  = @pEntityId
          AND s.BatchId    = @pBatchId
          AND s.ImportStatus = 3
          AND s.ImportAction IN (3,4,5,6);';

        EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId, @pEntityId = @EntityId;

        SET @SQL = N'
        SELECT @pDeleteCount = COUNT(*)
        FROM ' + @StagingTable + N' s
        WHERE s.BatchId = @pBatchId
          AND s.ImportStatus = 3
          AND s.ImportAction IN (3,4,5,6);';

        SET @Params = N'@pBatchId INT, @pDeleteCount INT OUTPUT';
        EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId, @pDeleteCount = @DeleteCount OUTPUT;

        COMMIT;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;

        -- Mark all still-processing rows as Error
        SET @SQL = N'
        UPDATE s
        SET s.ImportStatus = 2,
            s.ErrorCode    = s.ErrorCode | 131072
        FROM ' + @StagingTable + N' s
        WHERE s.BatchId = @pBatchId
          AND s.ImportStatus = 3;';

        SET @Params = N'@pBatchId INT';
        EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId;

        -- Log catch error to StagingErrorDetails
        INSERT INTO StagingErrorDetails (BatchId, StagingRowId, Code, AttributeName, StagingValue, ErrorCode, ErrorMessage)
        SELECT @NewBatchId, 0, NULL, NULL, NULL, 0,
               LEFT('Fatal error during processing: ' + ERROR_MESSAGE(), 500);

        -- Mark batch as Failed
        UPDATE StagingBatches
        SET Status      = 5,
            CompletedAt = GETUTCDATE()
        WHERE Id = @NewBatchId;

        -- Rethrow so the caller sees the error
        THROW;
    END CATCH;

    -- ==========================================
    -- STEP 7: AUDIT LOG
    -- ==========================================

    -- Mark success rows (still in Processing state = no errors = processed OK)
    SET @SQL = N'
    UPDATE s
    SET s.ImportStatus = 1
    FROM ' + @StagingTable + N' s
    WHERE s.BatchId    = @pBatchId
      AND s.ImportStatus = 3;';

    SET @Params = N'@pBatchId INT';
    EXEC sp_executesql @SQL, @Params, @pBatchId = @NewBatchId;

    IF ISNULL(@InsertCount, 0) > 0
        EXEC usp_AuditLog_Write
            @EntityId   = @EntityId,
            @EntityName = @EntityName,
            @ModelName  = @ModelName,
            @Action     = 'import',
            @RecordCount = @InsertCount,
            @UserId     = @UserId,
            @Comment    = NULL,
            @Details    = NULL;

    IF ISNULL(@UpdateCount, 0) > 0
        EXEC usp_AuditLog_Write
            @EntityId   = @EntityId,
            @EntityName = @EntityName,
            @ModelName  = @ModelName,
            @Action     = 'edit',
            @RecordCount = @UpdateCount,
            @UserId     = @UserId,
            @Comment    = NULL,
            @Details    = NULL;

    IF ISNULL(@DeleteCount, 0) > 0
        EXEC usp_AuditLog_Write
            @EntityId   = @EntityId,
            @EntityName = @EntityName,
            @ModelName  = @ModelName,
            @Action     = 'delete',
            @RecordCount = @DeleteCount,
            @UserId     = @UserId,
            @Comment    = NULL,
            @Details    = NULL;

    -- ==========================================
    -- STEP 8: FINALIZE BATCH
    -- ==========================================

    SET @SQL = N'
    SELECT
        @pSuccessRows = SUM(CASE WHEN ImportStatus = 1 THEN 1 ELSE 0 END),
        @pErrorRows   = SUM(CASE WHEN ImportStatus = 2 THEN 1 ELSE 0 END)
    FROM ' + @StagingTable + N'
    WHERE BatchId = @pBatchId;';

    DECLARE @pSuccessRows INT = 0, @pErrorRows INT = 0;
    SET @Params = N'@pBatchId INT, @pSuccessRows INT OUTPUT, @pErrorRows INT OUTPUT';
    EXEC sp_executesql @SQL, @Params,
        @pBatchId = @NewBatchId,
        @pSuccessRows = @pSuccessRows OUTPUT,
        @pErrorRows = @pErrorRows OUTPUT;

    SET @SuccessRows = ISNULL(@pSuccessRows, 0);
    SET @ErrorRows   = ISNULL(@pErrorRows, 0);

    UPDATE StagingBatches
    SET
        Status      = CASE
                          WHEN @ErrorRows > 0 AND @SuccessRows > 0 THEN 4  -- CompletedWithErrors
                          WHEN @ErrorRows > 0 AND @SuccessRows = 0 THEN 5  -- Failed
                          ELSE 3                                            -- Completed
                      END,
        CompletedAt = GETUTCDATE(),
        TotalRows   = @TotalRows,
        SuccessRows = @SuccessRows,
        ErrorRows   = @ErrorRows
    WHERE Id = @NewBatchId;

    -- Return batch summary
    SELECT
        sb.Id           AS BatchId,
        sb.EntityId,
        @EntityName     AS EntityName,
        sb.Status,
        CASE sb.Status
            WHEN 3 THEN 'Completed'
            WHEN 4 THEN 'CompletedWithErrors'
            WHEN 5 THEN 'Failed'
            ELSE 'Unknown'
        END             AS StatusName,
        sb.TotalRows,
        sb.SuccessRows,
        sb.ErrorRows,
        sb.StartedAt,
        sb.CompletedAt,
        DATEDIFF(MILLISECOND, sb.StartedAt, sb.CompletedAt) AS DurationMs
    FROM StagingBatches sb
    WHERE sb.Id = @NewBatchId;

    -- Cleanup temp tables
    DROP TABLE IF EXISTS #EligibleIds;
    DROP TABLE IF EXISTS #ExistingCodes;
    DROP TABLE IF EXISTS #NewRowIds;
END;
GO

-- ============================================
-- STAGING UTILITY PROCEDURES
-- ============================================

-- ============================================
-- usp_Staging_GetBatches
-- Returns paginated batch history for an entity, plus total count.
-- ============================================
CREATE OR ALTER PROCEDURE usp_Staging_GetBatches
    @EntityId   INT,
    @PageSize   INT = 50,
    @PageNumber INT = 1
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        b.Id,
        b.BatchTag,
        b.Status,
        b.TotalRows,
        b.SuccessRows,
        b.ErrorRows,
        b.SkippedRows,
        b.StartedAt,
        b.CompletedAt,
        b.StartedBy,
        u.DisplayName AS StartedByName,
        b.CreatedAt,
        CASE b.Status
            WHEN 1 THEN 'Queued'
            WHEN 2 THEN 'Running'
            WHEN 3 THEN 'Completed'
            WHEN 4 THEN 'Completed with Errors'
            WHEN 5 THEN 'Failed'
        END AS StatusLabel
    FROM StagingBatches b
    LEFT JOIN Users u ON b.StartedBy = u.Id
    WHERE b.EntityId = @EntityId
    ORDER BY b.CreatedAt DESC
    OFFSET (@PageNumber - 1) * @PageSize ROWS FETCH NEXT @PageSize ROWS ONLY;

    -- Second result set: total count for pagination
    SELECT COUNT(*) AS TotalCount
    FROM StagingBatches
    WHERE EntityId = @EntityId;
END;
GO

-- ============================================
-- usp_Staging_GetErrors
-- Returns paginated error details for a batch, plus summary.
-- ============================================
CREATE OR ALTER PROCEDURE usp_Staging_GetErrors
    @BatchId    INT,
    @PageSize   INT = 100,
    @PageNumber INT = 1
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        e.Id,
        e.StagingRowId,
        e.Code,
        e.AttributeName,
        e.StagingValue,
        e.ErrorCode,
        e.ErrorMessage,
        e.CreatedAt
    FROM StagingErrorDetails e
    WHERE e.BatchId = @BatchId
    ORDER BY e.StagingRowId, e.AttributeName
    OFFSET (@PageNumber - 1) * @PageSize ROWS FETCH NEXT @PageSize ROWS ONLY;

    -- Second result set: total error count + batch summary
    SELECT
        COUNT(*) AS TotalErrors,
        b.TotalRows,
        b.SuccessRows,
        b.ErrorRows,
        b.SkippedRows,
        b.Status,
        b.BatchTag
    FROM StagingErrorDetails e
    JOIN StagingBatches b ON e.BatchId = b.Id
    WHERE e.BatchId = @BatchId
    GROUP BY
        b.TotalRows,
        b.SuccessRows,
        b.ErrorRows,
        b.SkippedRows,
        b.Status,
        b.BatchTag;
END;
GO

-- ============================================
-- usp_Staging_GetStagedRows
-- Returns paginated rows from the dynamic per-entity staging
-- table, plus row-count summary and column metadata.
-- ============================================
CREATE OR ALTER PROCEDURE usp_Staging_GetStagedRows
    @EntityId     INT,
    @ImportStatus TINYINT = NULL,  -- NULL = all statuses
    @BatchId      INT     = NULL,  -- NULL = all batches
    @PageSize     INT     = 50,
    @PageNumber   INT     = 1
AS
BEGIN
    SET NOCOUNT ON;

    -- 1. Verify staging is enabled for this entity
    IF NOT EXISTS (
        SELECT 1 FROM StagingConfigurations
        WHERE EntityId = @EntityId AND IsEnabled = 1
    )
    BEGIN
        RAISERROR('Staging is not enabled for this entity.', 16, 1);
        RETURN;
    END

    -- 2. Resolve staging table name
    DECLARE @StagingTable NVARCHAR(300) = dbo.fn_ResolveStagingTable(@EntityId);

    -- 3. Build comma-separated attribute column list
    DECLARE @AttrColumns NVARCHAR(MAX) = N'';

    SELECT @AttrColumns = @AttrColumns + N', ' + QUOTENAME(a.Name)
    FROM Attributes a
    WHERE a.EntityId = @EntityId
      AND a.IsSystemDate = 0
      AND a.IsHidden = 0
      AND a.IsCode = 0
      AND a.IsName = 0
    ORDER BY a.SortOrder;

    -- 4. Build WHERE clause fragments (parameterised via sp_executesql)
    DECLARE @WhereClause NVARCHAR(500) = N' WHERE 1 = 1';

    IF @ImportStatus IS NOT NULL
        SET @WhereClause = @WhereClause + N' AND ImportStatus = @p_ImportStatus';

    IF @BatchId IS NOT NULL
        SET @WhereClause = @WhereClause + N' AND BatchId = @p_BatchId';

    -- 5. Build and execute the main paged query
    DECLARE @PagedSQL NVARCHAR(MAX) =
        N'SELECT Id, ImportAction, ImportStatus, BatchId, BatchTag,'
        + N'       ErrorCode, Code, NewCode, SourceSystem, SourceTimestamp, CreatedAt'
        + @AttrColumns
        + N' FROM ' + @StagingTable
        + @WhereClause
        + N' ORDER BY Id'
        + N' OFFSET (@p_PageNumber - 1) * @p_PageSize ROWS'
        + N' FETCH NEXT @p_PageSize ROWS ONLY;';

    EXEC sp_executesql
        @PagedSQL,
        N'@p_ImportStatus TINYINT, @p_BatchId INT, @p_PageNumber INT, @p_PageSize INT',
        @p_ImportStatus = @ImportStatus,
        @p_BatchId      = @BatchId,
        @p_PageNumber   = @PageNumber,
        @p_PageSize     = @PageSize;

    -- 6. Summary counts (second result set)
    DECLARE @SummarySQL NVARCHAR(MAX) =
        N'SELECT'
        + N'    COUNT(*)                                             AS TotalRows,'
        + N'    SUM(CASE WHEN ImportStatus = 0 THEN 1 ELSE 0 END)  AS ReadyRows,'
        + N'    SUM(CASE WHEN ImportStatus = 1 THEN 1 ELSE 0 END)  AS OkRows,'
        + N'    SUM(CASE WHEN ImportStatus = 2 THEN 1 ELSE 0 END)  AS ErrorRows,'
        + N'    SUM(CASE WHEN ImportStatus = 3 THEN 1 ELSE 0 END)  AS ProcessingRows'
        + N' FROM ' + @StagingTable
        + @WhereClause + N';';

    EXEC sp_executesql
        @SummarySQL,
        N'@p_ImportStatus TINYINT, @p_BatchId INT',
        @p_ImportStatus = @ImportStatus,
        @p_BatchId      = @BatchId;

    -- 7. Column metadata (third result set) so the UI can render the grid
    SELECT
        a.Id          AS AttributeId,
        a.Name,
        a.DisplayName,
        a.DataType,
        a.SortOrder
    FROM Attributes a
    WHERE a.EntityId = @EntityId
      AND a.IsSystemDate = 0
      AND a.IsHidden = 0
      AND a.IsCode = 0
      AND a.IsName = 0
    ORDER BY a.SortOrder;
END;
GO

-- ============================================
-- usp_Staging_ClearBatch
-- Deletes staging rows (and related error details) for a batch.
-- @ClearStatus: 'all' | 'processed' | 'errors'
-- ============================================
CREATE OR ALTER PROCEDURE usp_Staging_ClearBatch
    @BatchId     INT,
    @ClearStatus NVARCHAR(20) = 'all'
AS
BEGIN
    SET NOCOUNT ON;

    -- 1. Validate @ClearStatus value
    IF @ClearStatus NOT IN ('all', 'processed', 'errors')
    BEGIN
        RAISERROR('Invalid @ClearStatus value. Must be ''all'', ''processed'', or ''errors''.', 16, 1);
        RETURN;
    END

    -- 2. Resolve EntityId from the batch record
    DECLARE @EntityId INT;
    SELECT @EntityId = EntityId FROM StagingBatches WHERE Id = @BatchId;

    IF @EntityId IS NULL
    BEGIN
        RAISERROR('Batch not found.', 16, 1);
        RETURN;
    END

    -- 3. Resolve staging table name
    DECLARE @StagingTable NVARCHAR(300) = dbo.fn_ResolveStagingTable(@EntityId);

    -- 4. Build WHERE clause based on clear mode
    DECLARE @StatusFilter NVARCHAR(200);

    IF @ClearStatus = 'all'
        SET @StatusFilter = N'';
    ELSE IF @ClearStatus = 'processed'
        SET @StatusFilter = N' AND ImportStatus = 1';
    ELSE -- 'errors'
        SET @StatusFilter = N' AND ImportStatus = 2';

    -- 5. For partial clears, remove matching error detail rows first
    --    (for 'all', CASCADE on the batch FK handles cleanup when batch is deleted)
    IF @ClearStatus IN ('processed', 'errors')
    BEGIN
        DECLARE @DeleteErrorsSQL NVARCHAR(MAX) =
            N'DELETE e'
            + N' FROM StagingErrorDetails e'
            + N' JOIN ' + @StagingTable + N' s ON e.StagingRowId = s.Id'
            + N' WHERE s.BatchId = @p_BatchId' + @StatusFilter + N';';

        EXEC sp_executesql
            @DeleteErrorsSQL,
            N'@p_BatchId INT',
            @p_BatchId = @BatchId;
    END

    -- 6. Delete matching rows from the staging table
    DECLARE @DeleteRowsSQL NVARCHAR(MAX) =
        N'DELETE FROM ' + @StagingTable
        + N' WHERE BatchId = @p_BatchId' + @StatusFilter + N';'
        + N' SELECT @@ROWCOUNT AS DeletedRows;';

    EXEC sp_executesql
        @DeleteRowsSQL,
        N'@p_BatchId INT',
        @p_BatchId = @BatchId;

    -- 7. If 'all', also remove the StagingErrorDetails and StagingBatches record
    IF @ClearStatus = 'all'
    BEGIN
        DELETE FROM StagingErrorDetails WHERE BatchId = @BatchId;
        DELETE FROM StagingBatches      WHERE Id      = @BatchId;
    END
END;
GO

-- ============================================
-- usp_Staging_ClearBatchHistory
-- Removes finished batch history for one entity: the batch records,
-- their error details (via the CASCADE on StagingErrorDetails.BatchId)
-- and their rows in the entity's staging table.
--
-- Batches still QueuedToRun (1) or Running (2) are left alone — clearing
-- history must never delete work that is in flight.
--
-- Change History:
--   v1.0  2026-07-28  Initial version. The route DELETE /api/staging/:entityId/history
--                     has called this procedure since the staging feature shipped, but
--                     it was never created — every call failed with "Could not find
--                     stored procedure". Found by E2E journey J28 (HIST-05).
-- ============================================
CREATE OR ALTER PROCEDURE usp_Staging_ClearBatchHistory
    @EntityId INT
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM Entities WHERE Id = @EntityId)
    BEGIN
        RAISERROR('Entity not found.', 16, 1);
        RETURN;
    END

    -- Pin the set of finished batches once: 3 = Completed, 4 = CompletedWithErrors,
    -- 5 = Failed. Both delete steps below work from this snapshot rather than
    -- re-evaluating Status, so a batch that finishes while this procedure runs is
    -- simply left for the next run instead of having its rows and its batch record
    -- deleted by different steps.
    -- A #temp table, not a table variable: the dynamic SQL below must be able to see it,
    -- and passing a table variable would need a user-defined table type this schema has no
    -- other use for. Same pattern as usp_Permission_BulkSave.
    IF OBJECT_ID('tempdb..#FinishedBatches') IS NOT NULL DROP TABLE #FinishedBatches;
    CREATE TABLE #FinishedBatches (BatchId INT PRIMARY KEY);

    BEGIN TRANSACTION;
    BEGIN TRY
        INSERT INTO #FinishedBatches (BatchId)
        SELECT Id FROM StagingBatches
        WHERE EntityId = @EntityId
          AND Status IN (3, 4, 5);

        -- Remove the staged rows belonging to those batches first. The staging table is
        -- per-entity and may not exist (staging never enabled, or already disabled),
        -- so resolve and probe it before touching it.
        DECLARE @StagingTable NVARCHAR(300) = dbo.fn_ResolveStagingTable(@EntityId);

        IF OBJECT_ID(@StagingTable, 'U') IS NOT NULL
        BEGIN
            -- Joins the snapshot, not StagingBatches, so the same set decides both deletes.
            DECLARE @DeleteRowsSQL NVARCHAR(MAX) =
                N'DELETE s FROM ' + @StagingTable + N' s'
                + N' JOIN #FinishedBatches b ON b.BatchId = s.BatchId;';

            EXEC sp_executesql @DeleteRowsSQL;
        END

        -- Deleting the batch cascades to StagingErrorDetails.
        DELETE FROM StagingBatches
        WHERE Id IN (SELECT BatchId FROM #FinishedBatches);

        DECLARE @DeletedBatches INT = @@ROWCOUNT;
        COMMIT TRANSACTION;
        SELECT @DeletedBatches AS DeletedBatches;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

-- ============================================
-- usp_Scheduler_CalculateNextRun
-- Pure calculation: given a schedule config and an optional
-- last-run time, returns the next UTC datetime the scheduler
-- should fire. Called by SaveConfig and Dispatch.
-- ============================================
CREATE OR ALTER PROCEDURE usp_Scheduler_CalculateNextRun
    @ScheduleType       NVARCHAR(20),
    @IntervalMinutes    INT           = NULL,
    @RunTimes           NVARCHAR(200) = NULL,   -- Comma-separated HH:mm
    @RunDays            NVARCHAR(100) = NULL,   -- Comma-separated Mon,Tue,...
    @RunDaysOfMonth     NVARCHAR(100) = NULL,   -- Comma-separated 1,15,...
    @LastRun            DATETIME2     = NULL,
    @NextRun            DATETIME2     OUTPUT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-02
-- Description: Calculates the next UTC run time for a scheduler configuration.
--              Handles interval, daily, weekly, and monthly schedule types.
--              Pure calculation — no side effects, no table writes.
--
-- Change History:
--   v1.0  2026-03-02  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Now DATETIME2 = SYSUTCDATETIME();
    SET @NextRun = NULL;

    -- ----------------------------------------
    -- Interval: fire every N minutes from last run (or now if never run)
    -- ----------------------------------------
    IF @ScheduleType = 'interval'
    BEGIN
        DECLARE @BaseTime DATETIME2 = ISNULL(@LastRun, @Now);
        SET @NextRun = DATEADD(MINUTE, @IntervalMinutes, @BaseTime);
        -- If calculated time is already in the past, fire immediately (now)
        IF @NextRun < @Now SET @NextRun = @Now;
        RETURN;
    END;

    -- ----------------------------------------
    -- Daily: fire at each HH:mm time today or tomorrow.
    -- Walk each comma-separated RunTime value and find the earliest future slot.
    -- ----------------------------------------
    IF @ScheduleType = 'daily'
    BEGIN
        DECLARE @BestDaily DATETIME2 = NULL;
        DECLARE @TimeVal NVARCHAR(10);
        DECLARE @TimeCursor CURSOR;

        SET @TimeCursor = CURSOR LOCAL FAST_FORWARD FOR
            SELECT LTRIM(RTRIM(value)) FROM STRING_SPLIT(ISNULL(@RunTimes, '00:00'), ',');
        OPEN @TimeCursor;
        FETCH NEXT FROM @TimeCursor INTO @TimeVal;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            DECLARE @HH INT = CAST(LEFT(@TimeVal, 2) AS INT);
            DECLARE @MM INT = CAST(RIGHT(@TimeVal, 2) AS INT);
            -- Build candidate time for today and tomorrow
            DECLARE @TodayBase DATETIME2 = CAST(CAST(@Now AS DATE) AS DATETIME2);
            DECLARE @CandToday    DATETIME2 = DATEADD(MINUTE, @MM, DATEADD(HOUR, @HH, @TodayBase));
            DECLARE @CandTomorrow DATETIME2 = DATEADD(DAY, 1, @CandToday);
            -- Prefer today's slot if still in the future, otherwise use tomorrow
            DECLARE @Cand DATETIME2 = CASE WHEN @CandToday > @Now THEN @CandToday ELSE @CandTomorrow END;
            IF @BestDaily IS NULL OR @Cand < @BestDaily SET @BestDaily = @Cand;
            FETCH NEXT FROM @TimeCursor INTO @TimeVal;
        END;
        CLOSE @TimeCursor; DEALLOCATE @TimeCursor;
        SET @NextRun = @BestDaily;
        RETURN;
    END;

    -- ----------------------------------------
    -- Weekly: fire on specified days-of-week at specified times.
    -- Scan the next 7 days to find the earliest matching day+time.
    -- ----------------------------------------
    IF @ScheduleType = 'weekly'
    BEGIN
        DECLARE @BestWeekly DATETIME2 = NULL;
        DECLARE @DayOffset INT = 0;

        -- Map day abbreviations to SQL Server DATEPART(dw) values (assuming SET DATEFIRST 7 / Sunday=1)
        -- We'll use day name matching by comparing DATENAME(dw, candidate)
        WHILE @DayOffset <= 7
        BEGIN
            DECLARE @CandDate DATE = DATEADD(DAY, @DayOffset, CAST(@Now AS DATE));
            DECLARE @DayName NVARCHAR(10) = LEFT(DATENAME(dw, @CandDate), 3); -- Mon, Tue, ...

            -- Check if this day is in RunDays
            IF EXISTS (
                SELECT 1 FROM STRING_SPLIT(ISNULL(@RunDays, ''), ',')
                WHERE LTRIM(RTRIM(value)) = @DayName
            )
            BEGIN
                -- For each RunTime on this day, check if slot is in the future
                DECLARE @WkTimeCursor CURSOR;
                SET @WkTimeCursor = CURSOR LOCAL FAST_FORWARD FOR
                    SELECT LTRIM(RTRIM(value)) FROM STRING_SPLIT(ISNULL(@RunTimes, '00:00'), ',');
                OPEN @WkTimeCursor;
                DECLARE @WkTimeVal NVARCHAR(10);
                FETCH NEXT FROM @WkTimeCursor INTO @WkTimeVal;
                WHILE @@FETCH_STATUS = 0
                BEGIN
                    DECLARE @WkHH INT = CAST(LEFT(@WkTimeVal, 2) AS INT);
                    DECLARE @WkMM INT = CAST(RIGHT(@WkTimeVal, 2) AS INT);
                    DECLARE @WkCand DATETIME2 = DATEADD(MINUTE, @WkMM, DATEADD(HOUR, @WkHH, CAST(@CandDate AS DATETIME2)));
                    IF @WkCand > @Now AND (@BestWeekly IS NULL OR @WkCand < @BestWeekly)
                        SET @BestWeekly = @WkCand;
                    FETCH NEXT FROM @WkTimeCursor INTO @WkTimeVal;
                END;
                CLOSE @WkTimeCursor; DEALLOCATE @WkTimeCursor;
            END;
            SET @DayOffset = @DayOffset + 1;
        END;
        SET @NextRun = @BestWeekly;
        RETURN;
    END;

    -- ----------------------------------------
    -- Monthly: fire on specified days-of-month at specified times.
    -- Scan up to 32 days to find the next matching day+time.
    -- ----------------------------------------
    IF @ScheduleType = 'monthly'
    BEGIN
        DECLARE @BestMonthly DATETIME2 = NULL;
        DECLARE @MonOffset INT = 0;

        WHILE @MonOffset <= 32
        BEGIN
            DECLARE @MonCandDate DATE = DATEADD(DAY, @MonOffset, CAST(@Now AS DATE));
            DECLARE @DayOfMonth INT = DATEPART(DAY, @MonCandDate);

            IF EXISTS (
                SELECT 1 FROM STRING_SPLIT(ISNULL(@RunDaysOfMonth, ''), ',')
                WHERE LTRIM(RTRIM(value)) = CAST(@DayOfMonth AS NVARCHAR(3))
            )
            BEGIN
                DECLARE @MonTimeCursor CURSOR;
                SET @MonTimeCursor = CURSOR LOCAL FAST_FORWARD FOR
                    SELECT LTRIM(RTRIM(value)) FROM STRING_SPLIT(ISNULL(@RunTimes, '00:00'), ',');
                OPEN @MonTimeCursor;
                DECLARE @MonTimeVal NVARCHAR(10);
                FETCH NEXT FROM @MonTimeCursor INTO @MonTimeVal;
                WHILE @@FETCH_STATUS = 0
                BEGIN
                    DECLARE @MonHH INT = CAST(LEFT(@MonTimeVal, 2) AS INT);
                    DECLARE @MonMM INT = CAST(RIGHT(@MonTimeVal, 2) AS INT);
                    DECLARE @MonCand DATETIME2 = DATEADD(MINUTE, @MonMM, DATEADD(HOUR, @MonHH, CAST(@MonCandDate AS DATETIME2)));
                    IF @MonCand > @Now AND (@BestMonthly IS NULL OR @MonCand < @BestMonthly)
                        SET @BestMonthly = @MonCand;
                    FETCH NEXT FROM @MonTimeCursor INTO @MonTimeVal;
                END;
                CLOSE @MonTimeCursor; DEALLOCATE @MonTimeCursor;
            END;
            SET @MonOffset = @MonOffset + 1;
        END;
        SET @NextRun = @BestMonthly;
        RETURN;
    END;
END;
GO

-- ============================================
-- usp_Scheduler_GetConfig
-- Returns the scheduler configuration for an entity,
-- plus live queue stats (PendingRows, OldestRowAge).
-- ============================================
CREATE OR ALTER PROCEDURE usp_Scheduler_GetConfig
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-02
-- Description: Retrieves the SchedulerConfigurations row for the given entity
--              and appends live staging queue stats via dynamic SQL.
--              Returns an empty result set if no config exists.
--
-- Change History:
--   v1.0  2026-03-02  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- Resolve the staging table name for this entity so we can count pending rows
    DECLARE @StagingTable NVARCHAR(300) = dbo.fn_ResolveStagingTable(@EntityId);

    -- Count pending rows and oldest row age using dynamic SQL because the
    -- table name is stored as data (in StagingConfigurations.TableName).
    DECLARE @PendingRows INT = 0;
    DECLARE @OldestRowAge INT = NULL;

    -- Only query if the staging table actually exists on disk
    DECLARE @SafeName NVARCHAR(200);
    SELECT @SafeName = TableName FROM StagingConfigurations WHERE EntityId = @EntityId;

    IF @SafeName IS NOT NULL AND EXISTS (
        SELECT 1 FROM sys.tables t
        JOIN sys.schemas s ON s.schema_id = t.schema_id
        WHERE s.name = 'stg' AND t.name = @SafeName
    )
    BEGIN
        DECLARE @SQL NVARCHAR(1000) = N'
            SELECT
                @PendingRows  = COUNT(*),
                @OldestRowAge = DATEDIFF(MINUTE, MIN(CreatedAt), SYSUTCDATETIME())
            FROM ' + @StagingTable + N'
            WHERE ImportStatus = 0;';

        EXEC sp_executesql @SQL,
            N'@PendingRows INT OUTPUT, @OldestRowAge INT OUTPUT',
            @PendingRows  OUTPUT,
            @OldestRowAge OUTPUT;
    END;

    SELECT
        sc.Id,
        sc.EntityId,
        sc.ProcessingMode,
        sc.ScheduleType,
        sc.IntervalMinutes,
        sc.RunTimes,
        sc.RunDays,
        sc.RunDaysOfMonth,
        sc.TriggerOnNewRows,
        sc.TriggerRowThreshold,
        sc.TriggerIdleMinutes,
        sc.TriggerDebounceSeconds,
        sc.ZombieTimeoutMinutes,
        sc.IsRunning,
        sc.RunStartedAt,
        sc.RunStartedBy,
        sc.NextScheduledRun,
        sc.LastCompletedAt,
        sc.LastTriggerCheck,
        sc.IsEnabled,
        sc.CreatedAt,
        sc.ModifiedAt,
        @PendingRows  AS PendingRows,
        @OldestRowAge AS OldestRowAge
    FROM SchedulerConfigurations sc
    WHERE sc.EntityId = @EntityId;
END;
GO

-- ============================================
-- usp_Scheduler_SaveConfig
-- Upserts the scheduler configuration for an entity.
-- Enforces server-side validation on mode+trigger consistency.
-- Returns the same result set as GetConfig after saving.
-- ============================================
CREATE OR ALTER PROCEDURE usp_Scheduler_SaveConfig
    @EntityId               INT,
    @ProcessingMode         NVARCHAR(20),
    @ScheduleType           NVARCHAR(20)  = NULL,
    @IntervalMinutes        INT           = NULL,
    @RunTimes               NVARCHAR(200) = NULL,
    @RunDays                NVARCHAR(100) = NULL,
    @RunDaysOfMonth         NVARCHAR(100) = NULL,
    @TriggerOnNewRows       BIT           = 0,
    @TriggerRowThreshold    INT           = NULL,
    @TriggerIdleMinutes     INT           = NULL,
    @TriggerDebounceSeconds INT           = 60,
    @ZombieTimeoutMinutes   INT           = 30,
    @IsEnabled              BIT           = 1
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-02
-- Description: Creates or updates the SchedulerConfigurations row for an entity.
--              Validates that mode-specific fields are supplied, clears stale
--              fields when switching modes, calculates NextScheduledRun, and
--              returns the full config row via GetConfig.
--
-- Change History:
--   v1.0  2026-03-02  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- ----------------------------------------
    -- Server-side validation: enforce required fields per mode.
    -- These rules are also enforced in the UI, but the SP is the
    -- authoritative gate so bad payloads (e.g. direct API calls) are rejected.
    -- ----------------------------------------
    IF @ProcessingMode = 'scheduled' AND @ScheduleType IS NULL
        THROW 50001, 'ScheduleType is required when ProcessingMode is scheduled', 1;

    IF @ProcessingMode = 'triggered'
       AND @TriggerOnNewRows = 0
       AND @TriggerRowThreshold IS NULL
       AND @TriggerIdleMinutes IS NULL
        THROW 50001, 'At least one trigger must be configured when ProcessingMode is triggered', 1;

    IF @ZombieTimeoutMinutes < 5 OR @ZombieTimeoutMinutes > 480
        THROW 50001, 'ZombieTimeoutMinutes must be between 5 and 480', 1;

    -- ----------------------------------------
    -- Clear stale fields when switching to manual — prevents a leftover
    -- schedule config from accidentally firing after the user disables it.
    -- ----------------------------------------
    IF @ProcessingMode = 'manual'
    BEGIN
        SET @ScheduleType        = NULL;
        SET @IntervalMinutes     = NULL;
        SET @RunTimes            = NULL;
        SET @RunDays             = NULL;
        SET @RunDaysOfMonth      = NULL;
        SET @TriggerOnNewRows    = 0;
        SET @TriggerRowThreshold = NULL;
        SET @TriggerIdleMinutes  = NULL;
    END;

    -- ----------------------------------------
    -- Calculate NextScheduledRun when mode is scheduled.
    -- Cleared to NULL for non-scheduled modes.
    -- ----------------------------------------
    DECLARE @NextRun DATETIME2 = NULL;
    IF @ProcessingMode = 'scheduled'
    BEGIN
        DECLARE @LastRun DATETIME2;
        SELECT @LastRun = LastCompletedAt FROM SchedulerConfigurations WHERE EntityId = @EntityId;

        EXEC usp_Scheduler_CalculateNextRun
            @ScheduleType    = @ScheduleType,
            @IntervalMinutes = @IntervalMinutes,
            @RunTimes        = @RunTimes,
            @RunDays         = @RunDays,
            @RunDaysOfMonth  = @RunDaysOfMonth,
            @LastRun         = @LastRun,
            @NextRun         = @NextRun OUTPUT;
    END;

    -- ----------------------------------------
    -- UPSERT: insert on first save, update on subsequent saves.
    -- @@TRANCOUNT guard ensures we don't double-open when called from Dispatch.
    -- ----------------------------------------
    DECLARE @OwnTransaction BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRANSACTION; SET @OwnTransaction = 1; END

    BEGIN TRY
        IF EXISTS (SELECT 1 FROM SchedulerConfigurations WHERE EntityId = @EntityId)
        BEGIN
            UPDATE SchedulerConfigurations SET
                ProcessingMode         = @ProcessingMode,
                ScheduleType           = @ScheduleType,
                IntervalMinutes        = @IntervalMinutes,
                RunTimes               = @RunTimes,
                RunDays                = @RunDays,
                RunDaysOfMonth         = @RunDaysOfMonth,
                TriggerOnNewRows       = @TriggerOnNewRows,
                TriggerRowThreshold    = @TriggerRowThreshold,
                TriggerIdleMinutes     = @TriggerIdleMinutes,
                TriggerDebounceSeconds = @TriggerDebounceSeconds,
                ZombieTimeoutMinutes   = @ZombieTimeoutMinutes,
                IsEnabled              = @IsEnabled,
                NextScheduledRun       = @NextRun,
                ModifiedAt             = SYSUTCDATETIME()
            WHERE EntityId = @EntityId;
        END
        ELSE
        BEGIN
            INSERT INTO SchedulerConfigurations (
                EntityId, ProcessingMode, ScheduleType, IntervalMinutes,
                RunTimes, RunDays, RunDaysOfMonth,
                TriggerOnNewRows, TriggerRowThreshold, TriggerIdleMinutes,
                TriggerDebounceSeconds, ZombieTimeoutMinutes, IsEnabled, NextScheduledRun
            )
            VALUES (
                @EntityId, @ProcessingMode, @ScheduleType, @IntervalMinutes,
                @RunTimes, @RunDays, @RunDaysOfMonth,
                @TriggerOnNewRows, @TriggerRowThreshold, @TriggerIdleMinutes,
                @TriggerDebounceSeconds, @ZombieTimeoutMinutes, @IsEnabled, @NextRun
            );
        END;

        IF @OwnTransaction = 1 COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @OwnTransaction = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;

    -- Return the saved config using GetConfig (includes live queue stats)
    EXEC usp_Scheduler_GetConfig @EntityId = @EntityId;
END;
GO

-- ============================================
-- usp_Scheduler_GetLog
-- Returns paginated scheduler history for an entity.
-- Result set 1: log rows ordered by EventTime DESC.
-- Result set 2: total count for pagination.
-- ============================================
CREATE OR ALTER PROCEDURE usp_Scheduler_GetLog
    @EntityId   INT,
    @PageSize   INT = 50,
    @PageNumber INT = 1
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-02
-- Description: Returns paginated SchedulerLog rows for the given entity,
--              most-recent-first, with a total count result set for the UI.
--
-- Change History:
--   v1.0  2026-03-02  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Offset INT = (@PageNumber - 1) * @PageSize;

    -- Result set 1: paginated log rows
    SELECT
        sl.Id,
        sl.EntityId,
        sl.EventTime,
        sl.EventType,
        sl.TriggerSource,
        sl.Message,
        sl.RowsQueued,
        sl.DurationMs,
        sl.BatchId
    FROM SchedulerLog sl
    WHERE sl.EntityId = @EntityId
    ORDER BY sl.EventTime DESC
    OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY;

    -- Result set 2: total count for pagination controls
    SELECT COUNT(*) AS TotalCount
    FROM SchedulerLog
    WHERE EntityId = @EntityId;
END;
GO

-- ============================================
-- usp_SchedulerLog_Cleanup
-- Removes old SchedulerLog entries to prevent unbounded growth.
-- ============================================
CREATE OR ALTER PROCEDURE usp_SchedulerLog_Cleanup
    @RetentionDays INT = 30
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-02
-- Description: Removes scheduler log entries older than @RetentionDays
--              (default 30 days).
--
-- Change History:
--   v1.0  2026-03-02  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM SchedulerLog WHERE EventTime < DATEADD(DAY, -@RetentionDays, GETUTCDATE());
    SELECT @@ROWCOUNT AS DeletedCount;
END;
GO

-- ============================================
-- usp_Maintenance_Cleanup
-- Master cleanup SP called by the Primentra_Scheduler SQL Agent job.
-- Reads retention settings from AppSettings and runs all cleanup SPs.
-- ============================================
CREATE OR ALTER PROCEDURE usp_Maintenance_Cleanup
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-02
-- Description: Reads retention days from AppSettings and runs all
--              cleanup SPs in sequence:
--                - usp_AuditLog_Cleanup      (auditRetentionDays, default 90)
--                - usp_Approval_Cleanup       (approvalRetentionDays, default 365)
--                - usp_ErrorLog_Cleanup       (errorLogRetentionDays, default 30)
--                - usp_SchedulerLog_Cleanup   (schedulerLogRetentionDays, default 30)
--                - usp_Import_CleanupStaging  (stagingRetentionDays, default 7)
--              Called every 60 seconds by the SQL Agent job but the
--              DELETEs are cheap no-ops when there is nothing to purge.
--
-- Change History:
--   v1.0  2026-03-02  Initial version
--   v1.1  2026-03-02  Read stagingRetentionDays from AppSettings
--   v1.2  2026-03-02  Dedicated schedulerLogRetentionDays (decoupled from errorLog)
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @AuditDays        INT;
    DECLARE @ApprovalDays     INT;
    DECLARE @ErrorLogDays     INT;
    DECLARE @SchedulerLogDays INT;
    DECLARE @StagingDays      INT;

    -- Read configured retention from AppSettings
    SELECT @AuditDays = TRY_CAST(SettingValue AS INT)
    FROM AppSettings WHERE SettingKey = 'auditRetentionDays';

    SELECT @ApprovalDays = TRY_CAST(SettingValue AS INT)
    FROM AppSettings WHERE SettingKey = 'approvalRetentionDays';

    SELECT @ErrorLogDays = TRY_CAST(SettingValue AS INT)
    FROM AppSettings WHERE SettingKey = 'errorLogRetentionDays';

    SELECT @SchedulerLogDays = TRY_CAST(SettingValue AS INT)
    FROM AppSettings WHERE SettingKey = 'schedulerLogRetentionDays';

    SELECT @StagingDays = TRY_CAST(SettingValue AS INT)
    FROM AppSettings WHERE SettingKey = 'stagingRetentionDays';

    -- Fall back to defaults if not configured
    SET @AuditDays        = ISNULL(@AuditDays, 90);
    SET @ApprovalDays     = ISNULL(@ApprovalDays, 365);
    SET @ErrorLogDays     = ISNULL(@ErrorLogDays, 30);
    SET @SchedulerLogDays = ISNULL(@SchedulerLogDays, 30);
    SET @StagingDays      = ISNULL(@StagingDays, 7);

    -- Capture results from each cleanup SP
    DECLARE @Results TABLE (CleanupName NVARCHAR(50), DeletedCount INT, RetentionDays INT, CutoffDate NVARCHAR(30));
    DECLARE @Deleted INT;

    -- Audit Log
    DECLARE @AuditResult TABLE (DeletedCount INT);
    INSERT INTO @AuditResult EXEC usp_AuditLog_Cleanup @RetentionDays = @AuditDays;
    SELECT @Deleted = ISNULL(DeletedCount, 0) FROM @AuditResult;
    INSERT INTO @Results VALUES ('Audit Log', @Deleted, @AuditDays, CONVERT(NVARCHAR(30), DATEADD(DAY, -@AuditDays, GETUTCDATE()), 120));

    -- Approval Data
    DECLARE @ApprovalResult TABLE (DeletedCount INT);
    INSERT INTO @ApprovalResult EXEC usp_Approval_Cleanup @RetentionDays = @ApprovalDays;
    SELECT @Deleted = ISNULL(DeletedCount, 0) FROM @ApprovalResult;
    INSERT INTO @Results VALUES ('Approval Data', @Deleted, @ApprovalDays, CONVERT(NVARCHAR(30), DATEADD(DAY, -@ApprovalDays, GETUTCDATE()), 120));

    -- Error Log
    DECLARE @ErrorResult TABLE (DeletedCount INT);
    INSERT INTO @ErrorResult EXEC usp_ErrorLog_Cleanup @RetentionDays = @ErrorLogDays;
    SELECT @Deleted = ISNULL(DeletedCount, 0) FROM @ErrorResult;
    INSERT INTO @Results VALUES ('Error Log', @Deleted, @ErrorLogDays, CONVERT(NVARCHAR(30), DATEADD(DAY, -@ErrorLogDays, GETUTCDATE()), 120));

    -- Scheduler Log
    DECLARE @SchedulerResult TABLE (DeletedCount INT);
    INSERT INTO @SchedulerResult EXEC usp_SchedulerLog_Cleanup @RetentionDays = @SchedulerLogDays;
    SELECT @Deleted = ISNULL(DeletedCount, 0) FROM @SchedulerResult;
    INSERT INTO @Results VALUES ('Scheduler Log', @Deleted, @SchedulerLogDays, CONVERT(NVARCHAR(30), DATEADD(DAY, -@SchedulerLogDays, GETUTCDATE()), 120));

    -- Staging Data
    DECLARE @StagingResult TABLE (DeletedCount INT);
    INSERT INTO @StagingResult EXEC usp_Import_CleanupStaging @RetentionDays = @StagingDays;
    SELECT @Deleted = ISNULL(DeletedCount, 0) FROM @StagingResult;
    INSERT INTO @Results VALUES ('Staging Data', @Deleted, @StagingDays, CONVERT(NVARCHAR(30), DATEADD(DAY, -@StagingDays, GETUTCDATE()), 120));

    -- Log only when records were actually deleted (skip no-op runs to avoid log noise)
    INSERT INTO SchedulerLog (EntityId, EventType, Message)
    SELECT 0, 'cleanup',
        '[' + CleanupName + '] Cleaned ' + CAST(DeletedCount AS NVARCHAR(20)) + ' records (retention: '
            + CAST(RetentionDays AS NVARCHAR(10)) + ' days). Everything before '
            + CutoffDate + ' was removed.'
    FROM @Results
    WHERE DeletedCount > 0;

    -- Return descriptive summary
    SELECT
        CleanupName,
        DeletedCount,
        RetentionDays,
        CutoffDate,
        '[' + CleanupName + '] Cleaned ' + CAST(DeletedCount AS NVARCHAR(20)) + ' records (retention: '
            + CAST(RetentionDays AS NVARCHAR(10)) + ' days). Everything before '
            + CutoffDate + ' was removed.' AS Message
    FROM @Results;
END;
GO

-- ============================================
-- usp_Scheduler_TestRun
-- Dry-run: simulates what the dispatcher would do for this entity
-- right now. Returns WouldFire, Reason, and queue stats.
-- No side effects — nothing is modified.
-- ============================================
CREATE OR ALTER PROCEDURE usp_Scheduler_TestRun
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-02
-- Description: Simulates one dispatcher cycle for the given entity and reports
--              what would happen without actually firing a batch. Used by the
--              UI "Test" button so users can validate their schedule config.
--
-- Change History:
--   v1.0  2026-03-02  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE
        @WouldFire      BIT           = 0,
        @Reason         NVARCHAR(200) = NULL,
        @PendingRows    INT           = 0,
        @OldestRowAge   INT           = NULL,
        @NextScheduledRun DATETIME2   = NULL;

    -- Load config
    DECLARE
        @ProcessingMode         NVARCHAR(20),
        @ScheduleType           NVARCHAR(20),
        @IntervalMinutes        INT,
        @RunTimes               NVARCHAR(200),
        @RunDays                NVARCHAR(100),
        @RunDaysOfMonth         NVARCHAR(100),
        @TriggerOnNewRows       BIT,
        @TriggerRowThreshold    INT,
        @TriggerIdleMinutes     INT,
        @TriggerDebounceSeconds INT,
        @ZombieTimeoutMinutes   INT,
        @IsRunning              BIT,
        @RunStartedAt           DATETIME2,
        @IsEnabled              BIT,
        @LastTriggerCheck       DATETIME2,
        @LastCompletedAt        DATETIME2;

    SELECT
        @ProcessingMode         = ProcessingMode,
        @ScheduleType           = ScheduleType,
        @IntervalMinutes        = IntervalMinutes,
        @RunTimes               = RunTimes,
        @RunDays                = RunDays,
        @RunDaysOfMonth         = RunDaysOfMonth,
        @TriggerOnNewRows       = TriggerOnNewRows,
        @TriggerRowThreshold    = TriggerRowThreshold,
        @TriggerIdleMinutes     = TriggerIdleMinutes,
        @TriggerDebounceSeconds = TriggerDebounceSeconds,
        @ZombieTimeoutMinutes   = ZombieTimeoutMinutes,
        @IsRunning              = IsRunning,
        @RunStartedAt           = RunStartedAt,
        @IsEnabled              = IsEnabled,
        @LastTriggerCheck       = LastTriggerCheck,
        @LastCompletedAt        = LastCompletedAt,
        @NextScheduledRun       = NextScheduledRun
    FROM SchedulerConfigurations
    WHERE EntityId = @EntityId;

    IF @ProcessingMode IS NULL
    BEGIN
        SELECT CAST(0 AS BIT) AS WouldFire, CAST('No scheduler config exists for this entity' AS NVARCHAR(200)) AS Reason,
               0 AS PendingRows, NULL AS OldestRowAge, NULL AS NextScheduledRun;
        RETURN;
    END;

    IF @IsEnabled = 0
    BEGIN
        SELECT CAST(0 AS BIT) AS WouldFire, CAST('Scheduler is disabled' AS NVARCHAR(200)) AS Reason,
               0 AS PendingRows, NULL AS OldestRowAge, @NextScheduledRun AS NextScheduledRun;
        RETURN;
    END;

    -- Overlap guard check
    IF @IsRunning = 1
    BEGIN
        IF @RunStartedAt < DATEADD(MINUTE, -@ZombieTimeoutMinutes, SYSUTCDATETIME())
            SET @Reason = 'Zombie batch detected (running >' + CAST(@ZombieTimeoutMinutes AS NVARCHAR(10)) + 'min) — would be released';
        ELSE
            SET @Reason = 'Batch already running — would skip (overlap guard)';
        SELECT CAST(0 AS BIT) AS WouldFire, @Reason AS Reason,
               0 AS PendingRows, NULL AS OldestRowAge, @NextScheduledRun AS NextScheduledRun;
        RETURN;
    END;

    -- Get live queue stats
    DECLARE @SafeName NVARCHAR(200);
    SELECT @SafeName = TableName FROM StagingConfigurations WHERE EntityId = @EntityId;

    IF @SafeName IS NOT NULL AND EXISTS (
        SELECT 1 FROM sys.tables t
        JOIN sys.schemas s ON s.schema_id = t.schema_id
        WHERE s.name = 'stg' AND t.name = @SafeName
    )
    BEGIN
        DECLARE @StatsSQL NVARCHAR(500) = N'
            SELECT @PendingRows = COUNT(*),
                   @OldestRowAge = DATEDIFF(MINUTE, MIN(CreatedAt), SYSUTCDATETIME())
            FROM stg.' + QUOTENAME(@SafeName) + N' WHERE ImportStatus = 0;';
        EXEC sp_executesql @StatsSQL,
            N'@PendingRows INT OUTPUT, @OldestRowAge INT OUTPUT',
            @PendingRows OUTPUT, @OldestRowAge OUTPUT;
    END;

    -- Evaluate scheduled mode
    IF @ProcessingMode = 'scheduled'
    BEGIN
        IF @NextScheduledRun IS NOT NULL AND @NextScheduledRun <= SYSUTCDATETIME()
        BEGIN
            SET @WouldFire = 1;
            SET @Reason = 'Scheduled run time has passed (NextScheduledRun: ' + CONVERT(NVARCHAR(30), @NextScheduledRun, 120) + ')';
        END
        ELSE
            SET @Reason = 'Next run not due yet. NextScheduledRun: ' + ISNULL(CONVERT(NVARCHAR(30), @NextScheduledRun, 120), 'not set');
    END;

    -- Evaluate triggered mode
    ELSE IF @ProcessingMode = 'triggered'
    BEGIN
        IF @TriggerRowThreshold IS NOT NULL AND @PendingRows >= @TriggerRowThreshold
        BEGIN
            SET @WouldFire = 1;
            SET @Reason = 'Row threshold met: ' + CAST(@PendingRows AS NVARCHAR(20)) + ' rows >= threshold ' + CAST(@TriggerRowThreshold AS NVARCHAR(20));
        END
        ELSE IF @TriggerIdleMinutes IS NOT NULL AND @PendingRows > 0 AND ISNULL(@OldestRowAge, 0) >= @TriggerIdleMinutes
        BEGIN
            SET @WouldFire = 1;
            SET @Reason = 'Idle timeout: oldest row has been waiting ' + CAST(ISNULL(@OldestRowAge, 0) AS NVARCHAR(20)) + ' minutes >= ' + CAST(@TriggerIdleMinutes AS NVARCHAR(20));
        END
        ELSE IF @TriggerOnNewRows = 1 AND @PendingRows > 0
        BEGIN
            DECLARE @DebounceElapsed BIT = 0;
            IF @LastTriggerCheck IS NULL OR DATEDIFF(SECOND, @LastTriggerCheck, SYSUTCDATETIME()) >= @TriggerDebounceSeconds
                SET @DebounceElapsed = 1;
            IF @DebounceElapsed = 1
            BEGIN
                SET @WouldFire = 1;
                SET @Reason = 'New rows detected (' + CAST(@PendingRows AS NVARCHAR(20)) + ') and debounce window elapsed';
            END
            ELSE
                SET @Reason = 'New rows detected but debounce window has not elapsed (' + CAST(DATEDIFF(SECOND, @LastTriggerCheck, SYSUTCDATETIME()) AS NVARCHAR(10)) + 's / ' + CAST(@TriggerDebounceSeconds AS NVARCHAR(10)) + 's)';
        END
        ELSE
            SET @Reason = 'No triggers met. Pending rows: ' + CAST(@PendingRows AS NVARCHAR(20));
    END
    ELSE
        SET @Reason = 'Mode is manual — dispatcher does not fire manual entities';

    SELECT
        @WouldFire      AS WouldFire,
        @Reason         AS Reason,
        @PendingRows    AS PendingRows,
        @OldestRowAge   AS OldestRowAge,
        @NextScheduledRun AS NextScheduledRun;
END;
GO

-- ============================================
-- usp_Scheduler_Dispatch
-- The dispatcher heart. Called every 60 seconds by a SQL Agent job.
-- Acquires an exclusive APPLOCK to prevent overlapping dispatcher runs,
-- then processes each enabled entity in sequence.
-- ============================================
CREATE OR ALTER PROCEDURE usp_Scheduler_Dispatch
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-02
-- Description: Single dispatcher SP called by SQL Agent every 60 seconds.
--              For each entity with scheduling enabled, checks overlap guard,
--              evaluates schedule or trigger conditions, and fires
--              usp_Staging_ProcessBatch when conditions are met.
--              Logs every significant action to SchedulerLog.
--              Uses APPLOCK to prevent concurrent dispatcher executions.
--              Errors for one entity do NOT stop processing of others.
--
-- Change History:
--   v1.0  2026-03-02  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- ----------------------------------------
    -- APPLOCK: prevent two concurrent dispatcher runs.
    -- If another instance is already running, exit immediately.
    -- ----------------------------------------
    IF APPLOCK_TEST('public', 'Primentra_Scheduler_Dispatch', 'Exclusive', 'Session') = 0
    BEGIN
        PRINT 'Dispatcher already running — skipping this cycle.';
        RETURN;
    END;

    BEGIN TRY
        EXEC sp_getapplock
            @Resource        = 'Primentra_Scheduler_Dispatch',
            @LockMode        = 'Exclusive',
            @LockOwner       = 'Session',
            @LockTimeout     = 0;

        -- ----------------------------------------
        -- Collect all entities with active scheduling configs.
        -- Snapshot into temp table so cursor is stable while we update rows.
        -- ----------------------------------------
        CREATE TABLE #DispatchQueue (
            EntityId                INT NOT NULL,
            EntityName              NVARCHAR(200) NOT NULL,
            ProcessingMode          NVARCHAR(20) NOT NULL,
            ScheduleType            NVARCHAR(20) NULL,
            IntervalMinutes         INT NULL,
            RunTimes                NVARCHAR(200) NULL,
            RunDays                 NVARCHAR(100) NULL,
            RunDaysOfMonth          NVARCHAR(100) NULL,
            TriggerOnNewRows        BIT NOT NULL,
            TriggerRowThreshold     INT NULL,
            TriggerIdleMinutes      INT NULL,
            TriggerDebounceSeconds  INT NOT NULL,
            ZombieTimeoutMinutes    INT NOT NULL,
            IsRunning               BIT NOT NULL,
            RunStartedAt            DATETIME2 NULL,
            NextScheduledRun        DATETIME2 NULL,
            LastCompletedAt         DATETIME2 NULL,
            LastTriggerCheck        DATETIME2 NULL
        );

        INSERT INTO #DispatchQueue (
            EntityId, EntityName, ProcessingMode, ScheduleType, IntervalMinutes,
            RunTimes, RunDays, RunDaysOfMonth,
            TriggerOnNewRows, TriggerRowThreshold, TriggerIdleMinutes,
            TriggerDebounceSeconds, ZombieTimeoutMinutes, IsRunning, RunStartedAt,
            NextScheduledRun, LastCompletedAt, LastTriggerCheck
        )
        SELECT
            sc.EntityId, e.Name, sc.ProcessingMode, sc.ScheduleType, sc.IntervalMinutes,
            sc.RunTimes, sc.RunDays, sc.RunDaysOfMonth,
            sc.TriggerOnNewRows, sc.TriggerRowThreshold, sc.TriggerIdleMinutes,
            sc.TriggerDebounceSeconds, sc.ZombieTimeoutMinutes, sc.IsRunning, sc.RunStartedAt,
            sc.NextScheduledRun, sc.LastCompletedAt, sc.LastTriggerCheck
        FROM SchedulerConfigurations sc
        INNER JOIN Entities e ON e.Id = sc.EntityId
        WHERE sc.IsEnabled = 1
          AND sc.ProcessingMode IN ('scheduled', 'triggered')
          AND sc.EntityId IS NOT NULL;

        -- ----------------------------------------
        -- Process each entity in turn.
        -- Wrap each in its own TRY/CATCH so one failure doesn't stop the rest.
        -- ----------------------------------------
        DECLARE
            @EntityId               INT,
            @EntityName             NVARCHAR(200),
            @ProcessingMode         NVARCHAR(20),
            @ScheduleType           NVARCHAR(20),
            @IntervalMinutes        INT,
            @RunTimes               NVARCHAR(200),
            @RunDays                NVARCHAR(100),
            @RunDaysOfMonth         NVARCHAR(100),
            @TriggerOnNewRows       BIT,
            @TriggerRowThreshold    INT,
            @TriggerIdleMinutes     INT,
            @TriggerDebounceSeconds INT,
            @ZombieTimeoutMinutes   INT,
            @IsRunning              BIT,
            @RunStartedAt           DATETIME2,
            @NextScheduledRun       DATETIME2,
            @LastCompletedAt        DATETIME2,
            @LastTriggerCheck       DATETIME2;

        DECLARE EntityCursor CURSOR LOCAL FAST_FORWARD FOR
            SELECT EntityId, EntityName, ProcessingMode, ScheduleType, IntervalMinutes,
                   RunTimes, RunDays, RunDaysOfMonth,
                   TriggerOnNewRows, TriggerRowThreshold, TriggerIdleMinutes,
                   TriggerDebounceSeconds, ZombieTimeoutMinutes, IsRunning, RunStartedAt,
                   NextScheduledRun, LastCompletedAt, LastTriggerCheck
            FROM #DispatchQueue;

        OPEN EntityCursor;
        FETCH NEXT FROM EntityCursor INTO
            @EntityId, @EntityName, @ProcessingMode, @ScheduleType, @IntervalMinutes,
            @RunTimes, @RunDays, @RunDaysOfMonth,
            @TriggerOnNewRows, @TriggerRowThreshold, @TriggerIdleMinutes,
            @TriggerDebounceSeconds, @ZombieTimeoutMinutes, @IsRunning, @RunStartedAt,
            @NextScheduledRun, @LastCompletedAt, @LastTriggerCheck;

        WHILE @@FETCH_STATUS = 0
        BEGIN
            BEGIN TRY
                DECLARE @StartTime DATETIME2 = SYSUTCDATETIME();

                -- ----------------------------------------
                -- OVERLAP GUARD: if IsRunning=1, check for zombie (>ZombieTimeoutMinutes).
                -- Release zombie and continue to next entity.
                -- ----------------------------------------
                IF @IsRunning = 1
                BEGIN
                    IF @RunStartedAt < DATEADD(MINUTE, -@ZombieTimeoutMinutes, SYSUTCDATETIME())
                    BEGIN
                        -- Zombie: batch stuck for over ZombieTimeoutMinutes — release and log
                        UPDATE SchedulerConfigurations SET IsRunning = 0, RunStartedAt = NULL WHERE EntityId = @EntityId;
                        INSERT INTO SchedulerLog (EntityId, EventType, Message)
                        VALUES (@EntityId, 'zombie', '[' + @EntityName + '] Zombie batch released after ' + CAST(@ZombieTimeoutMinutes AS NVARCHAR(10)) + '-minute timeout. RunStartedAt was ' + CONVERT(NVARCHAR(30), @RunStartedAt, 120));
                        -- Fall through: zombie released, now evaluate whether to fire
                        SET @IsRunning = 0;
                    END
                    ELSE
                    BEGIN
                        -- Live running batch — skip this entity to avoid overlap
                        INSERT INTO SchedulerLog (EntityId, EventType, Message)
                        VALUES (@EntityId, 'skipped', '[' + @EntityName + '] Batch already running (overlap guard). RunStartedAt: ' + CONVERT(NVARCHAR(30), @RunStartedAt, 120));
                        GOTO NextEntity;
                    END;
                END;

                -- ----------------------------------------
                -- Collect live queue stats needed for trigger evaluation.
                -- Use dynamic SQL because the staging table name is stored as data.
                -- ----------------------------------------
                DECLARE @PendingRows INT = 0;
                DECLARE @OldestRowAge INT = 0;
                DECLARE @SafeName NVARCHAR(200);
                SELECT @SafeName = TableName FROM StagingConfigurations WHERE EntityId = @EntityId;

                IF @SafeName IS NOT NULL AND EXISTS (
                    SELECT 1 FROM sys.tables t
                    JOIN sys.schemas s ON s.schema_id = t.schema_id
                    WHERE s.name = 'stg' AND t.name = @SafeName
                )
                BEGIN
                    DECLARE @QueueSQL NVARCHAR(500) = N'
                        SELECT @PendingRows  = COUNT(*),
                               @OldestRowAge = ISNULL(DATEDIFF(MINUTE, MIN(CreatedAt), SYSUTCDATETIME()), 0)
                        FROM stg.' + QUOTENAME(@SafeName) + N' WHERE ImportStatus = 0;';
                    EXEC sp_executesql @QueueSQL,
                        N'@PendingRows INT OUTPUT, @OldestRowAge INT OUTPUT',
                        @PendingRows OUTPUT, @OldestRowAge OUTPUT;
                END;

                -- ----------------------------------------
                -- MODE: SCHEDULED — fire when NextScheduledRun has passed
                -- ----------------------------------------
                IF @ProcessingMode = 'scheduled'
                BEGIN
                    IF @NextScheduledRun IS NOT NULL AND @NextScheduledRun <= SYSUTCDATETIME()
                    BEGIN
                        -- Mark as running before calling ProcessBatch
                        UPDATE SchedulerConfigurations SET
                            IsRunning    = 1,
                            RunStartedAt = SYSUTCDATETIME(),
                            RunStartedBy = 'Schedule'
                        WHERE EntityId = @EntityId;

                        INSERT INTO SchedulerLog (EntityId, EventType, TriggerSource, RowsQueued, Message)
                        VALUES (@EntityId, 'fired', 'Schedule', @PendingRows,
                                '[' + @EntityName + '] Scheduled run fired. NextScheduledRun was: ' + CONVERT(NVARCHAR(30), @NextScheduledRun, 120));

                        -- Fire the batch
                        EXEC usp_Staging_ProcessBatch @EntityId = @EntityId;

                        -- Tag the most recent batch for this entity with TriggerSource.
                        -- Use MAX(Id) to identify the most recent batch since UPDATE TOP does not support ORDER BY.
                        UPDATE StagingBatches SET TriggerSource = 'Schedule'
                        WHERE Id = (SELECT MAX(Id) FROM StagingBatches WHERE EntityId = @EntityId);

                        -- Recalculate next scheduled run
                        DECLARE @NewNextRun DATETIME2;
                        EXEC usp_Scheduler_CalculateNextRun
                            @ScheduleType    = @ScheduleType,
                            @IntervalMinutes = @IntervalMinutes,
                            @RunTimes        = @RunTimes,
                            @RunDays         = @RunDays,
                            @RunDaysOfMonth  = @RunDaysOfMonth,
                            @LastRun         = @StartTime,
                            @NextRun         = @NewNextRun OUTPUT;

                        UPDATE SchedulerConfigurations SET
                            IsRunning        = 0,
                            RunStartedAt     = NULL,
                            RunStartedBy     = NULL,
                            LastCompletedAt  = SYSUTCDATETIME(),
                            NextScheduledRun = @NewNextRun
                        WHERE EntityId = @EntityId;

                        DECLARE @DurationMs INT = DATEDIFF(MILLISECOND, @StartTime, SYSUTCDATETIME());
                        INSERT INTO SchedulerLog (EntityId, EventType, TriggerSource, DurationMs, Message)
                        VALUES (@EntityId, 'completed', 'Schedule', @DurationMs,
                                '[' + @EntityName + '] Scheduled batch completed. Next run: ' + ISNULL(CONVERT(NVARCHAR(30), @NewNextRun, 120), 'not calculated'));
                    END;
                END;

                -- ----------------------------------------
                -- MODE: TRIGGERED — fire when threshold, idle, or new-row conditions are met
                -- ----------------------------------------
                ELSE IF @ProcessingMode = 'triggered'
                BEGIN
                    DECLARE @TriggerSource NVARCHAR(100) = NULL;

                    -- Row threshold: enough rows queued to warrant a batch
                    IF @TriggerRowThreshold IS NOT NULL AND @PendingRows >= @TriggerRowThreshold
                        SET @TriggerSource = 'Trigger: ' + CAST(@PendingRows AS NVARCHAR(20)) + ' rows (threshold ' + CAST(@TriggerRowThreshold AS NVARCHAR(20)) + ')';

                    -- Idle timeout: rows have been waiting too long (takes priority over new-row trigger)
                    ELSE IF @TriggerIdleMinutes IS NOT NULL AND @PendingRows > 0 AND @OldestRowAge >= @TriggerIdleMinutes
                        SET @TriggerSource = 'Trigger: idle ' + CAST(@OldestRowAge AS NVARCHAR(20)) + 'min (timeout ' + CAST(@TriggerIdleMinutes AS NVARCHAR(20)) + 'min)';

                    -- New rows with debounce: fire when new rows detected and debounce window has elapsed
                    ELSE IF @TriggerOnNewRows = 1 AND @PendingRows > 0
                    BEGIN
                        IF @LastTriggerCheck IS NULL OR DATEDIFF(SECOND, @LastTriggerCheck, SYSUTCDATETIME()) >= @TriggerDebounceSeconds
                            SET @TriggerSource = 'Trigger: new rows detected (' + CAST(@PendingRows AS NVARCHAR(20)) + ')';
                    END;

                    -- Update LastTriggerCheck regardless of whether we fire —
                    -- this stamps the debounce window for the next dispatcher cycle.
                    UPDATE SchedulerConfigurations SET LastTriggerCheck = SYSUTCDATETIME() WHERE EntityId = @EntityId;

                    IF @TriggerSource IS NOT NULL
                    BEGIN
                        UPDATE SchedulerConfigurations SET
                            IsRunning    = 1,
                            RunStartedAt = SYSUTCDATETIME(),
                            RunStartedBy = @TriggerSource
                        WHERE EntityId = @EntityId;

                        INSERT INTO SchedulerLog (EntityId, EventType, TriggerSource, RowsQueued, Message)
                        VALUES (@EntityId, 'fired', @TriggerSource, @PendingRows,
                                '[' + @EntityName + '] Trigger condition met. Firing batch.');

                        EXEC usp_Staging_ProcessBatch @EntityId = @EntityId;

                        -- Tag the most recent batch for this entity with TriggerSource.
                        -- Use MAX(Id) to identify the most recent batch since UPDATE TOP does not support ORDER BY.
                        UPDATE StagingBatches SET TriggerSource = @TriggerSource
                        WHERE Id = (SELECT MAX(Id) FROM StagingBatches WHERE EntityId = @EntityId);

                        UPDATE SchedulerConfigurations SET
                            IsRunning       = 0,
                            RunStartedAt    = NULL,
                            RunStartedBy    = NULL,
                            LastCompletedAt = SYSUTCDATETIME()
                        WHERE EntityId = @EntityId;

                        DECLARE @TrigDurationMs INT = DATEDIFF(MILLISECOND, @StartTime, SYSUTCDATETIME());
                        INSERT INTO SchedulerLog (EntityId, EventType, TriggerSource, DurationMs, RowsQueued, Message)
                        VALUES (@EntityId, 'completed', @TriggerSource, @TrigDurationMs, @PendingRows, '[' + @EntityName + '] Triggered batch completed.');
                    END;
                END;

            END TRY
            BEGIN CATCH
                -- Log per-entity errors but continue to the next entity.
                -- Ensures one bad entity doesn't block the entire dispatcher.
                DECLARE @ErrMsg NVARCHAR(500) = ERROR_MESSAGE();
                BEGIN TRY
                    -- Ensure IsRunning is cleared on error so the entity isn't stuck.
                    -- Also recalculate NextScheduledRun for scheduled entities — without this,
                    -- a failed scheduled run would re-fire every 60 seconds until it succeeds.
                    IF @ProcessingMode = 'scheduled' AND @ScheduleType IS NOT NULL
                    BEGIN
                        DECLARE @ErrNextRun DATETIME2;
                        EXEC usp_Scheduler_CalculateNextRun
                            @ScheduleType    = @ScheduleType,
                            @IntervalMinutes = @IntervalMinutes,
                            @RunTimes        = @RunTimes,
                            @RunDays         = @RunDays,
                            @RunDaysOfMonth  = @RunDaysOfMonth,
                            @LastRun         = @StartTime,
                            @NextRun         = @ErrNextRun OUTPUT;

                        UPDATE SchedulerConfigurations SET
                            IsRunning = 0, RunStartedAt = NULL,
                            NextScheduledRun = @ErrNextRun
                        WHERE EntityId = @EntityId;
                    END
                    ELSE
                    BEGIN
                        UPDATE SchedulerConfigurations SET IsRunning = 0, RunStartedAt = NULL WHERE EntityId = @EntityId;
                    END;

                    INSERT INTO SchedulerLog (EntityId, EventType, Message)
                    VALUES (@EntityId, 'error', '[' + ISNULL(@EntityName, 'Unknown') + '] Dispatcher error: ' + @ErrMsg);
                END TRY
                BEGIN CATCH
                    -- Swallow secondary errors in error logging — main loop must continue
                    PRINT 'Secondary error during error logging for EntityId ' + CAST(@EntityId AS NVARCHAR(10));
                END CATCH;
            END CATCH;

            NextEntity:
            FETCH NEXT FROM EntityCursor INTO
                @EntityId, @EntityName, @ProcessingMode, @ScheduleType, @IntervalMinutes,
                @RunTimes, @RunDays, @RunDaysOfMonth,
                @TriggerOnNewRows, @TriggerRowThreshold, @TriggerIdleMinutes,
                @TriggerDebounceSeconds, @ZombieTimeoutMinutes, @IsRunning, @RunStartedAt,
                @NextScheduledRun, @LastCompletedAt, @LastTriggerCheck;
        END;

        CLOSE EntityCursor;
        DEALLOCATE EntityCursor;
        DROP TABLE #DispatchQueue;

    END TRY
    BEGIN CATCH
        -- Top-level catch: log and re-raise. AppLock is session-scoped and
        -- releases automatically when the session ends or the SP returns.
        DECLARE @TopErrMsg NVARCHAR(500) = ERROR_MESSAGE();
        BEGIN TRY
            INSERT INTO SchedulerLog (EntityId, EventType, Message)
            VALUES (-1, 'error', 'Dispatcher top-level error: ' + @TopErrMsg);
        END TRY
        BEGIN CATCH
            PRINT 'Failed to log dispatcher top-level error: ' + @TopErrMsg;
        END CATCH;
    END CATCH;

    -- Release the app lock whether we succeeded or failed
    EXEC sp_releaseapplock
        @Resource  = 'Primentra_Scheduler_Dispatch',
        @LockOwner = 'Session';
END;
GO

-- ============================================
-- MODEL IMPORT/EXPORT — STAGING TABLE
-- ============================================
-- Stores unresolved domain FK references during model import (Phase 1).
-- usp_ModelImport_SyncAttributes inserts rows here when @SkipDomainFKs=1.
-- usp_ModelImport_ResolveDomainFKs reads and resolves them, then cleans up.
CREATE TABLE ImportDomainFKStaging (
    Id                    INT IDENTITY(1,1) CONSTRAINT PK_ImportDomainFKStaging PRIMARY KEY,
    AttributeId           INT NOT NULL REFERENCES Attributes(Id) ON DELETE CASCADE,
    DomainEntityName      NVARCHAR(200) NOT NULL,
    DomainEntityModelName NVARCHAR(200) NOT NULL,
    CreatedAt             DATETIME2 NOT NULL DEFAULT GETUTCDATE()
);
GO

-- ============================================
-- MODEL EXPORT PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_ModelExport_GetSchema
    @ModelIdsJson NVARCHAR(MAX) = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-04
-- Description: Returns full schema for one or more models (or all if NULL).
--              5 result sets: Models, Entities, Attributes, DerivedColumns,
--              DomainWarnings. Used by the model export feature.
--
-- Change History:
--   v1.0  2026-03-04  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- Parse model IDs from JSON array (or NULL = all)
    CREATE TABLE #ModelIds (Id INT);
    IF @ModelIdsJson IS NOT NULL
        INSERT INTO #ModelIds (Id)
        SELECT CAST(value AS INT) FROM OPENJSON(@ModelIdsJson);

    -- Result set 1: Models
    SELECT m.Id AS ModelId, m.Name, m.Description, m.IsActive, m.SortOrder
    FROM Models m
    WHERE @ModelIdsJson IS NULL OR m.Id IN (SELECT Id FROM #ModelIds)
    ORDER BY m.SortOrder, m.Id;

    -- Result set 2: Entities
    SELECT e.Id AS EntityId, e.ModelId, e.Name, e.Description, e.TableName,
           e.SortOrder, e.IsActive, e.RequiresApproval, e.ApprovalStrategy,
           e.ApproverCanApproveOwn, e.SharedAcrossModels, e.AutoGenerateCode
    FROM Entities e
    WHERE @ModelIdsJson IS NULL OR e.ModelId IN (SELECT Id FROM #ModelIds)
    ORDER BY e.ModelId, e.SortOrder, e.Id;

    -- Result set 3: Attributes (excluding system date attrs)
    SELECT a.Id AS AttributeId, a.EntityId, a.DisplayName, a.Name, a.DataType,
           a.MaxLength, a.IsRequired, a.IsCode, a.IsName, a.IsHidden, a.SortOrder,
           domEnt.Name AS DomainEntityName,
           domModel.Name AS DomainEntityModelName,
           a.DateFormat, a.BooleanDisplayFormat, a.DecimalPlaces, a.AllowNegative,
           a.Description
    FROM Attributes a
    INNER JOIN Entities e ON e.Id = a.EntityId
    LEFT JOIN Entities domEnt ON domEnt.Id = a.DomainEntityId
    LEFT JOIN Models domModel ON domModel.Id = domEnt.ModelId
    WHERE a.IsSystemDate = 0
      AND (@ModelIdsJson IS NULL OR e.ModelId IN (SELECT Id FROM #ModelIds))
    ORDER BY a.EntityId, a.SortOrder, a.Id;

    -- Result set 4: DerivedColumns
    SELECT dc.Id AS DerivedColumnId, dc.EntityId, dc.DisplayName, dc.AttributePath, dc.SortOrder
    FROM EntityDerivedColumns dc
    INNER JOIN Entities e ON e.Id = dc.EntityId
    WHERE @ModelIdsJson IS NULL OR e.ModelId IN (SELECT Id FROM #ModelIds)
    ORDER BY dc.EntityId, dc.SortOrder, dc.Id;

    -- Result set 5: DomainWarnings — domain attrs referencing entities NOT in export scope
    SELECT CONCAT(
        'Attribute "', a.DisplayName, '" on entity "', srcEnt.Name,
        '" references entity "', domEnt.Name, '" (model "', domModel.Name,
        '") which is not included in this export.'
    ) AS Warning
    FROM Attributes a
    INNER JOIN Entities srcEnt ON srcEnt.Id = a.EntityId
    INNER JOIN Entities domEnt ON domEnt.Id = a.DomainEntityId
    INNER JOIN Models domModel ON domModel.Id = domEnt.ModelId
    WHERE a.IsSystemDate = 0
      AND a.DomainEntityId IS NOT NULL
      AND (@ModelIdsJson IS NULL OR srcEnt.ModelId IN (SELECT Id FROM #ModelIds))
      AND @ModelIdsJson IS NOT NULL
      AND domEnt.ModelId NOT IN (SELECT Id FROM #ModelIds);

    DROP TABLE #ModelIds;
END;
GO

CREATE OR ALTER PROCEDURE usp_ModelExport_GetEntityRows
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-04
-- Description: Returns committed (non-pending) rows for an entity with EAV
--              values pivoted to flat columns. Same approach as
--              usp_Export_GetEntityData result set 3.
--
-- Change History:
--   v1.0  2026-03-04  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    SELECT er.Id, er.Code, er.Name,
           a.Name AS AttributeName, a.DataType,
           ev.TextValue, ev.IntValue, ev.DecimalValue, ev.DateTimeValue, ev.DomainValue,
           dr.Code AS DomainCode, dr.Name AS DomainName
    FROM EntityRows er
    LEFT JOIN EntityValues ev ON ev.EntityRowId = er.Id
    LEFT JOIN Attributes a ON a.Id = ev.AttributeId
    LEFT JOIN EntityRows dr ON dr.Id = ev.DomainValue
    WHERE er.EntityId = @EntityId
    ORDER BY er.Id, a.SortOrder;
END;
GO

CREATE OR ALTER PROCEDURE usp_ModelExport_GetPermissions
    @EntityIdsJson NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-04
-- Description: Returns entity-level permissions as a flat list of
--              EntityId + UserEmail + RoleName. Only active, non-deleted users.
--
-- Change History:
--   v1.0  2026-03-04  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #EntityIds (Id INT);
    INSERT INTO #EntityIds (Id)
    SELECT CAST(value AS INT) FROM OPENJSON(@EntityIdsJson);

    SELECT p.TargetId AS EntityId,
           u.Email AS UserEmail,
           r.Name AS Role
    FROM Permissions p
    INNER JOIN Roles r ON r.Id = p.RoleId
    INNER JOIN RoleMembers rm ON rm.RoleId = r.Id
    INNER JOIN Users u ON u.Id = rm.UserId
    WHERE p.Scope = 'entity'
      AND p.TargetId IN (SELECT Id FROM #EntityIds)
      AND u.IsActive = 1
      AND u.IsDeleted = 0
    ORDER BY p.TargetId, u.Email;

    DROP TABLE #EntityIds;
END;
GO

-- ============================================
-- MODEL IMPORT PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_ModelImport_UpsertModel
    @Name        NVARCHAR(255),
    @Description NVARCHAR(MAX),
    @IsActive    BIT,
    @SortOrder   INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-04
-- Description: Upserts a model by Name. If exists, updates fields.
--              Returns Id and WasCreated flag.
--
-- Change History:
--   v1.0  2026-03-04  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Id INT, @WasCreated BIT = 0;

    SELECT @Id = Id FROM Models WHERE Name = @Name;

    IF @Id IS NULL
    BEGIN
        INSERT INTO Models (Name, Description, IsActive, SortOrder)
        VALUES (@Name, @Description, @IsActive, @SortOrder);
        SET @Id = SCOPE_IDENTITY();
        SET @WasCreated = 1;
    END
    ELSE
    BEGIN
        UPDATE Models
        SET Description = @Description,
            IsActive    = @IsActive,
            SortOrder   = @SortOrder,
            ModifiedAt  = GETUTCDATE()
        WHERE Id = @Id;
    END

    SELECT @Id AS Id, @WasCreated AS WasCreated;
END;
GO

CREATE OR ALTER PROCEDURE usp_ModelImport_UpsertEntity
    @ModelId              INT,
    @Name                 NVARCHAR(255),
    @Description          NVARCHAR(MAX),
    @TableName            NVARCHAR(100),
    @SortOrder            INT,
    @IsActive             BIT,
    @RequiresApproval     BIT,
    @ApprovalStrategy     NVARCHAR(50),
    @ApproverCanApproveOwn BIT,
    @SharedAcrossModels   BIT,
    @AutoGenerateCode     BIT,
    @ConflictAction       NVARCHAR(20) = 'overwrite'
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-04
-- Description: Upserts an entity by ModelId + Name.
--              ConflictAction: 'overwrite' | 'skip' | 'merge'.
--              Returns Id, WasCreated, WasSkipped flags.
--
-- Change History:
--   v1.0  2026-03-04  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Id INT, @WasCreated BIT = 0, @WasSkipped BIT = 0;

    SELECT @Id = Id FROM Entities WHERE ModelId = @ModelId AND Name = @Name;

    IF @Id IS NULL
    BEGIN
        -- New entity — insert
        INSERT INTO Entities (ModelId, Name, Description, TableName, SortOrder, IsActive,
                              RequiresApproval, ApprovalStrategy, ApproverCanApproveOwn,
                              SharedAcrossModels, AutoGenerateCode)
        VALUES (@ModelId, @Name, @Description, @TableName, @SortOrder, @IsActive,
                @RequiresApproval, @ApprovalStrategy, @ApproverCanApproveOwn,
                @SharedAcrossModels, @AutoGenerateCode);
        SET @Id = SCOPE_IDENTITY();
        SET @WasCreated = 1;

        -- Auto-create system date attributes (same pattern as usp_Entity_Create)
        IF NOT EXISTS (SELECT 1 FROM Attributes WHERE EntityId = @Id AND Name = 'createdAt' AND IsSystemDate = 1)
            INSERT INTO Attributes (EntityId, DisplayName, Name, DataType, IsRequired, IsCode, IsName, IsHidden, IsSystemDate, SortOrder, Description)
            VALUES (@Id, 'Created', 'createdAt', 'DateTime', 0, 0, 0, 1, 1, 9998, 'Date this record was created');
        IF NOT EXISTS (SELECT 1 FROM Attributes WHERE EntityId = @Id AND Name = 'modifiedAt' AND IsSystemDate = 1)
            INSERT INTO Attributes (EntityId, DisplayName, Name, DataType, IsRequired, IsCode, IsName, IsHidden, IsSystemDate, SortOrder, Description)
            VALUES (@Id, 'Last Modified', 'modifiedAt', 'DateTime', 0, 0, 0, 1, 1, 9999, 'Date this record was last modified');
    END
    ELSE IF @ConflictAction = 'skip'
    BEGIN
        SET @WasSkipped = 1;
    END
    ELSE IF @ConflictAction = 'overwrite'
    BEGIN
        UPDATE Entities
        SET Description          = @Description,
            TableName            = @TableName,
            SortOrder            = @SortOrder,
            IsActive             = @IsActive,
            RequiresApproval     = @RequiresApproval,
            ApprovalStrategy     = @ApprovalStrategy,
            ApproverCanApproveOwn = @ApproverCanApproveOwn,
            SharedAcrossModels   = @SharedAcrossModels,
            AutoGenerateCode     = @AutoGenerateCode,
            ModifiedAt           = GETUTCDATE()
        WHERE Id = @Id;
    END
    ELSE IF @ConflictAction = 'merge'
    BEGIN
        UPDATE Entities
        SET Description          = COALESCE(NULLIF(@Description, ''), Description),
            TableName            = COALESCE(NULLIF(@TableName, ''), TableName),
            SortOrder            = COALESCE(@SortOrder, SortOrder),
            IsActive             = COALESCE(@IsActive, IsActive),
            RequiresApproval     = COALESCE(@RequiresApproval, RequiresApproval),
            ApprovalStrategy     = COALESCE(NULLIF(@ApprovalStrategy, ''), ApprovalStrategy),
            ApproverCanApproveOwn = COALESCE(@ApproverCanApproveOwn, ApproverCanApproveOwn),
            SharedAcrossModels   = COALESCE(@SharedAcrossModels, SharedAcrossModels),
            AutoGenerateCode     = COALESCE(@AutoGenerateCode, AutoGenerateCode),
            ModifiedAt           = GETUTCDATE()
        WHERE Id = @Id;
    END

    SELECT @Id AS Id, @WasCreated AS WasCreated, @WasSkipped AS WasSkipped;
END;
GO

SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE usp_ModelImport_SyncAttributes
    @EntityId       INT,
    @AttributesJson NVARCHAR(MAX),
    @SkipDomainFKs  BIT = 0
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-04
-- Description: Full sync of attributes for an entity from import JSON.
--              Inserts new, updates existing (match by Name), deletes removed.
--              Excludes system date attributes from sync.
--              When @SkipDomainFKs=1, stores domain references in
--              ImportDomainFKStaging for later resolution.
--
-- Change History:
--   v1.0  2026-03-04  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @Inserted INT = 0, @Updated INT = 0, @Deleted INT = 0;

        -- Parse JSON into temp table
        CREATE TABLE #ImportAttrs (
            Name                 NVARCHAR(128),
            DisplayName          NVARCHAR(200),
            DataType             NVARCHAR(20),
            MaxLength            INT,
            IsRequired           BIT,
            IsCode               BIT,
            IsName               BIT,
            IsHidden             BIT,
            SortOrder            INT,
            DomainEntityName     NVARCHAR(200),
            DomainEntityModelName NVARCHAR(200),
            DateFormat           NVARCHAR(20),
            BooleanDisplayFormat NVARCHAR(20),
            DecimalPlaces        INT,
            AllowNegative        BIT,
            Description          NVARCHAR(500)
        );

        INSERT INTO #ImportAttrs (Name, DisplayName, DataType, MaxLength, IsRequired,
            IsCode, IsName, IsHidden, SortOrder, DomainEntityName, DomainEntityModelName,
            DateFormat, BooleanDisplayFormat, DecimalPlaces, AllowNegative, Description)
        SELECT
            JSON_VALUE(value, '$.name'),
            JSON_VALUE(value, '$.displayName'),
            JSON_VALUE(value, '$.dataType'),
            CAST(JSON_VALUE(value, '$.maxLength') AS INT),
            CAST(ISNULL(JSON_VALUE(value, '$.isRequired'), '0') AS BIT),
            CAST(ISNULL(JSON_VALUE(value, '$.isCode'), '0') AS BIT),
            CAST(ISNULL(JSON_VALUE(value, '$.isName'), '0') AS BIT),
            CAST(ISNULL(JSON_VALUE(value, '$.isHidden'), '0') AS BIT),
            CAST(ISNULL(JSON_VALUE(value, '$.sortOrder'), '0') AS INT),
            JSON_VALUE(value, '$.domainEntityName'),
            JSON_VALUE(value, '$.domainEntityModelName'),
            JSON_VALUE(value, '$.dateFormat'),
            JSON_VALUE(value, '$.booleanDisplayFormat'),
            CAST(JSON_VALUE(value, '$.decimalPlaces') AS INT),
            CAST(JSON_VALUE(value, '$.allowNegative') AS BIT),
            JSON_VALUE(value, '$.description')
        FROM OPENJSON(@AttributesJson);

        -- Resolve DomainEntityId for domain attrs (unless skipping)
        ALTER TABLE #ImportAttrs ADD DomainEntityId INT NULL;

        IF @SkipDomainFKs = 0
        BEGIN
            UPDATE ia
            SET ia.DomainEntityId = e.Id
            FROM #ImportAttrs ia
            INNER JOIN Entities e ON e.Name = ia.DomainEntityName
            INNER JOIN Models m ON m.Id = e.ModelId AND m.Name = ia.DomainEntityModelName
            WHERE ia.DomainEntityName IS NOT NULL;
        END

        -- UPDATE existing attributes (match by Name, exclude system dates)
        UPDATE a
        SET a.DisplayName          = ia.DisplayName,
            a.DataType             = ia.DataType,
            a.MaxLength            = ia.MaxLength,
            a.IsRequired           = ia.IsRequired,
            a.IsCode               = ia.IsCode,
            a.IsName               = ia.IsName,
            a.IsHidden             = ia.IsHidden,
            a.SortOrder            = ia.SortOrder,
            a.DomainEntityId       = CASE WHEN @SkipDomainFKs = 1 THEN NULL ELSE ia.DomainEntityId END,
            a.DateFormat           = ia.DateFormat,
            a.BooleanDisplayFormat = ia.BooleanDisplayFormat,
            a.DecimalPlaces        = ia.DecimalPlaces,
            a.AllowNegative        = ia.AllowNegative,
            a.Description          = ia.Description,
            a.ModifiedAt           = GETUTCDATE()
        FROM Attributes a
        INNER JOIN #ImportAttrs ia ON ia.Name = a.Name
        WHERE a.EntityId = @EntityId AND a.IsSystemDate = 0;

        SET @Updated = @@ROWCOUNT;

        -- INSERT new attributes
        INSERT INTO Attributes (EntityId, DisplayName, Name, DataType, MaxLength, IsRequired,
            IsCode, IsName, IsHidden, SortOrder, DomainEntityId, DateFormat,
            BooleanDisplayFormat, DecimalPlaces, AllowNegative, Description)
        SELECT @EntityId, ia.DisplayName, ia.Name, ia.DataType, ia.MaxLength, ia.IsRequired,
            ia.IsCode, ia.IsName, ia.IsHidden, ia.SortOrder,
            CASE WHEN @SkipDomainFKs = 1 THEN NULL ELSE ia.DomainEntityId END,
            ia.DateFormat, ia.BooleanDisplayFormat, ia.DecimalPlaces, ia.AllowNegative, ia.Description
        FROM #ImportAttrs ia
        WHERE NOT EXISTS (
            SELECT 1 FROM Attributes a
            WHERE a.EntityId = @EntityId AND a.Name = ia.Name AND a.IsSystemDate = 0
        );

        SET @Inserted = @@ROWCOUNT;

        -- If skipping domain FKs, stage unresolved references
        IF @SkipDomainFKs = 1
        BEGIN
            -- Clean any previous staging for these attributes
            DELETE FROM ImportDomainFKStaging
            WHERE AttributeId IN (SELECT Id FROM Attributes WHERE EntityId = @EntityId);

            -- Insert staging rows for domain attrs
            INSERT INTO ImportDomainFKStaging (AttributeId, DomainEntityName, DomainEntityModelName)
            SELECT a.Id, ia.DomainEntityName, ia.DomainEntityModelName
            FROM Attributes a
            INNER JOIN #ImportAttrs ia ON ia.Name = a.Name
            WHERE a.EntityId = @EntityId
              AND ia.DomainEntityName IS NOT NULL
              AND ia.DomainEntityModelName IS NOT NULL;
        END

        -- DELETE attributes not in import (excluding system dates)
        -- First remove StagingFieldRules referencing attrs about to be deleted (NO ACTION FK)
        DELETE FROM StagingFieldRules
        WHERE AttributeId IN (
            SELECT Id FROM Attributes
            WHERE EntityId = @EntityId AND IsSystemDate = 0
              AND Name NOT IN (SELECT Name FROM #ImportAttrs)
        );

        DELETE FROM Attributes
        WHERE EntityId = @EntityId
          AND IsSystemDate = 0
          AND Name NOT IN (SELECT Name FROM #ImportAttrs);

        SET @Deleted = @@ROWCOUNT;

        DROP TABLE #ImportAttrs;

        COMMIT TRANSACTION;

        SELECT @Inserted AS AttributesInserted, @Updated AS AttributesUpdated, @Deleted AS AttributesDeleted;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE usp_ModelImport_ResolveDomainFKs
    @ImportedEntityIdsJson NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-04
-- Description: Resolves domain FK references for imported entities.
--              Reads from ImportDomainFKStaging, looks up entities by
--              Name + Model Name, sets DomainEntityId on attributes.
--              Cleans up staging rows after resolution.
--
-- Change History:
--   v1.0  2026-03-04  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    CREATE TABLE #ImportedEntityIds (Id INT);
    INSERT INTO #ImportedEntityIds (Id)
    SELECT CAST(value AS INT) FROM OPENJSON(@ImportedEntityIdsJson);

    DECLARE @FKsResolved INT = 0;

    -- Resolve: set DomainEntityId on attributes where staging row exists
    UPDATE a
    SET a.DomainEntityId = e.Id,
        a.ModifiedAt     = GETUTCDATE()
    FROM Attributes a
    INNER JOIN ImportDomainFKStaging s ON s.AttributeId = a.Id
    INNER JOIN Entities e ON e.Name = s.DomainEntityName
    INNER JOIN Models m ON m.Id = e.ModelId AND m.Name = s.DomainEntityModelName
    WHERE a.EntityId IN (SELECT Id FROM #ImportedEntityIds);

    SET @FKsResolved = @@ROWCOUNT;

    -- Cleanup staging rows for resolved attributes
    DELETE FROM ImportDomainFKStaging
    WHERE AttributeId IN (
        SELECT a.Id FROM Attributes a
        WHERE a.EntityId IN (SELECT Id FROM #ImportedEntityIds)
    );

    DROP TABLE #ImportedEntityIds;

    SELECT @FKsResolved AS FKsResolved;
END;
GO

SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE usp_ModelImport_SyncDerivedColumns
    @EntityId          INT,
    @DerivedColumnsJson NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-04
-- Description: Syncs derived columns for an entity. Deletes all existing
--              derived columns and inserts the provided ones.
--
-- Change History:
--   v1.0  2026-03-04  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        -- Delete all existing derived columns for this entity
        DELETE FROM EntityDerivedColumns WHERE EntityId = @EntityId;

        -- Insert provided derived columns
        DECLARE @DerivedColumnsInserted INT = 0;

        INSERT INTO EntityDerivedColumns (EntityId, DisplayName, AttributePath, SortOrder)
        SELECT
            @EntityId,
            JSON_VALUE(value, '$.displayName'),
            JSON_VALUE(value, '$.attributePath'),
            CAST(ISNULL(JSON_VALUE(value, '$.sortOrder'), '0') AS INT)
        FROM OPENJSON(@DerivedColumnsJson);

        SET @DerivedColumnsInserted = @@ROWCOUNT;

        COMMIT TRANSACTION;

        SELECT @DerivedColumnsInserted AS DerivedColumnsInserted;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

SET QUOTED_IDENTIFIER ON;
GO
CREATE OR ALTER PROCEDURE usp_ModelImport_SyncPermissions
    @EntityId        INT,
    @PermissionsJson NVARCHAR(MAX)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-04
-- Description: Syncs entity-level permissions from import JSON.
--              Looks up users by Email (active only). For each matched user,
--              finds their role and upserts entity-scope permission.
--              Skips inactive/missing users. Removes permissions for this
--              entity that are not in the provided list.
--
-- Change History:
--   v1.0  2026-03-04  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        DECLARE @Linked INT = 0, @Skipped INT = 0;

        -- Parse permissions JSON
        CREATE TABLE #ImportPerms (
            UserEmail NVARCHAR(255),
            RoleName  NVARCHAR(200)
        );

        INSERT INTO #ImportPerms (UserEmail, RoleName)
        SELECT
            JSON_VALUE(value, '$.userEmail'),
            JSON_VALUE(value, '$.role')
        FROM OPENJSON(@PermissionsJson);

        -- Resolve users and roles
        CREATE TABLE #ResolvedPerms (
            UserId INT,
            RoleId INT
        );

        INSERT INTO #ResolvedPerms (UserId, RoleId)
        SELECT u.Id, r.Id
        FROM #ImportPerms ip
        INNER JOIN Users u ON u.Email = ip.UserEmail AND u.IsActive = 1 AND u.IsDeleted = 0
        INNER JOIN Roles r ON r.Name = ip.RoleName
        INNER JOIN RoleMembers rm ON rm.RoleId = r.Id AND rm.UserId = u.Id;

        SET @Linked = (SELECT COUNT(*) FROM #ResolvedPerms);
        SET @Skipped = (SELECT COUNT(*) FROM #ImportPerms) - @Linked;

        -- Upsert permissions: for each resolved role, ensure entity-scope permission exists
        INSERT INTO Permissions (RoleId, Scope, TargetId, Level, CanCreate, CanRead, CanUpdate, CanDelete, IsModerator)
        SELECT DISTINCT rp.RoleId, 'entity', @EntityId, 'read', 0, 1, 0, 0, 0
        FROM #ResolvedPerms rp
        WHERE NOT EXISTS (
            SELECT 1 FROM Permissions p
            WHERE p.RoleId = rp.RoleId AND p.Scope = 'entity' AND p.TargetId = @EntityId
        );

        -- Delete entity-scope permissions NOT in the import list
        DELETE FROM Permissions
        WHERE Scope = 'entity'
          AND TargetId = @EntityId
          AND RoleId NOT IN (SELECT RoleId FROM #ResolvedPerms);

        DROP TABLE #ImportPerms;
        DROP TABLE #ResolvedPerms;

        COMMIT TRANSACTION;

        SELECT @Linked AS PermissionsLinked, @Skipped AS PermissionsSkipped;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

-- ============================================
-- API SETTINGS SEED
-- ============================================
-- Seed default apiEnabled=true if not already set (idempotent)
IF NOT EXISTS (SELECT 1 FROM AppSettings WHERE SettingKey = 'apiEnabled')
    INSERT INTO AppSettings (SettingKey, SettingValue) VALUES ('apiEnabled', 'true');
GO

-- ============================================
-- API USER & KEY STORED PROCEDURES
-- ============================================

CREATE OR ALTER PROCEDURE usp_ApiUser_GetAll
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-06
-- Description: Returns all API users (UserType='api') with their current
--              (non-deleted) key info. Returns two result sets:
--              [0] users + key metadata, [1] role memberships for all API users.
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- Result set 1: API users joined with their active key
    SELECT u.Id, u.DisplayName, u.Email, u.IsActive, u.IsDeleted, u.CreatedAt, u.ModifiedAt,
           k.Id AS KeyId, k.Name AS KeyName, k.KeyPrefix, k.IsActive AS KeyIsActive,
           k.IsDeleted AS KeyIsDeleted, k.ExpiresAt, k.LastUsedAt, k.CallCount,
           k.ReadCount, k.CreateCount, k.UpdateCount, k.DeleteCount, k.CreatedAt AS KeyCreatedAt
    FROM Users u
    LEFT JOIN ApiKeys k ON k.UserId = u.Id AND k.IsDeleted = 0
    WHERE u.UserType = 'api' AND u.IsDeleted = 0
    ORDER BY u.DisplayName;

    -- Result set 2: role memberships for all API users
    SELECT rm.UserId, rm.RoleId, r.Name AS RoleName
    FROM RoleMembers rm
    JOIN Roles r ON r.Id = rm.RoleId
    WHERE rm.UserId IN (SELECT Id FROM Users WHERE UserType = 'api' AND IsDeleted = 0)
    ORDER BY rm.UserId, r.Name;
END;
GO

CREATE OR ALTER PROCEDURE usp_ApiUser_Create
    @DisplayName    NVARCHAR(200),
    @Email          NVARCHAR(320),
    @KeyName        NVARCHAR(200),
    @KeyHash        NVARCHAR(500),
    @KeyPrefix      NVARCHAR(12),
    @ExpiresAt      DATETIME2 = NULL,
    @RoleIdsJson    NVARCHAR(MAX) = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-06
-- Description: Creates an API user (UserType='api', IsSystem=1, no password)
--              and its initial ApiKeys row. Assigns role memberships when provided.
--              Returns the created user row and its key row.
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM Users WHERE Email = @Email AND IsDeleted = 0)
        THROW 50001, 'An API user with this email already exists.', 1;

    BEGIN TRANSACTION;
    BEGIN TRY
        -- Create the user row (no password, IsSystem=1 prevents accidental deletion)
        INSERT INTO Users (Email, DisplayName, PasswordHash, MustChangePassword, IsActive, IsSystem, UserType, PasswordLastChangedAt)
        VALUES (@Email, @DisplayName, NULL, 0, 1, 1, 'api', NULL);
        DECLARE @UserId INT = SCOPE_IDENTITY();

        -- Assign role memberships
        IF @RoleIdsJson IS NOT NULL
            INSERT INTO RoleMembers (RoleId, UserId)
            SELECT CAST(value AS INT), @UserId FROM OPENJSON(@RoleIdsJson) WHERE value IS NOT NULL;

        -- Create the API key row
        INSERT INTO ApiKeys (UserId, Name, KeyHash, KeyPrefix, IsActive, ExpiresAt)
        VALUES (@UserId, @KeyName, @KeyHash, @KeyPrefix, 1, @ExpiresAt);
        DECLARE @KeyId INT = SCOPE_IDENTITY();

        COMMIT TRANSACTION;

        -- Return user
        SELECT u.Id, u.DisplayName, u.Email, u.IsActive, u.UserType, u.CreatedAt
        FROM Users u WHERE u.Id = @UserId;

        -- Return key
        SELECT k.Id, k.UserId, k.Name, k.KeyPrefix, k.IsActive, k.ExpiresAt, k.CallCount,
               k.ReadCount, k.CreateCount, k.UpdateCount, k.DeleteCount, k.LastUsedAt, k.CreatedAt
        FROM ApiKeys k WHERE k.Id = @KeyId;

        -- Return role memberships
        SELECT rm.UserId, rm.RoleId, r.Name AS RoleName
        FROM RoleMembers rm JOIN Roles r ON r.Id = rm.RoleId
        WHERE rm.UserId = @UserId ORDER BY r.Name;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_ApiUser_Update
    @UserId         INT,
    @DisplayName    NVARCHAR(200) = NULL,
    @IsActive       BIT = NULL,
    @ExpiresAt      DATETIME2 = NULL,
    @ClearExpiry    BIT = 0,
    @RoleIdsJson    NVARCHAR(MAX) = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-06
-- Description: Updates an API user's display name, active status, and role
--              memberships. Also updates IsActive/ExpiresAt on their active key.
--              Pass @ClearExpiry=1 to remove the expiry date.
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT EXISTS (SELECT 1 FROM Users WHERE Id = @UserId AND UserType = 'api' AND IsDeleted = 0)
        THROW 50001, 'API user not found.', 1;

    BEGIN TRANSACTION;
    BEGIN TRY
        UPDATE Users SET
            DisplayName = ISNULL(@DisplayName, DisplayName),
            IsActive    = ISNULL(@IsActive, IsActive),
            ModifiedAt  = GETUTCDATE()
        WHERE Id = @UserId;

        -- Update the active key's IsActive and ExpiresAt
        UPDATE ApiKeys SET
            IsActive   = ISNULL(@IsActive, IsActive),
            ExpiresAt  = CASE WHEN @ClearExpiry = 1 THEN NULL
                              WHEN @ExpiresAt IS NOT NULL THEN @ExpiresAt
                              ELSE ExpiresAt END,
            ModifiedAt = GETUTCDATE()
        WHERE UserId = @UserId AND IsDeleted = 0;

        -- Sync role memberships when provided
        IF @RoleIdsJson IS NOT NULL
        BEGIN
            DELETE FROM RoleMembers WHERE UserId = @UserId;
            INSERT INTO RoleMembers (RoleId, UserId)
            SELECT CAST(value AS INT), @UserId FROM OPENJSON(@RoleIdsJson) WHERE value IS NOT NULL;
        END

        COMMIT TRANSACTION;

        SELECT u.Id, u.DisplayName, u.Email, u.IsActive, u.UserType, u.CreatedAt, u.ModifiedAt
        FROM Users u WHERE u.Id = @UserId;

        SELECT k.Id, k.UserId, k.Name, k.KeyPrefix, k.IsActive, k.ExpiresAt, k.CallCount,
               k.ReadCount, k.CreateCount, k.UpdateCount, k.DeleteCount, k.LastUsedAt
        FROM ApiKeys k WHERE k.UserId = @UserId AND k.IsDeleted = 0;

        SELECT rm.UserId, rm.RoleId, r.Name AS RoleName
        FROM RoleMembers rm JOIN Roles r ON r.Id = rm.RoleId
        WHERE rm.UserId = @UserId ORDER BY r.Name;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_ApiUser_Delete
    @UserId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-06
-- Description: Soft-deletes an API user and their key. The key row is kept
--              with IsDeleted=1 for audit trail. Role memberships are removed.
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @DisplayName NVARCHAR(200);
    SELECT @DisplayName = DisplayName FROM Users WHERE Id = @UserId AND UserType = 'api';

    IF @DisplayName IS NULL
        THROW 50001, 'API user not found.', 1;

    BEGIN TRANSACTION;
    BEGIN TRY
        -- Soft-delete the user
        UPDATE Users SET IsDeleted = 1, IsActive = 0, ModifiedAt = GETUTCDATE()
        WHERE Id = @UserId;

        -- Soft-delete all their keys (preserves audit trail)
        UPDATE ApiKeys SET IsDeleted = 1, IsActive = 0, ModifiedAt = GETUTCDATE()
        WHERE UserId = @UserId;

        -- Remove role memberships
        DELETE FROM RoleMembers WHERE UserId = @UserId;

        COMMIT TRANSACTION;
        SELECT @DisplayName AS DisplayName;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_ApiKey_GetByHash
    @KeyHash NVARCHAR(500)
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-06
-- Description: Auth lookup for API key authentication. Finds the key by hash
--              (WHERE IsDeleted=0), returns user details in result set 1 and
--              role memberships in result set 2. Called on every API request.
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    -- Result set 1: key + user details for auth validation
    SELECT k.Id AS KeyId, k.UserId, k.IsActive, k.ExpiresAt,
           u.Email, u.DisplayName, u.IsActive AS UserIsActive, u.UserType
    FROM ApiKeys k
    JOIN Users u ON u.Id = k.UserId
    WHERE k.KeyHash = @KeyHash AND k.IsDeleted = 0 AND u.IsDeleted = 0;

    -- Result set 2: role memberships for permission resolution
    SELECT rm.UserId, rm.RoleId, r.Name AS RoleName, r.IsAdmin, r.CanApprove
    FROM RoleMembers rm
    JOIN Roles r ON r.Id = rm.RoleId
    JOIN ApiKeys k ON k.UserId = rm.UserId
    WHERE k.KeyHash = @KeyHash AND k.IsDeleted = 0;
END;
GO

CREATE OR ALTER PROCEDURE usp_ApiKey_Regenerate
    @UserId     INT,
    @KeyName    NVARCHAR(200),
    @NewHash    NVARCHAR(500),
    @NewPrefix  NVARCHAR(12),
    @ExpiresAt  DATETIME2 = NULL
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-06
-- Description: Soft-deletes the existing key for the API user, then inserts a
--              new key row. Returns the new key info and old key prefix for audit.
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @OldPrefix NVARCHAR(12);
    SELECT @OldPrefix = KeyPrefix FROM ApiKeys WHERE UserId = @UserId AND IsDeleted = 0;

    IF @OldPrefix IS NULL
        THROW 50001, 'No active key found for this API user.', 1;

    BEGIN TRANSACTION;
    BEGIN TRY
        -- Soft-delete the old key
        UPDATE ApiKeys SET IsDeleted = 1, IsActive = 0, ModifiedAt = GETUTCDATE()
        WHERE UserId = @UserId AND IsDeleted = 0;

        -- Insert new key
        INSERT INTO ApiKeys (UserId, Name, KeyHash, KeyPrefix, IsActive, ExpiresAt)
        VALUES (@UserId, @KeyName, @NewHash, @NewPrefix, 1, @ExpiresAt);
        DECLARE @NewKeyId INT = SCOPE_IDENTITY();

        COMMIT TRANSACTION;

        SELECT @OldPrefix AS OldKeyPrefix,
               k.Id, k.KeyPrefix AS NewKeyPrefix, k.CreatedAt
        FROM ApiKeys k WHERE k.Id = @NewKeyId;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_ApiKey_RecordUsage
    @KeyId     INT,
    @Operation CHAR(1) = 'R'  -- R=Read, C=Create, U=Update, D=Delete
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-06
-- Modified:    2026-03-08
-- Description: Increments CallCount (total) and the matching CRUD operation
--              counter, then sets LastUsedAt. Called fire-and-forget after
--              each successful API key auth.
-- Parameters:  @Operation CHAR(1) — R=Read, C=Create, U=Update, D=Delete
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE ApiKeys
    SET CallCount   = CallCount + 1,
        ReadCount   = ReadCount   + CASE WHEN @Operation = 'R' THEN 1 ELSE 0 END,
        CreateCount = CreateCount + CASE WHEN @Operation = 'C' THEN 1 ELSE 0 END,
        UpdateCount = UpdateCount + CASE WHEN @Operation = 'U' THEN 1 ELSE 0 END,
        DeleteCount = DeleteCount + CASE WHEN @Operation = 'D' THEN 1 ELSE 0 END,
        LastUsedAt  = GETUTCDATE(),
        ModifiedAt  = GETUTCDATE()
    WHERE Id = @KeyId AND IsDeleted = 0;
END;
GO

-- ============================================
-- MIGRATIONS
-- ============================================
-- This section contains incremental schema changes for existing installations.
-- Each block is idempotent (IF NOT EXISTS guard) and tagged with the version
-- that introduced it. New installations get these columns in the CREATE TABLE
-- above; this section upgrades older databases.
--
-- Add new migrations at the bottom, always with a version comment.
-- ============================================

-- v0.2026.3.6 — Initial release (base schema)
-- No migrations needed — this is the baseline version.
--
-- EVERY schema change from here on needs an entry:
--   new column -> IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('T')
--                                  AND name = 'C') ALTER TABLE T ADD C ...;
--   new table  -> guard the CREATE TABLE itself with IF NOT EXISTS (SELECT * FROM sys.tables ...)
--   new index  -> guard the CREATE INDEX with IF NOT EXISTS (SELECT * FROM sys.indexes ...)
-- Bare CREATE TABLE/INDEX batches are filtered out on upgrade and never reach an
-- existing customer database. Verify with: node scripts/verify-upgrade-matrix.js

GO

-- ============================================
-- SCHEMA VERSION TRACKING
-- ============================================

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'SchemaVersion')
BEGIN
    CREATE TABLE SchemaVersion (
        Version NVARCHAR(20) NOT NULL,
        UpdatedAt DATETIME2 NOT NULL DEFAULT GETUTCDATE()
    );
    INSERT INTO SchemaVersion (Version) VALUES ('1.2026.7.31');
END
ELSE
BEGIN
    UPDATE SchemaVersion SET Version = '1.2026.7.31', UpdatedAt = GETUTCDATE();
END
GO

-- ============================================
-- USER HIDDEN ENTITIES (per-user sidebar visibility)
-- ============================================
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'UserHiddenEntities')
CREATE TABLE UserHiddenEntities (
    Id          INT IDENTITY(1,1) CONSTRAINT PK_UserHiddenEntities PRIMARY KEY,
    UserId      INT NOT NULL REFERENCES Users(Id) ON DELETE CASCADE,
    EntityId    INT NOT NULL REFERENCES Entities(Id) ON DELETE CASCADE,
    CreatedAt   DATETIME2 NOT NULL DEFAULT GETUTCDATE(),

    CONSTRAINT UQ_UserHiddenEntities UNIQUE (UserId, EntityId)
);
GO

CREATE OR ALTER PROCEDURE usp_UserHiddenEntities_GetByUser
    @UserId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-07
-- Description: Returns the list of EntityIds hidden by the given user.
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    SELECT EntityId FROM UserHiddenEntities
    WHERE UserId = @UserId
    ORDER BY CreatedAt;
END;
GO

CREATE OR ALTER PROCEDURE usp_UserHiddenEntities_Toggle
    @UserId INT,
    @EntityId INT
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-07
-- Description: Toggles a user's hidden state for an entity: removes it if
--              already hidden, adds it if not. Returns Status ('hidden' or 'shown').
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @OwnTransaction BIT = 0;
    IF @@TRANCOUNT = 0 BEGIN BEGIN TRANSACTION; SET @OwnTransaction = 1; END

    BEGIN TRY
        IF EXISTS (SELECT 1 FROM UserHiddenEntities WHERE UserId = @UserId AND EntityId = @EntityId)
        BEGIN
            DELETE FROM UserHiddenEntities WHERE UserId = @UserId AND EntityId = @EntityId;
            IF @OwnTransaction = 1 COMMIT TRANSACTION;
            SELECT 'shown' AS Status;
        END
        ELSE
        BEGIN
            INSERT INTO UserHiddenEntities (UserId, EntityId) VALUES (@UserId, @EntityId);
            IF @OwnTransaction = 1 COMMIT TRANSACTION;
            SELECT 'hidden' AS Status;
        END
    END TRY
    BEGIN CATCH
        IF @OwnTransaction = 1 AND @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;
GO

CREATE OR ALTER PROCEDURE usp_Dashboard_GetUserActivity
-- ============================================
-- Creator:     Primentra.com
-- Created:     2026-03-08
-- Description: Returns user activity summary for the dashboard
--              Active Users widget. First result set: all non-deleted,
--              non-system, non-api users with their LastLoginAt.
--              Second result set: summary counts (active last 7/30/90
--              days, total active, total inactive).
--
-- Change History:
--   v1.0  2026-03-08  Initial version
-- ============================================
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Now DATETIME2 = GETUTCDATE();

    -- Result set 1: User list
    SELECT
        u.Id,
        u.DisplayName,
        u.LastLoginAt,
        u.IsActive
    FROM Users u
    WHERE u.IsDeleted = 0
      AND u.IsSystem = 0
      AND u.UserType = 'standard'
    ORDER BY u.DisplayName;

    -- Result set 2: Summary counts
    SELECT
        SUM(CASE WHEN u.IsActive = 1 AND u.LastLoginAt >= DATEADD(DAY, -7, @Now) THEN 1 ELSE 0 END)  AS ActiveLastWeek,
        SUM(CASE WHEN u.IsActive = 1 AND u.LastLoginAt >= DATEADD(DAY, -30, @Now) THEN 1 ELSE 0 END) AS ActiveLastMonth,
        SUM(CASE WHEN u.IsActive = 1 AND u.LastLoginAt >= DATEADD(DAY, -90, @Now) THEN 1 ELSE 0 END) AS ActiveLastQuarter,
        SUM(CASE WHEN u.IsActive = 1 THEN 1 ELSE 0 END)  AS TotalActive,
        SUM(CASE WHEN u.IsActive = 0 THEN 1 ELSE 0 END)  AS TotalInactive
    FROM Users u
    WHERE u.IsDeleted = 0
      AND u.IsSystem = 0
      AND u.UserType = 'standard';
END;
GO

-- ============================================
-- ENSURE SYSTEM USER (Id = 5)
-- Used by staging batch processing and MDS migration wizard.
-- ============================================
EXEC usp_User_CreateSystem @Email = N'system@mds-import', @DisplayName = N'System User';
GO


PRINT 'Primentra database setup complete.';
GO
