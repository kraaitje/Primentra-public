import { Router } from 'express';
import { execute, query, sql } from '../db.js';
import { asyncHandler, requireFields, requireId, optionalInt } from '../middleware/validate.js';
import { requireAdmin } from '../middleware/authzMiddleware.js';
import { pivotRowsForAudit } from './data.js';
import logger from '../logger.js';

const router = Router();

const VALID_DATE_FORMATS = ['DD/MM/YYYY', 'MM/DD/YYYY', 'YYYY-MM-DD', 'DD MMM YYYY'];

// Helper: map DB row to entity object
function mapEntity(row) {
  return {
    id: row.Id,
    modelId: row.ModelId,
    modelName: row.ModelName || '',
    name: row.Name,
    description: row.Description,
    tableName: row.TableName,
    sortOrder: row.SortOrder,
    isActive: row.IsActive,
    requiresApproval: row.RequiresApproval,
    approverCanApproveOwn: row.ApproverCanApproveOwn,
    approvalStrategy: row.ApprovalStrategy,
    sharedAcrossModels: row.SharedAcrossModels,
    autoGenerateCode: row.AutoGenerateCode,
    hasStaging: !!row.HasStaging,
    createdDate: row.CreatedAt?.toISOString().slice(0, 10),
    modifiedDate: row.ModifiedAt?.toISOString().slice(0, 10),
  };
}

function mapAttribute(row) {
  return {
    id: row.Id,
    entityId: row.EntityId,
    displayName: row.DisplayName,
    name: row.Name,
    dataType: row.DataType,
    maxLength: row.MaxLength,
    isRequired: row.IsRequired,
    isCode: row.IsCode,
    isName: row.IsName,
    isHidden: !!row.IsHidden,
    isSystemDate: !!row.IsSystemDate,
    sortOrder: row.SortOrder,
    domainEntityId: row.DomainEntityId,
    domainParentAttributeId: row.DomainParentAttributeId ?? null,
    dateFormat: row.DateFormat || null,
    booleanDisplayFormat: row.BooleanDisplayFormat || null,
    description: row.Description || null,
    decimalPlaces: row.DecimalPlaces != null ? row.DecimalPlaces : null,
    allowNegative: row.AllowNegative != null ? !!row.AllowNegative : null,
    createdAt: row.CreatedAt?.toISOString() || null,
    modifiedAt: row.ModifiedAt?.toISOString() || null,
  };
}

// PUT /api/entities/reorder — Reorder entities within a model
// (must be before /:id to avoid matching "reorder" as an id)
router.put('/reorder', requireAdmin, asyncHandler(async (req, res) => {
  const { order } = req.body;
  if (!Array.isArray(order)) {
    return res.status(400).json({ success: false, message: 'order array required' });
  }

  await execute('usp_Entity_Reorder', { OrderJson: JSON.stringify(order) });
  res.json({ success: true });
}));

// GET /api/entities/attributes/:id/datatype-preview — Preview impact of datatype change
router.get('/attributes/:id/datatype-preview', asyncHandler(async (req, res) => {
  const id = requireId(req.params);
  const { newType } = req.query;
  if (!newType) return res.status(400).json({ success: false, message: 'newType query parameter required' });

  const result = await execute('usp_Attribute_DataTypePreview', {
    Id: id,
    NewDataType: String(newType),
  });

  const row = result.recordset[0];
  if (row.Error) return res.status(404).json({ success: false, message: row.Error });

  res.json({
    totalRows: row.TotalRows,
    convertibleCount: row.ConvertibleCount,
    willClearCount: row.WillClearCount,
    attributeName: row.AttributeName,
    oldDataType: row.OldDataType,
  });
}));

// PUT /api/entities/attributes/:id/change-datatype — Change datatype with conversion/clear
router.put('/attributes/:id/change-datatype', requireAdmin, asyncHandler(async (req, res) => {
  const id = requireId(req.params);
  requireFields(req.body, ['newDataType', 'action']);
  const { newDataType, action } = req.body;

  if (!['convert', 'clear'].includes(action))
    return res.status(400).json({ success: false, message: "action must be 'convert' or 'clear'" });

  const userId = req.user?.id || null;
  const result = await execute('usp_Attribute_ChangeDataType', {
    Id: id,
    NewDataType: String(newDataType),
    Action: String(action),
    UserId: userId,
  });

  // The LAST recordset, not the first: usp_Attribute_ChangeDataType calls usp_AuditLog_Write
  // on its way out, and that procedure ends with `SELECT SCOPE_IDENTITY() AS Id`, so the audit
  // row arrives ahead of the result. Reading recordset[0] returned {Id} — every count came back
  // undefined, and `row.Error` was undefined too, so a failed change reported success.
  const row = result.recordsets[result.recordsets.length - 1][0];
  if (row.Error) return res.status(500).json({ success: false, message: row.Error });

  res.json({
    success: true,
    totalAffected: row.TotalAffected,
    converted: row.Converted,
    cleared: row.Cleared,
  });
}));

// PUT /api/entities/attributes/:id — Update attribute
// (must be before /:id to avoid matching "attributes" as an id)
router.put('/attributes/:id', requireAdmin, asyncHandler(async (req, res) => {
  const id = requireId(req.params);
  const attr = req.body;

  if (attr.dateFormat != null && !VALID_DATE_FORMATS.includes(attr.dateFormat))
    return res.status(400).json({ success: false, message: `Invalid dateFormat. Allowed: ${VALID_DATE_FORMATS.join(', ')}` });

  const result = await execute('usp_Attribute_Update', {
    Id: id,
    DisplayName: attr.displayName ? String(attr.displayName) : null,
    Name: attr.name ? String(attr.name) : null,
    DataType: attr.dataType ? String(attr.dataType) : null,
    MaxLength: attr.maxLength !== undefined ? attr.maxLength : null,
    IsRequired: attr.isRequired !== undefined ? (attr.isRequired ? 1 : 0) : null,
    IsCode: attr.isCode !== undefined ? (attr.isCode ? 1 : 0) : null,
    IsName: attr.isName !== undefined ? (attr.isName ? 1 : 0) : null,
    SortOrder: attr.sortOrder !== undefined ? attr.sortOrder : null,
    DomainEntityId: attr.domainEntityId !== undefined ? attr.domainEntityId : null,
    DomainParentAttributeId: attr.domainParentAttributeId !== undefined ? attr.domainParentAttributeId : null,
    DateFormat: attr.dateFormat !== undefined ? (attr.dateFormat ? String(attr.dateFormat) : null) : null,
    BooleanDisplayFormat: attr.booleanDisplayFormat !== undefined ? (attr.booleanDisplayFormat ? String(attr.booleanDisplayFormat) : null) : null,
    Description: attr.description !== undefined ? (attr.description ? String(attr.description) : null) : null,
    DecimalPlaces: attr.decimalPlaces != null ? parseInt(attr.decimalPlaces, 10) : null,
    AllowNegative: attr.allowNegative != null ? (attr.allowNegative ? 1 : 0) : null,
  });

  if (result.recordset.length === 0) {
    return res.status(404).json({ success: false, message: 'Attribute not found' });
  }

  res.json(mapAttribute(result.recordset[0]));
}));

// DELETE /api/entities/attributes/:id
router.delete('/attributes/:id', requireAdmin, asyncHandler(async (req, res) => {
  const id = requireId(req.params);
  const result = await execute('usp_Attribute_Delete', { Id: id });
  res.json({ success: true, deleted: (result.recordset[0]?.Deleted || 0) > 0 });
}));

// GET /api/entities — All entities (optionally filtered by modelId)
router.get('/', asyncHandler(async (req, res) => {
  const modelId = optionalInt(req.query.modelId);

  const result = await execute('usp_Entity_GetAll', { ModelId: modelId || null });
  const entities = result.recordsets[0].map(mapEntity);

  // Build attributes lookup from second result set
  const attrsByEntity = {};
  for (const a of result.recordsets[1]) {
    const eid = a.EntityId;
    if (!attrsByEntity[eid]) attrsByEntity[eid] = [];
    attrsByEntity[eid].push(mapAttribute(a));
  }

  // Build derived columns lookup from third result set.
  //
  // AttributePath is NVARCHAR(MAX) with no CHECK constraint and usp_Model_ImportDerivedColumns
  // writes whatever scalar JSON_VALUE yields, so a malformed path is possible. This is the call
  // that loads the whole model/entity tree — one bad row must not throw the entire application
  // to a load error. Skip the column instead: a missing derived column is a visible, contained
  // fault; an empty app is not.
  const dcByEntity = {};
  for (const r of (result.recordsets[2] || [])) {
    let attributePath;
    try {
      attributePath = JSON.parse(r.AttributePath);
    } catch {
      logger.warn(`Derived column #${r.Id} on entity ${r.EntityId} has an unparseable AttributePath — skipped`, { category: 'data' });
      continue;
    }
    const eid = r.EntityId;
    if (!dcByEntity[eid]) dcByEntity[eid] = [];
    dcByEntity[eid].push({
      id: r.Id,
      entityId: r.EntityId,
      displayName: r.DisplayName,
      attributePath,
      sortOrder: r.SortOrder,
      createdAt: r.CreatedAt?.toISOString() || null,
    });
  }

  for (const e of entities) {
    e.attributes = attrsByEntity[e.id] || [];
    e.derivedColumns = dcByEntity[e.id] || [];
  }

  res.json(entities);
}));

const VALID_STRATEGIES = ['any', 'all'];

// GET /api/entities/:id/approvers — Get approvers for an entity
router.get('/:id/approvers', requireAdmin, asyncHandler(async (req, res) => {
  const id = requireId(req.params);
  const result = await execute('usp_EntityApprover_GetByEntity', { EntityId: id });
  res.json(result.recordset.map(r => ({ userId: r.UserId, displayName: r.DisplayName, email: r.Email, receivesEmail: !!r.ReceivesEmail })));
}));

// PUT /api/entities/:id/approvers — Bulk-replace approvers for an entity
router.put('/:id/approvers', requireAdmin, asyncHandler(async (req, res) => {
  const id = requireId(req.params);
  const { approvers } = req.body;
  await execute('usp_EntityApprover_Set', {
    EntityId: id,
    ApproversJson: JSON.stringify(Array.isArray(approvers) ? approvers : []),
  });
  res.json({ success: true });
}));

// GET /api/entities/:id/derived-columns
router.get('/:id/derived-columns', asyncHandler(async (req, res) => {
  const id = requireId(req.params);
  const result = await execute('usp_EntityDerivedColumns_Get', { EntityId: id });
  res.json(result.recordset.map(r => ({
    id: r.Id,
    entityId: r.EntityId,
    displayName: r.DisplayName,
    attributePath: JSON.parse(r.AttributePath),
    sortOrder: r.SortOrder,
    createdAt: r.CreatedAt?.toISOString() || null,
  })));
}));

// POST /api/entities/:id/derived-columns
router.post('/:id/derived-columns', requireAdmin, asyncHandler(async (req, res) => {
  const id = requireId(req.params);
  requireFields(req.body, ['displayName', 'attributePath']);
  const { displayName, attributePath, sortOrder, colId } = req.body;
  if (!Array.isArray(attributePath) || attributePath.length < 1)
    return res.status(400).json({ success: false, message: 'attributePath must be a non-empty array of attribute IDs' });

  const result = await execute('usp_EntityDerivedColumns_Save', {
    EntityId: id,
    Id: colId || null,
    DisplayName: String(displayName),
    AttributePath: JSON.stringify(attributePath),
    SortOrder: sortOrder || 0,
  });
  const r = result.recordset[0];
  res.json({
    id: r.Id,
    entityId: r.EntityId,
    displayName: r.DisplayName,
    attributePath: JSON.parse(r.AttributePath),
    sortOrder: r.SortOrder,
    createdAt: r.CreatedAt?.toISOString() || null,
  });
}));

// DELETE /api/entities/:id/derived-columns/:colId
router.delete('/:id/derived-columns/:colId', requireAdmin, asyncHandler(async (req, res) => {
  const id = requireId(req.params);
  const colId = parseInt(req.params.colId, 10);
  if (isNaN(colId)) return res.status(400).json({ success: false, message: 'Invalid colId' });
  await execute('usp_EntityDerivedColumns_Delete', { Id: colId, EntityId: id });
  res.json({ success: true });
}));

// POST /api/entities/:id/clone — Clone an entity with streaming progress
// Uses NDJSON (newline-delimited JSON) to stream progress events to the frontend.
// Phase 1: Clone structure (instant). Phase 2: Clone data in batches with % progress.
router.post('/:id/clone', requireAdmin, async (req, res) => {
  let id;
  try {
    id = requireId(req.params);
    requireFields(req.body, ['name']);
  } catch (err) {
    return res.status(400).json({ success: false, message: err.message });
  }
  const { name, cloneData = true, clonePermissions = false } = req.body;
  const userId = req.user?.id || null;

  res.writeHead(200, {
    'Content-Type': 'application/x-ndjson',
    'Cache-Control': 'no-cache',
    'X-Accel-Buffering': 'no',
  });

  const send = (data) => { try { res.write(JSON.stringify(data) + '\n'); } catch { /* connection closed */ } };

  try {
    // Phase 1: Clone structure (no data — always fast)
    send({ phase: 'structure', progress: 0, message: 'Cloning entity structure...' });

    const structResult = await execute('usp_Entity_Clone', {
      SourceEntityId: id,
      NewName: String(name),
      CloneData: 0,
      ClonePermissions: clonePermissions ? 1 : 0,
      UserId: userId,
    });

    const entity = mapEntity(structResult.recordsets[0][0]);
    entity.attributes = structResult.recordsets[1].map(mapAttribute);
    const permsCopied = structResult.recordsets[2]?.[0]?.PermissionsCopied ?? 0;

    send({ phase: 'structure', progress: 100, message: 'Structure cloned' });

    // Phase 2: Clone data in batches
    let totalRowsCopied = 0;

    if (cloneData) {
      const countResult = await query(
        'SELECT COUNT(*) AS Total FROM EntityRows WHERE EntityId = @Id',
        { Id: id }
      );
      const totalRows = countResult.recordset[0].Total;

      if (totalRows > 0) {
        const BATCH_SIZE = 5000;
        let lastSourceRowId = 0;

        send({ phase: 'data', progress: 0, copied: 0, total: totalRows });

        while (totalRowsCopied < totalRows) {
          const batchResult = await execute('usp_Entity_CloneDataBatch', {
            SourceEntityId: id,
            NewEntityId: entity.id,
            LastSourceRowId: lastSourceRowId,
            BatchSize: BATCH_SIZE,
            UserId: userId,
          }, { timeout: 120000 });

          const batch = batchResult.recordset[0];
          totalRowsCopied += batch.RowsCopied;
          const newLastId = batch.LastSourceRowId;

          // Safety: break if SP didn't advance cursor (prevents infinite loop)
          if (newLastId <= lastSourceRowId && batch.RowsCopied === 0) break;
          lastSourceRowId = newLastId;

          const pct = Math.min(99, Math.round((totalRowsCopied / totalRows) * 100));
          send({ phase: 'data', progress: pct, copied: totalRowsCopied, total: totalRows });

          if (batch.RowsCopied < BATCH_SIZE) break;
        }

        // Fix self-referencing domain values
        await execute('usp_Entity_CloneFixDomainRefs', {
          SourceEntityId: id,
          NewEntityId: entity.id,
        }, { timeout: 120000 });

        send({ phase: 'data', progress: 100, copied: totalRowsCopied, total: totalRows });
      }
    }

    // Write audit log with actual clone results (cloneData/rowsCopied reflect reality)
    const auditMeta = await query(
      `SELECT src.Name AS SourceName, m.Name AS ModelName
       FROM Entities nw
       INNER JOIN Models m ON m.Id = nw.ModelId
       LEFT JOIN Entities src ON src.Id = @SourceId
       WHERE nw.Id = @NewId`,
      { NewId: entity.id, SourceId: id }
    );
    const meta = auditMeta.recordset[0] || {};
    await execute('usp_AuditLog_Write', {
      EntityId: entity.id,
      EntityName: String(name),
      ModelName: meta.ModelName || '',
      Action: 'create',
      RecordCount: totalRowsCopied,
      UserId: userId,
      Details: JSON.stringify({
        clonedFrom: id,
        clonedFromName: meta.SourceName || null,
        cloneData: !!cloneData,
        clonePermissions: !!clonePermissions,
        rowsCopied: totalRowsCopied,
        permissionsCopied: permsCopied,
      }),
    });

    send({ phase: 'done', entity, rowsCopied: totalRowsCopied, permissionsCopied: permsCopied });
    res.end();

  } catch (err) {
    let message = err.message || 'Clone failed';
    if (err.number === 2627 || err.number === 2601 || /UQ_Entities_ModelId_Name/.test(message)) {
      message = `An entity named "${name}" already exists in this model. Please choose a different name.`;
    }
    send({ phase: 'error', message });
    res.end();
  }
});

// GET /api/entities/:id — Single entity with attributes
router.get('/:id', asyncHandler(async (req, res) => {
  const id = requireId(req.params);

  const [entityResult, dcResult] = await Promise.all([
    execute('usp_Entity_GetById', { Id: id }),
    execute('usp_EntityDerivedColumns_Get', { EntityId: id }),
  ]);
  if (entityResult.recordsets[0].length === 0) {
    return res.status(404).json({ success: false, message: 'Entity not found' });
  }

  const entity = mapEntity(entityResult.recordsets[0][0]);
  entity.attributes = entityResult.recordsets[1].map(mapAttribute);
  entity.derivedColumns = dcResult.recordset.map(r => ({
    id: r.Id,
    entityId: r.EntityId,
    displayName: r.DisplayName,
    attributePath: JSON.parse(r.AttributePath),
    sortOrder: r.SortOrder,
    createdAt: r.CreatedAt?.toISOString() || null,
  }));
  res.json(entity);
}));

// POST /api/entities — Create entity (with optional attributes)
router.post('/', requireAdmin, asyncHandler(async (req, res) => {
  requireFields(req.body, ['modelId', 'name']);
  const { modelId, name, description, tableName, sortOrder, isActive, requiresApproval, sharedAcrossModels, autoGenerateCode, attributes, createdAt, modifiedAt } = req.body;

  // Strip frontend-generated Date.now() IDs — SP ignores attribute IDs on create
  const sanitizedAttrs = Array.isArray(attributes) && attributes.length > 0
    ? attributes.map(a => ({ ...a, id: null }))
    : null;

  const result = await execute('usp_Entity_Create', {
    ModelId: modelId,
    Name: String(name),
    Description: description != null ? String(description) : null,
    TableName: tableName ? String(tableName) : null,
    SortOrder: sortOrder || 0,
    IsActive: isActive !== false ? 1 : 0,
    RequiresApproval: requiresApproval ? 1 : 0,
    SharedAcrossModels: sharedAcrossModels ? 1 : 0,
    AutoGenerateCode: autoGenerateCode ? 1 : 0,
    AttributesJson: sanitizedAttrs ? JSON.stringify(sanitizedAttrs) : null,
    CreatedAt: createdAt || null,
    ModifiedAt: modifiedAt || null,
  });

  const entity = mapEntity(result.recordsets[0][0]);
  entity.attributes = result.recordsets[1].map(mapAttribute);
  res.json(entity);
}));

// PUT /api/entities/:id — Update entity (with optional attribute sync)
router.put('/:id', requireAdmin, asyncHandler(async (req, res) => {
  const id = requireId(req.params);
  const { name, description, tableName, sortOrder, isActive, requiresApproval, approverCanApproveOwn, approvalStrategy, sharedAcrossModels, autoGenerateCode, attributes } = req.body;

  if (approvalStrategy !== undefined && approvalStrategy !== null && !VALID_STRATEGIES.includes(approvalStrategy))
    return res.status(400).json({ success: false, message: "approvalStrategy must be 'any' or 'all'" });

  // Sanitize attribute IDs: frontend uses Date.now() for new attributes which overflows SQL INT.
  // Also clamp domainParentAttributeId — it too may carry a Date.now() temp ID before the parent
  // attr is saved to the DB, which would overflow the INT column.
  const sanitizedAttrs = Array.isArray(attributes)
    ? attributes.map(a => ({
        ...a,
        id: (a.id && a.id <= 2147483647) ? a.id : null,
        domainParentAttributeId: (a.domainParentAttributeId && a.domainParentAttributeId <= 2147483647) ? a.domainParentAttributeId : null,
      }))
    : null;

  const result = await execute('usp_Entity_Update', {
    Id: id,
    Name: name ? String(name) : null,
    Description: description != null ? String(description) : null,
    TableName: tableName ? String(tableName) : null,
    SortOrder: sortOrder !== undefined ? sortOrder : null,
    IsActive: isActive !== undefined ? (isActive ? 1 : 0) : null,
    RequiresApproval: requiresApproval !== undefined ? (requiresApproval ? 1 : 0) : null,
    ApproverCanApproveOwn: approverCanApproveOwn !== undefined ? (approverCanApproveOwn ? 1 : 0) : null,
    ApprovalStrategy: approvalStrategy ? String(approvalStrategy) : null,
    SharedAcrossModels: sharedAcrossModels !== undefined ? (sharedAcrossModels ? 1 : 0) : null,
    AutoGenerateCode: autoGenerateCode !== undefined ? (autoGenerateCode ? 1 : 0) : null,
    AttributesJson: sanitizedAttrs ? JSON.stringify(sanitizedAttrs) : null,
  });

  if (!result.recordsets[0]?.length)
    return res.status(404).json({ success: false, message: 'Entity not found' });
  const entity = mapEntity(result.recordsets[0][0]);
  entity.attributes = result.recordsets[1].map(mapAttribute);

  // Attach derived columns so adminEntities stays complete after save
  const dcResult = await execute('usp_EntityDerivedColumns_Get', { EntityId: id });
  entity.derivedColumns = dcResult.recordset.map(r => ({
    id: r.Id,
    entityId: r.EntityId,
    displayName: r.DisplayName,
    attributePath: JSON.parse(r.AttributePath),
    sortOrder: r.SortOrder,
    createdAt: r.CreatedAt?.toISOString() || null,
  }));

  // Auto-rebuild staging table if staging is enabled (silent — never fails the save)
  try { await execute('usp_Staging_RebuildTable', { EntityId: id }); } catch { /* staging not enabled */ }

  res.json(entity);
}));

// GET /api/entities/:id/domain-usage — Check if entity is used as a domain source
router.get('/:id/domain-usage', asyncHandler(async (req, res) => {
  const id = requireId(req.params);
  const result = await execute('usp_Entity_CheckDomainUsage', { EntityId: id });
  res.json(result.recordset.map(r => ({
    attributeId: r.AttributeId,
    attributeName: r.AttributeName,
    usedInEntityId: r.UsedInEntityId,
    usedInEntityName: r.UsedInEntityName,
    usageType: r.UsageType,
    derivedColumnId: r.DerivedColumnId,
    derivedColumnName: r.DerivedColumnName,
  })));
}));

// GET /api/entities/:id/row-count — Quick row count for the entity
router.get('/:id/row-count', asyncHandler(async (req, res) => {
  const id = requireId(req.params);
  const result = await query('SELECT COUNT(*) AS Total FROM EntityRows WHERE EntityId = @Id', { Id: id });
  res.json({ count: result.recordset[0].Total });
}));

// DELETE /api/entities/:id — Delete entity with streaming progress
// Uses NDJSON (newline-delimited JSON) to stream progress events to the frontend.
// Phase 1: Batch-delete data rows with progress. Phase 2: Metadata cleanup.
router.delete('/:id', requireAdmin, async (req, res) => {
  let id;
  try { id = requireId(req.params); } catch (err) {
    return res.status(400).json({ success: false, message: err.message });
  }
  const clearDomain = req.body?.clearDomain ? 1 : 0;
  const saveSnapshot = req.body?.saveSnapshot !== false; // default true

  res.writeHead(200, {
    'Content-Type': 'application/x-ndjson',
    'Cache-Control': 'no-cache',
    'X-Accel-Buffering': 'no',
  });

  const send = (data) => { try { res.write(JSON.stringify(data) + '\n'); } catch { /* connection closed */ } };

  try {
    // Get total row count for progress calculation (fast partition stats)
    const countResult = await query(
      `SELECT
         (SELECT COUNT(*) FROM EntityRows WHERE EntityId = @Id) AS TotalRows,
         (SELECT COUNT(*) FROM EntityValues ev INNER JOIN EntityRows er ON er.Id = ev.EntityRowId WHERE er.EntityId = @Id) AS TotalValues`,
      { Id: id }
    );
    const totalRows = countResult.recordset[0].TotalRows;
    const totalValues = countResult.recordset[0].TotalValues;
    const grandTotal = totalValues + totalRows; // approvals are typically tiny, skip in count

    // Optionally snapshot all rows before deleting for audit trail
    if (saveSnapshot && totalRows > 0) {
      send({ phase: 'snapshot', progress: 0, message: 'Creating data snapshot for audit trail...' });
      const snapshotResult = await execute('usp_Data_GetAllRowsSnapshot', { EntityId: id }, { timeout: 120000 });
      const entitySnapshot = pivotRowsForAudit(snapshotResult.recordset);
      // Get entity meta for audit log
      const metaResult = await execute('usp_Data_GetEntityMeta', { EntityId: id });
      const entInfo = metaResult.recordset[0] || { EntityName: 'Unknown', ModelName: 'Unknown' };
      // Write snapshot to audit log before deletion begins
      await execute('usp_AuditLog_Write', {
        EntityId: { type: sql.Int, value: id },
        EntityName: { type: sql.NVarChar(200), value: entInfo.EntityName },
        ModelName: { type: sql.NVarChar(200), value: entInfo.ModelName },
        Action: { type: sql.NVarChar(20), value: 'delete_entity' },
        RecordCount: { type: sql.Int, value: totalRows },
        UserId: { type: sql.Int, value: req.user?.id || null },
        Comment: { type: sql.NVarChar(1000), value: `Entity "${entInfo.EntityName}" deleted with ${totalRows} rows (snapshot saved)` },
        Details: { type: sql.NVarChar(sql.MAX), value: entitySnapshot.length > 0 ? JSON.stringify(entitySnapshot) : null },
      });
      send({ phase: 'snapshot', progress: 1, message: `Snapshot saved (${totalRows} rows)` });
    }

    send({ phase: 'start', totalRows, totalValues, grandTotal });

    // Phase 1: Batch-delete data rows with progress
    const BATCH_SIZE = 50000;
    const MAX_BATCHES = 2000;
    let batches = 0;
    let deletedTotal = 0;

    while (batches < MAX_BATCHES) {
      const batch = await execute('usp_Entity_DeleteDataBatch', { Id: id, BatchSize: BATCH_SIZE }, { timeout: 60000 });
      const row = batch.recordset?.[0];
      if (!row || row.BatchDeleted === 0) break;

      deletedTotal += row.BatchDeleted;
      const pct = grandTotal > 0 ? Math.min(99, Math.round((deletedTotal / grandTotal) * 100)) : 0;
      send({ phase: row.Phase, progress: pct, deleted: deletedTotal, total: grandTotal });
      batches++;
    }

    // Phase 2: Metadata cleanup + final delete
    send({ phase: 'metadata', progress: 99, message: 'Cleaning up metadata...' });
    const result = await execute('usp_Entity_Delete', { Id: id, ClearDomain: clearDomain, UserId: req.user?.id || null }, { timeout: 120000 });
    const deleted = (result.recordset[0]?.Deleted || 0) > 0;

    send({ phase: 'done', deleted, deletedTotal, totalRows, totalValues });
    res.end();

  } catch (err) {
    send({ phase: 'error', message: err.message || 'Delete failed' });
    res.end();
  }
});

// ==========================================
// ATTRIBUTES sub-routes (nested under /:id)
// ==========================================

// GET /api/entities/:id/attributes
router.get('/:id/attributes', asyncHandler(async (req, res) => {
  const id = requireId(req.params);
  const result = await execute('usp_Attribute_GetByEntity', { EntityId: id });
  res.json(result.recordset.map(mapAttribute));
}));

// POST /api/entities/:id/attributes — Add attribute
router.post('/:id/attributes', requireAdmin, asyncHandler(async (req, res) => {
  const entityId = requireId(req.params);
  requireFields(req.body, ['displayName']);
  const attr = req.body;

  if (attr.dateFormat != null && !VALID_DATE_FORMATS.includes(attr.dateFormat))
    return res.status(400).json({ success: false, message: `Invalid dateFormat. Allowed: ${VALID_DATE_FORMATS.join(', ')}` });

  const result = await execute('usp_Attribute_Create', {
    EntityId: entityId,
    DisplayName: String(attr.displayName),
    Name: attr.name ? String(attr.name) : null,
    DataType: attr.dataType ? String(attr.dataType) : 'Text',
    MaxLength: attr.maxLength || null,
    IsRequired: attr.isRequired ? 1 : 0,
    IsCode: attr.isCode ? 1 : 0,
    IsName: attr.isName ? 1 : 0,
    SortOrder: attr.sortOrder || 0,
    DomainEntityId: attr.domainEntityId || null,
    DomainParentAttributeId: attr.domainParentAttributeId || null,
    DateFormat: attr.dateFormat ? String(attr.dateFormat) : null,
    BooleanDisplayFormat: attr.booleanDisplayFormat ? String(attr.booleanDisplayFormat) : null,
    Description: attr.description ? String(attr.description) : null,
    DecimalPlaces: attr.decimalPlaces != null ? parseInt(attr.decimalPlaces, 10) : null,
    AllowNegative: attr.allowNegative != null ? (attr.allowNegative ? 1 : 0) : null,
  });

  res.json(mapAttribute(result.recordset[0]));
}));

export default router;
