PRIMENTRA v1.2026.8.7
=================

Primentra is an on-premise master data management platform for Windows.
It stores all data in your own SQL Server — no cloud dependency, no lock-in.

What's in this package
-----------------------
  server.js          Node.js application server (Express)
  server/            Server modules (routes, middleware, database layer)
  dist/              Built web frontend (served by the application server)
  node_modules/      Production Node.js dependencies
  nssm.exe           Service manager (used to run Primentra as a Windows Service)
  scripts\setup-db-and-user.sql   Creates the Primentra SQL Server database and login
  scripts\setup-database.sql      Creates the full database schema and stored procedures
  scripts/recover-admin.mjs  Emergency admin account recovery tool
  web.config         IIS + iisnode configuration (optional IIS setup only)
  INSTALL.txt        Step-by-step setup instructions — read this next
  README.txt         This file

How to get started
------------------
The installer (Primentra-Setup-v1.2026.8.7.exe) has already set up Node.js,
copied these files to your install folder, and started the Primentra service.

Open INSTALL.txt for the three remaining steps:
  1. Create the SQL Server database
  2. Configure the database connection in the app
  3. Create your administrator account

Access Primentra at:  http://localhost:3001  (or the port you chose)
On other machines:    http://YOUR-SERVER-IP:3001

Service management
------------------
Primentra runs as a Windows Service and starts automatically on boot.

  net start Primentra
  net stop Primentra
  sc query Primentra

Logs: logs\  (in the install folder)

Support
-------
  Website:   https://www.primentra.com
  Docs:      https://www.primentra.com/docs
  Support:   support@primentra.com
