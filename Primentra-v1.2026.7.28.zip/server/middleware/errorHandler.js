import logger from '../logger.js';

const SENSITIVE_KEYS = new Set(['password', 'oldPassword', 'newPassword', 'confirmPassword', 'token', 'apiKey', 'secret', 'hash']);

function redactBody(body) {
  if (!body || typeof body !== 'object') return body;
  return Object.fromEntries(
    Object.entries(body).map(([k, v]) => [k, SENSITIVE_KEYS.has(k) ? '[redacted]' : v])
  );
}

export function errorHandler(err, req, res, _next) {
  // Body-parser JSON parse failures (malformed request body)
  if (err.type === 'entity.parse.failed') {
    logger.warn('Malformed JSON in request body', {
      method: req.method,
      path: req.path,
      statusCode: 400,
      userId: req.user?.id || null,
    });
    return res.status(400).json({
      success: false,
      error: 'Invalid request. Please check for special characters and try again.',
    });
  }

  const statusCode = err.code === 'ELOGIN' || err.code === 'ESOCKET' ? 503 : (err.status || 500);

  logger.error(err.message, {
    method: req.method,
    path: req.path,
    statusCode,
    userId: req.user?.id || null,
    stack: err.stack,
    requestBody: statusCode >= 500 ? JSON.stringify(redactBody(req.body))?.slice(0, 2000) : null,
  });

  if (statusCode === 503) {
    return res.status(503).json({
      success: false,
      error: 'Database connection failed. Check server settings.',
      code: err.code,
    });
  }

  let clientError = 'An unexpected error occurred. Please try again.';
  if (statusCode >= 500) {
    clientError += ' Check logs/errorlog.txt for details.';
  } else {
    clientError = err.message || 'Request failed.';
  }

  res.status(statusCode).json({
    success: false,
    error: clientError,
  });
}
